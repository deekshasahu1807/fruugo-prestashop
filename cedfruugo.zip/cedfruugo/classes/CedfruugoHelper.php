<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

class CedfruugoHelper
{
    public function log($method = '', $type = '', $message = '', $response = '', $force_log = false)
    {
        if (Configuration::get('CEDFRUUGO_DEBUG_ENABLE') || $force_log == true) {
            $db = Db::getInstance();
            $db->insert(
                'fruugo_logs',
                array(
                    'method' => pSQL($method),
                    'type' => pSQL($type),
                    'message' => pSQL($message),
                    'data' => pSQL($response, true),
                )
            );
        }
    }

    public function xml2array($contents, $get_attributes = 1, $priority = 'tag')
    {
        if (!$contents) {
            return array();
        }
        if (is_array($contents)) {
            return array();
        }
        if (!function_exists('xml_parser_create')) {
            // print "'xml_parser_create()' function not found!";
            return array();
        }
        // Get the XML parser of PHP - PHP must have this module for the parser to work
        $parser = xml_parser_create('');
        xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8"); // http://minutillo.com/steve/weblog/2004/6/17/php-xml-and-character-encodings-a-tale-of-sadness-rage-and-data-loss
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
        xml_parse_into_struct($parser, trim($contents), $xml_values);
        xml_parser_free($parser);
        if (!$xml_values) {
            return; //Hmm...
        }
        // Initializations
        $xml_array = array();
//        $parents = array();
//        $opened_tags = array();
//        $arr = array();
        $current = &$xml_array; //Refference
        // Go through the tags.
        $repeated_tag_index = array(); //Multiple tags with same name will be turned into an array
        $attributes = array();
        $value = array();
        $parent = array();
        $type = '';
        $level = '';
        $tag = '';
        foreach ($xml_values as $data) {
            unset($attributes, $value); //Remove existing values, or there will be trouble
            // This command will extract these variables into the foreach scope
            // tag(string), type(string), level(int), attributes(array).
            extract($data); //We could use the array by itself, but this cooler.
            $result = array();
            $attributes_data = array();
            if (isset($value)) {
                if ($priority == 'tag') {
                    $result = $value;
                } else {
                    $result['value'] = $value; //Put the value in a assoc array if we are in the 'Attribute' mode
                }
            }
            // Set the attributes too.
            if (isset($attributes) and $get_attributes) {
                foreach ($attributes as $attr => $val) {
                    if ($attr == 'ResStatus') {
                        $current[$attr][] = $val;
                    }
                    if ($priority == 'tag') {
                        $attributes_data[$attr] = $val;
                    } else {
                        $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
                    }
                }
            }
            // See tag status and do the needed.
            //echo"<br/> Type:".$type;
            if ($type == "open") { //The starting of the tag '<tag>'
                $parent[$level - 1] = &$current;
                if (!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
                    $current[$tag] = $result;
                    if ($attributes_data) {
                        $current[$tag . '_attr'] = $attributes_data;
                    }
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    $current = &$current[$tag];
                } else { //There was another element with the same tag name
                    if (isset($current[$tag][0])) { //If there is a 0th element it is already an array
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else { //This section will make the value an array if multiple tags with
                        // the same name appear together
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //This will combine the existing item and the new item together to make an array
                        $repeated_tag_index[$tag . '_' . $level] = 2;
                        if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th)
                            // tag must be moved as well
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset($current[$tag . '_attr']);
                        }
                    }
                    $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                    $current = &$current[$tag][$last_item_index];
                }
            } elseif ($type == "complete") { //Tags that ends in 1 line '<tag />'
                // See if the key is already taken.
                if (!isset($current[$tag])) { //New Key
                    $current[$tag] = $result;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $attributes_data) {
                        $current[$tag . '_attr'] = $attributes_data;
                    }
                } else { //If taken, put all things inside a list(array)
                    if (isset($current[$tag][0]) and is_array($current[$tag])) { //If it is already an array...
                        // ...push the new element into that array.
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        if ($priority == 'tag' and $get_attributes and $attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else { //If it is not an array...
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        ); //...Make it an array using using the existing value and the new value
                        $repeated_tag_index[$tag . '_' . $level] = 1;
                        if ($priority == 'tag' and $get_attributes) {
                            if (isset($current[$tag . '_attr'])) { //The attribute of the last(0th)
                                // tag must be moved as well
                                $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                                unset($current[$tag . '_attr']);
                            }
                            if ($attributes_data) {
                                $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                            }
                        }
                        $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                    }
                }
            } elseif ($type == 'close') { //End of tag '</tag>'
                $current = &$parent[$level - 1];
            }
        }
        return ($xml_array);
    }

    public function WPostRequest($url, $params = array())
    {
        $enable = $this->isEnabled();
        if ($enable) {
            try {
                $url = Configuration::get('CEDFRUUGO_API_URL') . $url;

                $body = array();
                if (isset($params['file'])) {
                    if (version_compare(phpversion(), '5.5.0', '>=') === false) {
                        $body['file'] = new CurlFile($params['file'], 'application/xml', basename($params['file']));
                    } elseif (function_exists('curl_file_create')) {
                        $body['file'] = curl_file_create($params['file'], 'application/xml', basename($params['file']));
                    } else {
                        $value = "@{$params['file']};filename=" . basename($params['file']) . ';type=application/xml';
                        $body['file'] = $value;
                    }
                } elseif (isset($params['data'])) {
                    $body = (string)$params['data'];
                } else {
                    $body = http_build_query($params);
                }

                $headers = array();

                $headers[] = "Content-Type: application/XML";

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_HEADER, 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                $curlError = curl_error($ch);
                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $body = Tools::substr($server_output, $header_size);
                $res = array(
                    'Post Request Url' => $url,
                    'Post Request Header' => $headers,
                    'Post Request Params' => $params,
                    'Post Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Post Request to fruugo', Tools::jsonEncode($res));
                if ($curlError) {
                    return array('success' => false, 'message' => $curlError);
                }
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($http_code == 200) {
                        return array('success' => true, 'response' => $body);
                    } else {
                        return array('success' => false, 'message' => $body);
                    }
                }
                curl_close($ch);
            } catch (Exception $e) {
                $this->log(
                    'CedfruugoHelper::WPostRequest',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                return array('success' => false, 'message' => $e->getMessage());
            }
        } else {
            return array('success' => false, 'message' => 'Module is not enable.');
        }
    }

    public function isEnabled()
    {

        $flag = false;

        if (Configuration::get('CEDFRUUGO_LIVE_MODE')) {
            $flag = true;

            $this->init();
        }
        return $flag;
    }

    public function init()
    {

        $this->_api_url = Configuration::get('CEDFRUUGO_API_URL');
        $this->user = Configuration::get('CEDFRUUGO_CONSUMER_ID');
        $this->pass = Configuration::get('CEDFRUUGO_CONSUMER_PASSWORD');
    }

    public function getCancelReasons()
    {
        return array(
            'out_of_stock' => 'out_of_stock - the product is out of stock and thus cannot be delivered',
            'product_discontinued' => 'product is no longer available and thus cannot be delivered',
            'invalid_delivery_address' => 'customer has given a delivery address that appears invalid',
            'customer_cancellation' => 'customer has has asked for the order to be cancelled',
            'legislation_restriction' => 'law or contract restriction prevents delivery to customer\'s address',
            'other' => 'other reason',
        );
    }

    public function getReturnReasons()
    {
        return array(
            'unsatisfied_with_item' => 'customer was not satisfied with the item',
            'item_did_not_match_description' => 'item didn\'t match the product description',
            'damaged_item' => 'item was damaged',
            'wrong_item' => 'wrong item was shipped to the customer',
            'other' => 'other reason',
        );
    }

    public function variantAttributes()
    {
        return array(
            'AttributeSize' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' => 'The specific size option of the SKU, 
                which where a product is available in several size choices will 
                present the size option to the retailer. 
                Note: The field becomes mandatory if you have products which are available in multiple sizes.
				We recommend including the size for all products, 
				however the field should not include generic terms such as one size or o/s.'
            ),
            'AttributeColor' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' => 'The specific colour option of the SKU, 
                which where a product is available in several colours choices will present 
                the colour option to the retailer. 
                Note: The field becomes mandatory if you have products which are available in multiple colours.
				We recommend including the colour for all products,
				however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            ),
            'Attribute1' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' => 'These are used for any additional attributes/options that most suit your product type 
                 that are not Size (AttributeSize) or Colour (AttributeColor).
				 They should be used so each column only contains one attribute type/value. 
				 The semantics of used attribute field must be communicated to a member of the Integration team.
				  Note: The attribute fields should not be used to list product features; 
				  only options to be selected by the customer.'
            ),
            'Attribute2' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute3' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options 
                    that most suit your product type that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value.
					The semantics of used attribute field must be communicated to a member of the Integration team.
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute4' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					 They should be used so each column only contains one attribute type/value. 
					 The semantics of used attribute field must be communicated to a member of the Integration team. 
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute5' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					 They should be used so each column only contains one attribute type/value. 
					 The semantics of used attribute field must be communicated to a member of the Integration team. 
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute6' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute7' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute8' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute9' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute10' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features;
					 only options to be selected by the customer.'
            )
        );
    }

    public function getValidationArray()
    {

        return array(
            'ProductId' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 50,
                'description' =>
                    'Your own product identifier code that you recognise when it is provided on order information.
					The same ProductId should be used to group together Skus 
					where they are available with multiple options (Colours, Sizes etc.).'
            ),
            'SkuId' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 50,
                'description' =>
                    'If the product has multiple options, the SkuId uniquely identifies and separates each option.
                     If a product doesn’t have multiple options the SkuId can be the same as the ProductId.
					Each ProductId & SkuId combination must be unique and not repeated for any other Product(s).'
            ),
            'EAN' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 14,
                'description' =>
                    'The unique GTIN for the product. GTIN stands for Global Trade Item Number 
                    - a globally unique number used to identify trade items, products, or services. 
                    GTIN is the umbrella term that refers to the entire family of data structures 
                    - UPC, EAN, UCC - 8, 12, 13 & 14 digits.
					If you are the manufacturer of the product you can mark the product to be an exception 
					to the requirement rule by using EXCEP in the EAN field.'
            ),
            'Brand' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 50,
                'description' => 'The brand name of the product.
'
            ),
            'Category' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 250,
                'description' =>
                    'The category name where the product is located on your own website or the category 
                    you wish the product to be classified in on Fruugo.
					The category value must be accurate enough to identify the nature of the product,
					and if relevant to the type of product it should include gender.'
            ),
            'Imageurl1' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 2150,
                'description' =>
                    'The link to your primary image for a product which will be displayed.
                     A minimum size of 400px x 400px (or larger). 
                     The image should be provided on a white background.
					Images will only be updated if the file name is changed,
					we do not check to see if your file is newer than your last scheduled import.
					Placeholder or images using watermarks are not permitted.'
            ),
            'StockStatus' => array(
                'type' => 'select',
                'is_required' => true,
                'length' => 12,
                'values' => array(
                    'INSTOCK' => 'INSTOCK',
                    'OUTOFSTOCK' => 'OUTOFSTOCK',
                    'NOTAVAILABLE' => 'NOTAVAILABLE',
                ),
                'description' =>
                    'The stock status of a product which indicates whether it’s available for purchase. 
                     The value of the field must be either:</br>
					 INSTOCK – If you have the product currently in stock.</br>
					 OUTOFSTOCK – The product is currently out of stock but may return.</br>
					 NOTAVAILABLE – The product is permanently out of stock and needs to be removed.'
            ),
            'StockQuantity' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 5,
                'description' =>
                    'The quantity of an item you have available to sell. 
                    If stock levels are not held a default number is recommended, 
                    such as 100 for in stock items and 0 for out of stock items.
					Negative values or decimal places are not supported.'
            ),
            'Title' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 150,
                'description' =>
                    'A concise title for your product in title case (not block capitals) 
                    which identifies the nature of the product.
					It should include any brand, model or part number 
					which is widely used to identify the product.
					It should not include any reference to 
					price; shipping; stock; special offers; or promotional text.
					It should not include any reference to size or colour when part of a grouped product.'
            ),
            'Description' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 5000,
                'description' =>
                    'A detailed explanation of the product and its features. Use sentence case.
					Do not include any URLs; Email Addresses; Telephone Numbers;
					Prices; Shipping information, or references to activity not on our site.'
            ),
            'NormalPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 7,
                'description' => "	
					The normal / list price of the product excluding VAT. 
					Must be a numeric value with a decimal separator and not include any currency symbol. 
					For example 4.12. If included, 'NormalPriceWithVAT' must not be included."
            ),
            'NormalPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 7,
                'description' =>
                    "The normal / list price of the product including VAT.
                     Must be a numeric value with a decimal separator and not include any currency symbol.
                      For example 4.12. If included, 'NormalPriceWithoutVAT' must not be included."
            ),
            'VATRate' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 4,
                'description' =>
                    'The numeric value of the correct VAT rate of the product in your VAT registered country (EU only).
					Do not include % or any other symbols. For example: 20. 
					To be listed as 0 for non-EU based retailers where VAT is not applicable.'
            ),
            'Imageurl2' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "Used to provide additional image URLs for the product.
                     Each URL should be in a separate field with up to 5 images being supported.
                      The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl3' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "Used to provide additional image URLs for the product.
                    Each URL should be in a separate field with up to 5 images being supported.
                     The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl4' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "Used to provide additional image URLs for the product.
                     Each URL should be in a separate field with up to 5 images being supported. 
                     The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'Imageurl5' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "Used to provide additional image URLs for the product.
                     Each URL should be in a separate field with up to 5 images being supported.
                      The same image policies apply to these fields as apply to 'Imageurl1'."
            ),
            'AttributeSize' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'The specific size option of the SKU, which where a product is available in several size
                     choices will present the size option to the retailer. Note: The field becomes mandatory 
                     if you have products which are available in multiple sizes.
					 We recommend including the size for all products,
					 however the field should not include generic terms such as one size or o/s.'
            ),
            'AttributeColor' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'The specific colour option of the SKU, which where a product is available in several colours
                     choices will present the colour option to the retailer. 
                     Note: The field becomes mandatory if you have products which are available in multiple colours.
					We recommend including the colour for all products,
					however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            ),

            'DiscountPriceWithoutVAT' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 6,
                'description' =>
                    "The discount / sale price of the product excluding VAT. Must be a numeric value with a 
                    decimal separator and not include any currency symbol. For example 4.12.
					Must only be used if you use 'NormalPriceWithoutVAT' for your normal list price. 
					If included 'DiscountPriceWithVAT' must not be included."
            ),
            'DiscountPriceWithVAT' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 6,
                'description' =>
                    "The discount / sale price of the product excluding VAT. 
                    Must be a numeric value with a decimal separator and not include any currency symbol. 
                    For example 4.12.
					Must only be used if you use 'NormalPriceWithVAT' 
					for your normal list price. If included 'DiscountPriceWithoutVAT' must not be included."
            ),
            'ISBN' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 13,
                'description' =>
                    'The unique ISBN for the product. ISBN stands for International 
                    Standard Book Number - the globally unique number used to identify publications. 
                    The data structure should be either the 10 or 13 digit number (13 preferred).
                     Note: The field becomes mandatory for all books.'
            ),
            'Manufacturer' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 50,
                'description' => 'The name of the manufacturer of the product.'
            ),
            'RestockDate' => array(
                'type' => 'date',
                'is_required' => false,
                'length' => 9,
                'description' =>
                    "The date when a product which is currently marked as OUTOFSTOCK in 'StockStatus' 
                    will be back in stock and available for order.
					The date must be provided in one of the following UNIX 
					timestamp formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY; DD-MM-YYYY;
					 YY-MM-DD; YYYY-MM-DD."
            ),
            'LeadTime' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 2,
                'description' =>
                    "The 'LeadTime' has two separate purposes depending on the 'StockStatus' of the product.
					 If the product is INSTOCK, the 'LeadTime' indicates the approximiate number of days
					  delay from order to the item being dispatched from the warehouse. 
					  Note: Only to be used if the time exceeds 24 hours as 1 day is the default product value.
					 If the is OUTOFSTOCK, the 'LeadTime' indicates the approximiate number 
					 of days until the product is back in stock and can be dispatched from the warehouse.
					  Note: The product will remain on the site as 'INSTOCK' with the number of days showing
					   as to when it is available."
            ),
            'PackageWeight' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 5,
                'description' =>
                    'The shipping weight of the product provided in grams with no decimal places or
                     unit of measurement. For example, 190.	Note: The field becomes mandatory 
                     if your shipping rules are calculated based on the total order
                      weight - please see Shipping > Weight Based Shipping. If you are utilising quantity 
                      based shipping all products must have a default value of 1000 - 
                      please see Shipping > Quantity Based Shipping.'
            ),
            'Attribute1' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of 
					the Integration team. Note: The attribute fields should not be used to list 
					product features; only options to be selected by the customer.'
            ),
            'Attribute2' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					 They should be used so each column only contains one attribute type/value.
					 The semantics of used attribute field must be communicated to a member 
					 of the Integration team. Note: The attribute fields should not be used to 
					 list product features; only options to be selected by the customer.'
            ),
            'Attribute3' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type 
                    that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team. 
					Note: The attribute fields should not be used to list product features; 
					only options to be selected by the customer.'
            ),
            'Attribute4' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product 
                    type that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute5' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute6' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute7' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute8' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute9' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Attribute10' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 30,
                'description' =>
                    'These are used for any additional attributes/options that most suit your product type
                     that are not Size (AttributeSize) or Colour (AttributeColor).
					They should be used so each column only contains one attribute type/value. 
					The semantics of used attribute field must be communicated to a member of the Integration team.
					 Note: The attribute fields should not be used to list product features; 
					 only options to be selected by the customer.'
            ),
            'Country' => array(
                'type' => 'select',
                'is_required' => false,
                'length' => 150,
                'case' => 'upper',
                'values' => $this->getFruugoCountry(),
                //'onClick' => 'getFruugoLanguageCurrency(this)',
                'description' => '	
						Two digit ISO code (Upper Case) is used to limit a product to listed countries 
						if they have a different restriction to your default account settings.
						It is an “include” list and for multiple countries should be separated by spaces.
						For example: IE FR DE. The country codes must be those supported on
						Fruugo (as listed in Fruugo Countries > Countries; Languages & Currency codes).
						Note: The field should be left blank if the product does not have a 
						country restriction that differs from your default account settings.'
            ),
            'Currency' => array(
                'type' => 'select',
                'length' => 3,
                'is_required' => false,
                'values' => $this->getFruugoCurrencyCode(),
                'case' => 'upper',
                'description' =>
                    'Three letter ISO code (Upper Case) of the currency of the price fields of the feed, 
                    such as NormalPriceWithoutVAT. The currency must be one of those 
                    supported on Fruugo (as listed in Fruugo Countries > Countries; Languages; & Currency codes).
					We strongly recommend always using the native currency of your registered country. 
					Note: The field becomes mandatory if the language used is not the native 
					language of your registered country.'
            ),
            'Language' => array(
                'type' => 'select',
                'is_required' => false,
                'length' => 2,
                'case' => 'lower',
                'values' => $this->getFruugoLanguage(),
                'description' =>
                    "Two digit ISO code (lower case) of the language of the text fields of the feed, 
                    such as Title, Description, AttributeColor etc. The language must be one of 
                    those supported on Fruugo (as listed in 
                    Fruugo Countries > Countries; Languages; & Currency codes).
					The text within the feed should all be in one language. 
					Note: The field becomes mandatory if the language used is not the native 
					language of your registered country."
            ),
            'DiscountPriceStartDate' => array(
                'type' => 'date',
                'is_required' => false,
                'length' => 11,
                'description' =>
                    "The start date for your discount price to begin being displayed, 
                    if it is a timelimited promotion, and you have populated 
                    either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
					The date must be provided in one of the following UNIX timestamp
					 formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; DDMM-YY;
					  DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
            'DiscountPriceEndDate' => array(
                'type' => 'date',
                'is_required' => false,
                'length' => 11,
                'description' =>
                    "The end date for your discount price to stop being displayed, 
                    if it is a timelimited promotion, and you have populated 
                    either 'DiscountPriceWithoutVAT' or 'DiscountPriceWithVAT'.
                    The date must be provided in one of the following UNIX timestamp
                     formats: DD:MM:YY; DD:MM:YYYY; YY:MM:DD; YYYY:MM:DD; 
                     DDMM-YY; DD-MM-YYYY; YY-MM-DD; YYYY-MM-DD."
            ),
        );
    }

    public function getFruugoCountry()
    {
        $db = Db::getInstance();
        $country = array();
        $result = $db->ExecuteS("SELECT `country`, `country_code`
                   FROM `" . _DB_PREFIX_ . "fruugo_country_currency`");
        foreach ($result as $value) {
            $country[$value['country_code']] = $value['country'];
        }
        return $country;
    }

    public function getFruugoCurrencyCode()
    {
        $db = Db::getInstance();
        $currency_code = array();
        $result = $db->ExecuteS("SELECT `currency_code`,`country_code` 
                 FROM `" . _DB_PREFIX_ . "fruugo_country_currency`");
        foreach ($result as $value) {
            $currency_code[$value['currency_code']] = $value['currency_code'];
        }
        if (count($currency_code)) {
            $currency_code = array_unique($currency_code);
        }
        return $currency_code;
    }

    public function getFruugoLanguage()
    {
        $db = Db::getInstance();
        $language = array();
        $result = $db->ExecuteS("SELECT `language`,`country_code` 
                FROM `" . _DB_PREFIX_ . "fruugo_country_currency`");
        foreach ($result as $value) {
            $language[$value['language']] = $value['language'];
        }
        if (count($language)) {
            $language = array_unique($language);
        }
        return $language;
    }

    public function validDate($date, $format = 'Y-m-d')
    {
        $date_obj = DateTime::createFromFormat($format, $date);
        return $date_obj && $date_obj->format($format) == $date;
    }

    public function carrierNameArray()
    {
        return array(
            'UPS' => 'UPS',
            'USPS' => 'USPS',
            'FedEx' => 'FedEx',
            'Airborne' => 'Airborne',
            'OnTrac' => 'OnTrac'
        );
    }

    public function methodCodeArrray()
    {
        return array(
            'Standard' => 'Standard',
            'Express' => 'Express',
            'Oneday' => 'Oneday',
            'Freigh' => 'Freigh',
            'WhiteGlove' => 'WhiteGlove',
            'Value' => 'Value'
        );
    }

    public function fruugoGetRequest($url, $params = array())
    {
        $enable = $this->isEnabled();
        if ($enable) {
            try {
                $url = $this->_api_url . $url;

                $headers = array();
                $headers[] = "Content-Type: application/x-www-form-urlencoded";

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
                $server_output = curl_exec($ch);
                $res = array(
                    'Get Request Url' => $url,
                    'Get Request Header' => $headers,
                    'Get Request Parameters' => $params,
                    'Get Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Fruugo Get Request', Tools::jsonEncode($res));

                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $body = Tools::substr($server_output, $header_size);
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($http_code == 200) {
                        return array('success' => true, 'response' => $server_output);
                    } else {
                        if ($body) {
                            return array('success' => false, 'message' => $body);
                        } else {
                            return array('success' => false, 'message' => $server_output);
                        }
                    }
                }
                curl_close($ch);
            } catch (Exception $e) {
                $this->log(
                    'CedfruugoHelper::fruugoGetRequest',
                    'Exception',
                    $e->getMessage() . 'for' . $url,
                    $e->getMessage(),
                    true
                );
                return array('success' => false, 'message' => $e->getMessage());
            }
        } else {
            return array('success' => false, 'message' => 'Module is not enable.');
        }
    }

//    public function fetchOrderStats($params)
//    {
//        $db = Db::getInstance();
//        $response = array();
//        $response['revenueTotal'] = array();
//        $shipped = Configuration::get('CEDFRUUGO_ORDER_STATE_SHIPPED');
//        $sql = "SELECT `fruugo_order_id`, `total_paid`, fo.order_place_date
//                FROM `" . _DB_PREFIX_ . "fruugo_order` fo  LEFT JOIN `" . _DB_PREFIX_ . "orders` o
//                ON (fo.prestashop_order_id = o.id_order) where fo.order_place_date
//                 BETWEEN '" . pSQL($params['from']) . "' AND '" . pSQL($params['to']) . "'
//                 AND `current_state` = '" . $shipped . "'";
//
//
//        $response['revenueTotal'] = $db->ExecuteS($sql);
//        /*        foreach ($result as $key => $value) {
//                    $response['revenueTotal'][$value['fruugo_order_id']] = $value['total_paid'];
//                }*/
//
//
//        $sql = "SELECT COUNT(*) as `total` FROM `" . _DB_PREFIX_ . "fruugo_products`
//        where `fruugo_status` ='OUTOFSTOCK'";
//        $result = $db->ExecuteS($sql);
//        if (isset($result['0']['total'])) {
//            $response['disabledSkus'] = (int)$result['0']['total'];
//        }
//
//        $sql = "SELECT COUNT(*) as `total` FROM `" . _DB_PREFIX_ . "fruugo_products`
//        where `fruugo_status` ='INSTOCK'";
//        $result = $db->ExecuteS($sql);
//        if (isset($result['0']['total'])) {
//            $response['liveSkus'] = (int)$result['0']['total'];
//        }
//
//        $csv_dir = _PS_MODULE_DIR_ . 'cedfruugo/product_upload/';
//        if (is_dir($csv_dir)) {
//            if (file_exists($csv_dir . 'product_feed.csv')) {
//                $fp = file($csv_dir . 'product_feed.csv');
//                $response['uploadedSkus'] = count($fp);
//            }
//        }
//        return $response;
//    }
}
