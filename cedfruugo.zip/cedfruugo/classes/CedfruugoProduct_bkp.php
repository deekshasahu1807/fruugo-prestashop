<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoHelper.php';

class CedfruugoProduct
{
    public function uploadProducts($product_ids = array())
    {
        $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $db = Db::getInstance();
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }

        $all_product_ids = array_chunk($product_ids, 1000);
        foreach ($all_product_ids as $product_ids) 
        {
            $product_to_upload = array();
            $product_error = array();
            foreach ($product_ids as $product_id) 
            {
                $fruugo_data = array();
                $productObject = new Product($product_id, false, $default_lang);
                $disabled_product_upload = Configuration::get('CEDFRUUGO_UPLOAD_DISABLE_PRODUCT');
                $product_status = $productObject->active;
                if (!$product_status && !$disabled_product_upload) {
                    continue;
                }
                $product = (array)new Product($product_id, true, $default_lang);
                //echo '<pre>'; print_r($product); die;
                $fruugo_product = $this->getFruugoProduct($product_id);
                $fruugo_product = array_filter($fruugo_product);

                $default_values = $this->getSavedDefaultValues();

                // Brand
                if(isset($default_values['Brand']) && !empty($default_values['Brand'])) 
                {
                    $default_values['Brand'] = trim($default_values['Brand']);
                    if(strlen($default_values['Brand']) > '50')
                    {
                        $default_values['Brand'] = substr($default_values['Brand'], 0, 50);
                    }
                }

                if ($productObject->getAttributeCombinations($default_lang)) {
                    $mapped_values = $this->getMappingValues($product_id, $product, false);
                } else {
                    $mapped_values = $this->getMappingValues($product_id, $product);
                }

                // Brand
                $mapped_values['Brand'] = trim($mapped_values['Brand']);
                if(strlen($mapped_values['Brand']) > '50'){
                    $mapped_values['Brand'] = substr($mapped_values['Brand'], 0, 50);
                }
                // Title
                $mapped_values['Title'] = trim($mapped_values['Title']);
                if(strlen($mapped_values['Title']) > '150'){
                    $mapped_values['Title'] = substr($mapped_values['Title'], 0, 150);
                }
                
                $category = $this->getFruugoCategory($product_id);
                foreach ($default_values as $valKey => $value) {
                    if (isset($mapped_values[$valKey]) && empty($mapped_values[$valKey])) {
                        $mapped_values[$valKey] = $value;
                    }
                }
                if (!isset($mapped_values['VATRate'])
                    || empty($mapped_values['VATRate'])
                    || $mapped_values['VATRate'] == '0') {
                    $mapped_values['VATRate'] = '0';
                }
                $mapped_values['Country'] = isset($default_values['Country']) ? $default_values['Country'] : '';
                $mapped_values['Currency'] = isset($default_values['Currency']) ? $default_values['Currency'] : '';
                $mapped_values['Language'] = isset($default_values['Language']) ? $default_values['Language'] : '';
                $fruugo_data = array_merge($mapped_values, array_filter($fruugo_product));

                if (isset($product['reference']) && $product['reference']) {
                    $fruugo_data['SkuId'] = $product['reference'];
                }

                if ($category) {
                    $fruugo_data['Category'] = $category;
                }

                if ($product_id) {
                    $fruugo_data['ProductId'] = $product_id;
                }

                if (isset($product['reference']) && $product['reference']) {
                    $fruugo_data['SkuId'] = $product['reference'];
                }

                $images = $this->productImageUrls($product_id);
                if (isset($images['mainImageUrl']) && $images['mainImageUrl']) {
                    $fruugo_data['Imageurl1'] = $images['mainImageUrl'];
                }

                if (isset($images['productSecondaryImageURL']) && $images['productSecondaryImageURL']) {
                    $secondaryImageURLs = $images['productSecondaryImageURL'];
                    if (count($secondaryImageURLs)) {
                        $i = 2;
                        foreach ($secondaryImageURLs as $secondaryImageURL) {
                            if ($i <= 5) {
                                $fruugo_data['Imageurl' . $i] = $secondaryImageURL;
                                $i++;
                            } else {
                                break;
                            }
                        }
                    }
                }
                for ($i = 2; $i <= 5; $i++) {
                    if (!isset($fruugo_data['Imageurl' . $i])) {
                        $fruugo_data['Imageurl' . $i] = '';
                    }
                }
                for ($i = 1; $i <= 10; $i++) {
                    if (!isset($fruugo_data['Attribute' . $i])) {
                        $fruugo_data['Attribute' . $i] = '';
                    }
                }
                foreach ($default_values as $ky => $value) {
                    if ((!isset($fruugo_data[trim($ky)])) || (isset($fruugo_data[trim($ky)])
                            && ($fruugo_data[trim($ky)] == ''))) {
                        if ($value) {
                            $fruugo_data[trim($ky)] = $value;
                        }
                    }
                }

                if (isset($fruugo_data['Description']) && $fruugo_data['Description']) {
                    $description = $fruugo_data['Description'];
                    $fruugo_data['Description'] = strip_tags($description);
                }

                if ($productObject->getAttributeCombinations($default_lang)) {
                   
                    $attributeSize = 0;
                    $AttributeColor = 0;
                    if ((isset($fruugo_data['AttributeSize']) && $fruugo_data['AttributeSize'])
                        || (isset($fruugo_data['AttributeColor']) && $fruugo_data['AttributeColor'])) {
                        $attributeSize = $mapped_values['AttributeSize'];
                        $AttributeColor = $mapped_values['AttributeColor'];
                    } elseif ((isset($mapped_values['AttributeSize']) && $mapped_values['AttributeSize'])
                        || (isset($mapped_values['AttributeColor']) && $mapped_values['AttributeColor'])) {
                        $attributeSize = $mapped_values['AttributeSize'];
                        $AttributeColor = $mapped_values['AttributeColor'];
                    }
                    if (!is_array($attributeSize)) {
                        $attributeSize = array($attributeSize);
                    }
                    if (!is_array($AttributeColor)) {
                        $AttributeColor = array($AttributeColor);
                    }
                    $additionalAttributes = array();
                    for ($i = 1; $i <= 10; $i++) {
                        if ((isset($fruugo_data['Attribute' . $i]) && $fruugo_data['Attribute' . $i])) {
                            $additionalAttributes['Attribute' . $i] = $mapped_values['Attribute' . $i];
                        } elseif ((isset($mapped_values['Attribute' . $i]) && $mapped_values['Attribute' . $i])) {
                            $additionalAttributes['Attribute' . $i] = $mapped_values['Attribute' . $i];
                        }
                    }
                    $product_combination = $this->getAttributesResume($product_id, $default_lang);

                    if (!empty($product_combination)) {
                        foreach ($product_combination as $k => $value) {
                            foreach ($AttributeColor as $attrColor) {
                                if (isset($value['combinations'][$attrColor]) && $value['combinations'][$attrColor]) {
                                    $product_combination[$k]['AttributeColor'] = $value['combinations'][$attrColor];
                                }
                            }
                            foreach ($attributeSize as $attrSize) {
                                if (isset($value['combinations'][$attrSize]) && $value['combinations'][$attrSize]) {
                                    $product_combination[$k]['AttributeSize'] = $value['combinations'][$attrSize];
                                }
                            }
                            foreach ($additionalAttributes as $attrKey => $attrVal) {
                                foreach ($attrVal as $val) {
                                    if (isset($value['combinations'][$val]) && $value['combinations'][$val]) {
                                        $product_combination[$k][$attrKey] = $value['combinations'][$val];
                                    }
                                }
                            }
                            if (!isset($product_combination[$k]['AttributeColor'])
                                || !$product_combination[$k]['AttributeColor']) {
                                $product_combination[$k]['AttributeColor'] = '';
                            }
                            if (!isset($product_combination[$k]['AttributeSize'])
                                || !$product_combination[$k]['AttributeSize']) {
                                $product_combination[$k]['AttributeSize'] = '';
                            }
                            unset($product_combination[$k]['combinations']);
                            $image = $this->productImageUrls($product_id, $value['id_product_attribute']);

                            $product_combination[$k]['images'] = $image;
                        }
                    }

                    $fruugo_data = $this->processCombinations(
                        $fruugo_data,
                        $product_combination,
                        $productObject,
                        $product_id
                    );

                } else {
                    if (isset($product['quantity']) && $product['quantity']) {
                        $fruugo_data['StockQuantity'] = $product['quantity'];
                        $fruugo_data['StockStatus'] = 'INSTOCK';
                    } else {
                        $fruugo_data['StockQuantity'] = $product['quantity'];
                        $fruugo_data['StockStatus'] = 'OUTOFSTOCK';
                    }
                    if (!$product_status && $disabled_product_upload) {
                        $fruugo_data['StockStatus'] = 'OUTOFSTOCK';
                    }

                    if (!isset($fruugo_data['StockStatus'])) {
                        $fruugo_data['StockStatus'] = 'OUTOFSTOCK';
                    }

                    $fruugo_data['NormalPriceWithoutVAT'] = $productObject::getPriceStatic(
                        $product_id,
                        false,
                        null,
                        2,
                        null,
                        false,
                        true,
                        1,
                        true,
                        null,
                        null,
                        null
                    );

                    $fruugo_data['NormalPriceWithVAT'] = $productObject::getPriceStatic(
                        $product_id,
                        true,
                        null,
                        2,
                        null,
                        false,
                        false,
                        1,
                        true,
                        null,
                        null,
                        null
                    );
                }
                
                if (isset($fruugo_data['0'])) {
                    $error = '';
                    $variant_error = array();
                    foreach ($fruugo_data as $value) {
                        $ProductId = '';
                        if (isset($value['id_product'])) {
                            $ProductId = $value['id_product'];
                            unset($value['id_product']);
                        }
                        $result = $this->validateProduct($value);

                        if (isset($result['error']) && ($result['error'] == '')) {
                            $product_to_upload[] = $value;
                            $db->Execute("UPDATE `" . _DB_PREFIX_ . "fruugo_product_variations` 
                            SET `error_message` = '' WHERE `product_id`='" . (int)$ProductId . "' 
                            AND `sku`='" . pSQL($value['SkuId']) . "'");
                            $db->Execute("UPDATE `" . _DB_PREFIX_ . "fruugo_products` 
                            SET `error_message` = '' WHERE `product_id`='" . (int)$value['ProductId'] . "'");
                        } else {
                            $error .= $value['SkuId'] . ' : ' . $result['error'];
                            ;
                            $variant_error[$value['SkuId']] = $result['error'];
                        }

                    } 

                    if ($error) {
                        $product_error[$product_id] = $error;
                    } else {
                        $product_error[$product_id] = '';
                    }

                    $this->saveProductVariants($fruugo_data, $product_id, $variant_error);
                } else {
                    if (isset($fruugo_data['id_product'])) {
                        unset($fruugo_data['id_product']);
                    }
                    $result = $this->validateProduct($fruugo_data);

                    if (isset($result['error']) && ($result['error'] == '')) {
                        $product_to_upload[] = $fruugo_data;
                        $db->getInstance()->Execute("UPDATE `" . _DB_PREFIX_ . "fruugo_products` 
                        SET `error_message` ='' where `product_id`='" . (int)$fruugo_data['ProductId'] . "'");
                    } else {
                        $product_error[$product_id] = $fruugo_data['SkuId'] . ' : ' . $result['error'];
                    }
                }
            }
            $response = array();
            if (count($product_error)) {
                $product_error = array_filter($product_error);
                $response['error'] = $product_error;
                $this->processUploadError($product_error);
            }
            if (count($product_to_upload)) {
                $response['success'] = $this->processUploadData($product_to_upload);
            }
            return $response;
        }
    }

    public function getFruugoProduct($product_id)
    {
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $product = $db->executeS('SELECT `attributes` FROM `' . _DB_PREFIX_ . 'fruugo_products` 
        where `product_id`="' . (int)$product_id . '"');
        if (isset($product['0']['attributes']) && $product['0']['attributes']) {
            return unserialize($product['0']['attributes']);
        }
        return array();
    }

    public function getSavedDefaultValues()
    {
        $db = Db::getInstance();
        $sql = "SELECT * FROM `" . _DB_PREFIX_ . "fruugo_default_values`";
        $status = $db->ExecuteS($sql);
        if (is_array($status) && count($status)) {
            $attributes = array();
            foreach ($status as $value) {
                $attributes[$value['fruugo_attribute']] = $value['default_value'];
            }
            return $attributes;
        } else {
            return array();
        }
    }

    public function getMappingValues($product_id, $product, $mapped_attribute_id = true)
    {
        $mapped_values = array();
        $result = $this->getMappedAttributes();
        if ($product_id && count($result)) {
            foreach ($result as $key => $value) {
                $attr_val = '';
                $vals = array();
                if (is_array($value)) {
                    foreach ($value as $val) {
                        $mapped_expresion = explode('-', $val);
                        $attr_val = '';
                        if (isset($mapped_expresion['0'])
                            && in_array($mapped_expresion['0'], array('system', 'attribute', 'feature'))) {
                            $attr_type = $mapped_expresion['0'];
                            $attribute_id = str_replace($attr_type . '-', "", $val);
                            switch ($attr_type) {
                                case 'attribute':
                                    if ($mapped_attribute_id) {
                                        $attr_val = $this->getAttributeValue($attribute_id, $product_id);
                                    } else {
                                        $attr_val = $attribute_id;
                                    }

                                    break;
                                case 'feature':
                                    $attr_val = $this->getFeatureValue($attribute_id, $product_id);
                                    break;
                                case 'system':
                                    $attr_val = $this->getSystemValue($attribute_id, $product);
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (isset($attr_val) && !empty($attr_val)) {
                            $vals[] = $attr_val;
                        }
                    }
                } else {
                    $mapped_expresion = explode('-', $value);
                    $attr_val = '';
                    if (isset($mapped_expresion['0'])
                        && in_array($mapped_expresion['0'], array('system', 'attribute', 'feature'))) {
                        $attr_type = $mapped_expresion['0'];
                        $attribute_id = str_replace($attr_type . '-', "", $value);

                        switch ($attr_type) {
                            case 'attribute':
                                if ($mapped_attribute_id) {
                                    $attr_val = $this->getAttributeValue($attribute_id, $product_id);
                                } else {
                                    $attr_val = $attribute_id;
                                }

                                break;
                            case 'feature':
                                $attr_val = $this->getFeatureValue($attribute_id, $product_id);
                                break;
                            case 'system':
                                $attr_val = $this->getSystemValue($attribute_id, $product);
                                break;
                            default:
                                break;
                        }
                    }
                }
                if (is_array($value)) {
                    $mapped_values[$key] = $vals;
                } else {
                    $mapped_values[$key] = $attr_val;
                }
            }
            return $mapped_values;
        } else {
            return array();
        }
    }

    public function getMappedAttributes($fruugo_attribute = '')
    {
        $db = Db::getInstance();
        $status = $db->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "fruugo_attribute_mapping`");

        if (is_array($status) && count($status)) {
            $attributes = array();
            foreach ($status as $value) {
                if (isset($value['fruugoSkuId']) && (int)$value['fruugoSkuId']) {
                    $attributes[trim($value['fruugo_attribute'])] = json_decode($value['prestashop_attribute']);
                } else {
                    $attributes[trim($value['fruugo_attribute'])] = $value['prestashop_attribute'];
                }
            }
            if ($fruugo_attribute && isset($attributes[trim($fruugo_attribute)])) {
                return $attributes[trim($fruugo_attribute)];
            }

            return $attributes;
        } else {
            return array();
        }
    }

    public function getAttributeValue($attribute_group_id, $product_id)
    {
        $sql_db_intance = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $features = $sql_db_intance->executeS('
	        SELECT *
			FROM ' . _DB_PREFIX_ . 'product_attribute pa
			LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_combination pac 
			ON pac.id_product_attribute = pa.id_product_attribute
			LEFT JOIN ' . _DB_PREFIX_ . 'attribute a ON a.id_attribute = pac.id_attribute
			LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group ag 
			ON ag.id_attribute_group = a.id_attribute_group
			LEFT JOIN ' . _DB_PREFIX_ . 'attribute_lang al ON (a.id_attribute = al.id_attribute 
			AND al.id_lang = ' . (int)$default_lang . ')
			LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group_lang agl 
			ON (ag.id_attribute_group = agl.id_attribute_group 
			AND agl.id_lang = ' . (int)$default_lang . ')
			WHERE pa.id_product = "' . (int)$product_id . '" 
			AND a.id_attribute_group = "' . (int)$attribute_group_id . '" 
			ORDER BY pa.id_product_attribute');

        if (isset($features['0']['name'])) {
            return $features['0']['name'];
        } else {
            return false;
        }
    }

    public function getFeatureValue($attribute_id, $product_id)
    {
        $sql_db_intance = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $features = $sql_db_intance->executeS('
	        SELECT value FROM ' . _DB_PREFIX_ . 'feature_product pf
	        LEFT JOIN ' . _DB_PREFIX_ . 'feature_lang fl 
	        ON (fl.id_feature = pf.id_feature 
	        AND fl.id_lang = ' . (int)$default_lang . ')
	        LEFT JOIN ' . _DB_PREFIX_ . 'feature_value_lang fvl 
	        ON (fvl.id_feature_value = pf.id_feature_value 
	        AND fvl.id_lang = ' . (int)$default_lang . ')
	        LEFT JOIN ' . _DB_PREFIX_ . 'feature f ON (f.id_feature = pf.id_feature 
	        AND fl.id_lang = ' . (int)$default_lang . ')
	        ' . Shop::addSqlAssociation('feature', 'f') . '
	        WHERE pf.id_product = ' . (int)$product_id . ' 
	        AND fl.id_feature = "' . (int)$attribute_id . '" 
	        ORDER BY f.position ASC');
        if (isset($features['0']['value'])) {
            return $features['0']['value'];
        } else {
            return false;
        }
    }

    public function getSystemValue($attribute_id, $product)
    {
        if (isset($product[$attribute_id])) {
            $db = Db::getInstance();
            if ($attribute_id == 'id_manufacturer') {
                if (isset($product['id_manufacturer']) && $product['id_manufacturer']) {
                    $Execute = 'SELECT `name` FROM `' . _DB_PREFIX_ . 'manufacturer` 
                    where `id_manufacturer`=' . (int)$product['id_manufacturer'];
                    $qresult = $db->ExecuteS($Execute);
                    if (isset($qresult['0']["name"])) {
                        return $qresult['0']["name"];
                    }
                }
            }
            if ($attribute_id == 'id_tax_rules_group') {
                if (isset($product['id_tax_rules_group']) && $product['id_tax_rules_group']) {
                    $Execute = 'SELECT `rate` FROM `' . _DB_PREFIX_ . 'tax_rule` tr 
                    LEFT JOIN `' . _DB_PREFIX_ . 'tax` t on (t.id_tax = tr.id_tax) 
                    where tr.`id_tax_rules_group`=' . (int)$product['id_tax_rules_group'];
                    $qresult = $db->ExecuteS($Execute);
                    if (isset($qresult['0']["rate"])) {
                        return number_format($qresult['0']["rate"], 2);
                    }
                }
            }
            return $product[$attribute_id];
        } else {
            return false;
        }
    }

    public function getFruugoCategory($product_id)
    {
        $db = Db::getInstance();
        $query = $db->ExecuteS("SELECT `id_category` FROM `" . _DB_PREFIX_ . "category_product` 
        WHERE `id_product` = '" . (int)$product_id . "'");
        $catgories = array();
        if (is_array($query) && count($query)) {
            foreach ($query as $result) {
                $catgories[] = $result['id_category'];
            }
        }
        $mapped_category = '';
        if (count($catgories)) {
            $rows = $db->ExecuteS("SELECT `name`, `mapped_categories` 
              FROM `" . _DB_PREFIX_ . "fruugo_category_list` WHERE `mapped_categories` != ''");
            if (isset($rows['0']) && $rows['0']) {
                foreach ($rows as $row) {
                    $mapped_categories = unserialize($row['mapped_categories']);
                    if (array_intersect($mapped_categories, $catgories)) {
                        $mapped_category = trim($row['name']);
                        break;
                    }
                }
            }
        } elseif (Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL')) {
            $mapped_category = Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL');
        }
        return $mapped_category;
    }

    public function productImageUrls($product_id = 0, $attribute_id = 0)
    {
        if ($product_id) {
            $additionalAssets = array();
            $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
                (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
                (int)Configuration::get('PS_LANG_DEFAULT');
            $db = Db::getInstance();
            $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'image` i 
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il 
            ON (i.`id_image` = il.`id_image`)';

            if ($attribute_id) {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_image` ai 
                ON (i.`id_image` = ai.`id_image`)';
                $attribute_filter = ' AND ai.`id_product_attribute` = ' . (int)$attribute_id;
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' 
                AND il.`id_lang` = ' . (int)$default_lang . $attribute_filter . ' 
                ORDER BY i.`position` ASC';
            } else {
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' 
                AND il.`id_lang` = ' . (int)$default_lang . ' ORDER BY i.`position` ASC';
            }

            $Execute = $db->ExecuteS($sql);
            if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                $type = ImageType::getFormattedName('thickbox');
            } else {
                $type = ImageType::getFormatedName('thickbox');
            }
            $product = new Product($product_id);
            $link = new Link;
            if (count($Execute) > 0) {
                foreach ($Execute as $image) {
                    $image_url = $link->getImageLink(
                        $product->link_rewrite[$default_lang],
                        $image['id_image'],
                        $type
                    );
                    if (isset($image['cover']) && $image['cover']) {
                        $additionalAssets['mainImageUrl'] = (Configuration::get('PS_SSL_ENABLED') ?
                                'https://' : 'http://') . $image_url;
                    } else {
                        if (!isset($additionalAssets['mainImageUrl'])) {
                            $additionalAssets['mainImageUrl'] = (Configuration::get('PS_SSL_ENABLED') ?
                                    'https://' : 'http://') . $image_url;
                        } else {
                            $additionalAssets['productSecondaryImageURL'][] =
                                (Configuration::get('PS_SSL_ENABLED') ?
                                    'https://' : 'http://') . $image_url;
                        }
                    }
                }
            }
            return $additionalAssets;
        }
    }

    /**
     * Get all available product attributes resume
     *
     * @param int $id_lang Language id
     * @return array Product attributes combinations
     */
    public function getAttributesResume($product_id, $id_lang, $attr_val_sep = ' - ', $attr_sep = ', ')
    {
        if (!Combination::isFeatureActive()) {
            return array();
        }

        $combinations = Db::getInstance()->executeS('SELECT pa.*, product_attribute_shop.*
                FROM `' . _DB_PREFIX_ . 'product_attribute` pa
                ' . Shop::addSqlAssociation('product_attribute', 'pa') . '
                WHERE pa.`id_product` = ' . (int)$product_id . '
                GROUP BY pa.`id_product_attribute`');

        if (!$combinations) {
            return false;
        }

        $product_attributes = array();
        foreach ($combinations as $combination) {
            $product_attributes[] = (int)$combination['id_product_attribute'];
        }

        $lang = Db::getInstance()->executeS('SELECT pac.id_product_attribute, 
                GROUP_CONCAT(agl.`id_attribute_group`, \'' . pSQL($attr_val_sep) . '\',al.`name` 
                ORDER BY agl.`id_attribute_group` 
                SEPARATOR \'' . pSQL($attr_sep) . '\') as combinations ,a.id_attribute_group
                FROM `' . _DB_PREFIX_ . 'product_attribute_combination` pac
                LEFT JOIN `' . _DB_PREFIX_ . 'attribute` a ON a.`id_attribute` = pac.`id_attribute`
                LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group` ag 
                ON (ag.`id_attribute_group` = a.`id_attribute_group`)
                LEFT JOIN `' . _DB_PREFIX_ . 'attribute_lang` al ON (a.`id_attribute` = al.`id_attribute` 
                )
                LEFT JOIN `' . _DB_PREFIX_ . 'attribute_group_lang` agl 
                ON (ag.`id_attribute_group` = agl.`id_attribute_group`
                 AND agl.`id_lang` = ' . (int)$id_lang . ')
                WHERE pac.id_product_attribute IN (' . implode(',', (array)$product_attributes) . ')
                GROUP BY pac.id_product_attribute');

        foreach ($lang as $k => $row) 
        {
            $temp = explode(',', $row['combinations']);
            $temp3 = array();

            foreach ($temp as $key => $value) {
                $temp1 = explode('-', $value);
                 
                 if($temp1['0']==1)
                 {
                    if (!isset($temp3[trim($temp1['0'])])) {
                        $temp3[trim($temp1['0'])] = trim($temp1['1']);
                    } else {
                        $temp3[trim($temp1['0'])] .= '/'. trim($temp1['1']) . ' EU';
                    }
                 } else {
                    $temp3[trim($temp1['0'])] = trim($temp1['1']);
                 }
                
            }
            $combinations[$k]['combinations'] = $temp3;
        }
        //echo '<pre>'; print_r($combinations); die;
        //Get quantity of each variations
        foreach ($combinations as $key => $row) 
        {
            $cache_key = $row['id_product'] . '_' . $row['id_product_attribute'] . '_quantity';

            if (!Cache::isStored($cache_key)) {
                $result = StockAvailable::getQuantityAvailableByProduct(
                    $row['id_product'],
                    $row['id_product_attribute']
                );
                Cache::store(
                    $cache_key,
                    $result
                );
                $combinations[$key]['quantity'] = $result;
            } else {
                $combinations[$key]['quantity'] = Cache::retrieve($cache_key);
            }
        }
//echo '<pre>'; print_r($combinations); die;
        return $combinations;
    }

    public function processCombinations($fruugo_data, $product_combination, $productObject, $product_id)
    {
        $variations = array();
        if (!empty($product_combination)) {
            foreach ($product_combination as $key => $value) {
                $variations[$key] = $fruugo_data;

                for ($i = 1; $i <= 10; $i++) {
                    if (isset($value['Attribute' . $i]) && $value['Attribute' . $i]) {
                        $variations[$key]['Attribute' . $i] = $value['Attribute' . $i];
                    } else {
                        $variations[$key]['Attribute' . $i] = '';
                    }
                }
                if (isset($value['quantity']) && $value['quantity']) {
                    $variations[$key]['StockQuantity'] = $value['quantity'];
                    $variations[$key]['StockStatus'] = 'INSTOCK';
                } else {
                    $variations[$key]['StockQuantity'] = 0;
                    $variations[$key]['StockStatus'] = 'OUTOFSTOCK';
                }
                $disabled_product_upload = Configuration::get('CEDFRUUGO_UPLOAD_DISABLE_PRODUCT');
                $product_status = $productObject->active;
                if (!$product_status && $disabled_product_upload) {
                    $variations[$key]['StockStatus'] = 'OUTOFSTOCK';
                }
                if (!isset($variations[$key]['StockStatus'])) {
                    $variations[$key]['StockStatus'] = 'INSTOCK';
                }

                if (isset($value['AttributeColor']) && $value['AttributeColor']) {
                    $variations[$key]['AttributeColor'] = $value['AttributeColor'];
                } else {
                    $variations[$key]['AttributeColor'] = '';
                }

                if (isset($value['AttributeSize']) && $value['AttributeSize']) {
                    $variations[$key]['AttributeSize'] = $value['AttributeSize'];
                } else {
                    $variations[$key]['AttributeSize'] = '';
                }

                $variations[$key]['NormalPriceWithoutVAT'] = $productObject::getPriceStatic(
                    $product_id,
                    false,
                    $value['id_product_attribute'],
                    2,
                    null,
                    false,
                    false,
                    1,
                    true,
                    null,
                    null,
                    null
                );

                $variations[$key]['NormalPriceWithVAT'] = $productObject::getPriceStatic(
                    $product_id,
                    true,
                    $value['id_product_attribute'],
                    2,
                    null,
                    false,
                    false,
                    1,
                    true,
                    null,
                    null,
                    null
                );

                if (isset($value['images']['mainImageUrl']) && $value['images']['mainImageUrl']) {
                    $variations[$key]['Imageurl1'] = $value['images']['mainImageUrl'];
                }

                if (isset($value['images']['productSecondaryImageURL'])
                    && count($value['images']['productSecondaryImageURL'])) {
                    $i = 2;
                    foreach ($value['images']['productSecondaryImageURL'] as $productSecondaryImageURL) {
                        if ($i <= 5) {
                            $variations[$key]['Imageurl' . $i] = $productSecondaryImageURL;
                            $i++;
                        } else {
                            break;
                        }
                    }
                }

                $field = $this->getMappedAttributes('EAN');
                if (!is_array($field)) {
                    $field = explode('-', $field);
                    if (isset($field['1']) && $field['1']) {
                        if (isset($value[trim($field['1'])])) {
                            $variations[$key]['EAN'] = $value[trim($field['1'])];
                        }
                    }
                }


                $field = $this->getMappedAttributes('ISBN');
                if (!is_array($field)) {
                    $field = explode('-', $field);
                    if (isset($field['1']) && $field['1']) {
                        if (isset($value[trim($field['1'])])) {
                            $variations[$key]['ISBN'] = $value[trim($field['1'])];
                        }
                    }
                }
                if (isset($value['reference']) && $value['reference']) {
                    $variations[$key]['SkuId'] = $value['reference'];
                } else {
                    continue;
                }
            }
        }
        return $variations;
    }
//  public function log($data, $force_log =false ) {
//      if (Configuration::get('CEDFRUUGO_DEBUG_ENABLE') || $force_log) {
//          $logLine = chr(10) . date('d/m/Y h:i:s A') . ' - ' . json_encode($data);
//          $outputDir = _PS_MODULE_DIR_ . 'cedfruugo/logs/';
//          if(!is_dir($outputDir)){
//            mkdir($outputDir,0777,true);
//          }
//          try{
//            $outputFile = _PS_MODULE_DIR_ . 'cedfruugo/logs/cedfruugo.log';
//            $fp = fopen($outputFile, 'a');
//            fwrite($fp, $logLine);
//            fclose($fp);
//          }catch (Exception $e){
//
//          }
//      }
//    }

    public function validateProduct($data)
    {
        $cedFruugoHelper = new CedfruugoHelper();
        $result = array();
        $validation = $cedFruugoHelper->getValidationArray();
        $result['error'] = '';
        foreach ($validation as $key => $value) {
            $key = trim($key);
            if (isset($value['is_required']) && $value['is_required'] && isset($data[$key])) {
                switch ($key) {
                    case 'ProductId':
                        if (isset($data['ProductId']) && $data['ProductId']) {
                            if (Tools::strlen(trim($data['ProductId'])) > $value['length']) {
                                $result['error'] .= 'The length of' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'SkuId':
                        if (isset($data['SkuId']) && $data['SkuId']) {
                            if (Tools::strlen(trim($data['SkuId'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'EAN':
                        $is_manufacturer = Configuration::get('CEDFRUUGO_IS_MANUFACTURER');
                        if ($is_manufacturer != '1') {
                            if (isset($data['EAN']) && is_numeric(trim($data['EAN']))
                                && substr_count($data['EAN'], ".") < 1) {
                                if (Tools::strlen(trim($data['EAN'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'Brand':
                        if (isset($data['Brand']) && $data['Brand']) {
                            if (Tools::strlen(trim($data['Brand'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'Category':
                        if (isset($data['Category']) && $data['Category']) {
                            if (Tools::strlen(trim($data['Category'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'Imageurl1':
                        if (isset($data['Imageurl1']) && $data['Imageurl1']) {
                            if (Tools::strlen(trim($data['Imageurl1'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'StockQuantity':
                        if (isset($data['StockQuantity']) && is_numeric(($data['StockQuantity']))) {
                            if (Tools::strlen(trim($data['StockQuantity'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' should be a valid number. </br>';
                        }
                        break;
                    case 'Title':
                        if (isset($data['Title']) && $data['Title']) {
                            if (Tools::strlen(trim($data['Title'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'Description':
                        if (isset($data['Description']) && $data['Description']) {
                            if (Tools::strlen(trim($data['Description'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'NormalPriceWithoutVAT':
                        if (isset($data['NormalPriceWithoutVAT']) && $data['NormalPriceWithoutVAT']) {
                            if ((float)(trim($data['NormalPriceWithoutVAT']))) {
                                $data['NormalPriceWithoutVAT'] =
                                    number_format(trim($data['NormalPriceWithoutVAT']), 2, '.', '');
                                if (Tools::strlen($data['NormalPriceWithoutVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'NormalPriceWithVAT':
                        if (isset($data['NormalPriceWithVAT']) && $data['NormalPriceWithVAT']) {
                            if ((float)(trim($data['NormalPriceWithVAT']))) {
                                $data['NormalPriceWithVAT'] =
                                    number_format(trim($data['NormalPriceWithVAT']), 2, '.', '');
                                if (Tools::strlen($data['NormalPriceWithVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'VATRate':
                        if (isset($data['VATRate'])) {
                            if (is_numeric((trim($data['VATRate'])))) {
                                $data['VATRate'] = (float)trim($data['VATRate']);
                                if (Tools::strlen($data['VATRate']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                }
            } elseif (isset($value['is_required']) && !$value['is_required']) {
                if (isset($data[$key]) && !$data[$key]) {
                    continue;
                }
                switch ($key) {
                    case 'StockStatus':
                        if (isset($data['StockStatus'])) {
                            if (Tools::strlen(trim($data['StockStatus'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Imageurl2':
                        if (isset($data['Imageurl2'])) {
                            if (Tools::strlen(trim($data['Imageurl2'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Imageurl3':
                        if (isset($data['Imageurl3'])) {
                            if (Tools::strlen(trim($data['Imageurl3'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Imageurl4':
                        if (isset($data['Imageurl4'])) {
                            if (Tools::strlen(trim($data['Imageurl4'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Imageurl5':
                        if (isset($data['Imageurl5'])) {
                            if (Tools::strlen(trim($data['Imageurl5'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'AttributeSize':
                        if (isset($data['AttributeSize'])) {
                            if (Tools::strlen(trim($data['AttributeSize'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'AttributeColor':
                        if (isset($data['AttributeColor'])) {
                            if (Tools::strlen(trim($data['AttributeColor'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'DiscountPriceWithoutVAT':
                        if (isset($data['DiscountPriceWithoutVAT'])) {
                            if ((float)(trim($data['DiscountPriceWithoutVAT']))) {
                                $data['DiscountPriceWithoutVAT'] =
                                    number_format(trim($data['DiscountPriceWithoutVAT']), 2, '.', '');
                                if (Tools::strlen($data['DiscountPriceWithoutVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'DiscountPriceWithVAT':
                        if (isset($data['DiscountPriceWithVAT'])) {
                            if ((float)(trim($data['DiscountPriceWithoutVAT']))) {
                                $data['DiscountPriceWithVAT'] =
                                    number_format(trim($data['DiscountPriceWithVAT']), 2, '.', '');
                                if (Tools::strlen($data['DiscountPriceWithVAT']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'ISBN':
                        if (isset($data['ISBN'])) {
                            if ((int)(trim($data['ISBN']))) {
                                $data['ISBN'] = (int)trim($data['ISBN']);
                                if (Tools::strlen($data['ISBN']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'Manufacturer':
                        if (isset($data['Manufacturer'])) {
                            if (Tools::strlen(trim($data['Manufacturer'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'RestockDate':
                        if (isset($data['RestockDate'])) {
                            if (!$cedFruugoHelper->validDate($data['RestockDate'])) {
                                $result['error'] .= ' ' . $key .
                                    ' does not have a valid value ' . $value['length'] . '</br>';
                            } else {
                                if (Tools::strlen(trim($data['RestockDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            }
                        }
                        break;
                    case 'LeadTime':
                        if (isset($data['LeadTime'])) {
                            if ((int)(trim($data['LeadTime']))) {
                                $data['LeadTime'] = (int)trim($data['LeadTime']);
                                if (Tools::strlen($data['LeadTime']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'PackageWeight':
                        if (isset($data['PackageWeight'])) {
                            if ((int)(trim($data['PackageWeight']))) {
                                $data['PackageWeight'] = (int)trim($data['PackageWeight']);
                                if (Tools::strlen($data['PackageWeight']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'Attribute1':
                        if (isset($data['Attribute1'])) {
                            if (Tools::strlen(trim($data['Attribute1'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute2':
                        if (isset($data['Attribute2'])) {
                            if (Tools::strlen(trim($data['Attribute2'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute3':
                        if (isset($data['Attribute3'])) {
                            if (Tools::strlen(trim($data['Attribute3'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute4':
                        if (isset($data['Attribute4'])) {
                            if (Tools::strlen(trim($data['Attribute4'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute5':
                        if (isset($data['Attribute5'])) {
                            if (Tools::strlen(trim($data['Attribute5'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute6':
                        if (isset($data['Attribute6'])) {
                            if (Tools::strlen(trim($data['Attribute6'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute7':
                        if (isset($data['Attribute7'])) {
                            if (Tools::strlen(trim($data['Attribute7'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute8':
                        if (isset($data['Attribute8'])) {
                            if (Tools::strlen(trim($data['Attribute8'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute9':
                        if (isset($data['Attribute9'])) {
                            if (Tools::strlen(trim($data['Attribute9'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Attribute10':
                        if (isset($data['Attribute10'])) {
                            if (Tools::strlen(trim($data['Attribute10'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Country':
                        if (isset($data['Country'])) {
                            if (Tools::strlen(trim($data['Country'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Currency':
                        if (isset($data['Currency'])) {
                            if (Tools::strlen(trim($data['Currency'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'Language':
                        if (isset($data['Language'])) {
                            if (Tools::strlen(trim($data['Language'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'DiscountPriceStartDate':
                        if (isset($data['DiscountPriceStartDate'])) {
                            if (!$cedFruugoHelper->validDate($data['DiscountPriceStartDate'])) {
                                $result['error'] .= ' ' . $key . ' does not have a valid value ' .
                                    $value['length'] . '</br>';
                            } else {
                                if (Tools::strlen(trim($data['DiscountPriceStartDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            }
                        }
                        break;
                    case 'DiscountPriceEndDate':
                        if (isset($data['DiscountPriceEndDate'])) {
                            if (!$cedFruugoHelper->validDate($data['DiscountPriceEndDate'])) {
                                $result['error'] .= ' ' . $key .
                                    ' does not have a valid value ' . $value['length'] . '</br>';
                            } else {
                                if (Tools::strlen(trim($data['DiscountPriceEndDate'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            }
                        }
                        break;
                }
            } else {
                $result['error'] .= $key . ' is Required Field.' . '</br>';
            }
        }
        return $result;
    }

    public function saveProductVariants($variations, $product_id, $errors)
    {

        $db = Db::getInstance();
        $sql = "SELECT * FROM `" . _DB_PREFIX_ . "fruugo_product_variations` 
        where product_id=" . (int)$product_id . " AND `fruugo_status` !='NOTAVAILABLE'";

        $priviousChilds = $db->ExecuteS($sql);
        $previousChildSkus = array();
        if (is_array($priviousChilds) && count($priviousChilds)) {
            foreach ($priviousChilds as $priviousChild) {
                $previousChildSkus[trim($priviousChild['sku'])] = array(
                    'fruugoSkuId' => $priviousChild['fruugoSkuId']
                );
            }
            $previousChildSkus = array_filter($previousChildSkus);
        }
        $sql = "DELETE FROM `" . _DB_PREFIX_ . "fruugo_product_variations` 
        where `product_id`=" . (int)($product_id);
        $db->Execute($sql);
        foreach ($variations as $product) {
            if (isset($product['ProductId']) && isset($product['SkuId'])
                && $product['ProductId'] && $product['SkuId']) {
                $error = '';
                if (isset($errors[$product['SkuId']])) {
                    $error = $errors[$product['SkuId']];
                }

                $combination = array();
                if (isset($product['AttributeColor']) && $product['AttributeColor']) {
                    $combination['AttributeColor'] = $product['AttributeColor'];
                }
                if (isset($product['AttributeSize']) && $product['AttributeSize']) {
                    $combination['AttributeSize'] = $product['AttributeSize'];
                }

                if (!isset($product['StockStatus'])) {
                    $product['StockStatus'] = 'INSTOCK';
                }
                $result = $db->insert(
                    'fruugo_product_variations',
                    array(
                        'product_id' => (int)$product['ProductId'],
                        'fruugo_status' => (int)$product['StockStatus'],
                        'error_message' => pSQL($error),
                        'sku' => pSQL($product['SkuId']),
                        'combination' => pSQL(Tools::jsonEncode($combination))
                    )
                );

                if ($result) {
                    if (isset($previousChildSkus[trim($product['SkuId'])])
                        && $previousChildSkus[trim($product['SkuId'])]) {
                        unset($previousChildSkus[trim($product['SkuId'])]);
                    }
                }
            }
        }
        if (count($previousChildSkus)) {
            $this->removeFruugoVariation($previousChildSkus);
        }
    }

    public function removeFruugoVariation($eligibleForRemove)
    {
        $cedFruugoHelper = new CedfruugoHelper();
        if (count($eligibleForRemove)) {
            $remove_post = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
            $remove_post .= '<skus>';
            foreach ($eligibleForRemove as $value) {
                $remove_post .= '<sku fruugoSkuId="' . $value['fruugoSkuId'] . '">';
                $remove_post .= '<availability>NOTAVAILABLE</availability>';
                $remove_post .= '<itemsInStock>0</itemsInStock>';
                $remove_post .= '</sku>';
            }
            $remove_post .= '</skus>';
            $cedFruugoHelper->WPostRequest('stockstatus-api', array('data' => $remove_post));
        }
    }

    public function processUploadError($data)
    {

        if (count($data)) {
            $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
            foreach ($data as $key => $value) {
                if (!is_array($value)) {
                    $value = array($value);
                }
                $result = $db->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "fruugo_products` 
                where `product_id`='" . (int)$key . "'");

                if (count($result)) {
                    $db->update(
                        'fruugo_products',
                        array(
                            'error_message' => pSQL(implode('<br>', (array)$value)),
                        ),
                        'product_id='.(int)$key.''
                    );
                } else {
                    $db->insert(
                        'fruugo_products',
                        array(
                            'error_message' => pSQL(implode('<br>', (array)$value)),
                            'product_id' => (int)$key
                        )
                    );
                }
            }
        }
    }

    public function processUploadData($data)
    {

        $price_type = Configuration::get('CEDFRUUGO_PRICE_TYPE');
        $is_manufacturer = (int)Configuration::get('CEDFRUUGO_IS_MANUFACTURER');
        if (count($data)) {
            $db = Db::getInstance();
            foreach ($data as $pro) {
                switch ($price_type) {
                    case 'NormalPriceWithoutVAT':
                        $pro['NormalPriceWithVAT'] = '';
                        break;

                    case 'NormalPriceWithVAT':
                        $pro['NormalPriceWithoutVAT'] = '';
                        break;

                    default:
                        $pro['NormalPriceWithVAT'] = '';
                        break;
                }

                if ($pro['LeadTime'] && ($pro['StockStatus'] != 'INSTOCK')) {
                    $pro['LeadTime'] = '';
                }
                if (isset($pro['NormalPriceWithoutVAT']) && !empty($pro['NormalPriceWithoutVAT'])) {
                    $pro['NormalPriceWithoutVAT'] = $this->getPriceFruugo($pro['NormalPriceWithoutVAT']);
                }

                if (isset($pro['NormalPriceWithVAT']) && !empty($pro['NormalPriceWithVAT'])) {
                    $pro['NormalPriceWithVAT'] = $this->getPriceFruugo($pro['NormalPriceWithVAT']);
                }
                if ($is_manufacturer == 1) {
                    $ean = trim($pro['EAN']);
                    if (!isset($pro['EAN']) || empty($ean)) {
                        $pro['EAN'] = 'EXCEP';
                    }
                }

                if(isset($pro['Brand']) && !empty($pro['Brand'])) {
                    $brand = trim($pro['Brand']);
                    if(strlen($brand) > '50') 
                    {
                      $brand = substr($brand, 0, 50);
                    }
                }

                if(isset($pro['Title']) && !empty($pro['Title'])) {
                    $title = trim($pro['Title']);
                    if(strlen($title) > '150')
                    {
                        $title = substr($title, 0, 150);
                    }
                }

                $res = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fruugo_final_products` 
                WHERE `SkuId`='" . pSQL($pro['SkuId']) . "'");
                if ($res && count($res)) {
                    $db->update(
                        'fruugo_final_products',
                        array(
                            'Attribute1' => pSQL($pro['Attribute1']), 'Attribute2' => pSQL($pro['Attribute2']),
                            'Attribute3' => pSQL($pro['Attribute3']), 'Attribute4' => pSQL($pro['Attribute4']),
                            'Attribute5' => pSQL($pro['Attribute5']), 'Attribute6' => pSQL($pro['Attribute6']),
                            'Attribute7' => pSQL($pro['Attribute7']), 'Attribute8' => pSQL($pro['Attribute8']),
                            'Attribute9' => pSQL($pro['Attribute9']), 'Attribute10' => pSQL($pro['Attribute10']),
                            'AttributeColor' => pSQL($pro['AttributeColor']),
                            'AttributeSize' => pSQL($pro['AttributeSize']),
                            'Brand' => pSQL(ucwords(Tools::strtolower($brand))),
                            'Category' => pSQL($pro['Category']),
                            'Description' => pSQL(ucwords(Tools::strtolower($pro['Description']))),
                            'DiscountPriceEndDate' => pSQL($pro['DiscountPriceEndDate']),
                            'DiscountPriceStartDate' => pSQL($pro['DiscountPriceStartDate']),
                            'DiscountPriceWithVAT' => (float)$pro['DiscountPriceWithVAT'],
                            'DiscountPriceWithoutVAT' => (float)$pro['DiscountPriceWithoutVAT'],
                            'EAN' => pSQL($pro['EAN']),
                            'ISBN' => pSQL($pro['ISBN']), 'Imageurl1' => pSQL($pro['Imageurl1']),
                            'Imageurl2' => pSQL($pro['Imageurl2']),
                            'Imageurl3' => pSQL($pro['Imageurl3']), 'Imageurl4' => pSQL($pro['Imageurl4']),
                            'Imageurl5' => pSQL($pro['Imageurl5']), 'LeadTime' => (int)$pro['LeadTime'],
                            'Manufacturer' => pSQL(ucwords(Tools::strtolower($pro['Manufacturer']))),
                            'NormalPriceWithVAT' => (float)$pro['NormalPriceWithVAT'],
                            'NormalPriceWithoutVAT' => (float)$pro['NormalPriceWithoutVAT'],
                            'PackageWeight' => (int)$pro['PackageWeight'], 'ProductId' => pSQL($pro['ProductId']),
                            'RestockDate' => pSQL($pro['RestockDate']), 'SkuId' => pSQL($pro['SkuId']),
                            'StockQuantity' => (int)$pro['StockQuantity'],
                            'Country' => pSQL($pro['Country']), 'Currency' => pSQL($pro['Currency']),
                            'Language' => pSQL($pro['Language']),
                            'StockStatus' => pSQL($pro['StockStatus']),
                            'Title' => pSQL(ucwords(Tools::strtolower($title))),
                            'VATRate' => (int)$pro['VATRate'],
                        ),
                        'SkuId="' . pSQL($pro['SkuId']) . '"'
                    );
                } else {
                    $db->insert(
                        'fruugo_final_products',
                        array(
                            'Attribute1' => pSQL($pro['Attribute1']), 'Attribute2' => pSQL($pro['Attribute2']),
                            'Attribute3' => pSQL($pro['Attribute3']), 'Attribute4' => pSQL($pro['Attribute4']),
                            'Attribute5' => pSQL($pro['Attribute5']), 'Attribute6' => pSQL($pro['Attribute6']),
                            'Attribute7' => pSQL($pro['Attribute7']), 'Attribute8' => pSQL($pro['Attribute8']),
                            'Attribute9' => pSQL($pro['Attribute9']), 'Attribute10' => pSQL($pro['Attribute10']),
                            'AttributeColor' => pSQL($pro['AttributeColor']),
                            'AttributeSize' => pSQL($pro['AttributeSize']),
                            'Brand' => pSQL(ucwords(Tools::strtolower($brand))),
                            'Category' => pSQL($pro['Category']),
                            'Description' => pSQL(ucwords(Tools::strtolower($pro['Description']))),
                            'DiscountPriceEndDate' => pSQL($pro['DiscountPriceEndDate']),
                            'DiscountPriceStartDate' => pSQL($pro['DiscountPriceStartDate']),
                            'DiscountPriceWithVAT' => (float)$pro['DiscountPriceWithVAT'],
                            'DiscountPriceWithoutVAT' => (float)$pro['DiscountPriceWithoutVAT'],
                            'EAN' => pSQL($pro['EAN']),
                            'ISBN' => pSQL($pro['ISBN']), 'Imageurl1' => pSQL($pro['Imageurl1']),
                            'Imageurl2' => pSQL($pro['Imageurl2']),
                            'Imageurl3' => pSQL($pro['Imageurl3']), 'Imageurl4' => pSQL($pro['Imageurl4']),
                            'Imageurl5' => pSQL($pro['Imageurl5']), 'LeadTime' => (int)$pro['LeadTime'],
                            'Manufacturer' => pSQL(ucwords(Tools::strtolower($pro['Manufacturer']))),
                            'NormalPriceWithVAT' => (float)$pro['NormalPriceWithVAT'],
                            'NormalPriceWithoutVAT' => (float)$pro['NormalPriceWithoutVAT'],
                            'PackageWeight' => (int)$pro['PackageWeight'], 'ProductId' => pSQL($pro['ProductId']),
                            'RestockDate' => pSQL($pro['RestockDate']), 'SkuId' => pSQL($pro['SkuId']),
                            'StockQuantity' => (int)$pro['StockQuantity'],
                            'Country' => pSQL($pro['Country']), 'Currency' => pSQL($pro['Currency']),
                            'Language' => pSQL($pro['Language']),
                            'StockStatus' => pSQL($pro['StockStatus']),
                            'Title' => pSQL(ucwords(Tools::strtolower($title))),
                            'VATRate' => (int)$pro['VATRate'],
                        )
                    );
                }
            }
            $this->generateFeed();
        }
        return 'Csv Generated Successfully.';
    }

    public function generateFeed()
    {
        $cedFruugoHelper = new CedfruugoHelper();
        $db = Db::getInstance();
        $result = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fruugo_final_products`");
        $headers = array();
        $csv_dir = _PS_MODULE_DIR_ . 'cedfruugo/product_upload/';
        if (!is_dir($csv_dir)) {
            mkdir($csv_dir, '0777', true);
        }
        try {
            $file = fopen($csv_dir . 'product_feed.csv', 'w');
            foreach ($result as $row_data) {
                ksort($row_data);
                if ($row_data['LeadTime'] && ($row_data['StockStatus'] != 'INSTOCK')) {
                    $row_data['LeadTime'] = '';
                }

                 if (isset($row_data['NormalPriceWithoutVAT']) && $row_data['NormalPriceWithoutVAT']) {
                    $row_data['NormalPriceWithoutVAT'] = number_format((float)$row_data['NormalPriceWithoutVAT'], 2, '.', '');
                }

                if (isset($row_data['NormalPriceWithVAT']) && $row_data['NormalPriceWithVAT']) {
                    $row_data['NormalPriceWithVAT'] = (float)number_format($row_data['NormalPriceWithVAT'], 2, '.', '');
                }

                if (isset($row_data['DiscountPriceWithoutVAT']) && $row_data['DiscountPriceWithoutVAT']) {
                    $row_data['DiscountPriceWithoutVAT'] = number_format((float)$row_data['DiscountPriceWithoutVAT'], 2, '.', '');
                }

                if (isset($row_data['DiscountPriceWithVAT']) && $row_data['DiscountPriceWithVAT']) {
                    $row_data['DiscountPriceWithVAT'] = (float)number_format($row_data['DiscountPriceWithVAT'], 2, '.', '');
                }

                $row = $this->removeNullValuesFromFinalProducts($row_data);
                ksort($row);

                if (count($headers) == 0) {
                    $headers = array_keys($row);
                    fputcsv($file, $headers);
                    fputcsv($file, $row);
                } else {
                    fputcsv($file, $row);
                }
            }
            fclose($file);
        } catch (Exception $e) {
            $cedFruugoHelper->log(
                'CedfruugoProduct::generateFeed',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return $e->getMessage();
        }
    }

    public function getPriceFruugo($price)
    {
        $type = Configuration::get('CEDFRUUGO_PRICE_VARIANT_TYPE');
        $amount = Configuration::get('CEDFRUUGO_PRICE_VARIANT_AMOUNT');
        switch ($type) {
            case 1:
                $price = $price;
                break;
            case 2:
                $price = $price + $amount;
                break;

            case 3:
                $price = $price - $amount;
                break;

            case 4:
                $price = $price + (($price * $amount) / 100);

                break;

            case 5:
                $price = $price - (($price * $amount) / 100);
                break;

            default:
                $price = $price;
                break;
        }
        return (float)$price;
    }

    public function removeNullValuesFromFinalProducts($data = array())
    {
        if (count($data)) {
            foreach ($data as $key => $value) {
                if (($key == 'StockStatus' && $value != 'INSTOCK')
                    || ($key == 'StockQuantity' && !(int)$value)) {
                    $data['LeadTime'] = '';
                }
                if ($key == 'StockQuantity') {
                    continue;
                }
                if ($key == 'VATRate') {
                    continue;
                }

                if (!$value || ((string)$value == '0000-00-00')) {
                    $data[$key] = '';
                }
                if ($key == 'Category') {
                    $data[$key] = str_replace(array("\r", "\r\n", "\n"), '', $value);
                }
                // Brand
                if($key == 'Brand') {
                    $brand = trim($value);
                    if(strlen($brand) > '50') 
                    {
                      $data[$key] = substr($brand, 0, 50);
                    }
                }
                
                // Title
                if($key == 'Title') {
                    $title = trim($value);
                    if(strlen($title) > '150')
                    {
                      $data[$key] = substr($title, 0, 150);
                    }
                }
                
            }
        }
        return $data;
    }

    public function removeDuplicateNodes($file)
    {
        $csv_array = array();
        if (($handle = fopen($file, "r")) !== false) {
            while (($data = fgetcsv($handle, 4000, ",")) !== false) {
                if (isset($data['36']) && $data['36']) {
                    $csv_array[trim($data['36'])] = $data;
                }
            }
        }

        fclose($handle);
        $product_feed = fopen($file, 'w');
        $headers = array();
        foreach ($csv_array as $row) {
            ksort($row);
            if (count($headers) == 0) {
                $headers = $row;
                fputcsv($product_feed, $headers);
            } else {
                if (isset($row['39'])) {
                    $row['39'] = ucwords(Tools::strtolower($row['39']));
                }
                switch (Configuration::get('CEDFRUUGO_PRICE_TYPE')) {
                    case 'NormalPriceWithoutVAT':
                        $row['31'] = '';
                        break;

                    case 'NormalPriceWithVAT':
                        $row['32'] = '';
                        break;

                    default:
                        $row['31'] = '';
                        break;
                }
                fputcsv($product_feed, $row);
            }
        }
        fclose($product_feed);
    }

    public function updateStockByCron()
    {
        $cedfruugoHelper = new CedfruugoHelper();
        $db = Db::getInstance();
        $inventory_type = 'cronupdatestock';
        $sql = "SELECT `inventory_chunk` FROM `" . _DB_PREFIX_ . "fruugo_products_cron` 
                WHERE `type` = '".pSQL($inventory_type)."'";
        $result = $db->executeS($sql);
        $ids = array();
        if (count($result) && isset($result[0]['inventory_chunk'])
            && count($result[0]['inventory_chunk'])) {
            $ids = json_decode($result[0]['inventory_chunk'], true);
        }
        if (!count($ids)) {
            $product_ids = array();
            $allproducts = Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL');
            if ($allproducts) {
                $query = $db->ExecuteS("SELECT `id_product` FROM " . _DB_PREFIX_ . "product");
                if (is_array($query) && count($query)) {
                    foreach ($query as $value) {
                        if (isset($value['id_product']) && $value['id_product']) {
                            $product_ids[] = $value['id_product'];
                        }
                    }
                }
            } else {
                $query = $db->ExecuteS("SELECT `mapped_categories` 
                        FROM `" . _DB_PREFIX_ . "fruugo_category_list` where `mapped_categories` != '' 
                        ORDER BY `mapped_categories` DESC");

                if (is_array($query) && count($query)) {
                    foreach ($query as $value) {
                        if (isset($value['mapped_categories']) && $value['mapped_categories']) {
                            $value['mapped_categories'] = unserialize($value['mapped_categories']);
                            $sql = "SELECT DISTINCT cp.`id_product` 
                                    FROM `" . _DB_PREFIX_ . "category_product` cp  
                                    JOIN `"._DB_PREFIX_."product` p ON (p.`id_product` = cp.`id_product`) 
                                    WHERE  cp.`id_category`
                                     IN (" . implode(',', (array)$value['mapped_categories']) .
                                ")";
                            $query = $db->ExecuteS($sql);

                            if (is_array($query) && count($query)) {
                                foreach ($query as $val) {
                                    if (isset($val['id_product']) && $val['id_product']) {
                                        $product_ids[] = $val['id_product'];
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $product_ids = array_unique($product_ids);
            $ids = array_chunk($product_ids, 999);
            $db->insert(
                'fruugo_products_cron',
                array(
                    'inventory_chunk' => pSQL(Tools::jsonEncode($ids)),
                    'type' => pSQL($inventory_type)
                )
            );
        }
        $cedfruugoHelper->log(
            __METHOD__,
            'Info',
            'Total Inventory Chunk',
            Tools::jsonEncode($ids)
        );
        foreach ($ids as $key => $productIds) {
            $cedfruugoHelper->log(
                __METHOD__,
                'Info',
                'Processing Inventory Chunk',
                Tools::jsonEncode($productIds)
            );
            $result = $this->updateStock($productIds);
            if (isset($result) && isset($result['success']) && $result['success']) {
                unset($ids[$key]);
                $db->delete(
                    'fruugo_products_cron',
                    'type="'.pSQL($inventory_type).'"'
                );
                $db->insert(
                    'fruugo_products_cron',
                    array(
                        'inventory_chunk' => pSQL(Tools::jsonEncode($ids)),
                        'type' => pSQL($inventory_type)
                    )
                );
                $cedfruugoHelper->log(
                    __METHOD__,
                    'Info',
                    'Remaining Inventory Chunk',
                    Tools::jsonEncode($ids)
                );
            }
        }
    }

    public function updateStock($product_ids = array())
    {
        $db = Db::getInstance();
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        $cedFruugoHelper = new CedfruugoHelper();
        try {
            $response = false;
            if (count($product_ids)) {
                $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
                    (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
                    (int)Configuration::get('PS_LANG_DEFAULT');
                $inventory_chunk = array_chunk($product_ids, '100');
                foreach ($inventory_chunk as $productIds) {
                    $updatestock = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
                    $updatestock .= '<skus>';
                    $upload_inventry = false;
                    $response = false;
                    $feed_array = array();
                    foreach ($productIds as $product_id) {
                        $productObject = new Product($product_id, false, $default_lang);
                        if ($productObject->getAttributeCombinations($default_lang)) {
                            $product_combination = $this->getAttributesResume($product_id, $default_lang);
                            foreach ($product_combination as $product_single) {
                                if (isset($product_single['reference']) && isset($product_single['quantity'])) {
                                    $sku = $product_single['reference'];
                                    $quantity = $product_single['quantity'];
                                    $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku, true);
                                    if ($fruugoSkuId) {
                                        $upload_inventry = true;
                                        $updatestock .= '<sku fruugoSkuId="' . trim($fruugoSkuId) . '">';
                                        if ($quantity) {
                                            $updatestock .= '<availability>INSTOCK</availability>';
                                        } else {
                                            $updatestock .= '<availability>OUTOFSTOCK</availability>';
                                        }
                                        $updatestock .= '<itemsInStock>' . (int)$quantity . '</itemsInStock>';
                                        $updatestock .= '</sku>';
                                        $feed_array[] = array(
                                            'SkuId' => $sku,
                                            'StockQuantity' => $quantity,
                                            'StockStatus' => $quantity > 0 ? 'INSTOCK' : 'OUTOFSTOCK'
                                        );
                                    }
                                }
                            }
                        } else {
                            $product = (array)$productObject;
                            $query = Db::getInstance()->ExecuteS("SELECT `quantity` 
                                               FROM " . _DB_PREFIX_ . "stock_available 
                                               WHERE  `id_product` ='" . (int)$product_id . "'");
                            $quantity = 0;
                            if (isset($query['0']['quantity'])) {
                                $quantity = $query['0']['quantity'];
                            }
                            $sku = $product['reference'];
                            $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);
                            if ($fruugoSkuId) {
                                $upload_inventry = true;
                                $updatestock .= '<sku fruugoSkuId="' . trim($fruugoSkuId) . '">';
                                if ($quantity) {
                                    $updatestock .= '<availability>INSTOCK</availability>';
                                } else {
                                    $updatestock .= '<availability>OUTOFSTOCK</availability>';
                                }
                                $updatestock .= '<itemsInStock>' . (int)$quantity . '</itemsInStock>';
                                $updatestock .= '</sku>';
                                $feed_array[] = array(
                                    'SkuId' => $sku,
                                    'StockQuantity' => $quantity,
                                    'StockStatus' => $quantity > 0 ? 'INSTOCK' : 'OUTOFSTOCK'
                                );
                            }
                        }
                    }
                    $updatestock .= '</skus>';
                    $cedFruugoHelper->log(
                        __METHOD__,
                        'Info',
                        'Inventory Update Request data',
                        $updatestock
                    );
                    if ($updatestock && $upload_inventry) {
                        $params = array('data' => $updatestock);
                        $response = $cedFruugoHelper->WPostRequest('stockstatus-api', $params);
                        $cedFruugoHelper->log(
                            __METHOD__,
                            'Info',
                            'Inventory Update Response data',
                            Tools::jsonEncode($response)
                        );
                    }
                    if ($response) {
                        foreach ($feed_array as $feed) {
                            $db->update(
                                'fruugo_final_products',
                                array(
                                    'StockQuantity' => (int)$feed['StockQuantity'],
                                    'StockStatus' => pSQL($feed['StockStatus'])
                                ),
                                'SkuId="' . pSQL($feed['SkuId']) . '"'
                            );
                        }
                    }
                }
                $this->generateFeed();
                if ($response) {
                    return $response;
                }
                return array('success' => false, 'message' => 'No Response for stock Update');
            }
        } catch (Exception $e) {
            $cedFruugoHelper->log(
                'CedfruugoProduct::updateStock',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function getFruugoSkuId($product_id, $sku, $variation = false)
    {
        $db = Db::getInstance();
        if ($variation) {
            $query = $db->ExecuteS("SELECT `fruugoSkuId` FROM `" . _DB_PREFIX_ . "fruugo_product_variations` 
            WHERE  `product_id`='" . (int)$product_id . "' AND `sku` = '" . pSQL($sku) . "'");
            if (isset($query['0']['fruugoSkuId'])) {
                return $query['0']['fruugoSkuId'];
            }
            return false;
        } else {
            $query = $db->ExecuteS("SELECT `fruugoSkuId` FROM `" . _DB_PREFIX_ . "fruugo_products` 
            WHERE  `product_id`='" . (int)$product_id . "'");
            if (isset($query['0']['fruugoSkuId'])) {
                return $query['0']['fruugoSkuId'];
            }
            return false;
        }
    }

    public function deleteProductAtFruugo($product_ids = array())
    {
        $default_lang = ((int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFRUUGO_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $cedFruugoHelper = new CedfruugoHelper();
        $db = Db::getInstance();
        try {
            $updatestock = '';
            if (count($product_ids)) {
                $updatestock .= '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
                $updatestock .= '<skus>';
                $update_inventry = false;
                $response = false;
                foreach ($product_ids as $product_id) {
                    $productObject = new Product($product_id, false, $default_lang);
                    if ($productObject->getAttributeCombinations($default_lang)) {
                        $product_combination = $this->getAttributesResume($product_id, $default_lang);
                        foreach ($product_combination as $product_single) {
                            if (isset($product_single['reference'])) {
                                $sku = $product_single['reference'];
                                $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku, true);
                                if ($fruugoSkuId) {
                                    $update_inventry = true;
                                    $updatestock .= '<sku fruugoSkuId="' . trim($fruugoSkuId) . '">';
                                    $updatestock .= '<availability>NOTAVAILABLE</availability>';
                                    $updatestock .= '<itemsInStock>' . 0 . '</itemsInStock>';
                                    $updatestock .= '</sku>';
                                }
                            }
                        }
                    } else {
                        $product = (array)$productObject;
                        $sku = $product['reference'];
                        $fruugoSkuId = $this->getFruugoSkuId($product_id, $sku);
                        if ($fruugoSkuId) {
                            $update_inventry = true;
                            $updatestock .= '<sku fruugoSkuId="' . trim($fruugoSkuId) . '">';
                            $updatestock .= '<availability>NOTAVAILABLE</availability>';
                            $updatestock .= '<itemsInStock>' . 0 . '</itemsInStock>';
                            $updatestock .= '</sku>';
                        }
                    }
                }
                $updatestock .= '</skus>';
                $cedFruugoHelper->log(
                    __METHOD__,
                    'Info',
                    'Delete Product At fruugo Request data',
                    ($updatestock)
                );

                if ($updatestock && $update_inventry) {
                    $params = array('data' => $updatestock);
                    $response = $cedFruugoHelper->WPostRequest('stockstatus-api', $params);
                    $cedFruugoHelper->log(
                        __METHOD__,
                        'Info',
                        'Delete Product At fruugo Response data',
                        Tools::jsonEncode($response)
                    );
                }
                if ($response && $response['success']) {
                    $db->delete(
                        'fruugo_final_products',
                        'ProductId IN ('.implode(",", (array)$product_ids).')'
                    );
                    $db->delete(
                        'fruugo_products',
                        'product_id IN ('.implode(",", (array)$product_ids).')'
                    );
                    $db->delete(
                        'fruugo_product_variations',
                        'product_id IN ('.implode(",", (array)$product_ids).')'
                    );
                    $this->generateFeed();
                    return $response;
                }
                return array('success' => false, 'message' => 'No Fruugo Sku Found To Delete');
            }
        } catch (Exception $e) {
            $cedFruugoHelper->log(
                'CedfruugoProduct::deleteProductAtFruugo',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function fetchStock()
    {
        $cedFruugoHelper = new CedfruugoHelper();
        $params = array();
        $response = $cedFruugoHelper->fruugoGetRequest('stockstatus-api', $params);
        return $response;
    }

    public function getAllFruugoCategory()
    {
        $db = Db::getInstance();

        $mapped_category = array();
        $rows = $db->ExecuteS("SELECT `name` FROM `" . _DB_PREFIX_ . "fruugo_category_list`");
        $mapped_category[] = array('id' => '', 'name' => '');
        if (isset($rows['0']) && $rows['0']) {
            foreach ($rows as $row) {
                $mapped_category[] = array('id' => trim($row['name']), 'name' => trim($row['name']));
            }
        }
        return $mapped_category;
    }
    public function getAllMappedCategories()
    {
        $db = Db::getInstance();
        $row = $db->ExecuteS("SELECT `mapped_categories` 
        FROM `" . _DB_PREFIX_ . "fruugo_category_list` 
        WHERE `mapped_categories` != ''");

        if (isset($row['0']) && $row['0']) {
            $mapped_categories = array();
            foreach ($row as $value) {
                $mapped_categories = array_merge($mapped_categories, unserialize($value['mapped_categories']));
            }
            return $mapped_categories;
        } else {
            return array();
        }
    }
}
