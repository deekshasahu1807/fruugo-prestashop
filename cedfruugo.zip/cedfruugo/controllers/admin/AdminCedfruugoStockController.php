<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoHelper.php';
require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoProduct.php';
class AdminCedfruugoStockController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        parent::__construct();
    }
    public function ajaxProcessUpdateStock()
    {
        $this->updatestock(Tools::getAllvalues());
    }
    public function ajaxProcessUpdateStatus()
    {
        $this->updatestatus(Tools::getAllvalues());
    }
    public function updatestock($value)
    {
        if (isset($value['selected']) && $value['selected']) {
            $value = $value['selected'];
            if (is_array($value) && count($value)) {
                $cedfruugoProduct = new CedfruugoProduct;
                $response = $cedfruugoProduct->updateStock($value);
                die(json_encode(array(
                            'status' => true,
                            'message' => htmlspecialchars(json_encode($response))
                        )));
            }
        } else {
            die(json_encode(array(
                        'status' => true,
                        'message' => htmlspecialchars('Invalid Report Data.')
                )));
        }
    }
    public function updatestatus($value)
    {
        $db =  Db::getInstance();
        $cfruugo_helper = new CedfruugoHelper;
        try {
            if (isset($value['selected']) && $value['selected']) {
                $value = $value['selected'];
                if (is_array($value) && count($value)) {
                    $fruugoSkuId = $value['fruugoSkuId'];
                    $merchantSkuId = $value['merchantSkuId'];
                    $merchantProductId = $value['merchantProductId'];
                    $availability = isset($value['value']['availability'])?
                        $value['value']['availability']:'INSTOCK';
                    $result = $db->ExecuteS("SELECT `id` FROM `"._DB_PREFIX_."fruugo_product_variations` 
                    WHERE `sku`='".pSQL(trim($merchantSkuId))."'");
                    if (is_array($result) && isset($result['0'])) {
                        $result = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_product_variations` 
                        SET `fruugoSkuId` = '".pSQL($fruugoSkuId)."' `fruugo_status` = '".pSQL($availability)."' 
                        WHERE `sku`='".pSQL(trim($merchantSkuId))."'");
                        die(json_encode(array(
                                'status' => true,
                                'message' => htmlspecialchars($merchantSkuId.' 
                                Updated With fruugoSkuId : '.$fruugoSkuId)
                            )));
                    } else {
                        $result = $db->ExecuteS("SELECT `product_id` 
                                  FROM `"._DB_PREFIX_."fruugo_products` 
                                  WHERE `product_id`='".(int)trim($merchantProductId)."'");

                        if (isset($result['0']['product_id'])) {
                            $result = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_products` 
                            SET `fruugoSkuId` = '".pSQL($fruugoSkuId)."', `fruugo_status` = '".pSQL($availability)."' 
                            WHERE `product_id`='".(int)trim($result['0']['product_id'])."'");
                            die(json_encode(array(
                                'status' => true,
                                'message' => htmlspecialchars('Product Reference '.$merchantSkuId.
                                    ' Updated With fruugoSkuId : '.$fruugoSkuId)
                            )));
                        } else {
                            $db->Execute("INSERT INTO `"._DB_PREFIX_."fruugo_products` 
                            (`fruugoSkuId`, `fruugo_status`, `product_id`)
                             VALUES ('".pSQL($fruugoSkuId)."', '".pSQL($availability)."','".(int)$merchantProductId
                                ."')");
                            die(json_encode(array(
                                'status' => true,
                                'message' => htmlspecialchars('Product Reference '.$merchantSkuId.
                                    ' Updated With fruugoSkuId : '.$fruugoSkuId)
                            )));
                        }
                    }
                }
            } else {
                die(json_encode(array(
                            'status' => false,
                            'message' => htmlspecialchars('Invalid Report Data.')
                    )));
            }
        } catch (Exception $e) {
            $cfruugo_helper->log(
                'AdminCedfruugoStockController::updatestatus',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            die(json_encode(array(
                'status' => false,
                'message' =>$e->getMessage()
            )));
        }
    }
    public function initContent()
    {
        parent::initContent();
        $cfruugo_helper = new CedfruugoHelper;
        $cfruugoProduct = new CedfruugoProduct();
        if (Tools::getIsset('sync_qty') && Tools::getValue('sync_qty')) {
            $product_ids = array();
            $allproducts= Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL');
            if ($allproducts) {
                $query = Db::getInstance()->ExecuteS("SELECT `id_product`
                         FROM " . _DB_PREFIX_ . "product");
                if (is_array($query) && count($query)) {
                    foreach ($query as $value) {
                        if (isset($value['id_product']) && $value['id_product']) {
                            $product_ids[] = $value['id_product'];
                        }
                    }
                }
            } else {
                $query = Db::getInstance()->ExecuteS("SELECT `mapped_categories`
                         FROM `" . _DB_PREFIX_ . "fruugo_category_list` where `mapped_categories` != ''
                          ORDER BY `mapped_categories` DESC");
                    
                if (is_array($query) && count($query)) {
                    foreach ($query as $value) {
                        if (isset($value['mapped_categories']) && $value['mapped_categories']) {
                            $value['mapped_categories'] = unserialize($value['mapped_categories']);

                            $query = Db::getInstance()->ExecuteS("SELECT `id_product` 
                                    FROM " . _DB_PREFIX_ . "category_product WHERE  `id_category` 
                                    IN (" . implode(',', (array)$value['mapped_categories']) . ")");
                            if (is_array($query) && count($query)) {
                                foreach ($query as $val) {
                                    if (isset($val['id_product']) && $val['id_product']) {
                                        $product_ids[] = $val['id_product'];
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $product_ids = array_unique($product_ids);
            $link = new LinkCore();
            $updatestock = $link->getAdminLink('AdminCedfruugoStock');
            $this->context->smarty->assign(array('updatestock' => $updatestock));
            $this->context->smarty->assign(array('token' => $this->token));
            $this->context->smarty->assign(array('stock_array' => addslashes(json_encode($product_ids))));
            $content = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ . 'cedfruugo/views/templates/admin/stock/update.tpl'
            );
            $this->context->smarty->assign(array(
                'content' => $this->content . $content
            ));
        } else {
            $response_data = $cfruugoProduct->fetchStock();
            
            $report_array = array();
            if (isset($response_data['success']) && isset($response_data['response'])) {
                $response_data = $this->getparsedData($response_data['response']);
                if (isset($response_data['skus']['value']['sku'])
                    && count($response_data['skus']['value']['sku'])) {
                    $report_array = $response_data['skus']['value']['sku'];
                }
            } else {
                $cfruugo_helper->log(
                    'FetchStock',
                    'Info',
                    'FetchStock Response',
                    Tools::jsonEncode($response_data)
                );
            }
            $link = new LinkCore();
            $updatestatus = $link->getAdminLink('AdminCedfruugoStock');
            $this->context->smarty->assign(array('updatestatus' => $updatestatus));
            $this->context->smarty->assign(array('stock_array' => addslashes(json_encode($report_array))));

            $content = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ . 'cedfruugo/views/templates/admin/stock/form.tpl'
            );
            $this->context->smarty->assign(array(
                'content' => $this->content . $content
            ));
        }
    }
    // credit goes to github
    public function getparsedData(&$string)
    {
        $parser = xml_parser_create();
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parse_into_struct($parser, $string, $vals, $index);
        xml_parser_free($parser);
        $mnary=array();
        $ary=&$mnary;

        foreach ($vals as $r) {
            $t=$r['tag'];
            if ($r['type']=='open') {
                if (isset($ary[$t])) {
                    if (isset($ary[$t][0])) {
                        $ary[$t][]=array();
                    } else {
                        $ary[$t]=array($ary[$t], array());
                    }
                    $cv=&$ary[$t][count($ary[$t])-1];
                } else {
                    $cv=&$ary[$t];
                }
                if (isset($r['attributes'])) {
                    foreach ($r['attributes'] as $k => $v) {
                        $cv[$k]=$v;
                    }
                }
                $cv['value']=array();
                $cv['value']['_p']=&$ary;
                $ary=&$cv['value'];
            } elseif ($r['type']=='complete') {
                if (isset($ary[$t])) {
                    if (isset($ary[$t][0])) {
                        $ary[$t][]=array();
                    } else {
                        $ary[$t]=array($ary[$t], array());
                    }
                    $cv=&$ary[$t][count($ary[$t])-1];
                } else {
                    $cv=&$ary[$t];
                }
                if (isset($r['attributes'])) {
                    foreach ($r['attributes'] as $k => $v) {
                        $cv[$k]=$v;
                    }
                }
                $cv=(isset($r['value']) ? $r['value'] : '');
            } elseif ($r['type']=='close') {
                $ary=&$ary['_p'];
            }
        }
        
        $this->delP($mnary);
        return $mnary;
    }

    public function delP(&$ary)
    {
        foreach ($ary as $k => $v) {
            if ($k==='_p') {
                unset($ary[$k]);
            } elseif (is_array($v)) {
                $this->delP($ary[$k]);
            }
        }
    }
}
