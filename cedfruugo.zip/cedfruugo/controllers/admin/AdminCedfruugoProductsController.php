<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoHelper.php';
include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoProduct.php';

class AdminCedfruugoProductsController extends ModuleAdminController
{
    /**
     * @var string name of the tab to display
     */
    protected $tab_display;

    protected $object;

    protected $id_fruugocat;

    protected $product_attributes;

    protected $position_identifier = 'id_product';

    protected $submitted_tabs;

    protected $id_current_category;

    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->table = 'product';
        $this->className = 'Product';
        $this->lang = false;
        $this->list_no_link = true;
        $this->explicitSelect = true;
        $this->bulk_actions = array(
            'upload' => array(
                'text' => ('Upload selected'),
                'icon' => 'icon-upload',
            ),
            'sync' => array(
                'text' => ('Sync Quantity'),
                'icon' => 'icon-refresh',
            ),
            'remove' => array(
                'text' => ('Remove From Fruugo'),
                'icon' => 'icon-trash',
            ),
//            'assing_cat' => array(
//                'text' => ('Assign Fruugo Category'),
//                'icon' => 'icon-upload',
//            ),
            // 'remove_cat' => array(
            //     'text' => ('Remove Fruugo Category'),
            //     'icon' => 'icon-eraser',
            // ),
            'include' => array(
                'text' => ('Include In Feed'),
                'icon' => 'icon-refresh',
            ),
            'exclude' => array(
                'text' => ('Exclude From Feed'),
                'icon' => 'icon-eraser',
            )
        );
        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }

        parent::__construct();
         /* Join categories table */
        if ($id_category = (int)Tools::getValue('productFilter_cl!name')) {
            $this->_category = new Category((int)$id_category);
            $_POST['productFilter_cl!name'] = $this->_category->name[$this->context->language->id];
        } else {
            if ($id_category = (int)Tools::getValue('id_category')) {
                $this->id_current_category = $id_category;
                $this->context->cookie->id_category_products_filter = $id_category;
            } elseif ($id_category = $this->context->cookie->id_category_products_filter) {
                $this->id_current_category = $id_category;
            }
            if ($this->id_current_category) {
                $this->_category = new Category((int)$this->id_current_category);
            } else {
                $this->_category = new Category();
            }
        }
        $this->_join .= '
        LEFT JOIN `'._DB_PREFIX_.'stock_available` sav ON (sav.`id_product` = a.`id_product` 
        AND sav.`id_product_attribute` = 0
        '.StockAvailable::addSqlShopRestriction(null, null, 'sav').') ';

        $alias = 'sa';
        $alias_image = 'image_shop';

        $id_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int)$this->context->shop->id : 'a.id_shop_default';

        if (Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL')) {
            $walmart_cat_filter = false;
        } else {
            $walmart_cat_filter = true;
        }
        $catgories =array();
        if ($walmart_cat_filter) {
            $cedfruugoProduct = new CedfruugoProduct();
            $mapped_categories = $cedfruugoProduct->getAllMappedCategories();
            $mapped_categories = array_unique($mapped_categories);

            if (is_array($mapped_categories) && count($mapped_categories)) {
                $catgories = $mapped_categories;
                if (count($catgories)) {
                    $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
                    AND sa.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                    AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                    LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                    AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'fruugo_products` wp ON (wp.product_id = a.`id_product`)
                    LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                    AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                    LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                    AND pd.`active` = 1)';
                }
            } else {
                $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
                    AND sa.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                    AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                    LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                    AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'fruugo_products` wp ON (wp.product_id = a.`id_product`)
                    LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                    AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                    LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                    AND pd.`active` = 1)';
            }
        } else {
            $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
                    AND sa.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                    AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                    LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                    AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'fruugo_products` wp ON (wp.product_id = a.`id_product`)
                    LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                    AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                    LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                    LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                    AND pd.`active` = 1)';
        }

        
        $this->_select .= 'shop.`name` AS `shopname`, a.`id_shop_default`, ';
        
        $this->_select .= $alias_image.'.`id_image` AS `id_image`, a.`id_product` as `id_temp`, cl.`name` 
        AS `name_category`, '.$alias.'.`price`, 0 
        AS `price_final`, a.`is_virtual`, pd.`nb_downloadable`, sav.`quantity` 
        AS `sav_quantity`, '.$alias.'.`active`, IF(sav.`quantity`<=0, 1, 0) AS `badge_danger`';

        if (count($catgories)) {
            $this->_where = 'AND '.$alias.'.`id_category_default` IN ('.implode(',', (array)$catgories).')';
        }
        $this->_where .= 'AND wp.product_id > 0';
        $this->_use_found_rows = true;

        $this->fields_list = array();
        $this->fields_list['id_product'] = array(
            'title' => ('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );
        $this->fields_list['image'] = array(
            'title' => ('Image'),
            'align' => 'center',
            'image' => 'p',
            'orderby' => false,
            'filter' => false,
            'search' => false
        );
        $this->fields_list['name'] = array(
            'title' => ('Name'),
            'filter_key' => 'b!name',
            'class' => 'fixed-width-sm',
        );
        $this->fields_list['reference'] = array(
            'title' => ('Reference'),
            'align' => 'left',
        );


        if (Shop::isFeatureActive() && Shop::getContext() != Shop::CONTEXT_SHOP) {
            $this->fields_list['shopname'] = array(
                'title' => ('Default shop'),
                'filter_key' => 'shop!name',
            );
        } else {
            $this->fields_list['name_category'] = array(
                'title' => ('Category'),
                'filter_key' => 'cl!name',
            );
        }
        $this->fields_list['price'] = array(
            'title' => ('Base price'),
            'type' => 'price',
            'align' => 'text-right',
            'filter_key' => 'a!price'
        );
        $this->fields_list['price_final'] = array(
            'title' => ('Final price'),
            'type' => 'price',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => false,
            'search' => false
        );
       
        if (Configuration::get('PS_STOCK_MANAGEMENT')) {
            $this->fields_list['sav_quantity'] = array(
                'title' => ('Quantity'),
                'type' => 'int',
                'align' => 'text-right',
                'filter_key' => 'sav!quantity',
                'orderby' => true,
                'badge_danger' => true,
                'hint' => ('This is the quantity available in the current shop/group.'),
            );
        }

        $this->fields_list['active'] = array(
            'title' => ('Status'),
            'active' => 'status',
            'filter_key' => $alias.'!active',
            'align' => 'text-center',
            'type' => 'bool',
            'class' => 'fixed-width-sm',
            'orderby' => false
        );
        
        $this->fields_list['fruugo_status'] = array(
            'title' => ('Fruugo Status'),
            'type' => 'text',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => true,
            'class' => 'fixed-width-xs',
            'search' => true

        );
        $this->fields_list['fruugoSkuId'] = array(
            'title' => ('Fruugo Sku ID'),
            'type' => 'text',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => true,
            'class' => 'fixed-width-xs',
            'search' => true
        );

        $this->fields_list['error_message'] = array(
            'title' => $this->l('View Details'),
            'align' =>'text-left',
            'search' => false,
            'class' => 'fixed-width-xs',
            'callback' => 'viewDetailsButton',
        );

        if ($id_fruugocat = Tools::getValue('id_fruugocat')) {
            $this->id_fruugocat = $id_fruugocat;
            $this->context->cookie->id_fruugocat = $id_fruugocat;
        } elseif ($id_category = $this->context->cookie->id_fruugocat) {
            $this->id_fruugocat = $id_fruugocat;
        }

        // Any action performed w/o selecting product
        if (Tools::getIsset('productSelectError') && Tools::getValue('productSelectError')) {
            $this->errors[] = "Please Select Product";
        }

        // Save Product
        if (Tools::getIsset('productSaveSuccess') && Tools::getValue('productSaveSuccess')) {
            $this->confirmations[] = "Product Data Saved Successfully";
        }

        if (Tools::getIsset('productSaveError') && Tools::getValue('productSaveError')) {
            $this->errors[] = "Some error while saving Product Data";
        }

        // Upload Product
        if (Tools::getIsset('productUploadSuccess') && Tools::getValue('productUploadSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Uploaded Successfully!';
            }
        }

        if (Tools::getIsset('productUploadError') && Tools::getValue('productUploadError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to upload Product';
            }
        }

        // Include Product
        if (Tools::getIsset('productIncludeSuccess') && Tools::getValue('productIncludeSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Included Successfully!';
            }
        }

        if (Tools::getIsset('productIncludeError') && Tools::getValue('productIncludeError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to include Product';
            }
        }

        // Exclude Product
        if (Tools::getIsset('productExcludeSuccess') && Tools::getValue('productExcludeSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Excluded Successfully!';
            }
        }

        if (Tools::getIsset('productExcludeError') && Tools::getValue('productExcludeError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to exclude Product';
            }
        }

        // Remove Product Category
        if (Tools::getIsset('productRemoveCatSuccess') && Tools::getValue('productRemoveCatSuccess')) {
            $this->confirmations[] = "Category Removed Successfully";
        }

        // Assign Product Category
        if (Tools::getIsset('productAssignCatSuccess') && Tools::getValue('productAssignCatSuccess')) {
            $this->confirmations[] = "Category Assinged Successfully";
        }

        // Category not selected for assign product category
        if (Tools::getIsset('productAssignCatError') && Tools::getValue('productAssignCatError')) {
            $this->errors[] = "Please select Fruugo Category";
        }
    }

    public function viewDetailsButton($data, $rowData)
    {
        $productName = isset($rowData['name'])?$rowData['name']: '';
        $this->context->smarty->assign(
            array(
                'validationJson' => $data,
                'productName' => $productName
            )
        );
        return $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/product/product_validation_detail.tpl'
        );
    }
   
    protected function processBulkUpload($product_ids = array())
    {
        if (is_array($product_ids) && count($product_ids)) {
            $CedfruugoProduct = new CedfruugoProduct();
            $result = $CedfruugoProduct->uploadProducts($product_ids);
            return $result;
        }
    }

    public function initContent()
    {
        $page = (int) Tools::getValue('page');

        if ($id_fruugocat = $this->id_fruugocat) {
            self::$currentIndex .= '&id_fruugocat='.$this->id_fruugocat . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
        }
        parent::initContent();
    }

    public function processBulkAssignCat()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $db = Db::getInstance();
        $ids = $this->boxes;
        $CedfruugoProduct = new CedfruugoProduct();
        $fruugoCat = (int)$this->id_fruugocat;
        if(!empty($fruugoCat)) {
            $catName = $CedfruugoProduct->getCategoryNameById($fruugoCat);
            if(!empty($ids)) {
                foreach ($ids as $id) {
                    $data = $db->executeS(
                        "SELECT `id`, `attributes` FROM `" . _DB_PREFIX_ . "fruugo_products` 
                WHERE `product_id`='" . (int)$id . "'"
                    );

                    if (isset($data[0]['id'],$data[0]['attributes']) && !empty($data[0]['id'])) {
                        if(!empty($data[0]['attributes'])) {
                            $savedData = unserialize($data[0]['attributes']);
                        } else {
                            $savedData = array();
                        }
                        $savedData['Category'] = $catName;
                        $res = $db->update(
                            'fruugo_products',
                            array(
                                'attributes' => pSQL(serialize($savedData)),
                                'category' => pSQL($catName),
                            ),
                            'product_id='.(int)$id.''
                        );
                    } else {
                        $savedData = array();
                        $savedData['Category'] = $catName;
                        $res = $db->insert(
                            'fruugo_products',
                            array(
                                'attributes' => pSQL(serialize($savedData)),
                                'category' => pSQL($catName),
                                'product_id' => (int)$id
                            )
                        );
                    }
                }
                if($res) {
                    $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productAssignCatSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->confirmations[] = "Category Assinged Successfully";
                }
            } else {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = "Please select Product(s)";
            }
        } else {
            $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productAssignCatError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
            Tools::redirectAdmin($controller_link);
            $this->errors[] = "Please select Fruugo Category";
        }
        $this->id_fruugocat = '';
        $this->context->cookie->id_fruugocat = '';
    }

    public function processBulkRemoveCat()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $db = Db::getInstance();
        $ids = $this->boxes;
        if(count($ids)) {
            foreach ($ids as $id) {
                $data = $db->executeS(
                    "SELECT `id`, `attributes` FROM `" . _DB_PREFIX_ . "fruugo_products` 
                WHERE `product_id`='" . (int)$id . "'"
                );
                if (isset($data[0]['id'],$data[0]['attributes']) && !empty($data[0]['id'])) {
                    if(!empty($data[0]['attributes'])) {
                        $savedData = unserialize($data[0]['attributes']);
                    } else {
                        $savedData = array();
                    }
                    $savedData['Category'] = '';
                    $res = $db->update(
                        'fruugo_products',
                        array(
                            'attributes' => pSQL(serialize($savedData)),
                            'category' => pSQL(''),
                        ),
                        'product_id='.(int)$id.''
                    );
                } else {
                    $savedData = array();
                    $savedData['Category'] = '';
                    $res = $db->insert(
                        'fruugo_products',
                        array(
                            'attributes' => pSQL(serialize($savedData)),
                            'category' => pSQL(''),
                            'product_id' => (int)$id
                        )
                    );
                }
            }
            if($res) {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productRemoveCatSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->confirmations[] = "Category Removed Successfully";
            }
        } else {
            $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
            Tools::redirectAdmin($controller_link);
            $this->errors[] = "Please select Product(s)";
        }
        $this->id_fruugocat = '';
        $this->context->cookie->id_fruugocat = '';
    }

    protected function processBulkExclude()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $error_message = array();
        $success_message = array();

        $db = Db::getInstance();
        $ids = $this->boxes;
        if(count($ids))
        {
            foreach ($ids as $id)
            {
                $status = $db->getValue(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fruugo_products` 
                where `product_id`='" . (int)$id . "'"
                );
                if (!empty($status)) {
                    $res = $db->update(
                        'fruugo_products',
                        array(
                            'fruugo_status' => pSQL('Excluded'),
                        ),
                        'product_id='.(int)$id.''
                    );
                } else {
                    $res = $db->insert(
                        'fruugo_products',
                        array(
                            'fruugo_status' => pSQL('Excluded'),
                            'product_id' => (int)$id
                        )
                    );
                }
                if($res) {
                    $success_message[] = "Product Id $id Set To Excluded Successfully.";
                } else {
                    $error_message[] = "Failed To Exclude Product Id $id ";
                }
            }
            if(is_array($error_message) && !empty($error_message))
            {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productExcludeError=1&msg=' . json_encode(implode(',', $error_message)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productExcludeSuccess=1&msg=' . json_encode(implode(',', $success_message)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->confirmations[] = implode(',', $success_message);
            } else {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productExcludeError=1&msg=' . json_encode('Error while excluding product(s) - '. implode(',', $ids)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = 'Error while excluding product(s) - '. implode(',', $ids);
            }
        }

    }

    protected function processBulkInclude()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $error_message = array();
        $success_message = array();

        $db = Db::getInstance();
        $ids = $this->boxes;
        if(count($ids))
        {
            foreach ($ids as $id)
            {
                $status = $db->getValue(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fruugo_products` 
                WHERE `product_id`='" . (int)$id . "'"
                );
                if (!empty($status)) {
                    $res = $db->update(
                        'fruugo_products',
                        array(
                            'fruugo_status' => pSQL(''),
                        ),
                        'product_id='.(int)$id.''
                    );
                } else {
                    $res = $db->insert(
                        'fruugo_products',
                        array(
                            'fruugo_status' => pSQL(''),
                            'product_id' => (int)$id
                        )
                    );
                }
                if($res) {
                    $success_message[] = "Product Id $id Set To Included Successfully.";
                } else {
                    $error_message[] = "Failed To Include Product Id $id ";
                }
            }
            if(is_array($error_message) && !empty($error_message))
            {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productIncludeError=1&msg=' . json_encode(implode(',', $error_message)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productIncludeSuccess=1&msg=' . json_encode(implode(',', $success_message)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->confirmations[] = implode(',', $success_message);
            } else {
                $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productIncludeError=1&msg=' . json_encode('Error while including product(s) - '. implode(',', $ids)) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = 'Error while including product(s) - '. implode(',', $ids);
            }
        }
    }

    public function processBulkRemove()
    {
        if (Tools::getIsset('productBox') && Tools::getValue('productBox')) {
            $ids = Tools::getValue('productBox');
        } else {
            $ids = array();
        }
        if (count($ids)) {
            $CedfruugoProduct = new CedfruugoProduct();
            $ids_chunk = array_chunk($ids, 999);
            foreach ($ids_chunk as $product_ids) {
                $response = $CedfruugoProduct->deleteProductAtFruugo($product_ids);
                if ($response && $response['success']) {
                    $this->confirmations[] = 'Product Delete request sent at fruugo';
                } else {
                    $this->errors[] = $response['message'];
                }
            }
        }
    }

    public function processBulkSync()
    {
        $product_ids = array();
        if (Tools::getIsset('productBox') && Tools::getValue('productBox')) {
            $product_ids = Tools::getValue('productBox');
        }
        if (is_array($product_ids) && count($product_ids)) {
            $CedfruugoProduct = new CedfruugoProduct();
            $result = $CedfruugoProduct->updateStock($product_ids);
            if (isset($result['success']) && $result['success']) {
                $this->confirmations[] = 'Update request sent at fruugo.';
            } else {
                $this->errors[] = $result['message'];
            }
        }
    }
    
    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = false
    ) {
        $orderByPriceFinal = (empty($orderBy) ? ($this->context->cookie->__get($this->table.'Orderby') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'id_'.$this->table) : $orderBy);
        $orderWayPriceFinal = (empty($orderWay) ? ($this->context->cookie->__get($this->table.'Orderway') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'ASC') : $orderWay);
        if ($orderByPriceFinal == 'price_final') {
            $orderBy = 'id_'.$this->table;
            $orderWay = 'ASC';
        }
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
        $nothing = null;
        /* update product quantity with attributes ...*/
        $nb = count($this->_list);
        if ($this->_list) {
            $context = $this->context->cloneContext();
            $context->shop = clone($context->shop);
            /* update product final price */
            for ($i = 0; $i < $nb; $i++) {
                if (Context::getContext()->shop->getContext() != Shop::CONTEXT_SHOP) {
                    $context->shop = new Shop((int)$this->_list[$i]['id_shop_default']);
                }

                // convert price with the currency from context
                $this->_list[$i]['price'] = Tools::convertPrice(
                    $this->_list[$i]['price'],
                    $this->context->currency,
                    true,
                    $this->context
                );
                $this->_list[$i]['price_tmp'] = Product::getPriceStatic(
                    $this->_list[$i]['id_product'],
                    true,
                    null,
                    (int)Configuration::get('PS_PRICE_DISPLAY_PRECISION'),
                    null,
                    false,
                    true,
                    1,
                    true,
                    null,
                    null,
                    null,
                    $nothing,
                    true,
                    true,
                    $context
                );
            }
        }

        if ($orderByPriceFinal == 'price_final') {
            if (Tools::strtolower($orderWayPriceFinal) == 'desc') {
                uasort($this->_list, 'cmpPriceDesc');
            } else {
                uasort($this->_list, 'cmpPriceAsc');
            }
        }
        for ($i = 0; $this->_list && $i < $nb; $i++) {
            $this->_list[$i]['price_final'] = $this->_list[$i]['price_tmp'];
            unset($this->_list[$i]['price_tmp']);
        }
    }


    public function initProcess()
    {
        if (Tools::isSubmit('submitProductFormAndStay')
            || Tools::isSubmit('submitProductForm')) {
            $this->id_object = (int)Tools::getValue('id_product');
            $this->object = new Product($this->id_object);
            $this->tab_display = Tools::getValue('currentTab');
        }
        if (!$this->action) {
            parent::initProcess();
        } else {
            $this->id_object = (int)Tools::getValue($this->identifier);
        }
    }

    /**
     * postProcess handle every checks before saving products information
     *
     * @return void
     */
    public function postProcess()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();
        try {
            if (Tools::getIsset('action') && Tools::getIsset('country_code')
                && Tools::getValue('country_code')
                && (Tools::getValue('action')=='getFruugoLanguageCurrency')) {
                $this->getFruugoLanguageCurrency();
            }
            if (Tools::isSubmit('submitProductSave')) {
                $status = $this->saveFruugoProduct(Tools::getAllValues());
                if ($status) {
                    $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productSaveSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->confirmations[] = 'Product Data Saved Successfully.';
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productSaveError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] ='Some error while saving Product Data.';
                }
            }
            if (Tools::getIsset('submitBulkuploadproduct')) {
                if (Tools::getIsset('productBox')
                    &&  count(Tools::getValue('productBox'))) {
                    $result = $this->processBulkUpload(Tools::getValue('productBox'));

                    if (isset($result['error']) && $result['error']) {
                        $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productUploadError=1&msg=' . json_encode(implode(',', $result['error'])) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->errors[] = implode(',', $result['error']);
                    }
                    if (isset($result['success']) && $result['success']) {
                        $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productUploadSuccess=1&msg=' . json_encode($result['success']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->confirmations[] = $result['success'];
                    }
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfruugoProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] = 'Please Select Product';
                }
            }
            if (Tools::getIsset('clear_feed')) {
                $this->clearFeedData();
            }
        } catch (PrestaShopException $e) {
            $this->errors[] = $e;
        }
        parent::postProcess();
    }

    protected function isTabSubmitted($tab_name)
    {
        if (!is_array($this->submitted_tabs)) {
            $this->submitted_tabs = Tools::getValue('submitted_tabs');
        }

        if (is_array($this->submitted_tabs) && in_array($tab_name, $this->submitted_tabs)) {
            return true;
        }

        return false;
    }


    public function renderList()
    {
        $feed_url = Configuration::get('CEDFRUUGO_FEED_URL');
        $this->context->smarty->assign(array(
            'feed_url' => $feed_url
        ));
        $this->addRowAction('edit');
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/product/product_list.tpl'
        );
        $cedfruugoProduct = new CedfruugoProduct();
        $categories = $cedfruugoProduct->getAllFruugoCategories();
        if(Tools::getValue('submitFilterproduct')){
                $reurl = $this->context->link->getAdminLink('AdminCedfruugoProducts').'&submitFilterproduct='.Tools::getValue('submitFilterproduct');
        } else {
                $reurl = $this->context->link->getAdminLink('AdminCedfruugoProducts');
        }
        $this->context->smarty->assign(array(
            'controllerUrl' => $reurl,
            'token' => $this->token,
            'fruugoCategories' => $categories,
            'idCurrentFruugoCategory' => $this->id_fruugocat,
        ));
//        $r = $this->context->smarty->fetch(
//            _PS_MODULE_DIR_ . 'cedfruugo/views/templates/admin/product/category_selector.tpl');
        return $parent.parent::renderList();
    }


    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
                $this->page_header_toolbar_btn['clear_feed'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedfruugoProducts').'&clear_feed',
                    'desc' => 'Clear Feed',
                    'icon' => 'process-icon-eraser'
                );
            $this->page_header_toolbar_btn['download_feed'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfruugoProducts'),
                'desc' => 'Download Feed',
                'icon' => 'process-icon-download'
            );
                $this->page_header_toolbar_btn['upload_all'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedfruugoUploadall'),
                    'desc' => 'Upload All',
                    'icon' => 'process-icon-upload'
                );
                $this->page_header_toolbar_btn['fetch_status'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedfruugoStock').'&fetchstatus',
                    'desc' => 'Fetch fruugoSkuId',
                    'icon' => 'process-icon-download'
                );
                $this->page_header_toolbar_btn['sync_qty'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedfruugoStock').'&sync_qty=true',
                    'desc' => 'Update Stock',
                    'icon' => 'process-icon-upload'
                );
        }
        parent::initPageHeaderToolbar();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
        if ($this->display == 'edit' || $this->display == 'add') {
            $this->toolbar_btn['save'] = array(
                'short' => 'Save',
                'href' => '#',
                'desc' => ('Save'),
            );

            $this->toolbar_btn['save-and-stay'] = array(
                'short' => 'SaveAndStay',
                'href' => '#',
                'desc' => ('Save and stay'),
            );
        }

        $this->context->smarty->assign('toolbar_scroll', 1);
        $this->context->smarty->assign('show_toolbar', 1);
        $this->context->smarty->assign('toolbar_btn', $this->toolbar_btn);
    }

    public function clearFeedData()
    {
        $db = Db::getInstance();
        try {
            $sql = "DELETE FROM  `"._DB_PREFIX_."fruugo_final_products`";
            $res = $db->execute($sql);
            if ($res) {
                $csv_dir = _PS_MODULE_DIR_.'cedfruugo/product_upload/';
                if (!is_dir($csv_dir)) {
                    mkdir($csv_dir, '0777', true);
                }
                $file = fopen($csv_dir.'product_feed.csv', 'w');
                fputcsv($file, array());
                fclose($file);
                $this->confirmations[] = 'Feed data cleared successfully';
            } else {
                $this->errors[] = 'Failed to clear feed data';
            }
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();
        }
    }

    /**
     * renderForm contains all necessary initialization needed for all tabs
     *
     * @return string|void
     * @throws PrestaShopException
     */
    public function renderForm()
    {
        $this->product_name = $this->object->name[$this->context->language->id];
        $product = $this->object;
        $fruugoHelper = new CedfruugoHelper;
        $this->context->smarty->assign(
            array(
                'currentIndex' => self::$currentIndex,
                'currentToken' => $this->token,
                'currentObject' => $product,
                'hasAttribute' => $product->hasAttributes(),
            )
        );
        $db =  Db::getInstance();
        $fruugo_products = $db->ExecuteS("SELECT `attributes` 
        FROM `"._DB_PREFIX_."fruugo_products` 
        where `product_id`='".(int)$this->object->id."'");
        
        if (isset($fruugo_products['0']['attributes'])) {
            $fruugo_products = unserialize($fruugo_products['0']['attributes']);
        } elseif (count(Tools::getAllValues())) {
            $fruugo_products = Tools::getAllValues();
        } else {
            $fruugo_products = array();
        }
        
        $validation_array = $fruugoHelper->getValidationArray();

        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }
        if (isset($fruugo_products['fruugo_status'])) {
            $this->context->smarty->assign(array('fruugo_status' => $fruugo_products['fruugo_status']));
        }

        $this->context->smarty->assign(array('fruugo_products' => $fruugo_products));

        $this->context->smarty->assign(array('product_id' => Tools::getValue('product_id')));

        $page = (int)Tools::getValue('page');
        
        $this->context->smarty->assign(
            array('back'=> $this->context->link->getAdminLink('AdminCedfruugoProducts').($page > 1 ? '&page='.(int)$page : ''))
        );
               
        if (Validate::isLoadedObject(($this->object))) {
            $id_product = (int)$this->object->id;
        } else {
            $id_product = (int)Tools::getvalue('id_product');
        }

        $this->context->smarty->assign(array(
            'action' => $this->context->link->getAdminLink('AdminCedfruugoProducts').'&'.($id_product ?
                    'updateproduct&id_product='.(int)$id_product :
                    'uploadproduct').($page > 1 ? '&page='.(int)$page : '')));

        $this->context->smarty->assign(array('id_product' => $id_product));
        
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/product/product_form.tpl'
        );
        if (Tools::getValue('success_message')) {
            $this->confirmations[] = Tools::getValue('success_message');
        }
        parent::renderForm();
        return $parent;
    }
    public function getFruugoLanguageCurrency()
    {
        $cedfruugoHelper = new CedfruugoHelper;
        $response = array();
        $response['language'] = $cedfruugoHelper->getFruugoLanguage();
        $response['currency'] = $cedfruugoHelper->getFruugoCurrencyCode();
        die(json_encode($response));
    }
   
    public function saveFruugoProduct($data)
    {
        $db =  Db::getInstance();
        if (isset($data['submitProductSave'])) {
            unset($data['submitProductSave']);
        }
        if (isset($data['controller'])) {
            unset($data['controller']);
        }
        if (isset($data['token'])) {
            unset($data['token']);
        }
        if (isset($data['controllerUri'])) {
            unset($data['controllerUri']);
        }

        $id_product = Tools::getValue('id_product');

        if (isset($id_product) && $id_product) {
            $result = $db->ExecuteS("SELECT * FROM `"._DB_PREFIX_."fruugo_products` 
            where `product_id`='".(int)$id_product."'");
        
            if (count($result)) {
                $status = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_products` 
                SET `attributes` = '".pSQL(serialize($data))."' 
                where `product_id`='".(int)$id_product."'");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            } else {
                $status = $db->Execute("INSERT INTO `"._DB_PREFIX_."fruugo_products` 
                (`attributes`, `product_id`) 
                VALUES ('".pSQL(serialize($data))."', '".(int)$id_product."')");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
//    public function setMedia($isNewTheme = false)
//    {
//        parent::setMedia();
//        $this->addJqueryUI('ui.datepicker');
//    }
}
