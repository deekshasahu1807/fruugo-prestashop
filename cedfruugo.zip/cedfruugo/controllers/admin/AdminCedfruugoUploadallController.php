<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoHelper.php';
require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoProduct.php';
class AdminCedfruugoUploadallController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        parent::__construct();
    }
    public function ajaxProcessUploadAll()
    {
            $cedfruugoHelper = new CedfruugoHelper;
            $cedfruugoProduct = new CedfruugoProduct;
        try {
            if (is_array(Tools::getValue('selected')) && count(Tools::getValue('selected'))) {
                $result = $cedfruugoProduct->uploadProducts(Tools::getValue('selected'));
                $cedfruugoHelper->log(
                    'UploadAll',
                    'Info',
                    'Products Ids',
                    Tools::jsonEncode(Tools::getValue('selected'))
                );
                $cedfruugoHelper->log(
                    'UploadAll',
                    'Info',
                    'Response',
                    Tools::jsonEncode($result)
                );

                die(json_encode(array(
                    'status' => true,
                    'message' => $result
                )));
            }
        } catch (\Exception $e) {
            $cedfruugoHelper->log(
                'AdminCedfruugoUploadallController::UploadAll',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            die(json_encode(array(
                'status' => true,
                'message' => $e->getMessage()
            )));
        }
    }
    public function initContent()
    {
        parent::initContent();

        $smarty = $this->context->smarty;
        $product_ids = array();
        $allproducts= Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL');
        if ($allproducts) {
            $query = Db::getInstance()->ExecuteS("SELECT `id_product` 
                     FROM " . _DB_PREFIX_ . "product");
            if (is_array($query) && count($query)) {
                foreach ($query as $value) {
                    if (isset($value['id_product']) && $value['id_product']) {
                        $product_ids[] = $value['id_product'];
                    }
                }
            }
        } else {
            $query = Db::getInstance()->ExecuteS("SELECT `mapped_categories` 
                       FROM `" . _DB_PREFIX_ . "fruugo_category_list` WHERE `mapped_categories` != '' 
                       ORDER BY `mapped_categories` DESC");
                
            if (is_array($query) && count($query)) {
                foreach ($query as $value) {
                    if (isset($value['mapped_categories']) && $value['mapped_categories']) {
                        $value['mapped_categories'] = unserialize($value['mapped_categories']);
                        $categories = implode(',', $value['mapped_categories']);

                        if($categories)
                        {
                            $pro_query = Db::getInstance()->ExecuteS("SELECT p.`id_product` 
                                FROM `" . _DB_PREFIX_ . "category_product` cp
                                LEFT JOIN `" . _DB_PREFIX_ . "product` p ON (p.id_product = cp.id_product)
                                LEFT JOIN `"._DB_PREFIX_."fruugo_products` fp ON (p.id_product = fp.`product_id`)
                                WHERE p.`id_category_default` IN (" . $categories . ")");

                            if (is_array($pro_query) && count($pro_query)) {
                                foreach ($pro_query as $val) {
                                    if (isset($val['id_product']) && $val['id_product']) {
                                        $product_ids[] = $val['id_product'];
                                    }
                                }
                            }
                        }
                    }
                }
            }


            $fruu_pro_query =  Db::getInstance()->ExecuteS("SELECT `product_id` FROM `". _DB_PREFIX_ ."fruugo_products`
                WHERE `fruugo_status` != 'Excluded' ");

            if (is_array($fruu_pro_query) && count($fruu_pro_query)) {
                foreach ($fruu_pro_query as $valu) {
                    if (isset($valu['product_id']) && $valu['product_id']) {
                        $product_ids[] = $valu['product_id'];
                    }
                }
            }
        }

        $product_ids = array_unique($product_ids);
        asort($product_ids);
        $product_ids = array_values($product_ids);
        //echo '<pre>'; print_r($product_ids); die;
        $this->context->smarty->assign(array('upload_array' => addslashes(json_encode($product_ids))));
        $this->context->smarty->assign(array('token' => $this->token));
        $link = new LinkCore();
        $updatestatus = $link->getAdminLink('AdminCedfruugoUploadall').'&uploadall=true';
        $this->context->smarty->assign(array('updatestatus' => $updatestatus));

        $content = $smarty->fetch(
            _PS_MODULE_DIR_ . 'cedfruugo/views/templates/admin/product/uploadallform.tpl'
        );
        $this->context->smarty->assign(array(
            'content' => $this->content . $content
        ));
    }
}
