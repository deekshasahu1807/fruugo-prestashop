<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoHelper.php';
class AdminCedfruugoDefaultController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;

        if (Tools::getIsset('submitDefaultValue') && (count(Tools::getAllValues())>4)) {
            $post = Tools::getAllValues();
            unset($post['submitDefaultValue']);
            unset($post['controller']);
            unset($post['token']);
            unset($post['controllerUri']);
            $response = $this->saveDefaultValueToFruugo($post);
            if ($response) {
                $this->confirmations[] = 'Default Value saved Successfully.';
            } else {
                $this->errors[] = ' There may be some error .';
            }
        }
        parent::__construct();
    }
    public function renderList()
    {
        $cedfruugoProduct = new CedfruugoProduct();
        $cedfruugoHelper = new CedfruugoHelper();
        $validation_array = $cedfruugoHelper->getValidationArray();
        $this->context->smarty->assign(
            array(
                'currentIndex' => self::$currentIndex,
                'currentToken' => $this->token,
            )
        );
        $already_default = $cedfruugoProduct->getSavedDefaultValues();
        if (is_array($already_default) && count($already_default)) {
            $this->context->smarty->assign(array('already_default'  => $already_default));
        } else {
            $this->context->smarty->assign(array('already_default'  => array()));
        }


        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }

        $this->context->smarty->assign(array('action'=> $this->context->link->getAdminLink('AdminCedfruugoDefault')));
        $this->context->smarty->assign(array('back'=> $this->context->link->getAdminLink('AdminCedfruugoDefault')));
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/default/default_form.tpl'
        );
        parent::renderList();
        return $parent;
    }
   
    public function saveDefaultValueToFruugo($data)
    {
        $db = Db::getInstance();
        $db->Execute("DELETE FROM `"._DB_PREFIX_."fruugo_default_values`");
        $sql = "INSERT INTO `"._DB_PREFIX_."fruugo_default_values` (`fruugo_attribute`, `default_value`) VALUES ";
        foreach ($data as $key => $value) {
            $sql .= "('".pSQL($key)."', '".pSQL($value)."'), ";
        }
        $sql = rtrim($sql, ', ');
        $status = $db->Execute($sql);
        if ($status) {
            return true;
        } else {
            return false;
        }
    }
    public function getFruugoLanguageCurrency()
    {
        $cedfruugoHelper = new CedfruugoHelper;
        $response = array();
        $response['language'] = $cedfruugoHelper->getFruugoLanguage();
        $response['currency'] = $cedfruugoHelper->getFruugoCurrencyCode();
        die(json_encode($response));
    }
}
