<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoHelper.php';
require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoProduct.php';
class AdminCedfruugoAttributeController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
     
        if (Tools::getIsset('submitAttributeMapping') && (count(Tools::getAllValues())>4)) {
            $post = Tools::getAllValues();
            unset($post['submitAttributeMapping']);
            unset($post['controller']);
            unset($post['token']);
            unset($post['controllerUri']);
            $response = $this->mapAttributeToFruugo($post);
            if ($response) {
                $this->confirmations[] = 'Attributes Mapped Successfully.';
            } else {
                $this->errors[] = 'Not Mapped, There may be some error .';
            }
        }
        parent::__construct();
    }
    public function renderList()
    {
        $fruugoHelper = new CedfruugoHelper;
        $fruugoProduct = new CedfruugoProduct();
        $already_mapped = array();
        $mapped_variant_attribute = array();
        $validation_array = $fruugoHelper->getValidationArray();
        $variant_attributes = $fruugoHelper->variantAttributes();
        $fruugo_mapped_attributes = $fruugoProduct->getMappedAttributes();
        foreach ($fruugo_mapped_attributes as $fruugoAttr => $presAttr) {
            if (!is_array($presAttr)) {
                $already_mapped[$fruugoAttr] = $presAttr;
            } else {
                $mapped_variant_attribute[$fruugoAttr] = $presAttr;
            }
        }
        if (is_array($already_mapped) && count($already_mapped)) {
            $this->context->smarty->assign(array('already_mapped'  => $already_mapped));
        } else {
            $this->context->smarty->assign(array('already_mapped'  => array()));
        }
        if (is_array($mapped_variant_attribute) && count($mapped_variant_attribute)) {
            $this->context->smarty->assign(array('mapped_variant_attribute'  => $mapped_variant_attribute));
        } else {
            $this->context->smarty->assign(array('mapped_variant_attribute'  => array()));
        }


        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }
        if (is_array($variant_attributes) && count($variant_attributes)) {
            $this->context->smarty->assign(array('variant_attributes'  => $variant_attributes));
        } else {
            $this->context->smarty->assign(array('variant_attributes'  => array()));
        }

        $features = $this->getFeatures();
        if (is_array($features) && count($features)) {
            $this->context->smarty->assign(array('features'  => $features));
        } else {
            $this->context->smarty->assign(array('features'  => array()));
        }

        $store_attributes = $this->getAttributes();
        if (is_array($store_attributes) && count($store_attributes)) {
            $this->context->smarty->assign(array('store_attributes'  => $store_attributes));
        } else {
            $this->context->smarty->assign(array('store_attributes'  => array()));
        }

        $system_attributes = $this->getSystemAttributes();
        if (is_array($system_attributes) && count($system_attributes)) {
            $this->context->smarty->assign(array('system_attributes'  => $system_attributes));
        } else {
            $this->context->smarty->assign(array('system_attributes'  => array()));
        }


        $this->context->smarty->assign(array('action'=> $this->context->link->getAdminLink('AdminCedfruugoAttribute')));
        $this->context->smarty->assign(array('back'=> $this->context->link->getAdminLink('AdminCedfruugoAttribute')));
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/attribute_map/form.tpl'
        );
        $this->informations[] = 'Map all the required Attributes that are mandatory at fruugo';
        parent::renderList();
        return $parent;
    }
   
    public function getFeatures()
    {
        $db = Db::getInstance();
        $default_lang = ((int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $sql="SELECT `id_feature`,`name` FROM `"._DB_PREFIX_."feature_lang` 
              where `id_lang`='".(int)$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }
    public function getAttributes()
    {
        $db = Db::getInstance();
        $default_lang = ((int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $sql="SELECT `id_attribute_group` as `id_attribute`,`name` 
               FROM `"._DB_PREFIX_."attribute_group_lang` 
               where `id_lang`='".(int)$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }
    public function getSystemAttributes()
    {
        return array(
            'reference' => 'Reference',
            'name'      => 'Name',
            'description' => 'Description',
            'description_short' => 'Short Description',
            'id_manufacturer' => 'Manufacturer',
            'id_tax_rules_group' => 'Tax Rule',
            'price' => 'Price (Tax Excl.)',
            'price_ttc' => 'Price (Tax Incl.)',
            'upc' => 'UPC',
            'ean13' => 'EAN',
            'quantity' => 'Quantity',
            'length' => 'Length',
            'width' => 'Width',
            'height' => 'Height',
            'weight' => 'Weight'
            );
    }
    public function mapAttributeToFruugo($data)
    {
        $fruugoHelper = new CedfruugoHelper();
        $variant_attributes = array_keys($fruugoHelper->variantAttributes());
        foreach ($variant_attributes as $at) {
            if (!in_array($at, array_keys($data))) {
                $data[$at] = array( 0=>'');
            }
        }
        $db = Db::getInstance();
        $db->Execute("DELETE FROM `"._DB_PREFIX_."fruugo_attribute_mapping`");
        $sql = "INSERT INTO `"._DB_PREFIX_."fruugo_attribute_mapping` 
        (`fruugo_attribute`, `prestashop_attribute`,`fruugoSkuId`) 
        VALUES ";
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sql .= "('".pSQL($key)."', '".pSQL(json_encode($value))."', '".(int)'1'."'),";
            } else {
                $sql .= "('".pSQL($key)."', '".pSQL($value)."', '".(int)'0'."'), ";
            }
        }
        $sql = rtrim($sql, ', ');
        $status = $db->Execute($sql);
        if ($status) {
            return true;
        } else {
            return false;
        }
    }
}
