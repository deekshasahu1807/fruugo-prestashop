<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoCategory.php';
class AdminCedfruugoCategoryController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        $this->table      = 'fruugo_category_list';
        $this->identifier = 'id';
        $this->list_no_link = true;
        $this->addRowAction('mapcategory');
        $this->fields_list = array(
            'id'       => array(
                'title' => 'ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'name'     => array(
                'title' => 'Name',
                'type'  => 'text',
            ),
        );
        $this->fields_list['mapped_categories'] = array(
            'title' =>'View Mapping',
            'align' =>'text-left',
            'search' => false,
            'callback' => 'viewMappingButton',
        );

        
        if (Tools::getIsset('submitCategoryMapping') && Tools::getIsset('id')) {
            $response = $this->mapCategoryToFruugo(Tools::getAllValues());
            if ($response) {
                $this->confirmations[] = 'Category Mapped Successfully.';
            } else {
                $this->errors[] = 'Not Mapped, There may be some error .';
            }
        }
        parent::__construct();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
    }
    public function viewMappingButton($id)
    {
        if ($id) {
            // $default_lang = ((int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'))?
            //     (int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'):
            //     (int) Configuration::get('PS_LANG_DEFAULT');
            $category_ids = unserialize($id);
            $result = array();
            if (count($category_ids)) {
                $result = Db::getInstance()->ExecuteS("SELECT `name`,`id_category` 
                         FROM 
                         `"._DB_PREFIX_."category_lang`  
                         WHERE 
                         `id_category` IN (".implode(',', (array)$category_ids).") AND 
                         id_lang='".Context::getContext()->language->id."' AND 
                         id_shop='".Context::getContext()->shop->id."'");
            }

            $this->context->smarty->assign(array(
               'category_ids' => $category_ids,
               'result' => $result,
               'id' => $id,
            ));
        } else {
            $this->context->smarty->assign(array(
                'category_ids' => array(),
                'result' => array(),
                'id' => null,
            ));
        }
        return $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/category_map/mapped_category.tpl'
        );
    }
    public function renderForm()
    {
        $default_lang = ((int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $store_categories = Category::getAllCategoriesName(null, $default_lang);
        $mapped_categories = $this->getMappedCategories(Tools::getValue('id'));
        $disable_categories = $this->getCategoriesToDisable(Tools::getValue('id'));

        if (is_array($mapped_categories) && count($mapped_categories)) {
            $this->context->smarty->assign(array('mapped_categories'  => $mapped_categories));
        } else {
            $this->context->smarty->assign(array('mapped_categories'  => array()));
        }
        if (is_array($disable_categories) && count($disable_categories)) {
            $this->context->smarty->assign(array('disable_categories'  => $disable_categories));
        } else {
            $this->context->smarty->assign(array('disable_categories'  => array()));
        }
        $this->context->smarty->assign(array(
            'action'=> $this->context->link->getAdminLink('AdminCedfruugoCategory').'&id='.Tools::getValue('id')));
        $this->context->smarty->assign(array(
            'back'=> $this->context->link->getAdminLink('AdminCedfruugoCategory')));
        if (is_array($store_categories) && count($store_categories)) {
            $this->context->smarty->assign(array('store_categories'  => $store_categories));
        } else {
            $this->context->smarty->assign(array('store_categories'  => array()));
        }
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/category_map/form.tpl'
        );
        parent::renderForm();
        return $parent;
    }
    public function displayMapcategoryLink($token = null, $id = null)
    {
        if ($token) {
            $tpl = $this->createTemplate('helpers/list/list_action_edit.tpl');
        } else {
            $tpl = $this->createTemplate('helpers/list/list_action_edit.tpl');
        }
        if (!array_key_exists('Edit Mapping', self::$cache_lang)) {
            self::$cache_lang['Edit Mapping'] = $this->l('Edit Mapping', 'Helper');
        }

        $tpl->assign(array(
                'href' => Context::getContext()->link->getAdminLink('AdminCedfruugoCategory')
                    .'&updatefruugo_category_list&id='.$id,
                'action' => self::$cache_lang['Edit Mapping'],
                'id' => $id
        ));

        return $tpl->fetch();
    }
    public function mapCategoryToFruugo($category_map)
    {
        $db = Db::getInstance();
        if (!isset($category_map['store_category'])) {
            $category_map['store_category'] = array();
        }
        $row = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_category_list` 
        SET `mapped_categories` = '".pSQL(serialize($category_map['store_category']))."' 
        WHERE `id`='".(int)$category_map['id']."'");
        if ($row) {
            return true;
        } else {
            return false;
        }
    }
    public function getMappedCategories($category_id)
    {
        $db = Db::getInstance();
        $row = $db->getRow("SELECT `mapped_categories` FROM `"._DB_PREFIX_."fruugo_category_list` 
        WHERE `id`='".(int)$category_id."'");
        if (isset($row['mapped_categories']) && $row['mapped_categories']) {
            return unserialize($row['mapped_categories']);
        } else {
            return array();
        }
    }
    public function getCategoriesToDisable($category_id)
    {
        $db = Db::getInstance();
        $row = $db->ExecuteS("SELECT `mapped_categories` FROM `"._DB_PREFIX_."fruugo_category_list` 
        WHERE `mapped_categories` != '' AND `id` != '".(int)$category_id."'");
        
        if (isset($row['0']) && $row['0']) {
            $mapped_categories = array();
            foreach ($row as $value) {
                $mapped_categories = array_merge($mapped_categories, unserialize($value['mapped_categories']));
            }
            return $mapped_categories  ;
        } else {
            return array();
        }
    }
}
