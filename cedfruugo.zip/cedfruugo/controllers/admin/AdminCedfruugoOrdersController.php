<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoHelper.php';
include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoOrder.php';
class AdminCedfruugoOrdersController extends ModuleAdminController
{
    public $toolbar_title;

    protected $statuses_array = array();
    protected $bulk_actions;
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'order';
        $this->className = 'Order';
        $this->lang = false;
        $this->addRowAction('view');
        $this->addRowAction('acknowledge');
        $this->addRowAction('reject');
        
        $this->explicitSelect = true;
        $this->allow_export = true;
        $this->deleted = false;
        $this->context = Context::getContext();

        $this->_select = '
        a.id_currency,
        a.id_order AS id_pdf,
        CONCAT(LEFT(c.`firstname`, 1), \'. \', c.`lastname`) AS `customer`,
        osl.`name` AS `osname`,
        os.`color`,
        IF((SELECT so.id_order FROM `'._DB_PREFIX_.'orders` so WHERE so.id_customer = a.id_customer
         AND so.id_order < a.id_order LIMIT 1) > 0, 0, 1) as new,
        country_lang.name as cname,
        IF(a.valid, 1, 0) badge_success';

        $this->_join = '
        LEFT JOIN `'._DB_PREFIX_.'customer` c ON (c.`id_customer` = a.`id_customer`)
        JOIN `'._DB_PREFIX_.'fruugo_order` wo ON (wo.`prestashop_order_id` = a.`id_order`)
        LEFT JOIN `'._DB_PREFIX_.'address` address ON address.id_address = a.id_address_delivery
        LEFT JOIN `'._DB_PREFIX_.'country` country ON address.id_country = country.id_country
        LEFT JOIN `'._DB_PREFIX_.'country_lang` country_lang 
        ON (country.`id_country` = country_lang.`id_country` 
        AND country_lang.`id_lang` = '.(int)$this->context->language->id.')
        LEFT JOIN `'._DB_PREFIX_.'order_state` os 
        ON (os.`id_order_state` = a.`current_state`)
        LEFT JOIN `'._DB_PREFIX_.'order_state_lang` osl 
        ON (os.`id_order_state` = osl.`id_order_state` 
        AND osl.`id_lang` = '.(int)$this->context->language->id.')';
        $this->_orderBy = 'id_order';
        $this->_orderWay = 'DESC';
        $this->_use_found_rows = true;

        $statuses = OrderState::getOrderStates((int)$this->context->language->id);
        foreach ($statuses as $status) {
            $this->statuses_array[$status['id_order_state']] = $status['name'];
        }

        $this->fields_list = array(
            'id_order' => array(
                'title' => 'ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'fruugo_order_id' => array(
                'title' => 'Purchase Order ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'reference' => array(
                'title' => 'Reference'
            ),
            'customer' => array(
                'title' => 'Customer',
                'havingFilter' => true,
            ),
        );

        $this->fields_list = array_merge($this->fields_list, array(
            'total_paid_tax_incl' => array(
                'title' => 'Total',
                'align' => 'text-right',
                'type' => 'price',
                'currency' => true,
                'callback' => 'setOrderCurrency',
                'badge_success' => true
            ),
            'payment' => array(
                'title' => 'Payment'
            ),
            'osname' => array(
                'title' => 'Status',
                'type' => 'select',
                'color' => 'color',
                'list' => $this->statuses_array,
                'filter_key' => 'os!id_order_state',
                'filter_type' => 'int',
                'order_key' => 'osname'
            ),
            'date_add' => array(
                'title' => 'Date',
                'align' => 'text-right',
                'type' => 'datetime',
                'filter_key' => 'a!date_add'
            )
            
        ));

            $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS('
            SELECT DISTINCT c.id_country, cl.`name`
            FROM `'._DB_PREFIX_.'orders` o
            '.Shop::addSqlAssociation('orders', 'o').'
            INNER JOIN `'._DB_PREFIX_.'address` a ON a.id_address = o.id_address_delivery
            INNER JOIN `'._DB_PREFIX_.'country` c ON a.id_country = c.id_country
            INNER JOIN `'._DB_PREFIX_.'country_lang` cl 
            ON (c.`id_country` = cl.`id_country` 
            AND cl.`id_lang` = '.(int)$this->context->language->id.')
            ORDER BY cl.name ASC');

            $country_array = array();
        foreach ($result as $row) {
            $country_array[$row['id_country']] = $row['name'];
        }

            $part1 = array_slice($this->fields_list, 0, 3);
            $part2 = array_slice($this->fields_list, 3);
            $part1['cname'] = array(
                'title' => 'Delivery',
                'type' => 'select',
                'list' => $country_array,
                'filter_key' => 'country!id_country',
                'filter_type' => 'int',
                'order_key' => 'cname'
            );
            $this->fields_list = array_merge($part1, $part2);

        $this->shopLinkType = 'shop';
        $this->shopShareDatas = Shop::SHARE_ORDER;

        if (Tools::isSubmit('id_order')) {
            $order = new Order((int)Tools::getValue('id_order'));
            $this->context->cart = new Cart($order->id_cart);
            $this->context->customer = new Customer($order->id_customer);
        }

        $this->bulk_actions = array(
            'accept' => array('text' => 'Accept Order', 'icon' => 'icon-refresh'),
            'cancal' => array('text' => 'Cancel Order', 'icon' => 'icon-trash'),
        );
        
        if (Tools::getIsset('submitBulkacceptorder') && Tools::getIsset('orderBox')) {
            if (count(Tools::getValue('orderBox'))) {
                $result = $this->processBulkAcknowledge(Tools::getValue('orderBox'));
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[]  = 'Order Accepted Successfully ';
                } else {
                    $this->errors[] = $result['message'];
                }
            } else {
                $this->errors[] = 'Please Select Order(s)';
            }
        }
        if (Tools::getIsset('submitBulkcancalorder') && Tools::getIsset('orderBox')) {
            if (count(Tools::getValue('orderBox'))) {
                $result = $this->processBulkCancel(Tools::getValue('orderBox'));
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[]  = 'Order Cancelled Successfully ';
                } else {
                    $this->errors[] = $result['message'];
                }
            } else {
                $this->errors[] = 'Please Select Order(s)';
            }
        }
        if (Tools::getIsset('acceptorder') && Tools::getValue('acceptorder')) {
            $acceptorder = array(Tools::getValue('acceptorder'));
            if (count($acceptorder)) {
                $result = $this->processBulkAcknowledge($acceptorder);
         
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[]  = 'Order Accepted Successfully ';
                } else {
                    $this->errors[] =$result['message'];
                }
            } else {
                $this->errors[] = 'Please Select Order(s)';
            }
        }
        if (Tools::getIsset('cancelorder') && Tools::getValue('cancelorder')) {
            $acceptorder = array(Tools::getValue('cancelorder'));
            if (count($acceptorder)) {
                $result = $this->processBulkCancel($acceptorder);
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[]  = 'Order Cancelled Successfully ';
                } else {
                    $this->errors[] =$result['message'];
                }
            } else {
                $this->errors[] = 'Please Select Order(s)';
            }
        }
        parent::__construct();
    }
    public function processBulkAcknowledge($order_ids = array())
    {
        if (count($order_ids)) {
            $CedfruugoHelper = new CedfruugoHelper;
            $CedfruugoOrder = new CedfruugoOrder();
            try {
                $sql = "SELECT `fruugo_order_id` FROM `"._DB_PREFIX_."fruugo_order` 
                where `prestashop_order_id` 
                IN (".implode(',', (array)$order_ids).")";
                $db = Db::getInstance();
                $ids_to_accept = $db->ExecuteS($sql);
                if (is_array($ids_to_accept) && count($ids_to_accept)) {
                    foreach ($ids_to_accept as $value) {
                        $result = $CedfruugoOrder->acceptOrder($value['fruugo_order_id'], 'orders/confirm');
                        $CedfruugoHelper->log(
                            __METHOD__,
                            'Info',
                            'Response for Bulk accept order',
                            Tools::jsonEncode($result)
                        );
                        if (isset($result['success']) && $result['success']) {
                            if (isset($result['response']) && $result['response']) {
                                if (is_array($result)) {
                                    $data = $CedfruugoHelper->xml2array($result['response']);
                                    $CedfruugoOrder->updatefruugoOrderData(
                                        $value['fruugo_order_id'],
                                        $data['o:orders']['o:order']
                                    );
                                    return array('success' =>true, 'response' =>json_encode($data));
                                } else {
                                    return array('success' =>false, 'message' => $result['message']);
                                }
                            } else {
                                return array('success' =>false, 'message' => $result['message']);
                            }
                        } else {
                            return array('success' =>false, 'message' => $result['message']);
                        }
                    }
                }
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::processBulkAcknowledge',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
            }
        }
    }
    public function processBulkCancel($order_ids = array())
    {
        if (count($order_ids)) {
            $sql = "SELECT `fruugo_order_id` FROM `"._DB_PREFIX_."fruugo_order` 
            where `prestashop_order_id` IN (".implode(',', (array)$order_ids).")";
            $db = Db::getInstance();
            $ids_to_accept = $db->ExecuteS($sql);
            if (is_array($ids_to_accept) && count($ids_to_accept)) {
                $CedfruugoHelper = new CedfruugoHelper;
                $CedfruugoOrder = new CedfruugoOrder();
                
                foreach ($ids_to_accept as $value) {
                    $result = $CedfruugoOrder->cancelOrder($value['fruugo_order_id'], 'orders/cancel');
                    if (isset($result['success']) && $result['success']) {
                        if (isset($result['response']) && $result['response']) {
                            if (is_array($result['response'])) {
                                $data = $CedfruugoHelper->xml2array($result['response']);
                                $CedfruugoOrder->updatefruugoOrderData(
                                    $value['fruugo_order_id'],
                                    $data['o:orders']['o:order']
                                );
                                return array('success' =>true, 'response' =>json_encode($data));
                            } else {
                                return array('success' =>false, 'message' => $result['message']);
                            }
                        } else {
                            return array('success' =>false, 'message' => $result['message']);
                        }
                    } else {
                        return array('success' =>false, 'message' => $result['message']);
                    }
                }
            }
        }
    }
    public function displayAcknowledgeLink($token = null, $id = null)
    {
        $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        if (!array_key_exists('Accept', self::$cache_lang)) {
            self::$cache_lang['Accept'] = 'Accept';
        }

        $tpl->assign(array(
            'href' => self::$currentIndex.'&'.$this->identifier.'='.$id.'&acceptorder='.$id.
                '&token='.($token != null ? $token : $this->token),
            'action' => self::$cache_lang['Accept'],
            'id' => $id
        ));

        return $tpl->fetch();
    }
    public function displayRejectLink($token = null, $id = null)
    {
        $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        if (!array_key_exists('Cancel', self::$cache_lang)) {
            self::$cache_lang['Cancel'] = 'Cancel';
        }

        $tpl->assign(array(
            'href' => self::$currentIndex.'&'.$this->identifier.'='.$id.'&cancelorder='.$id.
                '&token='.($token != null ? $token : $this->token),
            'action' => self::$cache_lang['Cancel'],
            'id' => $id
        ));

        return $tpl->fetch();
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new_order'] = array(
                'href' => self::$currentIndex.'&fetchorder&token='.$this->token,
                'desc' => 'Fetch Order',
                'icon' => 'process-icon-new'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function initToolbar()
    {
        if ($this->display == 'view') {
            /** @var Order $order */
            $order = $this->loadObject();
            $customer = $this->context->customer;

            if (!Validate::isLoadedObject($order)) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdmincedfruugoOrder'));
            }
            $this->toolbar_title[] = sprintf(
                'Order %1$s from %2$s %3$s',
                $order->reference,
                $customer->firstname,
                $customer->lastname
            );
            $this->addMetaTitle($this->toolbar_title[count($this->toolbar_title) - 1]);
        }
    }

    public function renderList()
    {
        if (Tools::isSubmit('submitBulkacceptorder'.$this->table)) {
            if (Tools::getIsset('cancel')) {
                Tools::redirectAdmin(self::$currentIndex.'&token='.$this->token);
            }

            $this->tpl_list_vars['updateOrderStatus_mode'] = true;
            $this->tpl_list_vars['order_statuses'] = $this->statuses_array;
            $this->tpl_list_vars['REQUEST_URI'] = $_SERVER['REQUEST_URI'];
            $this->tpl_list_vars['POST'] = $_POST;
        }
        if (Tools::getIsset('fetchorder')) {
            $CedfruugoHelper = new CedfruugoHelper;
            $CedfruugoOrder = new CedfruugoOrder();
            try {
                $status = $CedfruugoHelper->isEnabled();
                if ($status) {
                    $url ='orders/download';
                    $params= array();
                    $createdStartDate = date('Y-m-d', strtotime("-2 days"));
                    $order = array('from' => $createdStartDate);
                    $order_data = $CedfruugoOrder->fetchOrder($params, $url, $order);
                    if (isset($order_data['success']) && $order_data['success']) {
                        $this->confirmations[] = json_encode($order_data['message']);
                    } elseif (isset($order_data['message'])) {
                        $fetch_errors = $order_data['message'];

                        $fetch_errors = json_decode($fetch_errors, true);
                        if (!$fetch_errors) {
                            $this->errors[] = $order_data['message'];
                        } else {
                            $error_msg = '';
                            if (is_array($fetch_errors['errors']) && count($fetch_errors['errors'])) {
                                foreach ($fetch_errors['errors'] as $value) {
                                    if (isset($value['0']['description'])) {
                                        $error_msg .=$value['0']['description'];
                                    }
                                }
                            }
                            $this->errors[] = $error_msg;
                        }
                    } else {
                        $this->errors[] = 'Can not fetch Order';
                    }
                }
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::FetchOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
            }
        }
        return parent::renderList();
    }

    public function postProcess()
    {
        $CedfruugoHelper = new CedfruugoHelper;
        $CedfruugoOrder = new CedfruugoOrder();

        if (Tools::getIsset('action') && Tools::getValue('action')=='acceptOrder') {
            try {
                $fruugoProductId = Tools::getValue('fruugoProductId');
                $fruugoSkuId = Tools::getValue('fruugoSkuId');
                $quantity = Tools::getValue('quantity');
                $fruugo_order_id = Tools::getValue('fruugo_order_id');
                $messageToCustomer = Tools::getValue('messageToCustomer');
                $messageToFruugo = Tools::getValue('messageToFruugo');
                $estimatedShippingDate = Tools::getValue('estimatedShippingDate');
                $result = $CedfruugoOrder->acceptOrderByFruugoId(
                    $fruugo_order_id,
                    $quantity,
                    $fruugoSkuId,
                    $fruugoProductId,
                    $messageToFruugo,
                    $messageToCustomer,
                    $estimatedShippingDate
                );
                if (isset($result['success']) && $result['success'] && isset($result['response'])) {
                    $data = $CedfruugoHelper->xml2array($result['response']);
                    $CedfruugoOrder->updatefruugoOrderData($fruugo_order_id, $data['o:orders']['o:order']);
                    die(json_encode(array('success' => true,'message' => 'Order Accepted Successfully')));
                }
                $error_res = 'Some Error While Accepting Order.';
                if (isset($result['message'])) {
                    $error_res = $result['message'];
                }
                die(json_encode(array('success' => false,'message' => $error_res)));
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::AcceptSingleOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                die(json_encode(array('success' => false,'message' => $e->getMessage())));
            }
        }
        if (Tools::getIsset('action') && Tools::getValue('action')=='cancelOrder') {
            try {
                $fruugoProductId = Tools::getValue('fruugoProductId');
                $fruugoSkuId = Tools::getValue('fruugoSkuId');
                $quantity = Tools::getValue('quantity');
                $fruugo_order_id = Tools::getValue('fruugo_order_id');
                $messageToCustomer = Tools::getValue('messageToCustomer');
                $messageToFruugo = Tools::getValue('messageToFruugo');
                $cancellationReason = Tools::getValue('cancellationReason');
                $result = $CedfruugoOrder->cancelOrderByFruugoId(
                    $fruugo_order_id,
                    $quantity,
                    $fruugoSkuId,
                    $fruugoProductId,
                    $messageToFruugo,
                    $messageToCustomer,
                    $cancellationReason
                );

                if (isset($result['success']) && $result['success'] && isset($result['response'])) {
                    $data = $CedfruugoHelper->xml2array($result['response']);
                    $CedfruugoOrder->updatefruugoOrderData($fruugo_order_id, $data['o:orders']['o:order']);
                    die(json_encode(array('success' => true,'message' => 'Order Cancelled Successfully')));
                }
                $error_res = 'Some Error While Cancelling Order.';
                if (isset($result['message'])) {
                    $error_res = $result['message'];
                }
                die(json_encode(array('success' => false,'message' => $error_res)));
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::CancelSingleOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                die(json_encode(array('success' => false,'message' => $e->getMessage())));
            }
        }
        if (Tools::getIsset('action') && Tools::getValue('action')=='shipOrder') {
            try {
                $fruugoProductId = Tools::getValue('fruugoProductId');
                $fruugoSkuId = Tools::getValue('fruugoSkuId');
                $quantity = Tools::getValue('quantity');
                $fruugo_order_id = Tools::getValue('fruugo_order_id');
                $messageToCustomer = Tools::getValue('messageToCustomer');
                $messageToFruugo = Tools::getValue('messageToFruugo');
                $trackingCode = Tools::getValue('trackingCode');
                $trackingUrl = Tools::getValue('trackingUrl');
                $result = $CedfruugoOrder->shipOrderByFruugoId(
                    $fruugo_order_id,
                    $quantity,
                    $fruugoSkuId,
                    $fruugoProductId,
                    $messageToFruugo,
                    $messageToCustomer,
                    $trackingCode,
                    $trackingUrl
                );

                if (isset($result['success']) && $result['success'] && isset($result['response'])) {
                    $data = $CedfruugoHelper->xml2array($result['response']);
                    $CedfruugoOrder->updatefruugoOrderData($fruugo_order_id, $data['o:orders']['o:order']);
                    die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
                }
                $error_res = 'Some Error While Shipment.';
                if (isset($result['message'])) {
                    $error_res = $result['message'];
                }
                die(json_encode(array('success' => false,'message' => $error_res)));
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::ShipOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                die(json_encode(array('success' => false,'message' => $e->getMessage())));
            }
        }
        if (Tools::getIsset('action') && Tools::getValue('action')=='shipCompleteOrder') {
            try {
                $fruugo_order_id = Tools::getValue('fruugo_order_id');
                $messageToCustomer = Tools::getValue('messageToCustomer');
                $messageToFruugo = Tools::getValue('messageToFruugo');
                $trackingCode = Tools::getValue('trackingCode');
                $trackingUrl = Tools::getValue('trackingUrl');
                $result = $CedfruugoOrder->shipCompleteOrder(
                    $fruugo_order_id,
                    $messageToFruugo,
                    $messageToCustomer,
                    $trackingCode,
                    $trackingUrl
                );
                $CedfruugoHelper->log(
                    'ShipOrder',
                    'Info',
                    'Ship order For Order'. $fruugo_order_id,
                    Tools::jsonEncode($result)
                );
                if (isset($result['success']) && $result['success'] && isset($result['response'])) {
                    $data = $CedfruugoHelper->xml2array($result['response']);
                    $CedfruugoOrder->updatefruugoOrderData($fruugo_order_id, $data['o:orders']['o:order']);
                    die(json_encode(array('success' => true,'message' => 'Order Shipped Successfully')));
                }
                $error_res = 'Some Error While Shipment.';
                if (isset($result['message'])) {
                    $error_res = $result['message'];
                }
                die(json_encode(array('success' => false,'message' => $error_res)));
            } catch (\Exception $e) {
                $CedfruugoHelper->log(
                    'AdminCedfruugoOrdersController::ShipOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                die(json_encode(array('success' => false,'message' => $e->getMessage())));
            }
        }
        // If id_order is sent, we instanciate a new Order object
        if (Tools::isSubmit('id_order') && Tools::getValue('id_order') > 0) {
            $order = new Order(Tools::getValue('id_order'));
            if (!Validate::isLoadedObject($order)) {
                $this->CedfruugoHelper = new CedfruugoHelper;
                $this->errors[] = 'The order cannot be found within your database.';
            }
            ShopUrl::cacheMainDomainForShop((int)$order->id_shop);
        }

        parent::postProcess();
    }

    public static function setOrderCurrency($echo, $tr)
    {
        $order = new Order($tr['id_order']);
        return Tools::displayPrice($echo, (int)$order->id_currency);
    }
    public function initContent()
    {
        parent::initContent();
    }
    public function renderView()
    { 
        $order = $this->loadObject();
        $order_data = (array)$order;
        $id_order = 0;
        if (isset($order_data['id']) && $order_data['id']) {
            $id_order =$order_data['id'];
        }
        if ($id_order) {
            $sql = "SELECT `order_data` FROM `"._DB_PREFIX_."fruugo_order` 
            where `prestashop_order_id` = '".(int)$id_order."'";
            $db = Db::getInstance();
            $result = $db->ExecuteS($sql);

            if (is_array($result) && count($result) && isset($result['0']['order_data'])) {
                if (Tools::stripslashes($result['0']['order_data'])) {
                    $order_data = json_decode(Tools::stripslashes(trim($result['0']['order_data'], '"')), true);
                    $this->context->smarty->assign(array('carrierNames' => array()));
                    $this->context->smarty->assign(array('methodCodes'  => array()));
                    $CedfruugoHelper = new CedfruugoHelper;

                    $methodCodes = $CedfruugoHelper->methodCodeArrray();
                    if ($methodCodes) {
                        $this->context->smarty->assign(array('methodCodes'  => $methodCodes));
                    }
                    $carrierNames = $CedfruugoHelper->carrierNameArray();
                    if ($carrierNames) {
                        $this->context->smarty->assign(array('carrierNames'  => $carrierNames));
                    }

                    $this->context->smarty->assign(array('order_info' => array()));
                    if ($order_data) {
                        $shippingInfo = $order_data['o:shippingAddress'];
                        unset($order_data['o:shippingAddress']);
                        $shipping_data = array();
                        if (isset($order_data['o:shipments'])) {
                            $shipping_data = $order_data['o:shipments'];
                            if (!isset($shipping_data['o:shipment']['0'])) {
                                $temp_shipping_data =$shipping_data['o:shipment'];
                                $shipping_data['o:shipment'] = array();
                                $shipping_data['o:shipment']['0'] = $temp_shipping_data;
                            }
                            unset($order_data['o:shipments']);
                        }
                        
                        
                        $this->context->smarty->assign(array('shippingInfo'  => $shippingInfo));

                        $orderLines = $order_data['o:orderLines'];
                        if (!isset($orderLines['o:orderLine']['0'])) {
                            $temp_orderLine =$orderLines['o:orderLine'];
                            $orderLines['o:orderLine'] = array();
                            $orderLines['o:orderLine']['0'] = $temp_orderLine;
                        }
                        unset($order_data['o:orderLines']);

                        $this->context->smarty->assign(array('orderLines'  => $orderLines));

                        $this->context->smarty->assign(array('order_info'  => $order_data));

                        $this->context->smarty->assign(array('shipping_info'  => $shipping_data));
                    }
                   
                    $this->context->smarty->assign(
                        'ship',
                        $this->context->link->getAdminLink('AdmincedfruugoOrder').
                        '&submitShippingNumber=true'
                    );
                    $this->context->smarty->assign('id_order', $id_order);
                    $this->context->smarty->assign('token', $this->token);
                    $parent = $this->context->smarty->fetch(
                        _PS_MODULE_DIR_ .'cedfruugo/views/templates/admin/orders/form.tpl'
                    );
                    parent::renderView();
                    return $parent;
                }
            }
        }
    }
    public function setMedia($isNewTheme = false)
    {
        parent::setMedia();

        $this->addJqueryUI('ui.datepicker');
    }
}
