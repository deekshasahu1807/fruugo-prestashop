<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoFailedorder.php';
require_once _PS_MODULE_DIR_ . 'cedfruugo/classes/CedfruugoOrder.php';
class AdminCedfruugoFailedorderController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        $this->table      = 'fruugo_order_error';
        $this->identifier = 'id';
        $this->list_no_link = true;
        $this->addRowAction('cancel');
        $this->fields_list = array(
            'id'       => array(
                'title' => 'ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'merchant_sku' => array(
                'title' => 'SKU',
                'type'  => 'text',
            ),
            'fruugo_order_id'     => array(
                'title' => 'Fruugo Order Id',
                'type'  => 'text',
            ),
            'reason'     => array(
                'title' => 'Reason',
                'type'  => 'text',
            ),
        );

        $this->bulk_actions = array(
            'cancel' => array('text' => 'Cancel Order', 'icon' => 'icon-trash'),
        );
        
        parent::__construct();
    }

    public function processBulkCancel()
    {
        if (Tools::getIsset('fruugo_order_errorBox') && Tools::getValue('fruugo_order_errorBox')) {
            $order_ids = Tools::getValue('fruugo_order_errorBox');
        } else {
            $order_ids = array();
        }
        if (count($order_ids)) {
            $sql = "SELECT `fruugo_order_id` FROM `"._DB_PREFIX_."fruugo_order_error`
             where `id` IN (".implode(',', (array)$order_ids).")";
            $db = Db::getInstance();
            $ids_to_cancel = $db->ExecuteS($sql);
            if (is_array($ids_to_cancel) && count($ids_to_cancel)) {
                foreach ($ids_to_cancel as $value) {
                    $this->cancelOrder($value['fruugo_order_id']);
                }
            }
        } else {
            $this->errors[] = 'Please select Order(s) to cancel at Fruugo';
        }
    }

    public function displayCancelLink($token = null, $id = null)
    {
        if ($token) {
            $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        } else {
            $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        }
        if (!array_key_exists('Cancel', self::$cache_lang)) {
            self::$cache_lang['Cancel'] = $this->l('Cancel', 'Helper');
        }

        $tpl->assign(array(
                'href' => Context::getContext()->link->getAdminLink('AdminCedfruugoFailedorder').
                    '&cancelorder='.$id.'&id='.$id,
                'action' => self::$cache_lang['Cancel'],
                'id' => $id
        ));

        return $tpl->fetch();
    }
    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
    }
    public function renderList()
    {
        if (Tools::getIsset('cancelorder') && Tools::getValue('cancelorder')) {
            $cancelOrder =Tools::getValue('cancelorder');
            if ($cancelOrder) {
                $sql = "SELECT `fruugo_order_id` FROM `"._DB_PREFIX_."fruugo_order_error` 
                WHERE `id`=".(int)($cancelOrder);
                $db = Db::getInstance();
                $id_to_cancel = $db->ExecuteS($sql);
                if (is_array($id_to_cancel) && count($id_to_cancel)) {
                    foreach ($id_to_cancel as $value) {
                        $this->cancelOrder($value['fruugo_order_id']);
                    }
                }
            }
        }

        return parent::renderList();
    }
    public function cancelOrder($order_id)
    {
        $CedfruugoOrder = new CedfruugoOrder();
        $CedfruugoHelper = new CedfruugoHelper();
        $result = $CedfruugoOrder->cancelOrder($order_id, 'orders/cancel');
        if (isset($result['success']) && $result['success']) {
            if (isset($result['response']) && $result['response']) {
                $response = str_replace('ns:2', '', $result['response']);
                if (!is_array($response)) {
                    $data = $CedfruugoHelper->xml2array($response);
                    $CedfruugoOrder->updatefruugoOrderData($order_id, $data['o:orders']['o:order']);
                    $this->confirmations[] = 'Order '.$order_id.' cancelled successfully at Fruugo';
                } else {
                    $this->errors[] = isset($response['message']) && $response['message'] ? $response['message']:
                        'Failed to cancel Order '.$order_id;
                }
            } else {
                $this->errors[] = 'Failed to cancel Order '.$order_id;
            }
        } else {
            $this->errors[] = 'Failed to cancel Order '.$order_id;
        }
    }
}
