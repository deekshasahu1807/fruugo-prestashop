<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include(_PS_MODULE_DIR_.'/cedfruugo/classes/CedfruugoHelper.php');
include(_PS_MODULE_DIR_.'/cedfruugo/classes/CedfruugoProduct.php');

if (!Tools::isSubmit('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFRUUGO_CRON_SECURE_KEY')) {
    die('Secure key not matched');
}

try {
    $CedfruugoHelper = new CedfruugoHelper;
    $CedfruugoProduct = new CedfruugoProduct();

    $response_data = $CedfruugoProduct->fetchStock();

    $CedfruugoHelper->log(
        'Cron FetchSkuID',
        'Info',
        'Response for fetch Fruugo sku id by cron',
        Tools::jsonEncode($response_data)
    );

    $report_array = array();
    $db = Db::getInstance();
    if(isset($response_data['success']) && ($response_data['success'] == true) && isset($response_data['response']))
    {
        $response_data = getparsedData($response_data['response']);
        if (isset($response_data['skus']['value']['sku']) && count($response_data['skus']['value']['sku']))
        {
            $report_array = $response_data['skus']['value']['sku'];

            if (is_array($report_array) && count($report_array))
            {
                foreach ($report_array as $key => $value)
                {
                    $fruugoSkuId = $value['fruugoSkuId'];
                    $merchantSkuId = $value['merchantSkuId'];
                    $result = $db->ExecuteS("SELECT `id` FROM `"._DB_PREFIX_."fruugo_product_variations` WHERE `sku`='".pSQL(trim($merchantSkuId))."'");
                    if (is_array($result) && isset($result['0']))
                    {
                        $result = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_product_variations` SET `fruugoSkuId` = '".pSQL($fruugoSkuId)."' WHERE `sku`='".pSQL(trim($merchantSkuId))."'");
                    } else {
                        $result = $db->ExecuteS("SELECT `id_product` FROM `"._DB_PREFIX_."product` WHERE `reference`='".pSQL(trim($merchantSkuId))."'");
                        if (isset($result['0']['id_product']))
                        {
                            $result = $db->Execute("UPDATE `"._DB_PREFIX_."fruugo_products` SET `fruugoSkuId` = '".pSQL($fruugoSkuId)."' WHERE `product_id`='".(int)trim($result['0']['id_product'])."'");
                        }
                    }
                }
            }
        }
        die(Tools::jsonEncode(array(
            'success' => true,
            'message' => Tools::jsonEncode($response_data)
        )));
    } else {
        die(Tools::jsonEncode($response_data));
    }

} catch (\Exception $e) {
    $CedfruugoHelper = new CedfruugoHelper;
    $CedfruugoHelper->log(
        'Cron FetchSkuID',
        'Exception',
        $e->getMessage(),
        $e->getMessage()
    );
    die(Tools::jsonEncode(array(
        'success' => false,
        'message' => $e->getMessage()
    )));
}

// credit goes to github
function getparsedData(&$string)
{
    $parser = xml_parser_create();
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parse_into_struct($parser, $string, $vals, $index);
    xml_parser_free($parser);
    $mnary=array();
    $ary=&$mnary;

    foreach ($vals as $r) {
        $t=$r['tag'];
        if ($r['type']=='open') {
            if (isset($ary[$t])) {
                if (isset($ary[$t][0])) {
                    $ary[$t][]=array();
                } else {
                    $ary[$t]=array($ary[$t], array());
                }
                $cv=&$ary[$t][count($ary[$t])-1];
            } else {
                $cv=&$ary[$t];
            }
            if (isset($r['attributes'])) {
                foreach ($r['attributes'] as $k => $v) {
                    $cv[$k]=$v;
                }
            }
            $cv['value']=array();
            $cv['value']['_p']=&$ary;
            $ary=&$cv['value'];
        } elseif ($r['type']=='complete') {
            if (isset($ary[$t])) {
                if (isset($ary[$t][0])) {
                    $ary[$t][]=array();
                } else {
                    $ary[$t]=array($ary[$t], array());
                }
                $cv=&$ary[$t][count($ary[$t])-1];
            } else {
                $cv=&$ary[$t];
            }
            if (isset($r['attributes'])) {
                foreach ($r['attributes'] as $k => $v) {
                    $cv[$k]=$v;
                }
            }
            $cv=(isset($r['value']) ? $r['value'] : '');
        } elseif ($r['type']=='close') {
            $ary=&$ary['_p'];
        }
    }

    _del_p($mnary);
    return $mnary;
}

function _del_p(&$ary)
{
    foreach ($ary as $k => $v) {
        if ($k==='_p') {
            unset($ary[$k]);
        } elseif (is_array($v)) {
            _del_p($ary[$k]);
        }
    }
}
