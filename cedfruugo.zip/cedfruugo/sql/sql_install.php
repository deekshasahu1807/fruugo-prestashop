<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

$sql = array();
$db = Db::getInstance();
$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_category_list` (  
 `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `mapped_categories` text NOT NULL,
PRIMARY KEY  (`id`) )";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_attribute_mapping` (
   `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
   `fruugo_attribute` text NOT NULL,   
   `prestashop_attribute` text NOT NULL,   
   `fruugoSkuId` bigint(20) NOT NULL,     
   PRIMARY KEY  (`id`) 
   )";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_products_cron` (
`id` int(15) NOT NULL AUTO_INCREMENT,   
`inventory_chunk` longtext NOT NULL,   
`type` text NOT NULL,    
PRIMARY KEY (`id`) 
);";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_final_products` (   
`Attribute1` text,
`Attribute2` text,   
`Attribute3` text,   
`Attribute4` text,   
`Attribute5` text,   
`Attribute6` text,   
`Attribute7` text,   
`Attribute8` text,   
`Attribute9` text,   
`Attribute10` text,  
`AttributeColor` text,   
`AttributeSize` text,
`Brand` text,   
`Category` text,   
`Description` longtext,   
`DiscountPriceEndDate` date,   
`DiscountPriceStartDate` date,   
`DiscountPriceWithVAT` float,   
`DiscountPriceWithoutVAT` float,   
`EAN` text,   
`ISBN` text,   
`Imageurl1` text,   
`Imageurl2` text,   
`Imageurl3` text,   
`Imageurl4` text,   
`Imageurl5` text,   
`LeadTime` int(10),
`Manufacturer` text,   
`NormalPriceWithVAT` float,   
`NormalPriceWithoutVAT` float,   
`PackageWeight` int(15),
`ProductId` int(15),
`RestockDate` date,   
`SkuId` text,   
`StockQuantity` int(15),
`StockStatus` text,   
`Title` text,   
`Language` text,   
`Currency` text,   
`Country` text,   
`VATRate` int(10) 
);";

$sql[]  = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` )
VALUES (1,'Animals & Pet Supplies > Live
Animals', ''),
(2, 'Animals & Pet Supplies > Pet Supplies > Bird Supplies > Bird Cage Accessories', ''),
(3, 'Animals &
Pet Supplies > Pet Supplies > Bird Supplies > Bird Cage Accessories > Bird Cage Bird Baths', ''),
(4, 'Animals & Pet
Supplies > Pet Supplies > Bird Supplies > Bird Cage Accessories > Bird Cage Food & Water Dishes', ''),
(5, 'Animals &
Pet Supplies > Pet Supplies > Bird Supplies > Bird Cages & Stands', ''),
(6, 'Animals & Pet Supplies > Pet Supplies >
Bird Supplies > Bird Food', ''),
(7, 'Animals & Pet Supplies > Pet Supplies > Bird Supplies > Bird Gyms & Playstands',
''),
(8, 'Animals & Pet Supplies > Pet Supplies > Bird Supplies > Bird Ladders & Perches', ''),
(9, 'Animals & Pet
Supplies > Pet Supplies > Bird Supplies > Bird Toys', ''),
(10, 'Animals & Pet Supplies > Pet Supplies > Bird Supplies >
Bird Treats', ''),
(11, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies > Cat Apparel', ''),
(12, 'Animals & Pet
Supplies > Pet Supplies > Cat Supplies > Cat Beds', ''),
(13, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies >
Cat Food', ''),
(14, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies > Cat Furniture', ''),
(15, 'Animals & Pet
Supplies > Pet Supplies > Cat Supplies > Cat Furniture Accessories', ''),
(16, 'Animals & Pet Supplies > Pet Supplies >
Cat Supplies > Cat Litter', ''),
(17, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies > Cat Litter Box Liners',
''),
(18, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies > Cat Litter Box Mats', ''),
(19, 'Animals & Pet
Supplies > Pet Supplies > Cat Supplies > Cat Litter Boxes', ''),
(20, 'Animals & Pet Supplies > Pet Supplies > Cat
Supplies > Cat Toys', ''),
(21, 'Animals & Pet Supplies > Pet Supplies > Cat Supplies > Cat Treats', ''),
(22, 'Animals
& Pet Supplies > Pet Supplies > Dog Supplies > Dog Apparel', ''),
(23, 'Animals & Pet Supplies > Pet Supplies > Dog
Supplies > Dog Beds', ''),
(24, 'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Diaper Pads & Liners', ''),
(25, 'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Diapers', ''),
(26, 'Animals & Pet Supplies > Pet
Supplies > Dog Supplies > Dog Food', ''),
(27, 'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Houses', ''),
(28, 'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Kennel & Run Accessories', ''),
(29, 'Animals & Pet
Supplies > Pet Supplies > Dog Supplies > Dog Kennels & Runs', ''),
(30, 'Animals & Pet Supplies > Pet Supplies > Dog
Supplies > Dog Toys', ''),
(31, 'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Treadmills', ''),
(32,
'Animals & Pet Supplies > Pet Supplies > Dog Supplies > Dog Treats', ''),
(33, 'Animals & Pet Supplies > Pet Supplies >
Fish Supplies > Aquarium & Pond Tubing', ''),
(34, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Air
Stones & Diffusers', ''),
(35, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Cleaning Supplies',
''),
(36, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Decor', ''),
(37, 'Animals & Pet Supplies >
Pet Supplies > Fish Supplies > Aquarium Filters', ''),
(38, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies >
Aquarium Fish Nets', ''),
(39, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Gravel &
Tools::substrates', ''),
(40, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Lighting', ''),
(41,
'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Overflow Boxes', ''),
(42, 'Animals & Pet Supplies >
Pet Supplies > Fish Supplies > Aquarium Stands', ''),
(43, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies >
Aquarium Temperature Controllers', ''),
(44, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquarium Water
Treatments', ''),
(45, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Aquariums', ''),
(46, 'Animals & Pet
Supplies > Pet Supplies > Fish Supplies > Aquatic Plant Fertilizers', ''),
(47, 'Animals & Pet Supplies > Pet Supplies >
Fish Supplies > Fish Feeders', ''),
(48, 'Animals & Pet Supplies > Pet Supplies > Fish Supplies > Fish Food', ''),
(49,
'Animals & Pet Supplies > Pet Supplies > Pet Agility Equipment', ''),
(50, 'Animals & Pet Supplies > Pet Supplies > Pet
Apparel Hangers', ''),
(51, 'Animals & Pet Supplies > Pet Supplies > Pet Bed Accessories', ''),
(52, 'Animals & Pet
Supplies > Pet Supplies > Pet Bells & Charms', ''),
(53, 'Animals & Pet Supplies > Pet Supplies > Pet Biometric Monitors
> Pet Glucose Meters', ''),
(54, 'Animals & Pet Supplies > Pet Supplies > Pet Biometric Monitors > Pet Pedometers', ''),
(55, 'Animals & Pet Supplies > Pet Supplies > Pet Biometric Monitors > Pet Thermometers', ''),
(56, 'Animals & Pet
Supplies > Pet Supplies > Pet Bowl Mats', ''),
(57, 'Animals & Pet Supplies > Pet Supplies > Pet Bowl Stands', ''),
(58,
'Animals & Pet Supplies > Pet Supplies > Pet Bowls,Feeders & Waterers', ''),
(59, 'Animals & Pet Supplies > Pet Supplies
> Pet Carrier & Crate Accessories', ''),
(60, 'Animals & Pet Supplies > Pet Supplies > Pet Carriers & Crates', ''),
(61,
'Animals & Pet Supplies > Pet Supplies > Pet Collars & Harnesses', ''),
(62, 'Animals & Pet Supplies > Pet Supplies >
Pet Containment Systems', ''),
(63, 'Animals & Pet Supplies > Pet Supplies > Pet Door Accessories', ''),
(64, 'Animals &
Pet Supplies > Pet Supplies > Pet Doors', ''),
(65, 'Animals & Pet Supplies > Pet Supplies > Pet Eye Drops &
Lubricants', ''),
(66, 'Animals & Pet Supplies > Pet Supplies > Pet First Aid & Emergency Kits', ''),
(67, 'Animals &
Pet Supplies > Pet Supplies > Pet Flea & Tick Control', ''),
(68, 'Animals & Pet Supplies > Pet Supplies > Pet Food
Containers', ''),
(69, 'Animals & Pet Supplies > Pet Supplies > Pet Food Scoops', ''),
(70, 'Animals & Pet Supplies >
Pet Supplies > Pet Grooming Supplies > Pet Combs & Brushes', ''),
(71, 'Animals & Pet Supplies > Pet Supplies > Pet
Grooming Supplies > Pet Fragrances & Deodorizing Sprays', ''),
(72, 'Animals & Pet Supplies > Pet Supplies > Pet
Grooming Supplies > Pet Hair Clippers & Trimmers', ''),
(73, 'Animals & Pet Supplies > Pet Supplies > Pet Grooming
Supplies > Pet Hair Dryers', ''),
(74, 'Animals & Pet Supplies > Pet Supplies > Pet Grooming Supplies > Pet Nail
Polish', ''),
(75, 'Animals & Pet Supplies > Pet Supplies > Pet Grooming Supplies > Pet Nail Tools', ''),
(76, 'Animals
& Pet Supplies > Pet Supplies > Pet Grooming Supplies > Pet Shampoo & Conditioner', ''),
(77, 'Animals & Pet Supplies >
Pet Supplies > Pet Grooming Supplies > Pet Wipes', ''),
(78, 'Animals & Pet Supplies > Pet Supplies > Pet Heating Pad
Accessories', ''),
(79, 'Animals & Pet Supplies > Pet Supplies > Pet Heating Pads', ''),
(80, 'Animals & Pet Supplies >
Pet Supplies > Pet ID Tags', ''),
(81, 'Animals & Pet Supplies > Pet Supplies > Pet Leash Extensions', ''),
(82,
'Animals & Pet Supplies > Pet Supplies > Pet Leashes', ''),
(83, 'Animals & Pet Supplies > Pet Supplies > Pet Medical
Collars', ''),
(84, 'Animals & Pet Supplies > Pet Supplies > Pet Medical Tape & Bandages', ''),
(85, 'Animals & Pet
Supplies > Pet Supplies > Pet Medicine', ''),
(86, 'Animals & Pet Supplies > Pet Supplies > Pet Muzzles', ''),
(87,
'Animals & Pet Supplies > Pet Supplies > Pet Oral Care Supplies', ''),
(88, 'Animals & Pet Supplies > Pet Supplies > Pet
Playpens', ''),
(89, 'Animals & Pet Supplies > Pet Supplies > Pet Steps & Ramps', ''),
(90, 'Animals & Pet Supplies >
Pet Supplies > Pet Strollers', ''),
(91, 'Animals & Pet Supplies > Pet Supplies > Pet Sunscreen', ''),
(92, 'Animals &
Pet Supplies > Pet Supplies > Pet Training Aids > Pet Training Clickers & Treat Dispensers', ''),
(93, 'Animals & Pet
Supplies > Pet Supplies > Pet Training Aids > Pet Training Pad Holders', ''),
(94, 'Animals & Pet Supplies > Pet
Supplies > Pet Training Aids > Pet Training Pads', ''),
(95, 'Animals & Pet Supplies > Pet Supplies > Pet Training Aids
> Pet Training Sprays & Solutions', ''),
(96, 'Animals & Pet Supplies > Pet Supplies > Pet Vitamins & Supplements', ''),
(97, 'Animals & Pet Supplies > Pet Supplies > Pet Waste Bag Dispensers & Holders', ''),
(98, 'Animals & Pet Supplies >
Pet Supplies > Pet Waste Bags', ''),
(99, 'Animals & Pet Supplies > Pet Supplies > Pet Waste Disposal Systems & Tools',
''),
(100, 'Animals & Pet Supplies > Pet Supplies > Reptile & Amphibian Supplies > Reptile & Amphibian Food', ''),
(101,
'Animals & Pet Supplies > Pet Supplies > Reptile & Amphibian Supplies > Reptile & Amphibian Habitat Accessories', ''),
(102, 'Animals & Pet Supplies > Pet Supplies > Reptile & Amphibian Supplies > Reptile & Amphibian Habitat Heating &
Lighting', ''),
(103, 'Animals & Pet Supplies > Pet Supplies > Reptile & Amphibian Supplies > Reptile & Amphibian
Habitats', ''),
(104, 'Animals & Pet Supplies > Pet Supplies > Reptile & Amphibian Supplies > Reptile & Amphibian
Tools::substrates', ''),
(105, 'Animals & Pet Supplies > Pet Supplies > Small Animal Supplies > Small Animal Bedding',
''),
(106, 'Animals & Pet Supplies > Pet Supplies > Small Animal Supplies > Small Animal Food', ''),
(107, 'Animals &
Pet Supplies > Pet Supplies > Small Animal Supplies > Small Animal Habitat Accessories', ''),
(108, 'Animals & Pet
Supplies > Pet Supplies > Small Animal Supplies > Small Animal Habitats & Cages', ''),
(109, 'Animals & Pet Supplies >
Pet Supplies > Small Animal Supplies > Small Animal Treats', ''),
(110, 'Animals & Pet Supplies > Pet Supplies > Vehicle
Pet Barriers', ''),
(111, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Bibs > Boys',
''),
(112, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Bibs > Girls', ''),
(113,
'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Bibs > Mens', ''),
(114, 'Apparel &
Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Bibs > Womens', ''),
(115, 'Apparel & Accessories >
Clothing > Activewear > Bicycle Activewear > Bicycle Jerseys > Boys', ''),
(116, 'Apparel & Accessories > Clothing >
Activewear > Bicycle Activewear > Bicycle Jerseys > Girls', ''),
(117, 'Apparel & Accessories > Clothing > Activewear >
Bicycle Activewear > Bicycle Jerseys > Mens', ''),
(118, 'Apparel & Accessories > Clothing > Activewear > Bicycle
Activewear > Bicycle Jerseys > Womens', ''),
(119, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear >
Bicycle Shorts & Briefs > Boys', ''),
(120, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear >
Bicycle Shorts & Briefs > Girls', ''),
(121, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear >
Bicycle Shorts & Briefs > Mens', ''),
(122, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear >
Bicycle Shorts & Briefs > Womens', ''),
(123, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear >
Bicycle Skinsuits > Boys', ''),
(124, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle
Skinsuits > Girls', ''),
(125, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Skinsuits >
Mens', ''),
(126, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Skinsuits > Womens',
''),
(127, 'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Tights > Boys', ''),
(128,
'Apparel & Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Tights > Girls', ''),
(129, 'Apparel &
Accessories > Clothing > Activewear > Bicycle Activewear > Bicycle Tights > Mens', ''),
(130, 'Apparel & Accessories >
Clothing > Activewear > Bicycle Activewear > Bicycle Tights > Womens', ''),
(131, 'Apparel & Accessories > Clothing >
Activewear > Boxing Shorts > Boys', ''),
(132, 'Apparel & Accessories > Clothing > Activewear > Boxing Shorts > Girls',
''),
(133, 'Apparel & Accessories > Clothing > Activewear > Boxing Shorts > Mens', ''),
(134, 'Apparel & Accessories >
Clothing > Activewear > Boxing Shorts > Womens', ''),
(135, 'Apparel & Accessories > Clothing > Activewear > Dance
Dresses,Skirts & Costumes > Boys', ''),
(136, 'Apparel & Accessories > Clothing > Activewear > Dance Dresses,Skirts &
Costumes > Girls', ''),
(137, 'Apparel & Accessories > Clothing > Activewear > Dance Dresses,Skirts & Costumes > Mens',
''),
(138, 'Apparel & Accessories > Clothing > Activewear > Dance Dresses,Skirts & Costumes > Womens', ''),
(139,
'Apparel & Accessories > Clothing > Activewear > Football Pants > Boys', ''),
(140, 'Apparel & Accessories > Clothing >
Activewear > Football Pants > Girls', ''),
(141, 'Apparel & Accessories > Clothing > Activewear > Football Pants >
Mens', ''),
(142, 'Apparel & Accessories > Clothing > Activewear > Football Pants > Womens', ''),
(143, 'Apparel &
Accessories > Clothing > Activewear > Hunting Clothing > Ghillie Suits > Boys', ''),
(144, 'Apparel & Accessories >
Clothing > Activewear > Hunting Clothing > Ghillie Suits > Girls', ''),
(145, 'Apparel & Accessories > Clothing >
Activewear > Hunting Clothing > Ghillie Suits > Mens', ''),
(146, 'Apparel & Accessories > Clothing > Activewear >
Hunting Clothing > Ghillie Suits > Womens', ''),
(147, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing
> Hunting & Fishing Vests > Boys', ''),
(148, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing >
Hunting & Fishing Vests > Girls', ''),
(149, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting
& Fishing Vests > Mens', ''),
(150, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting &
Fishing Vests > Womens', ''),
(151, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting &
Tactical Pants > Boys', ''),
(152, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting &
Tactical Pants > Girls', ''),
(153, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting &
Tactical Pants > Mens', ''),
(154, 'Apparel & Accessories > Clothing > Activewear > Hunting Clothing > Hunting &
Tactical Pants > Womens', ''),
(155, 'Apparel & Accessories > Clothing > Activewear > Martial Arts Shorts > Boys', ''),
(156, 'Apparel & Accessories > Clothing > Activewear > Martial Arts Shorts > Girls', ''),
(157, 'Apparel & Accessories >
Clothing > Activewear > Martial Arts Shorts > Mens', ''),
(158, 'Apparel & Accessories > Clothing > Activewear > Martial
Arts Shorts > Womens', ''),
(159, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective Clothing >
Motorcycle Jackets > Boys', ''),
(160, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective Clothing >
Motorcycle Jackets > Girls', ''),
(161, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective Clothing
> Motorcycle Jackets > Mens', ''),
(162, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective Clothing
> Motorcycle Jackets > Womens', ''),
(163, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Pants > Boys', ''),
(164, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Pants > Girls', ''),
(165, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Pants > Mens', ''),
(166, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Pants > Womens', ''),
(167, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Suits > Boys', ''),
(168, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Suits > Girls', ''),
(169, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Suits > Mens', ''),
(170, 'Apparel & Accessories > Clothing > Activewear > Motorcycle Protective
Clothing > Motorcycle Suits > Womens', ''),
(171, 'Apparel & Accessories > Clothing > Activewear > Paintball Clothing >
Boys', ''),
(172, 'Apparel & Accessories > Clothing > Activewear > Paintball Clothing > Girls', ''),
(173, 'Apparel &
Accessories > Clothing > Activewear > Paintball Clothing > Mens', ''),
(174, 'Apparel & Accessories > Clothing >
Activewear > Paintball Clothing > Womens', ''),
(175, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby
& Toddler Bottoms > Boys', ''),
(176, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler
Bottoms > Girls', ''),
(177, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Bottoms > Kids
(unisex)', ''),
(178, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Diaper Covers >
Boys', ''),
(179, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Diaper Covers > Girls',
''),
(180, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Diaper Covers > Kids (unisex)',
''),
(181, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Dresses > Boys', ''),
(182,
'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Dresses > Girls', ''),
(183, 'Apparel &
Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Dresses > Kids (unisex)', ''),
(184, 'Apparel &
Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Outerwear > Boys', ''),
(185, 'Apparel & Accessories >
Clothing > Baby & Toddler Clothing > Baby & Toddler Outerwear > Girls', ''),
(186, 'Apparel & Accessories > Clothing >
Baby & Toddler Clothing > Baby & Toddler Outerwear > Kids (unisex)', ''),
(187, 'Apparel & Accessories > Clothing > Baby
& Toddler Clothing > Baby & Toddler Outfits > Boys', ''),
(188, 'Apparel & Accessories > Clothing > Baby & Toddler
Clothing > Baby & Toddler Outfits > Girls', ''),
(189, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing >
Baby & Toddler Outfits > Kids (unisex)', ''),
(190, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby &
Toddler Sleepwear > Boys', ''),
(191, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler
Sleepwear > Girls', ''),
(192, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Sleepwear >
Kids (unisex)', ''),
(193, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Socks & Tights >
Boys', ''),
(194, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Socks & Tights > Girls',
''),
(195, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Socks & Tights > Kids (unisex)',
''),
(196, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Swimwear > Boys', ''),
(197,
'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Swimwear > Girls', ''),
(198, 'Apparel &
Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Swimwear > Kids (unisex)', ''),
(199, 'Apparel &
Accessories > Clothing > Baby & Toddler Clothing > Baby & Toddler Tops > Boys', ''),
(200, 'Apparel & Accessories >
Clothing > Baby & Toddler Clothing > Baby & Toddler Tops > Girls', ''),
(201, 'Apparel & Accessories > Clothing > Baby &
Toddler Clothing > Baby & Toddler Tops > Kids (unisex)', ''),
(202, 'Apparel & Accessories > Clothing > Baby & Toddler
Clothing > Baby One-Pieces > Boys', ''),
(203, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby One-
Pieces > Girls', ''),
(204, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Baby One-Pieces > Kids
(unisex)', ''),
(205, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Toddler Underwear > Boys', ''),
(206, 'Apparel & Accessories > Clothing > Baby & Toddler Clothing > Toddler Underwear > Girls', ''),
(207, 'Apparel &
Accessories > Clothing > Baby & Toddler Clothing > Toddler Underwear > Kids (unisex)', ''),
(208, 'Apparel & Accessories
> Clothing > Dresses > Girls', ''),
(209, 'Apparel & Accessories > Clothing > Dresses > Womens', ''),
(210, 'Apparel &
Accessories > Clothing > One-Pieces > Jumpsuits & Rompers > Girls', ''),
(211, 'Apparel & Accessories > Clothing > One-
Pieces > Jumpsuits & Rompers > Womens', ''),
(212, 'Apparel & Accessories > Clothing > One-Pieces > Leotards & Unitards
> Boys', ''),
(213, 'Apparel & Accessories > Clothing > One-Pieces > Leotards & Unitards > Girls', ''),
(214, 'Apparel &
Accessories > Clothing > One-Pieces > Leotards & Unitards > Mens', ''),
(215, 'Apparel & Accessories > Clothing > One-
Pieces > Leotards & Unitards > Womens', ''),
(216, 'Apparel & Accessories > Clothing > One-Pieces > Overalls > Boys',
''),
(217, 'Apparel & Accessories > Clothing > One-Pieces > Overalls > Girls', ''),
(218, 'Apparel & Accessories >
Clothing > One-Pieces > Overalls > Mens', ''),
(219, 'Apparel & Accessories > Clothing > One-Pieces > Overalls >
Womens', ''),
(220, 'Apparel & Accessories > Clothing > Outerwear > Chaps > Boys', ''),
(221, 'Apparel & Accessories >
Clothing > Outerwear > Chaps > Girls', ''),
(222, 'Apparel & Accessories > Clothing > Outerwear > Chaps > Mens', ''),
(223, 'Apparel & Accessories > Clothing > Outerwear > Chaps > Womens', ''),
(224, 'Apparel & Accessories > Clothing >
Outerwear > Coats & Jackets > Boys', ''),
(225, 'Apparel & Accessories > Clothing > Outerwear > Coats & Jackets >
Girls', ''),
(226, 'Apparel & Accessories > Clothing > Outerwear > Coats & Jackets > Mens', ''),
(227, 'Apparel &
Accessories > Clothing > Outerwear > Coats & Jackets > Womens', ''),
(228, 'Apparel & Accessories > Clothing > Outerwear
> Rain Pants > Boys', ''),
(229, 'Apparel & Accessories > Clothing > Outerwear > Rain Pants > Girls', ''),
(230,
'Apparel & Accessories > Clothing > Outerwear > Rain Pants > Mens', ''),
(231, 'Apparel & Accessories > Clothing >
Outerwear > Rain Pants > Womens', ''),
(232, 'Apparel & Accessories > Clothing > Outerwear > Rain Suits > Boys', ''),
(233, 'Apparel & Accessories > Clothing > Outerwear > Rain Suits > Girls', ''),
(234, 'Apparel & Accessories > Clothing
> Outerwear > Rain Suits > Mens', ''),
(235, 'Apparel & Accessories > Clothing > Outerwear > Rain Suits > Womens', ''),
(236, 'Apparel & Accessories > Clothing > Outerwear > Snow Pants & Suits > Boys', ''),
(237, 'Apparel & Accessories >
Clothing > Outerwear > Snow Pants & Suits > Girls', ''),
(238, 'Apparel & Accessories > Clothing > Outerwear > Snow
Pants & Suits > Mens', ''),
(239, 'Apparel & Accessories > Clothing > Outerwear > Snow Pants & Suits > Womens', ''),
(240, 'Apparel & Accessories > Clothing > Outerwear > Vests > Boys', ''),
(241, 'Apparel & Accessories > Clothing >
Outerwear > Vests > Girls', ''),
(242, 'Apparel & Accessories > Clothing > Outerwear > Vests > Mens', ''),
(243,
'Apparel & Accessories > Clothing > Outerwear > Vests > Womens', ''),
(244, 'Apparel & Accessories > Clothing > Outfit
Sets > Boys', ''),
(245, 'Apparel & Accessories > Clothing > Outfit Sets > Girls', ''),
(246, 'Apparel & Accessories >
Clothing > Outfit Sets > Mens', ''),
(247, 'Apparel & Accessories > Clothing > Outfit Sets > Womens', ''),
(248,
'Apparel & Accessories > Clothing > Pants > Boys', ''),
(249, 'Apparel & Accessories > Clothing > Pants > Girls', ''),
(250, 'Apparel & Accessories > Clothing > Pants > Mens', ''),
(251, 'Apparel & Accessories > Clothing > Pants > Womens',
''),
(252, 'Apparel & Accessories > Clothing > Shirts & Tops > Boys', ''),
(253, 'Apparel & Accessories > Clothing >
Shirts & Tops > Girls', ''),
(254, 'Apparel & Accessories > Clothing > Shirts & Tops > Mens', ''),
(255, 'Apparel &
Accessories > Clothing > Shirts & Tops > Womens', ''),
(256, 'Apparel & Accessories > Clothing > Shorts > Boys', ''),
(257, 'Apparel & Accessories > Clothing > Shorts > Girls', ''),
(258, 'Apparel & Accessories > Clothing > Shorts >
Mens', ''),
(259, 'Apparel & Accessories > Clothing > Shorts > Womens', ''),
(260, 'Apparel & Accessories > Clothing >
Skirts > Girls', ''),
(261, 'Apparel & Accessories > Clothing > Skirts > Womens', ''),
(262, 'Apparel & Accessories >
Clothing > Skorts > Girls', ''),
(263, 'Apparel & Accessories > Clothing > Skorts > Womens', ''),
(264, 'Apparel &
Accessories > Clothing > Sleepwear & Loungewear > Loungewear > Boys', ''),
(265, 'Apparel & Accessories > Clothing >
Sleepwear & Loungewear > Loungewear > Girls', ''),
(266, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear >
Loungewear > Mens', ''),
(267, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Loungewear > Womens', ''),
(268, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Nightgowns > Girls', ''),
(269, 'Apparel &
Accessories > Clothing > Sleepwear & Loungewear > Nightgowns > Womens', ''),
(270, 'Apparel & Accessories > Clothing >
Sleepwear & Loungewear > Pajamas > Boys', ''),
(271, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear >
Pajamas > Girls', ''),
(272, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Pajamas > Mens', ''),
(273,
'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Pajamas > Womens', ''),
(274, 'Apparel & Accessories >
Clothing > Sleepwear & Loungewear > Robes > Boys', ''),
(275, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear
> Robes > Girls', ''),
(276, 'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Robes > Mens', ''),
(277,
'Apparel & Accessories > Clothing > Sleepwear & Loungewear > Robes > Womens', ''),
(278, 'Apparel & Accessories >
Clothing > Suits > Boys', ''),
(279, 'Apparel & Accessories > Clothing > Suits > Girls', ''),
(280, 'Apparel &
Accessories > Clothing > Suits > Mens', ''),
(281, 'Apparel & Accessories > Clothing > Suits > Pant Suits > Boys', ''),
(282, 'Apparel & Accessories > Clothing > Suits > Pant Suits > Girls', ''),
(283, 'Apparel & Accessories > Clothing >
Suits > Pant Suits > Mens', ''),
(284, 'Apparel & Accessories > Clothing > Suits > Pant Suits > Womens', ''),
(285,
'Apparel & Accessories > Clothing > Suits > Skirt Suits > Girls', ''),
(286, 'Apparel & Accessories > Clothing > Suits >
Skirt Suits > Womens', ''),
(287, 'Apparel & Accessories > Clothing > Suits > Tuxedos > Boys', ''),
(288, 'Apparel &
Accessories > Clothing > Suits > Tuxedos > Girls', ''),
(289, 'Apparel & Accessories > Clothing > Suits > Tuxedos >
Mens', ''),
(290, 'Apparel & Accessories > Clothing > Suits > Tuxedos > Womens', ''),
(291, 'Apparel & Accessories >
Clothing > Suits > Womens', ''),
(292, 'Apparel & Accessories > Clothing > Swimwear > Boys', ''),
(293, 'Apparel &
Accessories > Clothing > Swimwear > Girls', ''),
(294, 'Apparel & Accessories > Clothing > Swimwear > Mens', ''),
(295,
'Apparel & Accessories > Clothing > Swimwear > Womens', ''),
(296, 'Apparel & Accessories > Clothing > Traditional &
Ceremonial Clothing > Dirndls > Girls', ''),
(297, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing
> Dirndls > Womens', ''),
(298, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Hakama Trousers
> Boys', ''),
(299, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Hakama Trousers > Girls',
''),
(300, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Hakama Trousers > Mens', ''),
(301,
'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Hakama Trousers > Womens', ''),
(302, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Japanese Black Formal Wear > Boys', ''),
(303, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Japanese Black Formal Wear > Girls', ''),
(304, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Japanese Black Formal Wear > Mens', ''),
(305, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Japanese Black Formal Wear > Womens', ''),
(306, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Kimono Outerwear > Boys', ''),
(307, 'Apparel & Accessories
> Clothing > Traditional & Ceremonial Clothing > Kimono Outerwear > Girls', ''),
(308, 'Apparel & Accessories > Clothing
> Traditional & Ceremonial Clothing > Kimono Outerwear > Mens', ''),
(309, 'Apparel & Accessories > Clothing >
Traditional & Ceremonial Clothing > Kimono Outerwear > Womens', ''),
(310, 'Apparel & Accessories > Clothing >
Traditional & Ceremonial Clothing > Kimonos > Boys', ''),
(311, 'Apparel & Accessories > Clothing > Traditional &
Ceremonial Clothing > Kimonos > Girls', ''),
(312, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing
> Kimonos > Mens', ''),
(313, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Kimonos > Womens',
''),
(314, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Religious Ceremonial Clothing >
Baptism & Communion Dresses > Boys', ''),
(315, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Religious Ceremonial Clothing > Baptism & Communion Dresses > Girls', ''),
(316, 'Apparel & Accessories > Clothing >
Traditional & Ceremonial Clothing > Religious Ceremonial Clothing > Baptism & Communion Dresses > Mens', ''),
(317,
'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Religious Ceremonial Clothing > Baptism &
Communion Dresses > Womens', ''),
(318, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Religious Ceremonial Clothing > Boys', ''),
(319, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing
> Religious Ceremonial Clothing > Girls', ''),
(320, 'Apparel & Accessories > Clothing > Traditional & Ceremonial
Clothing > Religious Ceremonial Clothing > Mens', ''),
(321, 'Apparel & Accessories > Clothing > Traditional &
Ceremonial Clothing > Religious Ceremonial Clothing > Womens', ''),
(322, 'Apparel & Accessories > Clothing >
Traditional & Ceremonial Clothing > Saris & Lehengas > Boys', ''),
(323, 'Apparel & Accessories > Clothing > Traditional
& Ceremonial Clothing > Saris & Lehengas > Girls', ''),
(324, 'Apparel & Accessories > Clothing > Traditional &
Ceremonial Clothing > Saris & Lehengas > Mens', ''),
(325, 'Apparel & Accessories > Clothing > Traditional & Ceremonial
Clothing > Saris & Lehengas > Womens', ''),
(326, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing
> Traditional Leather Pants > Boys', ''),
(327, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Traditional Leather Pants > Girls', ''),
(328, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Traditional Leather Pants > Mens', ''),
(329, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Traditional Leather Pants > Womens', ''),
(330, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing >
Yukata > Boys', ''),
(331, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Yukata > Girls', ''),
(332, 'Apparel & Accessories > Clothing > Traditional & Ceremonial Clothing > Yukata > Mens', ''),
(333, 'Apparel &
Accessories > Clothing > Traditional & Ceremonial Clothing > Yukata > Womens', ''),
(334, 'Apparel & Accessories >
Clothing > Underwear & Socks > Bra Accessories > Bra Strap Pads > Womens', ''),
(335, 'Apparel & Accessories > Clothing
> Underwear & Socks > Bra Accessories > Bra Straps & Extenders > Womens', ''),
(336, 'Apparel & Accessories > Clothing >
Underwear & Socks > Bra Accessories > Breast Enhancing Inserts > Womens', ''),
(337, 'Apparel & Accessories > Clothing >
Underwear & Socks > Bra Accessories > Breast Petals & Concealers > Womens', ''),
(338, 'Apparel & Accessories > Clothing
> Underwear & Socks > Bras > Girls', ''),
(339, 'Apparel & Accessories > Clothing > Underwear & Socks > Bras > Womens',
''),
(340, 'Apparel & Accessories > Clothing > Underwear & Socks > Hosiery > Girls', ''),
(341, 'Apparel & Accessories >
Clothing > Underwear & Socks > Hosiery > Womens', ''),
(342, 'Apparel & Accessories > Clothing > Underwear & Socks >
Jock Straps > Boys', ''),
(343, 'Apparel & Accessories > Clothing > Underwear & Socks > Jock Straps > Mens', ''),
(344,
'Apparel & Accessories > Clothing > Underwear & Socks > Lingerie > Womens', ''),
(345, 'Apparel & Accessories > Clothing
> Underwear & Socks > Lingerie Accessories > Garter Belts > Womens', ''),
(346, 'Apparel & Accessories > Clothing >
Underwear & Socks > Lingerie Accessories > Garters > Womens', ''),
(347, 'Apparel & Accessories > Clothing > Underwear &
Socks > Lingerie Accessories > Womens', ''),
(348, 'Apparel & Accessories > Clothing > Underwear & Socks > Long Johns >
Boys', ''),
(349, 'Apparel & Accessories > Clothing > Underwear & Socks > Long Johns > Girls', ''),
(350, 'Apparel &
Accessories > Clothing > Underwear & Socks > Long Johns > Mens', ''),
(351, 'Apparel & Accessories > Clothing >
Underwear & Socks > Long Johns > Womens', ''),
(352, 'Apparel & Accessories > Clothing > Underwear & Socks > Petticoats
& Pettipants > Girls', ''),
(353, 'Apparel & Accessories > Clothing > Underwear & Socks > Petticoats & Pettipants >
Womens', ''),
(354, 'Apparel & Accessories > Clothing > Underwear & Socks > Shapewear > Girls', ''),
(355, 'Apparel &
Accessories > Clothing > Underwear & Socks > Shapewear > Womens', ''),
(356, 'Apparel & Accessories > Clothing >
Underwear & Socks > Socks > Boys', ''),
(357, 'Apparel & Accessories > Clothing > Underwear & Socks > Socks > Girls',
''),
(358, 'Apparel & Accessories > Clothing > Underwear & Socks > Socks > Mens', ''),
(359, 'Apparel & Accessories >
Clothing > Underwear & Socks > Socks > Womens', ''),
(360, 'Apparel & Accessories > Clothing > Underwear & Socks >
Undershirts > Boys', ''),
(361, 'Apparel & Accessories > Clothing > Underwear & Socks > Undershirts > Girls', ''),
(362,
'Apparel & Accessories > Clothing > Underwear & Socks > Undershirts > Mens', ''),
(363, 'Apparel & Accessories >
Clothing > Underwear & Socks > Undershirts > Womens', ''),
(364, 'Apparel & Accessories > Clothing > Underwear & Socks >
Underwear > Boys', ''),
(365, 'Apparel & Accessories > Clothing > Underwear & Socks > Underwear > Girls', ''),
(366,
'Apparel & Accessories > Clothing > Underwear & Socks > Underwear > Mens', ''),
(367, 'Apparel & Accessories > Clothing
> Underwear & Socks > Underwear > Womens', ''),
(368, 'Apparel & Accessories > Clothing > Underwear & Socks > Underwear
Slips > Girls', ''),
(369, 'Apparel & Accessories > Clothing > Underwear & Socks > Underwear Slips > Womens', ''),
(370,
'Apparel & Accessories > Clothing > Uniforms > Contractor Pants & Coveralls > Mens', ''),
(371, 'Apparel & Accessories >
Clothing > Uniforms > Contractor Pants & Coveralls > Womens', ''),
(372, 'Apparel & Accessories > Clothing > Uniforms >
Flight Suits > Mens', ''),
(373, 'Apparel & Accessories > Clothing > Uniforms > Flight Suits > Womens', ''),
(374,
'Apparel & Accessories > Clothing > Uniforms > Food Service Uniforms > Chef''s Hats > Mens', ''),
(375, 'Apparel &
Accessories > Clothing > Uniforms > Food Service Uniforms > Chef''s Hats > Womens', ''),
(376, 'Apparel & Accessories >
Clothing > Uniforms > Food Service Uniforms > Chef''s Jackets > Mens', ''),
(377, 'Apparel & Accessories > Clothing >
Uniforms > Food Service Uniforms > Chef''s Jackets > Womens', ''),
(378, 'Apparel & Accessories > Clothing > Uniforms >
Food Service Uniforms > Chef''s Pants > Mens', ''),
(379, 'Apparel & Accessories > Clothing > Uniforms > Food Service
Uniforms > Chef''s Pants > Womens', ''),
(380, 'Apparel & Accessories > Clothing > Uniforms > Food Service Uniforms >
Mens', ''),
(381, 'Apparel & Accessories > Clothing > Uniforms > Food Service Uniforms > Womens', ''),
(382, 'Apparel &
Accessories > Clothing > Uniforms > Military Uniforms > Mens', ''),
(383, 'Apparel & Accessories > Clothing > Uniforms >
Military Uniforms > Womens', ''),
(384, 'Apparel & Accessories > Clothing > Uniforms > School Uniforms > Boys', ''),
(385, 'Apparel & Accessories > Clothing > Uniforms > School Uniforms > Girls', ''),
(386, 'Apparel & Accessories >
Clothing > Uniforms > School Uniforms > Mens', ''),
(387, 'Apparel & Accessories > Clothing > Uniforms > School Uniforms
> Womens', ''),
(388, 'Apparel & Accessories > Clothing > Uniforms > Security Uniforms > Mens', ''),
(389, 'Apparel &
Accessories > Clothing > Uniforms > Security Uniforms > Womens', ''),
(390, 'Apparel & Accessories > Clothing > Uniforms
> Sports Uniforms > Baseball Uniforms > Boys', ''),
(391, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms
> Baseball Uniforms > Girls', ''),
(392, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Baseball
Uniforms > Mens', ''),
(393, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Baseball Uniforms >
Womens', ''),
(394, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Basketball Uniforms > Boys', ''),
(395, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Basketball Uniforms > Girls', ''),
(396, 'Apparel
& Accessories > Clothing > Uniforms > Sports Uniforms > Basketball Uniforms > Mens', ''),
(397, 'Apparel & Accessories >
Clothing > Uniforms > Sports Uniforms > Basketball Uniforms > Womens', ''),
(398, 'Apparel & Accessories > Clothing >
Uniforms > Sports Uniforms > Cheerleading Uniforms > Boys', ''),
(399, 'Apparel & Accessories > Clothing > Uniforms >
Sports Uniforms > Cheerleading Uniforms > Girls', ''),
(400, 'Apparel & Accessories > Clothing > Uniforms > Sports
Uniforms > Cheerleading Uniforms > Mens', ''),
(401, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms >
Cheerleading Uniforms > Womens', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` )
VALUES (402,
'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Cricket Uniforms > Boys', ''),
(403, 'Apparel &
Accessories > Clothing > Uniforms > Sports Uniforms > Cricket Uniforms > Girls', ''),
(404, 'Apparel & Accessories >
Clothing > Uniforms > Sports Uniforms > Cricket Uniforms > Mens', ''),
(405, 'Apparel & Accessories > Clothing >
Uniforms > Sports Uniforms > Cricket Uniforms > Womens', ''),
(406, 'Apparel & Accessories > Clothing > Uniforms >
Sports Uniforms > Football Uniforms > Boys', ''),
(407, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms >
Football Uniforms > Girls', ''),
(408, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Football
Uniforms > Mens', ''),
(409, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Football Uniforms >
Womens', ''),
(410, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Hockey Uniforms > Boys', ''),
(411,
'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Hockey Uniforms > Girls', ''),
(412, 'Apparel &
Accessories > Clothing > Uniforms > Sports Uniforms > Hockey Uniforms > Mens', ''),
(413, 'Apparel & Accessories >
Clothing > Uniforms > Sports Uniforms > Hockey Uniforms > Womens', ''),
(414, 'Apparel & Accessories > Clothing >
Uniforms > Sports Uniforms > Martial Arts Uniforms > Boys', ''),
(415, 'Apparel & Accessories > Clothing > Uniforms >
Sports Uniforms > Martial Arts Uniforms > Girls', ''),
(416, 'Apparel & Accessories > Clothing > Uniforms > Sports
Uniforms > Martial Arts Uniforms > Mens', ''),
(417, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms >
Martial Arts Uniforms > Womens', ''),
(418, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Officiating
Uniforms > Boys', ''),
(419, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Officiating Uniforms >
Girls', ''),
(420, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Officiating Uniforms > Mens', ''),
(421, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Officiating Uniforms > Womens', ''),
(422,
'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Soccer Uniforms > Boys', ''),
(423, 'Apparel &
Accessories > Clothing > Uniforms > Sports Uniforms > Soccer Uniforms > Girls', ''),
(424, 'Apparel & Accessories >
Clothing > Uniforms > Sports Uniforms > Soccer Uniforms > Mens', ''),
(425, 'Apparel & Accessories > Clothing > Uniforms
> Sports Uniforms > Soccer Uniforms > Womens', ''),
(426, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms
> Softball Uniforms > Boys', ''),
(427, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Softball
Uniforms > Girls', ''),
(428, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Softball Uniforms >
Mens', ''),
(429, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Softball Uniforms > Womens', ''),
(430, 'Apparel & Accessories > Clothing > Uniforms > Sports Uniforms > Wrestling Uniforms > Boys', ''),
(431, 'Apparel &
Accessories > Clothing > Uniforms > Sports Uniforms > Wrestling Uniforms > Girls', ''),
(432, 'Apparel & Accessories >
Clothing > Uniforms > Sports Uniforms > Wrestling Uniforms > Mens', ''),
(433, 'Apparel & Accessories > Clothing >
Uniforms > Sports Uniforms > Wrestling Uniforms > Womens', ''),
(434, 'Apparel & Accessories > Clothing > Uniforms >
White Coats > Mens', ''),
(435, 'Apparel & Accessories > Clothing > Uniforms > White Coats > Womens', ''),
(436,
'Apparel & Accessories > Clothing > Wedding & Bridal Party Dresses > Bridal Party Dresses > Womens', ''),
(437, 'Apparel
& Accessories > Clothing > Wedding & Bridal Party Dresses > Wedding Dresses > Womens', ''),
(438, 'Apparel & Accessories
> Clothing Accessories > Arm Warmers & Sleeves > Boys', ''),
(439, 'Apparel & Accessories > Clothing Accessories > Arm
Warmers & Sleeves > Girls', ''),
(440, 'Apparel & Accessories > Clothing Accessories > Arm Warmers & Sleeves > Mens',
''),
(441, 'Apparel & Accessories > Clothing Accessories > Arm Warmers & Sleeves > Womens', ''),
(442, 'Apparel &
Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Belts > Boys', ''),
(443,
'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Belts > Girls',
''),
(444, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Belts >
Kids (unisex)', ''),
(445, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby &
Toddler Gloves & Mittens > Boys', ''),
(446, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing
Accessories > Baby & Toddler Gloves & Mittens > Girls', ''),
(447, 'Apparel & Accessories > Clothing Accessories > Baby
& Toddler Clothing Accessories > Baby & Toddler Gloves & Mittens > Kids (unisex)', ''),
(448, 'Apparel & Accessories >
Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Hats > Boys', ''),
(449, 'Apparel &
Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Hats > Girls', ''),
(450,
'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby & Toddler Hats > Kids
(unisex)', ''),
(451, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories > Baby
Protective Wear > Boys', ''),
(452, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing Accessories
> Baby Protective Wear > Girls', ''),
(453, 'Apparel & Accessories > Clothing Accessories > Baby & Toddler Clothing
Accessories > Baby Protective Wear > Kids (unisex)', ''),
(454, 'Apparel & Accessories > Clothing Accessories >
Balaclavas > Adult (unisex)', ''),
(455, 'Apparel & Accessories > Clothing Accessories > Balaclavas > Kids (unisex)',
''),
(456, 'Apparel & Accessories > Clothing Accessories > Bandanas & Headties > Adult (unisex)', ''),
(457, 'Apparel &
Accessories > Clothing Accessories > Bandanas & Headties > Boys', ''),
(458, 'Apparel & Accessories > Clothing
Accessories > Bandanas & Headties > Girls', ''),
(459, 'Apparel & Accessories > Clothing Accessories > Bandanas &
Headties > Kids (unisex)', ''),
(460, 'Apparel & Accessories > Clothing Accessories > Bandanas & Headties > Mens', ''),
(461, 'Apparel & Accessories > Clothing Accessories > Bandanas & Headties > Womens', ''),
(462, 'Apparel & Accessories >
Clothing Accessories > Belt Buckles > Boys', ''),
(463, 'Apparel & Accessories > Clothing Accessories > Belt Buckles >
Girls', ''),
(464, 'Apparel & Accessories > Clothing Accessories > Belt Buckles > Mens', ''),
(465, 'Apparel &
Accessories > Clothing Accessories > Belt Buckles > Womens', ''),
(466, 'Apparel & Accessories > Clothing Accessories >
Belts > Boys', ''),
(467, 'Apparel & Accessories > Clothing Accessories > Belts > Girls', ''),
(468, 'Apparel &
Accessories > Clothing Accessories > Belts > Mens', ''),
(469, 'Apparel & Accessories > Clothing Accessories > Belts >
Womens', ''),
(470, 'Apparel & Accessories > Clothing Accessories > Bridal Accessories > Bridal Veils > Womens', ''),
(471, 'Apparel & Accessories > Clothing Accessories > Bridal Accessories > Womens', ''),
(472, 'Apparel & Accessories >
Clothing Accessories > Button Studs > Adult (unisex)', ''),
(473, 'Apparel & Accessories > Clothing Accessories > Button
Studs > Kids (unisex)', ''),
(474, 'Apparel & Accessories > Clothing Accessories > Collar Stays > Adult (unisex)', ''),
(475, 'Apparel & Accessories > Clothing Accessories > Collar Stays > Kids (unisex)', ''),
(476, 'Apparel & Accessories >
Clothing Accessories > Cufflinks > Adult (unisex)', ''),
(477, 'Apparel & Accessories > Clothing Accessories > Cufflinks
> Kids (unisex)', ''),
(478, 'Apparel & Accessories > Clothing Accessories > Decorative Fans > Adult (unisex)', ''),
(479, 'Apparel & Accessories > Clothing Accessories > Decorative Fans > Kids (unisex)', ''),
(480, 'Apparel &
Accessories > Clothing Accessories > Earmuffs > Adult (unisex)', ''),
(481, 'Apparel & Accessories > Clothing
Accessories > Earmuffs > Kids (unisex)', ''),
(482, 'Apparel & Accessories > Clothing Accessories > Gloves & Mittens >
Boys', ''),
(483, 'Apparel & Accessories > Clothing Accessories > Gloves & Mittens > Girls', ''),
(484, 'Apparel &
Accessories > Clothing Accessories > Gloves & Mittens > Mens', ''),
(485, 'Apparel & Accessories > Clothing Accessories
> Gloves & Mittens > Womens', ''),
(486, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Bun &
Volume Shapers > Adult (unisex)', ''),
(487, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Bun
& Volume Shapers > Kids (unisex)', ''),
(488, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair
Combs > Adult (unisex)', ''),
(489, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Combs > Kids
(unisex)', ''),
(490, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Extensions > Adult
(unisex)', ''),
(491, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Extensions > Kids
(unisex)', ''),
(492, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Forks & Sticks > Adult
(unisex)', ''),
(493, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Forks & Sticks > Kids
(unisex)', ''),
(494, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Nets > Adult (unisex)',
''),
(495, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Nets > Kids (unisex)', ''),
(496,
'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Pins,Claws & Clips > Adult (unisex)', ''),
(497,
'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Pins,Claws & Clips > Kids (unisex)', ''),
(498,
'Apparel & Accessories > Clothing Accessories > Hair Accessories > Hair Wreaths > Adult (unisex)', ''),
(499, 'Apparel &
Accessories > Clothing Accessories > Hair Accessories > Hair Wreaths > Kids (unisex)', ''),
(500, 'Apparel & Accessories
> Clothing Accessories > Hair Accessories > Headbands > Adult (unisex)', ''),
(501, 'Apparel & Accessories > Clothing
Accessories > Hair Accessories > Headbands > Kids (unisex)', ''),
(502, 'Apparel & Accessories > Clothing Accessories >
Hair Accessories > Ponytail Holders > Adult (unisex)', ''),
(503, 'Apparel & Accessories > Clothing Accessories > Hair
Accessories > Ponytail Holders > Kids (unisex)', ''),
(504, 'Apparel & Accessories > Clothing Accessories > Hair
Accessories > Tiaras > Boys', ''),
(505, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Tiaras >
Girls', ''),
(506, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Tiaras > Mens', ''),
(507,
'Apparel & Accessories > Clothing Accessories > Hair Accessories > Tiaras > Womens', ''),
(508, 'Apparel & Accessories >
Clothing Accessories > Hair Accessories > Wig Accessories > Wig Caps > Adult (unisex)', ''),
(509, 'Apparel &
Accessories > Clothing Accessories > Hair Accessories > Wig Accessories > Wig Caps > Kids (unisex)', ''),
(510, 'Apparel
& Accessories > Clothing Accessories > Hair Accessories > Wig Accessories > Wig Glue & Tape > Adult (unisex)', ''),
(511, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Wig Accessories > Wig Glue & Tape > Kids
(unisex)', ''),
(512, 'Apparel & Accessories > Clothing Accessories > Hair Accessories > Wigs > Boys', ''),
(513,
'Apparel & Accessories > Clothing Accessories > Hair Accessories > Wigs > Girls', ''),
(514, 'Apparel & Accessories >
Clothing Accessories > Hair Accessories > Wigs > Mens', ''),
(515, 'Apparel & Accessories > Clothing Accessories > Hair
Accessories > Wigs > Womens', ''),
(516, 'Apparel & Accessories > Clothing Accessories > Hand Muffs > Adult (unisex)',
''),
(517, 'Apparel & Accessories > Clothing Accessories > Hand Muffs > Kids (unisex)', ''),
(518, 'Apparel &
Accessories > Clothing Accessories > Handkerchiefs > Adult (unisex)', ''),
(519, 'Apparel & Accessories > Clothing
Accessories > Handkerchiefs > Kids (unisex)', ''),
(520, 'Apparel & Accessories > Clothing Accessories > Hats > Boys',
''),
(521, 'Apparel & Accessories > Clothing Accessories > Hats > Girls', ''),
(522, 'Apparel & Accessories > Clothing
Accessories > Hats > Mens', ''),
(523, 'Apparel & Accessories > Clothing Accessories > Hats > Womens', ''),
(524,
'Apparel & Accessories > Clothing Accessories > Headwear > Fascinators > Girls', ''),
(525, 'Apparel & Accessories >
Clothing Accessories > Headwear > Fascinators > Womens', ''),
(526, 'Apparel & Accessories > Clothing Accessories >
Headwear > Headdresses > Girls', ''),
(527, 'Apparel & Accessories > Clothing Accessories > Headwear > Headdresses >
Womens', ''),
(528, 'Apparel & Accessories > Clothing Accessories > Headwear > Turbans > Boys', ''),
(529, 'Apparel &
Accessories > Clothing Accessories > Headwear > Turbans > Mens', ''),
(530, 'Apparel & Accessories > Clothing
Accessories > Leg Warmers > Boys', ''),
(531, 'Apparel & Accessories > Clothing Accessories > Leg Warmers > Girls', ''),
(532, 'Apparel & Accessories > Clothing Accessories > Leg Warmers > Mens', ''),
(533, 'Apparel & Accessories > Clothing
Accessories > Leg Warmers > Womens', ''),
(534, 'Apparel & Accessories > Clothing Accessories > Leis > Boys', ''),
(535,
'Apparel & Accessories > Clothing Accessories > Leis > Girls', ''),
(536, 'Apparel & Accessories > Clothing Accessories
> Leis > Mens', ''),
(537, 'Apparel & Accessories > Clothing Accessories > Leis > Womens', ''),
(538, 'Apparel &
Accessories > Clothing Accessories > Maternity Belts & Support Bands > Girls', ''),
(539, 'Apparel & Accessories >
Clothing Accessories > Maternity Belts & Support Bands > Womens', ''),
(540, 'Apparel & Accessories > Clothing
Accessories > Neck Gaiters > Boys', ''),
(541, 'Apparel & Accessories > Clothing Accessories > Neck Gaiters > Girls',
''),
(542, 'Apparel & Accessories > Clothing Accessories > Neck Gaiters > Mens', ''),
(543, 'Apparel & Accessories >
Clothing Accessories > Neck Gaiters > Womens', ''),
(544, 'Apparel & Accessories > Clothing Accessories > Neckties >
Boys', ''),
(545, 'Apparel & Accessories > Clothing Accessories > Neckties > Girls', ''),
(546, 'Apparel & Accessories >
Clothing Accessories > Neckties > Mens', ''),
(547, 'Apparel & Accessories > Clothing Accessories > Neckties > Womens',
''),
(548, 'Apparel & Accessories > Clothing Accessories > Pinback Buttons > Boys', ''),
(549, 'Apparel & Accessories >
Clothing Accessories > Pinback Buttons > Girls', ''),
(550, 'Apparel & Accessories > Clothing Accessories > Pinback
Buttons > Mens', ''),
(551, 'Apparel & Accessories > Clothing Accessories > Pinback Buttons > Womens', ''),
(552,
'Apparel & Accessories > Clothing Accessories > Sashes > Girls', ''),
(553, 'Apparel & Accessories > Clothing
Accessories > Sashes > Womens', ''),
(554, 'Apparel & Accessories > Clothing Accessories > Scarves & Shawls > Boys',
''),
(555, 'Apparel & Accessories > Clothing Accessories > Scarves & Shawls > Girls', ''),
(556, 'Apparel & Accessories
> Clothing Accessories > Scarves & Shawls > Mens', ''),
(557, 'Apparel & Accessories > Clothing Accessories > Scarves &
Shawls > Womens', ''),
(558, 'Apparel & Accessories > Clothing Accessories > Sunglasses > Adult (unisex)', ''),
(559,
'Apparel & Accessories > Clothing Accessories > Sunglasses > Boys', ''),
(560, 'Apparel & Accessories > Clothing
Accessories > Sunglasses > Girls', ''),
(561, 'Apparel & Accessories > Clothing Accessories > Sunglasses > Kids
(unisex)', ''),
(562, 'Apparel & Accessories > Clothing Accessories > Sunglasses > Mens', ''),
(563, 'Apparel &
Accessories > Clothing Accessories > Sunglasses > Womens', ''),
(564, 'Apparel & Accessories > Clothing Accessories >
Suspenders > Girls', ''),
(565, 'Apparel & Accessories > Clothing Accessories > Suspenders > Womens', ''),
(566,
'Apparel & Accessories > Clothing Accessories > Tie Clips > Adult (unisex)', ''),
(567, 'Apparel & Accessories >
Clothing Accessories > Tie Clips > Kids (unisex)', ''),
(568, 'Apparel & Accessories > Clothing Accessories >
Traditional Clothing Accessories > Obis > Girls', ''),
(569, 'Apparel & Accessories > Clothing Accessories > Traditional
Clothing Accessories > Obis > Womens', ''),
(570, 'Apparel & Accessories > Clothing Accessories > Traditional Clothing
Accessories > Tabi Socks > Girls', ''),
(571, 'Apparel & Accessories > Clothing Accessories > Traditional Clothing
Accessories > Tabi Socks > Womens', ''),
(572, 'Apparel & Accessories > Clothing Accessories > Wristbands > Adult
(unisex)', ''),
(573, 'Apparel & Accessories > Clothing Accessories > Wristbands > Kids (unisex)', ''),
(574, 'Apparel &
Accessories > Costumes & Accessories > Costume Accessories > Bald Caps > Adult (unisex)', ''),
(575, 'Apparel &
Accessories > Costumes & Accessories > Costume Accessories > Bald Caps > Kids (unisex)', ''),
(576, 'Apparel &
Accessories > Costumes & Accessories > Costume Accessories > Costume Accessory Sets > Adult (unisex)', ''),
(577,
'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Accessory Sets > Kids (unisex)', ''),
(578, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Capes > Adult (unisex)', ''),
(579, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Capes > Kids (unisex)', ''),
(580,
'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Gloves > Adult (unisex)', ''),
(581,
'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Gloves > Boys', ''),
(582, 'Apparel &
Accessories > Costumes & Accessories > Costume Accessories > Costume Gloves > Girls', ''),
(583, 'Apparel & Accessories
> Costumes & Accessories > Costume Accessories > Costume Gloves > Kids (unisex)', ''),
(584, 'Apparel & Accessories >
Costumes & Accessories > Costume Accessories > Costume Gloves > Mens', ''),
(585, 'Apparel & Accessories > Costumes &
Accessories > Costume Accessories > Costume Gloves > Womens', ''),
(586, 'Apparel & Accessories > Costumes & Accessories
> Costume Accessories > Costume Hats > Adult (unisex)', ''),
(587, 'Apparel & Accessories > Costumes & Accessories >
Costume Accessories > Costume Hats > Boys', ''),
(588, 'Apparel & Accessories > Costumes & Accessories > Costume
Accessories > Costume Hats > Girls', ''),
(589, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories >
Costume Hats > Kids (unisex)', ''),
(590, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories >
Costume Hats > Mens', ''),
(591, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Hats >
Womens', ''),
(592, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Special Effects >
Adult (unisex)', ''),
(593, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume Special
Effects > Kids (unisex)', ''),
(594, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories > Costume
Tobacco Products > Adult (unisex)', ''),
(595, 'Apparel & Accessories > Costumes & Accessories > Costume Accessories >
Costume Tobacco Products > Kids (unisex)', ''),
(596, 'Apparel & Accessories > Costumes & Accessories > Costume
Accessories > Pretend Jewelry > Adult (unisex)', ''),
(597, 'Apparel & Accessories > Costumes & Accessories > Costume
Accessories > Pretend Jewelry > Kids (unisex)', ''),
(598, 'Apparel & Accessories > Costumes & Accessories > Costume
Shoes > Adult (unisex)', ''),
(599, 'Apparel & Accessories > Costumes & Accessories > Costume Shoes > Boys', ''),
(600,
'Apparel & Accessories > Costumes & Accessories > Costume Shoes > Girls', ''),
(601, 'Apparel & Accessories > Costumes &
Accessories > Costume Shoes > Kids (unisex)', ''),
(602, 'Apparel & Accessories > Costumes & Accessories > Costume Shoes
> Mens', ''),
(603, 'Apparel & Accessories > Costumes & Accessories > Costume Shoes > Womens', ''),
(604, 'Apparel &
Accessories > Costumes & Accessories > Costumes > Adult (unisex)', ''),
(605, 'Apparel & Accessories > Costumes &
Accessories > Costumes > Boys', ''),
(606, 'Apparel & Accessories > Costumes & Accessories > Costumes > Girls', ''),
(607, 'Apparel & Accessories > Costumes & Accessories > Costumes > Kids (unisex)', ''),
(608, 'Apparel & Accessories >
Costumes & Accessories > Costumes > Mens', ''),
(609, 'Apparel & Accessories > Costumes & Accessories > Costumes >
Womens', ''),
(610, 'Apparel & Accessories > Costumes & Accessories > Masks > Adult (unisex)', ''),
(611, 'Apparel &
Accessories > Costumes & Accessories > Masks > Boys', ''),
(612, 'Apparel & Accessories > Costumes & Accessories > Masks
> Girls', ''),
(613, 'Apparel & Accessories > Costumes & Accessories > Masks > Kids (unisex)', ''),
(614, 'Apparel &
Accessories > Costumes & Accessories > Masks > Mens', ''),
(615, 'Apparel & Accessories > Costumes & Accessories > Masks
> Womens', ''),
(616, 'Apparel & Accessories > Handbag & Wallet Accessories > Checkbook Covers > Adult (unisex)', ''),
(617, 'Apparel & Accessories > Handbag & Wallet Accessories > Checkbook Covers > Kids (unisex)', ''),
(618, 'Apparel &
Accessories > Handbag & Wallet Accessories > Keychains > Adult (unisex)', ''),
(619, 'Apparel & Accessories > Handbag &
Wallet Accessories > Keychains > Kids (unisex)', ''),
(620, 'Apparel & Accessories > Handbag & Wallet Accessories >
Lanyards > Adult (unisex)', ''),
(621, 'Apparel & Accessories > Handbag & Wallet Accessories > Lanyards > Kids
(unisex)', ''),
(622, 'Apparel & Accessories > Handbag & Wallet Accessories > Wallet Chains > Adult (unisex)', ''),
(623, 'Apparel & Accessories > Handbag & Wallet Accessories > Wallet Chains > Kids (unisex)', ''),
(624, 'Apparel &
Accessories > Handbags,Wallets & Cases > Badge & Pass Holders > Adult (unisex)', ''),
(625, 'Apparel & Accessories >
Handbags,Wallets & Cases > Badge & Pass Holders > Kids (unisex)', ''),
(626, 'Apparel & Accessories > Handbags,Wallets &
Cases > Business Card Cases > Adult (unisex)', ''),
(627, 'Apparel & Accessories > Handbags,Wallets & Cases > Business
Card Cases > Kids (unisex)', ''),
(628, 'Apparel & Accessories > Handbags,Wallets & Cases > Handbags > Girls', ''),
(629, 'Apparel & Accessories > Handbags,Wallets & Cases > Handbags > Womens', ''),
(630, 'Apparel & Accessories >
Handbags,Wallets & Cases > Wallets & Money Clips > Adult (unisex)', ''),
(631, 'Apparel & Accessories > Handbags,Wallets
& Cases > Wallets & Money Clips > Kids (unisex)', ''),
(632, 'Apparel & Accessories > Jewelry > Anklets > Boys', ''),
(633, 'Apparel & Accessories > Jewelry > Anklets > Girls', ''),
(634, 'Apparel & Accessories > Jewelry > Anklets >
Mens', ''),
(635, 'Apparel & Accessories > Jewelry > Anklets > Womens', ''),
(636, 'Apparel & Accessories > Jewelry >
Body Jewelry > Boys', ''),
(637, 'Apparel & Accessories > Jewelry > Body Jewelry > Girls', ''),
(638, 'Apparel &
Accessories > Jewelry > Body Jewelry > Mens', ''),
(639, 'Apparel & Accessories > Jewelry > Body Jewelry > Womens', ''),
(640, 'Apparel & Accessories > Jewelry > Bracelets > Boys', ''),
(641, 'Apparel & Accessories > Jewelry > Bracelets >
Girls', ''),
(642, 'Apparel & Accessories > Jewelry > Bracelets > Mens', ''),
(643, 'Apparel & Accessories > Jewelry >
Bracelets > Womens', ''),
(644, 'Apparel & Accessories > Jewelry > Brooches & Lapel Pins > Boys', ''),
(645, 'Apparel &
Accessories > Jewelry > Brooches & Lapel Pins > Girls', ''),
(646, 'Apparel & Accessories > Jewelry > Brooches & Lapel
Pins > Mens', ''),
(647, 'Apparel & Accessories > Jewelry > Brooches & Lapel Pins > Womens', ''),
(648, 'Apparel &
Accessories > Jewelry > Charms & Pendants > Boys', ''),
(649, 'Apparel & Accessories > Jewelry > Charms & Pendants >
Girls', ''),
(650, 'Apparel & Accessories > Jewelry > Charms & Pendants > Mens', ''),
(651, 'Apparel & Accessories >
Jewelry > Charms & Pendants > Womens', ''),
(652, 'Apparel & Accessories > Jewelry > Earrings > Boys', ''),
(653,
'Apparel & Accessories > Jewelry > Earrings > Girls', ''),
(654, 'Apparel & Accessories > Jewelry > Earrings > Mens',
''),
(655, 'Apparel & Accessories > Jewelry > Earrings > Womens', ''),
(656, 'Apparel & Accessories > Jewelry > Jewelry
Sets > Boys', ''),
(657, 'Apparel & Accessories > Jewelry > Jewelry Sets > Girls', ''),
(658, 'Apparel & Accessories >
Jewelry > Jewelry Sets > Mens', ''),
(659, 'Apparel & Accessories > Jewelry > Jewelry Sets > Womens', ''),
(660,
'Apparel & Accessories > Jewelry > Necklaces > Boys', ''),
(661, 'Apparel & Accessories > Jewelry > Necklaces > Girls',
''),
(662, 'Apparel & Accessories > Jewelry > Necklaces > Mens', ''),
(663, 'Apparel & Accessories > Jewelry > Necklaces
> Womens', ''),
(664, 'Apparel & Accessories > Jewelry > Rings > Boys', ''),
(665, 'Apparel & Accessories > Jewelry >
Rings > Girls', ''),
(666, 'Apparel & Accessories > Jewelry > Rings > Mens', ''),
(667, 'Apparel & Accessories > Jewelry
> Rings > Womens', ''),
(668, 'Apparel & Accessories > Jewelry > Watch Accessories > Watch Bands > Adult (unisex)', ''),
(669, 'Apparel & Accessories > Jewelry > Watch Accessories > Watch Bands > Boys', ''),
(670, 'Apparel & Accessories >
Jewelry > Watch Accessories > Watch Bands > Girls', ''),
(671, 'Apparel & Accessories > Jewelry > Watch Accessories >
Watch Bands > Kids (unisex)', ''),
(672, 'Apparel & Accessories > Jewelry > Watch Accessories > Watch Bands > Mens',
''),
(673, 'Apparel & Accessories > Jewelry > Watch Accessories > Watch Bands > Womens', ''),
(674, 'Apparel &
Accessories > Jewelry > Watch Accessories > Watch Stickers & Decals > Adult (unisex)', ''),
(675, 'Apparel & Accessories
> Jewelry > Watch Accessories > Watch Stickers & Decals > Kids (unisex)', ''),
(676, 'Apparel & Accessories > Jewelry >
Watch Accessories > Watch Winders > Adult (unisex)', ''),
(677, 'Apparel & Accessories > Jewelry > Watch Accessories >
Watch Winders > Kids (unisex)', ''),
(678, 'Apparel & Accessories > Jewelry > Watches > Adult (unisex)', ''),
(679,
'Apparel & Accessories > Jewelry > Watches > Boys', ''),
(680, 'Apparel & Accessories > Jewelry > Watches > Girls', ''),
(681, 'Apparel & Accessories > Jewelry > Watches > Kids (unisex)', ''),
(682, 'Apparel & Accessories > Jewelry > Watches
> Mens', ''),
(683, 'Apparel & Accessories > Jewelry > Watches > Womens', ''),
(684, 'Apparel & Accessories > Shoe
Accessories > Boot Liners > Adult (unisex)', ''),
(685, 'Apparel & Accessories > Shoe Accessories > Boot Liners > Kids
(unisex)', ''),
(686, 'Apparel & Accessories > Shoe Accessories > Gaiters > Adult (unisex)', ''),
(687, 'Apparel &
Accessories > Shoe Accessories > Gaiters > Kids (unisex)', ''),
(688, 'Apparel & Accessories > Shoe Accessories > Shoe
Covers > Adult (unisex)', ''),
(689, 'Apparel & Accessories > Shoe Accessories > Shoe Covers > Kids (unisex)', ''),
(690, 'Apparel & Accessories > Shoe Accessories > Shoelaces > Adult (unisex)', ''),
(691, 'Apparel & Accessories > Shoe
Accessories > Shoelaces > Kids (unisex)', ''),
(692, 'Apparel & Accessories > Shoe Accessories > Spurs > Adult
(unisex)', ''),
(693, 'Apparel & Accessories > Shoe Accessories > Spurs > Kids (unisex)', ''),
(694, 'Apparel &
Accessories > Shoes > Adult (unisex)', ''),
(695, 'Apparel & Accessories > Shoes > Boys', ''),
(696, 'Apparel &
Accessories > Shoes > Girls', ''),
(697, 'Apparel & Accessories > Shoes > Kids (unisex)', ''),
(698, 'Apparel &
Accessories > Shoes > Mens', ''),
(699, 'Apparel & Accessories > Shoes > Womens', ''),
(700, 'Arts & Entertainment >
Event Tickets', ''),
(701, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Candle
Making Kits', ''),
(702, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Drawing &
Painting Kits', ''),
(703, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Fabric
Repair Kits', ''),
(704, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Incense
Making Kits', ''),
(705, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Jewelry
Making Kits', ''),
(706, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Mosaic
Kits', ''),
(707, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Needlecraft
Kits', ''),
(708, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Scrapbooking &
Stamping Kits', ''),
(709, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Craft Kits > Toy
Craft Kits', ''),
(710, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Art
& Craft Paper > Cardstock & Scrapbooking Paper', ''),
(711, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Materials > Art & Craft Paper > Construction Paper', ''),
(712, 'Arts & Entertainment > Hobbies
& Creative Arts > Arts & Crafts > Art & Crafting Materials > Art & Craft Paper > Craft Foil', ''),
(713, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Art & Craft Paper > Drawing &
Painting Paper', ''),
(714, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials >
Art & Craft Paper > Origami Paper', ''),
(715, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Materials > Art & Craft Paper > Transfer Paper', ''),
(716, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Materials > Art & Craft Paper > Vellum Paper', ''),
(717, 'Arts & Entertainment > Hobbies
& Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Fasteners & Closures > Buttons & Snaps', ''),
(718,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Fasteners & Closures
> Clasps & Hooks', ''),
(719, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials
> Craft Fasteners & Closures > Eyelets & Grommets', ''),
(720, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Materials > Craft Fasteners & Closures > Hook and Loop Fasteners', ''),
(721, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Fasteners & Closures > Zipper
Pulls', ''),
(722, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft
Fasteners & Closures > Zippers', ''),
(723, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Materials > Craft Paint,Ink & Glaze > Art & Craft Paint', ''),
(724, 'Arts & Entertainment > Hobbies & Creative
Arts > Arts & Crafts > Art & Crafting Materials > Craft Paint,Ink & Glaze > Art Fixatives', ''),
(725, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Paint,Ink & Glaze > Art Ink',
''),
(726, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Paint,Ink
& Glaze > Ceramic & Pottery Glazes', ''),
(727, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Materials > Craft Paint,Ink & Glaze > Craft Dyes', ''),
(728, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Materials > Craft Paint,Ink & Glaze > Ink Pads', ''),
(729, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Paint,Ink & Glaze > Paint Mediums', ''),
(730, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Shapes & Bases
> Craft Foam & Styrofoam', ''),
(731, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Materials > Craft Shapes & Bases > Craft Wood & Shapes', ''),
(732, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Materials > Craft Shapes & Bases > Papier Mache Shapes', ''),
(733, 'Arts & Entertainment
> Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Craft Shapes & Bases > Wreath & Floral Frames',
''),
(734, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting
Adhesives & Magnets > Craft & Office Glue', ''),
(735, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts >
Art & Crafting Materials > Crafting Adhesives & Magnets > Craft Magnets', ''),
(736, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting Adhesives & Magnets > Decorative Tape', ''),
(737,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting Adhesives &
Magnets > Floral Tape', ''),
(738, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Materials > Crafting Adhesives & Magnets > Fusible Tape', ''),
(739, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Materials > Crafting Fibers > Jewelry & Beading Cord', ''),
(740, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting Fibers > Thread & Floss', ''),
(741, 'Arts
& Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting Fibers > Unspun Fiber',
''),
(742, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Crafting Fibers
> Yarn', ''),
(743, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials >
Crafting Wire > Craft Pipe Cleaners', ''),
(744, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Materials > Crafting Wire > Floral Wire', ''),
(745, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Materials > Crafting Wire > Jewelry & Beading Wire', ''),
(746, 'Arts & Entertainment > Hobbies
& Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments & Trims > Appliques & Patches', ''),
(747,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments & Trims >
Beads', ''),
(748, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials >
Embellishments & Trims > Bows & Yo-Yos', ''),
(749, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts >
Art & Crafting Materials > Embellishments & Trims > Decorative Stickers', ''),
(750, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments & Trims > Elastic', ''),
(751, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments & Trims > Feathers',
''),
(752, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments &
Trims > Jewelry Findings', ''),
(753, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Materials > Embellishments & Trims > Loose Stones', ''),
(754, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Materials > Embellishments & Trims > Rhinestones & Flatbacks', ''),
(755, 'Arts & Entertainment
> Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments & Trims > Ribbons & Trim', ''),
(756, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Embellishments &
Trims > Sequins & Glitter', ''),
(757, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Materials > Embellishments & Trims > Sew-in Labels', ''),
(758, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Materials > Embossing Powder', ''),
(759, 'Arts & Entertainment > Hobbies & Creative Arts > Arts
& Crafts > Art & Crafting Materials > Filling & Padding Material > Batting & Stuffing', ''),
(760, 'Arts & Entertainment
> Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Filling & Padding Material > Filling Pellets',
''),
(761, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Filling &
Padding Material > Pillow Forms', ''),
(762, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Materials > Leather & Vinyl', ''),
(763, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art
& Crafting Materials > Pottery & Sculpting Materials > Clay & Modeling Dough', ''),
(764, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Pottery & Sculpting Materials > Papier Mache
Mixes', ''),
(765, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Pottery
& Sculpting Materials > Plaster Gauze', ''),
(766, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art
& Crafting Materials > Pottery & Sculpting Materials > Pottery Slips', ''),
(767, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Raw Candle Wax', ''),
(768, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles', ''),
(769, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Crafting Canvas > Needlecraft Canvas', ''),
(770,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Crafting Canvas
> Painting Canvas', ''),
(771, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Materials > Textiles > Crafting Canvas > Plastic Canvas', ''),
(772, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Materials > Textiles > Fabric', ''),
(773, 'Arts & Entertainment > Hobbies & Creative
Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Interfacing', ''),
(774, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Materials > Textiles > Printable Fabric', ''),
(775, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Wick Tabs', '');";         $sql[] =
    "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` )
    VALUES (776, 'Arts & Entertainment
> Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Materials > Wicks', ''),
(777, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tool Accessories > Craft Knife Blades', ''),
(778, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tool Accessories > Craft Machine Cases &
Covers', ''),
(779, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tool Accessories >
Sewing Machine Extension Tables', ''),
(780, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Tool Accessories > Sewing Machine Feet', ''),
(781, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Tool Accessories > Sewing Machine Replacement Parts', ''),
(782, 'Arts & Entertainment > Hobbies
& Creative Arts > Arts & Crafts > Art & Crafting Tool Accessories > Spinning Wheel Accessories', ''),
(783, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tool Accessories > Stamp Blocks', ''),
(784,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Blocking Mats', ''),
(785,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Blocking Wires', ''),
(786,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Color Mixing Tools', ''),
(787,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Color Mixing Tools > Palette
Knives', ''),
(788, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Color
Mixing Tools > Palettes', ''),
(789, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Tools > Craft Cutting & Embossing Tools > Craft & Office Scissors', ''),
(790, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Cutting & Embossing Tools > Craft Cutters & Embossers',
''),
(791, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Cutting &
Embossing Tools > Craft Knives', ''),
(792, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Tools > Craft Cutting & Embossing Tools > Craft Scoring Tools', ''),
(793, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Cutting & Embossing Tools > Embossing Heat Tools', ''),
(794, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Cutting & Embossing
Tools > Embossing Pens & Styluses', ''),
(795, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Tools > Craft Cutting & Embossing Tools > Seam Rippers', ''),
(796, 'Arts & Entertainment > Hobbies & Creative
Arts > Arts & Crafts > Art & Crafting Tools > Craft Cutting & Embossing Tools > Thread & Yarn Cutters', ''),
(797, 'Arts
& Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Decoration Makers', ''),
(798,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring & Marking Tools
> Art Brushes', ''),
(799, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools >
Craft Measuring & Marking Tools > Brayer Rollers', ''),
(800, 'Arts & Entertainment > Hobbies & Creative Arts > Arts &
Crafts > Art & Crafting Tools > Craft Measuring & Marking Tools > Decorative Stamps', ''),
(801, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring & Marking Tools > Drafting Compasses',
''),
(802, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring &
Marking Tools > Screen Printing Squeegees', ''),
(803, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts >
Art & Crafting Tools > Craft Measuring & Marking Tools > Stencil Machines', ''),
(804, 'Arts & Entertainment > Hobbies &
Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring & Marking Tools > Stencils & Die Cuts', ''),
(805, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring & Marking
Tools > Stitch Markers & Counters', ''),
(806, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Tools > Craft Measuring & Marking Tools > Textile Art Gauges & Rulers', ''),
(807, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Craft Measuring & Marking Tools > Wood Burning Tools',
''),
(808, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Cutting Mats', ''),
(809, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Dress Forms', ''),
(810,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Felting Pads & Mats', ''),
(811, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Frames,Hoops &
Stretchers', ''),
(812, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Glue
Guns', ''),
(813, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Light Boxes',
''),
(814, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Needles & Hooks >
Crochet Hooks', ''),
(815, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools >
Needles & Hooks > Hand-Sewing Needles', ''),
(816, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art
& Crafting Tools > Needles & Hooks > Knitting Needles', ''),
(817, 'Arts & Entertainment > Hobbies & Creative Arts >
Arts & Crafts > Art & Crafting Tools > Needles & Hooks > Latch & Locker Hooks', ''),
(818, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Needles & Hooks > Sewing Machine Needles', ''),
(819,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Safety Pins', ''),
(820, 'Arts
& Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Straight Pins', ''),
(821, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Textile Craft Machines > Felting
Needles & Machines', ''),
(822, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools >
Textile Craft Machines > Hand Looms', ''),
(823, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art &
Crafting Tools > Textile Craft Machines > Mechanical Looms', ''),
(824, 'Arts & Entertainment > Hobbies & Creative Arts
> Arts & Crafts > Art & Crafting Tools > Textile Craft Machines > Sewing Machines', ''),
(825, 'Arts & Entertainment >
Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Textile Craft Machines > Spinning Wheels', ''),
(826,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Thimbles & Sewing Palms', ''),
(827, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Thread & Yarn Tools >
Fiber Cards & Brushes', ''),
(828, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting
Tools > Thread & Yarn Tools > Hand Spindles', ''),
(829, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts
> Art & Crafting Tools > Thread & Yarn Tools > Needle Threaders', ''),
(830, 'Arts & Entertainment > Hobbies & Creative
Arts > Arts & Crafts > Art & Crafting Tools > Thread & Yarn Tools > Thread & Yarn Guides', ''),
(831, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Thread & Yarn Tools > Thread & Yarn
Spools', ''),
(832, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Art & Crafting Tools > Thread &
Yarn Tools > Thread,Yarn & Bobbin Winders', ''),
(833, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts >
Art & Crafting Tools > Thread & Yarn Tools > Weaving Beaters', ''),
(834, 'Arts & Entertainment > Hobbies & Creative
Arts > Arts & Crafts > Art & Crafting Tools > Thread & Yarn Tools > Weaving Shuttles', ''),
(835, 'Arts & Entertainment
> Hobbies & Creative Arts > Arts & Crafts > Craft Organization > Needle,Pin & Hook Organizers', ''),
(836, 'Arts &
Entertainment > Hobbies & Creative Arts > Arts & Crafts > Craft Organization > Sewing Baskets & Kits', ''),
(837, 'Arts
& Entertainment > Hobbies & Creative Arts > Arts & Crafts > Craft Organization > Thread & Yarn Organizers', ''),
(838,
'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Crafting Patterns & Molds > Beading Patterns', ''),
(839, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Crafting Patterns & Molds > Craft Molds', ''),
(840, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Crafting Patterns & Molds > Felting Molds', ''),
(841, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Crafting Patterns & Molds > Needlecraft
Patterns', ''),
(842, 'Arts & Entertainment > Hobbies & Creative Arts > Arts & Crafts > Crafting Patterns & Molds >
Sewing Patterns', ''),
(843, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Autographs', ''),
(844,
'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Collectible Coins & Currency', ''),
(845, 'Arts &
Entertainment > Hobbies & Creative Arts > Collectibles > Collectible Trading Cards', ''),
(846, 'Arts & Entertainment >
Hobbies & Creative Arts > Collectibles > Collectible Weapons', ''),
(847, 'Arts & Entertainment > Hobbies & Creative
Arts > Collectibles > Collectible Weapons > Collectible Guns', ''),
(848, 'Arts & Entertainment > Hobbies & Creative
Arts > Collectibles > Collectible Weapons > Collectible Knives', ''),
(849, 'Arts & Entertainment > Hobbies & Creative
Arts > Collectibles > Collectible Weapons > Collectible Swords', ''),
(850, 'Arts & Entertainment > Hobbies & Creative
Arts > Collectibles > Collectible Weapons > Sword Stands & Displays', ''),
(851, 'Arts & Entertainment > Hobbies &
Creative Arts > Collectibles > Postage Stamps', ''),
(852, 'Arts & Entertainment > Hobbies & Creative Arts >
Collectibles > Rocks & Fossils', ''),
(853, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Scale Model
Accessories', ''),
(854, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Scale Models', ''),
(855,
'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Seal Stamps', ''),
(856, 'Arts & Entertainment >
Hobbies & Creative Arts > Collectibles > Sports Collectibles > Autographed Sports Paraphernalia', ''),
(857, 'Arts &
Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles > Autographed Sports Paraphernalia > Auto
Racing Autographed Paraphernalia', ''),
(858, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports
Collectibles > Autographed Sports Paraphernalia > Baseball & Softball Autographed Paraphernalia', ''),
(859, 'Arts &
Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles > Autographed Sports Paraphernalia >
Basketball Autographed Paraphernalia', ''),
(860, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles >
Sports Collectibles > Autographed Sports Paraphernalia > Boxing Autographed Paraphernalia', ''),
(861, 'Arts &
Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles > Autographed Sports Paraphernalia >
Football Autographed Paraphernalia', ''),
(862, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports
Collectibles > Autographed Sports Paraphernalia > Hockey Autographed Paraphernalia', ''),
(863, 'Arts & Entertainment >
Hobbies & Creative Arts > Collectibles > Sports Collectibles > Autographed Sports Paraphernalia > Soccer Autographed
Paraphernalia', ''),
(864, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles >
Autographed Sports Paraphernalia > Tennis Autographed Sports Paraphernalia', ''),
(865, 'Arts & Entertainment > Hobbies
& Creative Arts > Collectibles > Sports Collectibles > Sports Fan Accessories', ''),
(866, 'Arts & Entertainment >
Hobbies & Creative Arts > Collectibles > Sports Collectibles > Sports Fan Accessories > Auto Racing Fan Accessories',
''),
(867, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles > Sports Fan Accessories
> Baseball & Softball Fan Accessories', ''),
(868, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles >
Sports Collectibles > Sports Fan Accessories > Basketball Fan Accessories', ''),
(869, 'Arts & Entertainment > Hobbies &
Creative Arts > Collectibles > Sports Collectibles > Sports Fan Accessories > Football Fan Accessories', ''),
(870,
'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles > Sports Fan Accessories > Hockey
Fan Accessories', ''),
(871, 'Arts & Entertainment > Hobbies & Creative Arts > Collectibles > Sports Collectibles >
Sports Fan Accessories > Soccer Fan Accessories', ''),
(872, 'Arts & Entertainment > Hobbies & Creative Arts >
Collectibles > Sports Collectibles > Sports Fan Accessories > Tennis Fan Accessories', ''),
(873, 'Arts & Entertainment
> Hobbies & Creative Arts > Collectibles > Vintage Advertisements', ''),
(874, 'Arts & Entertainment > Hobbies &
Creative Arts > Homebrewing & Winemaking Supplies > Beer Brewing Grains & Malts', ''),
(875, 'Arts & Entertainment >
Hobbies & Creative Arts > Homebrewing & Winemaking Supplies > Bottling Bottles', ''),
(876, 'Arts & Entertainment >
Hobbies & Creative Arts > Homebrewing & Winemaking Supplies > Homebrewing & Winemaking Kits', ''),
(877, 'Arts &
Entertainment > Hobbies & Creative Arts > Homebrewing & Winemaking Supplies > Wine Making', ''),
(878, 'Arts &
Entertainment > Hobbies & Creative Arts > Juggling', ''),
(879, 'Arts & Entertainment > Hobbies & Creative Arts > Magic
& Novelties', ''),
(880, 'Arts & Entertainment > Hobbies & Creative Arts > Model Making', ''),
(881, 'Arts &
Entertainment > Hobbies & Creative Arts > Model Making > Model Rocketry', ''),
(882, 'Arts & Entertainment > Hobbies &
Creative Arts > Model Making > Model Train Accessories', ''),
(883, 'Arts & Entertainment > Hobbies & Creative Arts >
Model Making > Model Trains & Train Sets', ''),
(884, 'Arts & Entertainment > Hobbies & Creative Arts > Model Making >
Scale Model Kits', ''),
(885, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Brass Instrument Accessories > Brass Instrument Care & Cleaning', ''),
(886, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Brass Instrument Accessories > Brass Instrument
Care & Cleaning > Brass Instrument Care Kits', ''),
(887, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Brass Instrument Accessories > Brass Instrument Care & Cleaning > Brass Instrument
Cleaners & Sanitizers', ''),
(888, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Brass Instrument Accessories > Brass Instrument Care & Cleaning > Brass Instrument Cleaning Tools', ''),
(889, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Brass Instrument
Accessories > Brass Instrument Care & Cleaning > Brass Instrument Guards', ''),
(890, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Brass Instrument Accessories > Brass Instrument Care &
Cleaning > Brass Instrument Lubricants', ''),
(891, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument
& Orchestra Accessories > Brass Instrument Accessories > Brass Instrument Care & Cleaning > Brass Instrument Polishing
Cloths', ''),
(892, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Brass
Instrument Accessories > Brass Instrument Cases & Gigbags', ''),
(893, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Brass Instrument Accessories > Brass Instrument Mouthpieces', ''),
(894,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Brass Instrument
Accessories > Brass Instrument Mutes', ''),
(895, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Brass Instrument Accessories > Brass Instrument Replacement Parts', ''),
(896, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Brass Instrument Accessories >
Brass Instrument Straps & Stands', ''),
(897, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Conductor Batons', ''),
(898, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Electronic Tuners', ''),
(899, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Metronomes', ''),
(900, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Music Benches & Stools', ''),
(901, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Music Lyres & Flip Folders', ''),
(902, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Music Stand Accessories > Music
Stand Bags', ''),
(903, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Music Stand Accessories > Music Stand Lights', ''),
(904, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Music Stand Accessories > Sheet Music Clips', ''),
(905, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Music Stands', ''),
(906, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Musical Instrument Amplifier Accessories >
Musical Instrument Amplifier Cabinets', ''),
(907, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument
& Orchestra Accessories > Musical Instrument Amplifier Accessories > Musical Instrument Amplifier Covers & Cases', ''),
(908, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Musical Instrument
Amplifier Accessories > Musical Instrument Amplifier Footswitches', ''),
(909, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Musical Instrument Amplifier Accessories > Musical
Instrument Amplifier Knobs', ''),
(910, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Musical Instrument Amplifier Accessories > Musical Instrument Amplifier Stands', ''),
(911, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Musical Instrument Amplifier
Accessories > Musical Instrument Amplifier Tubes', ''),
(912, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Musical Instrument Amplifiers', ''),
(913, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Musical Keyboard Accessories > Musical Keyboard Bags &
Cases', ''),
(914, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Musical Keyboard Accessories > Musical Keyboard Stands', ''),
(915, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Musical Keyboard Accessories > Sustain Pedals', ''),
(916, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Cymbal &
Drum Cases', ''),
(917, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Percussion Accessories > Cymbal & Drum Mutes', ''),
(918, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Percussion Accessories > Drum Heads', ''),
(919, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum Keys', ''),
(920, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum Kit
Hardware', ''),
(921, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Percussion Accessories > Drum Kit Hardware > Bass Drum Beaters', ''),
(922, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum Kit Hardware > Drum Kit Mounting
Hardware', ''),
(923, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Percussion Accessories > Drum Kit Hardware > Drum Pedals', ''),
(924, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum Stick & Brush Accessories', ''),
(925, 'Arts
& Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum
Stick & Brush Accessories > Drum Stick & Brush Bags & Holders', ''),
(926, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Drum Sticks & Brushes', ''),
(927, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories >
Electronic Drum Modules', ''),
(928, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Percussion Accessories > Hand Percussion Accessories', ''),
(929, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories > Hand Percussion Accessories > Hand
Percussion Bags & Cases', ''),
(930, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Percussion Accessories > Hand Percussion Accessories > Hand Percussion Stands & Mounts', ''),
(931, 'Arts
& Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Percussion Accessories >
Percussion Mallets', ''),
(932, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Percussion Accessories > Percussion Stands', ''),
(933, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Acoustic Guitar
Pickups', ''),
(934, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
String Instrument Accessories > Guitar Accessories > Capos', ''),
(935, 'Arts & Entertainment > Hobbies & Creative Arts
> Musical Instrument & Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Electric Guitar
Pickups', ''),
(936, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
String Instrument Accessories > Guitar Accessories > Guitar Cases & Gig Bags', ''),
(937, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories > Guitar
Accessories > Guitar Fittings & Parts', ''),
(938, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument
& Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Guitar Humidifiers', ''),
(939, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories >
Guitar Accessories > Guitar Picks', ''),
(940, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Guitar Slides', ''),
(941, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories >
Guitar Accessories > Guitar Stands', ''),
(942, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Guitar Straps', ''),
(943, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories >
Guitar Accessories > Guitar String Winders', ''),
(944, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > String Instrument Accessories > Guitar Accessories > Guitar Strings', ''),
(945,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument
Accessories > Guitar Accessories > Guitar Tuning Pegs', ''),
(946, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > String Instrument Accessories > Orchestral String Instrument Accessories >
Orchestral String Instrument Bow Cases', ''),
(947, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument
& Orchestra Accessories > String Instrument Accessories > Orchestral String Instrument Accessories > Orchestral String
Instrument Bows', ''),
(948, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > String Instrument Accessories > Orchestral String Instrument Accessories > Orchestral String Instrument
Cases', ''),
(949, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String
Instrument Accessories > Orchestral String Instrument Accessories > Orchestral String Instrument Fittings & Parts', ''),
(950, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument
Accessories > Orchestral String Instrument Accessories > Orchestral String Instrument Mutes', ''),
(951, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories >
Orchestral String Instrument Accessories > Orchestral String Instrument Pickups', ''),
(952, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories > Orchestral String
Instrument Accessories > Orchestral String Instrument Stands', ''),
(953, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories > Orchestral String Instrument
Accessories > Orchestral String Instrument Strings', ''),
(954, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > String Instrument Accessories > String Instrument Care & Cleaning > Bow
Rosin', ''),
(955, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String
Instrument Accessories > String Instrument Care & Cleaning > String Instrument Cleaning Cloths', ''),
(956, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > String Instrument Accessories >
String Instrument Care & Cleaning > String Instrument Polish', ''),
(957, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Bassoon Accessories > Bassoon Care
& Cleaning', ''),
(958, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Bassoon Accessories > Bassoon Care & Cleaning > Bassoon Swabs', ''),
(959, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Bassoon Accessories > Bassoon Cases & Gigbags', ''),
(960, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Bassoon Accessories > Bassoon Parts', ''),
(961,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Bassoon Accessories > Bassoon Parts > Bassoon Bocals', ''),
(962, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Bassoon Accessories >
Bassoon Parts > Bassoon Small Parts', ''),
(963, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Woodwind Instrument Accessories > Bassoon Accessories > Bassoon Reeds', ''),
(964, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Bassoon Accessories > Bassoon Stands', ''),
(965, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Woodwind Instrument Accessories > Bassoon Accessories > Bassoon Straps & Supports', ''),
(966,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Clarinet Accessories > Clarinet Care & Cleaning', ''),
(967, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet
Care & Cleaning > Clarinet Care Kits', ''),
(968, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Care & Cleaning > Clarinet Pad
Savers', ''),
(969, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Care & Cleaning > Clarinet Swabs', ''),
(970, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Clarinet Accessories > Clarinet Cases & Gigbags', ''),
(971, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Ligatures &
Caps', ''),
(972, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Parts > Clarinet Barrels', ''),
(973, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Clarinet Accessories > Clarinet Parts > Clarinet Bells', ''),
(974, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Parts >
Clarinet Mouthpieces', ''),
(975, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Parts > Clarinet Small Parts', ''),
(976, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Clarinet Accessories > Clarinet Pegs & Stands', ''),
(977, 'Arts & Entertainment > Hobbies & Creative Arts
> Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Clarinet Accessories > Clarinet Reeds',
''),
(978, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind
Instrument Accessories > Clarinet Accessories > Clarinet Straps & Supports', ''),
(979, 'Arts & Entertainment > Hobbies
& Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Flute Accessories >
Flute Care & Cleaning', ''),
(980, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Woodwind Instrument Accessories > Flute Accessories > Flute Care & Cleaning > Flute Care Kits', ''),
(981,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Flute Accessories > Flute Care & Cleaning > Flute Cleaning Rods', ''),
(982, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Flute
Accessories > Flute Care & Cleaning > Flute Swabs', ''),
(983, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Flute Accessories > Flute Cases & Gigbags', ''),
(984, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Flute Accessories > Flute Parts', ''),
(985, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Flute Accessories > Flute Parts > Flute
Headjoints', ''),
(986, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Flute Accessories > Flute Parts > Flute Small Parts', ''),
(987, 'Arts & Entertainment
> Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Flute
Accessories > Flute Pegs & Stands', ''),
(988, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Woodwind Instrument Accessories > Harmonica Accessories > Harmonica Cases', ''),
(989, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Harmonica Accessories > Harmonica Holders', ''),
(990, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Oboe & English Horn Accessories > Oboe Care &
Cleaning', ''),
(991, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Oboe & English Horn Accessories > Oboe Care & Cleaning > Oboe Care Kits', ''),
(992,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Oboe & English Horn Accessories > Oboe Care & Cleaning > Oboe Swabs', ''),
(993, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Oboe & English
Horn Accessories > Oboe Cases & Gigbags', ''),
(994, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Oboe & English Horn Accessories > Oboe Parts',
''),
(995, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind
Instrument Accessories > Oboe & English Horn Accessories > Oboe Parts > Oboe Small Parts', ''),
(996, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Oboe & English Horn Accessories > Oboe Pegs & Stands', ''),
(997, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Oboe & English Horn Accessories > Oboe
Reeds', ''),
(998, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Oboe & English Horn Accessories > Oboe Straps & Supports', ''),
(999, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Recorder Accessories > Recorder Care & Cleaning', ''),
(1000, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Recorder Accessories > Recorder Cases', ''),
(1001, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind
Instrument Accessories > Recorder Accessories > Recorder Parts', ''),
(1002, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone
Care & Cleaning', ''),
(1003, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Care & Cleaning > Saxophone Care
Kits', ''),
(1004, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Care & Cleaning > Saxophone Pad Savers', ''),
(1005,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Saxophone Accessories > Saxophone Care & Cleaning > Saxophone Swabs', ''),
(1006, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Saxophone
Accessories > Saxophone Cases & Gigbags', ''),
(1007, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Ligatures &
Caps', ''),
(1008, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Parts > Saxophone Mouthpieces', ''),
(1009, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Saxophone Accessories > Saxophone Parts > Saxophone Necks', ''),
(1010, 'Arts & Entertainment > Hobbies & Creative Arts
> Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Parts
> Saxophone Small Parts', ''),
(1011, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra
Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Pegs & Stands', ''),
(1012, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories >
Saxophone Accessories > Saxophone Reeds', ''),
(1013, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Saxophone Accessories > Saxophone Straps &
Supports', ''),
(1014, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories >
Woodwind Instrument Accessories > Woodwind Cork Grease', ''),
(1015, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instrument & Orchestra Accessories > Woodwind Instrument Accessories > Woodwind Polishing Cloths', ''),
(1016,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument & Orchestra Accessories > Woodwind Instrument
Accessories > Woodwind Reed Cases', ''),
(1017, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instrument &
Orchestra Accessories > Woodwind Instrument Accessories > Woodwind Reed Knives', ''),
(1018, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instruments > Accordions & Concertinas', ''),
(1019, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instruments > Bagpipes', ''),
(1020, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Brass Instruments > Alto & Baritone Horns', ''),
(1021, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Brass Instruments > Euphoniums', ''),
(1022, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Brass Instruments > French Horns', ''),
(1023, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Brass Instruments > Trombones', ''),
(1024, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Brass Instruments > Trumpets & Cornets', ''),
(1025, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instruments > Brass Instruments > Tubas', ''),
(1026, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Electronic Musical Instruments > Audio Samplers', ''),
(1027, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instruments > Electronic Musical Instruments > MIDI Controllers', ''),
(1028, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instruments > Electronic Musical Instruments > Musical Keyboards',
''),
(1029, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Electronic Musical Instruments >
Sound Synthesizers', ''),
(1030, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion >
Bass Drums', ''),
(1031, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Cymbals',
''),
(1032, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Drum Kits', ''),
(1033,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Electronic Drums', ''),
(1034,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Glockenspiels & Xylophones', ''),
(1035, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Gongs', ''),
(1036, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Claves & Castanets', ''),
(1037, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Finger &
Hand Cymbals', ''),
(1038, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand
Percussion > Hand Bells & Chimes', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (1039,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Hand Drums', ''),
(1040, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Hand Drums
> Bongos', ''),
(1041, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand
Percussion > Hand Drums > Cajons', ''),
(1042, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Percussion > Hand Percussion > Hand Drums > Congas', ''),
(1043, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Percussion > Hand Percussion > Hand Drums > Frame Drums', ''),
(1044, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Hand Drums > Goblet Drums', ''),
(1045,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Hand Drums >
Tablas', ''),
(1046, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand
Percussion > Hand Drums > Talking Drums', ''),
(1047, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Percussion > Hand Percussion > Musical Blocks', ''),
(1048, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instruments > Percussion > Hand Percussion > Musical Cowbells', ''),
(1049, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Musical Scrapers & Ratchets', ''),
(1050,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion > Musical Shakers',
''),
(1051, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion > Hand Percussion >
Musical Triangles', ''),
(1052, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Percussion >
Hand Percussion > Tambourines', ''),
(1053, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Percussion > Hand Percussion > Vibraslaps', ''),
(1054, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Percussion > Hi-Hats', ''),
(1055, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Percussion > Practice Pads', ''),
(1056, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Percussion > Snare Drums', ''),
(1057, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Percussion > Tom-Toms', ''),
(1058, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Pianos',
''),
(1059, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Cellos', ''),
(1060, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Guitars', ''),
(1061, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Harps', ''),
(1062,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Upright Basses', ''),
(1063, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Violas', ''),
(1064,
'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > String Instruments > Violins', ''),
(1065, 'Arts
& Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds > Bassoons', ''),
(1066, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds > Clarinets', ''),
(1067, 'Arts &
Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds > Flutes', ''),
(1068, 'Arts & Entertainment >
Hobbies & Creative Arts > Musical Instruments > Woodwinds > Flutophones', ''),
(1069, 'Arts & Entertainment > Hobbies &
Creative Arts > Musical Instruments > Woodwinds > Harmonicas', ''),
(1070, 'Arts & Entertainment > Hobbies & Creative
Arts > Musical Instruments > Woodwinds > Jew''s Harps', ''),
(1071, 'Arts & Entertainment > Hobbies & Creative Arts >
Musical Instruments > Woodwinds > Melodicas', ''),
(1072, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Woodwinds > Musical Pipes', ''),
(1073, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Woodwinds > Oboes & English Horns', ''),
(1074, 'Arts & Entertainment > Hobbies & Creative Arts > Musical
Instruments > Woodwinds > Ocarinas', ''),
(1075, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments >
Woodwinds > Recorders', ''),
(1076, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds >
Saxophones', ''),
(1077, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds > Tin
Whistles', ''),
(1078, 'Arts & Entertainment > Hobbies & Creative Arts > Musical Instruments > Woodwinds > Train
Whistles', ''),
(1079, 'Arts & Entertainment > Party & Celebration > Gift Giving > Corsage & Boutonni├¿re Pins', ''),
(1080, 'Arts & Entertainment > Party & Celebration > Gift Giving > Corsages & Boutonni├¿res', ''),
(1081, 'Arts &
Entertainment > Party & Celebration > Gift Giving > Fresh Cut Flowers', ''),
(1082, 'Arts & Entertainment > Party &
Celebration > Gift Giving > Gift Cards & Certificates', ''),
(1083, 'Arts & Entertainment > Party & Celebration > Gift
Giving > Gift Wrapping', ''),
(1084, 'Arts & Entertainment > Party & Celebration > Gift Giving > Gift Wrapping > Gift
Bags', ''),
(1085, 'Arts & Entertainment > Party & Celebration > Gift Giving > Gift Wrapping > Gift Boxes & Tins', ''),
(1086, 'Arts & Entertainment > Party & Celebration > Gift Giving > Gift Wrapping > Gift Tags & Labels', ''),
(1087,
'Arts & Entertainment > Party & Celebration > Gift Giving > Gift Wrapping > Tissue Paper', ''),
(1088, 'Arts &
Entertainment > Party & Celebration > Gift Giving > Gift Wrapping > Wrapping Paper', ''),
(1089, 'Arts & Entertainment >
Party & Celebration > Gift Giving > Greeting & Note Cards', ''),
(1090, 'Arts & Entertainment > Party & Celebration >
Party Supplies > Advice Cards', ''),
(1091, 'Arts & Entertainment > Party & Celebration > Party Supplies > Balloon
Kits', ''),
(1092, 'Arts & Entertainment > Party & Celebration > Party Supplies > Balloons', ''),
(1093, 'Arts &
Entertainment > Party & Celebration > Party Supplies > Banners', ''),
(1094, 'Arts & Entertainment > Party & Celebration
> Party Supplies > Birthday Candles', ''),
(1095, 'Arts & Entertainment > Party & Celebration > Party Supplies > Chair
Sashes', ''),
(1096, 'Arts & Entertainment > Party & Celebration > Party Supplies > Cocktail Decorations', ''),
(1097,
'Arts & Entertainment > Party & Celebration > Party Supplies > Confetti', ''),
(1098, 'Arts & Entertainment > Party &
Celebration > Party Supplies > Decorative Pom-Poms', ''),
(1099, 'Arts & Entertainment > Party & Celebration > Party
Supplies > Drinking Games', ''),
(1100, 'Arts & Entertainment > Party & Celebration > Party Supplies > Drinking Games >
Beer Pong', ''),
(1101, 'Arts & Entertainment > Party & Celebration > Party Supplies > Drinking Games > Beer Pong > Beer
Pong Tables', ''),
(1102, 'Arts & Entertainment > Party & Celebration > Party Supplies > Drinking Straws & Stirrers',
''),
(1103, 'Arts & Entertainment > Party & Celebration > Party Supplies > Envelope Seals', ''),
(1104, 'Arts &
Entertainment > Party & Celebration > Party Supplies > Event Programs', ''),
(1105, 'Arts & Entertainment > Party &
Celebration > Party Supplies > Fireworks & Firecrackers', ''),
(1106, 'Arts & Entertainment > Party & Celebration >
Party Supplies > Inflatable Party Decorations', ''),
(1107, 'Arts & Entertainment > Party & Celebration > Party Supplies
> Invitations', ''),
(1108, 'Arts & Entertainment > Party & Celebration > Party Supplies > Noisemakers & Party Blowers',
''),
(1109, 'Arts & Entertainment > Party & Celebration > Party Supplies > Party Favors', ''),
(1110, 'Arts &
Entertainment > Party & Celebration > Party Supplies > Party Favors > Wedding Favors', ''),
(1111, 'Arts & Entertainment
> Party & Celebration > Party Supplies > Party Games', ''),
(1112, 'Arts & Entertainment > Party & Celebration > Party
Supplies > Party Hats', ''),
(1113, 'Arts & Entertainment > Party & Celebration > Party Supplies > Party Streamers &
Curtains', ''),
(1114, 'Arts & Entertainment > Party & Celebration > Party Supplies > Party Supply Kits', ''),
(1115,
'Arts & Entertainment > Party & Celebration > Party Supplies > Pi├▒atas', ''),
(1116, 'Arts & Entertainment > Party &
Celebration > Party Supplies > Place Card Holders', ''),
(1117, 'Arts & Entertainment > Party & Celebration > Party
Supplies > Place Cards', ''),
(1118, 'Arts & Entertainment > Party & Celebration > Party Supplies > Response Cards',
''),
(1119, 'Arts & Entertainment > Party & Celebration > Party Supplies > Sparklers', ''),
(1120, 'Arts & Entertainment
> Party & Celebration > Party Supplies > Special Occasion Card Boxes & Holders', ''),
(1121, 'Arts & Entertainment >
Party & Celebration > Party Supplies > Spray String', ''),
(1122, 'Arts & Entertainment > Party & Celebration > Special
Effects > Disco Balls', ''),
(1123, 'Arts & Entertainment > Party & Celebration > Special Effects > Fog Machines', ''),
(1124, 'Arts & Entertainment > Party & Celebration > Special Effects > Special Effects Controllers', ''),
(1125, 'Arts &
Entertainment > Party & Celebration > Special Effects > Special Effects Light Stands', ''),
(1126, 'Arts & Entertainment
> Party & Celebration > Special Effects > Special Effects Lighting', ''),
(1127, 'Arts & Entertainment > Party &
Celebration > Trophies & Awards', ''),
(1128, 'Baby & Toddler > Baby Bathing', ''),
(1129, 'Baby & Toddler > Baby
Bathing > Baby Bathtubs & Bath Seats', ''),
(1130, 'Baby & Toddler > Baby Bathing > Shower Visors', ''),
(1131, 'Baby &
Toddler > Baby Gift Sets', ''),
(1132, 'Baby & Toddler > Baby Health > Baby Health & Grooming Kits', ''),
(1133, 'Baby &
Toddler > Baby Health > Nasal Aspirators', ''),
(1134, 'Baby & Toddler > Baby Health > Pacifier Clips & Holders', ''),
(1135, 'Baby & Toddler > Baby Health > Pacifier Wipes', ''),
(1136, 'Baby & Toddler > Baby Health > Pacifiers &
Teethers', ''),
(1137, 'Baby & Toddler > Baby Safety > Baby & Pet Gate Accessories', ''),
(1138, 'Baby & Toddler > Baby
Safety > Baby & Pet Gates', ''),
(1139, 'Baby & Toddler > Baby Safety > Baby Monitors', ''),
(1140, 'Baby & Toddler >
Baby Safety > Baby Safety Harnesses & Leashes', ''),
(1141, 'Baby & Toddler > Baby Safety > Baby Safety Locks & Guards',
''),
(1142, 'Baby & Toddler > Baby Safety > Baby Safety Rails', ''),
(1143, 'Baby & Toddler > Baby Toys & Activity
Equipment > Alphabet Toys', ''),
(1144, 'Baby & Toddler > Baby Toys & Activity Equipment > Baby Activity Toys', ''),
(1145, 'Baby & Toddler > Baby Toys & Activity Equipment > Baby Bouncers & Rockers', ''),
(1146, 'Baby & Toddler > Baby
Toys & Activity Equipment > Baby Jumpers & Swings', ''),
(1147, 'Baby & Toddler > Baby Toys & Activity Equipment > Baby
Mobile Accessories', ''),
(1148, 'Baby & Toddler > Baby Toys & Activity Equipment > Baby Mobiles', ''),
(1149, 'Baby &
Toddler > Baby Toys & Activity Equipment > Baby Soothers', ''),
(1150, 'Baby & Toddler > Baby Toys & Activity Equipment
> Baby Walkers & Entertainers', ''),
(1151, 'Baby & Toddler > Baby Toys & Activity Equipment > Play Mats & Gyms', ''),
(1152, 'Baby & Toddler > Baby Toys & Activity Equipment > Play Yards', ''),
(1153, 'Baby & Toddler > Baby Toys &
Activity Equipment > Push & Pull Toys', ''),
(1154, 'Baby & Toddler > Baby Toys & Activity Equipment > Rattles', ''),
(1155, 'Baby & Toddler > Baby Toys & Activity Equipment > Sorting & Stacking Toys', ''),
(1156, 'Baby & Toddler > Baby
Transport > Baby & Toddler Car Seats', ''),
(1157, 'Baby & Toddler > Baby Transport > Baby Carriers', ''),
(1158, 'Baby
& Toddler > Baby Transport > Baby Strollers', ''),
(1159, 'Baby & Toddler > Baby Transport Accessories > Baby & Toddler
Car Seat Accessories', ''),
(1160, 'Baby & Toddler > Baby Transport Accessories > Baby Carrier Accessories', ''),
(1161,
'Baby & Toddler > Baby Transport Accessories > Baby Stroller Accessories', ''),
(1162, 'Baby & Toddler > Baby Transport
Accessories > Baby Transport Liners & Sacks', ''),
(1163, 'Baby & Toddler > Baby Transport Accessories > Shopping Cart &
High Chair Covers', ''),
(1164, 'Baby & Toddler > Diapering > Baby Wipe Dispensers & Warmers', ''),
(1165, 'Baby &
Toddler > Diapering > Baby Wipes', ''),
(1166, 'Baby & Toddler > Diapering > Changing Mat & Tray Covers', ''),
(1167,
'Baby & Toddler > Diapering > Changing Mats & Trays', ''),
(1168, 'Baby & Toddler > Diapering > Diaper Kits', ''),
(1169, 'Baby & Toddler > Diapering > Diaper Liners', ''),
(1170, 'Baby & Toddler > Diapering > Diaper Organizers', ''),
(1171, 'Baby & Toddler > Diapering > Diaper Pail Accessories', ''),
(1172, 'Baby & Toddler > Diapering > Diaper Pails',
''),
(1173, 'Baby & Toddler > Diapering > Diaper Rash Treatments', ''),
(1174, 'Baby & Toddler > Diapering > Diaper Wet
Bags', ''),
(1175, 'Baby & Toddler > Diapering > Diapers', ''),
(1176, 'Baby & Toddler > Nursing & Feeding > Baby &
Toddler Food > Baby Cereal', ''),
(1177, 'Baby & Toddler > Nursing & Feeding > Baby & Toddler Food > Baby Drinks', ''),
(1178, 'Baby & Toddler > Nursing & Feeding > Baby & Toddler Food > Baby Food', ''),
(1179, 'Baby & Toddler > Nursing &
Feeding > Baby & Toddler Food > Baby Formula', ''),
(1180, 'Baby & Toddler > Nursing & Feeding > Baby & Toddler Food >
Baby Snacks', ''),
(1181, 'Baby & Toddler > Nursing & Feeding > Baby & Toddler Food > Toddler Nutrition Drinks &
Shakes', ''),
(1182, 'Baby & Toddler > Nursing & Feeding > Baby Bottle Nipples & Liners', ''),
(1183, 'Baby & Toddler >
Nursing & Feeding > Baby Bottles', ''),
(1184, 'Baby & Toddler > Nursing & Feeding > Baby Care Timers', ''),
(1185,
'Baby & Toddler > Nursing & Feeding > Bibs', ''),
(1186, 'Baby & Toddler > Nursing & Feeding > Bottle Warmers &
Sterilizers', ''),
(1187, 'Baby & Toddler > Nursing & Feeding > Breast Milk Storage Containers', ''),
(1188, 'Baby &
Toddler > Nursing & Feeding > Breast Pump Accessories', ''),
(1189, 'Baby & Toddler > Nursing & Feeding > Breast Pumps',
''),
(1190, 'Baby & Toddler > Nursing & Feeding > Burp Cloths', ''),
(1191, 'Baby & Toddler > Nursing & Feeding >
Nursing Covers', ''),
(1192, 'Baby & Toddler > Nursing & Feeding > Nursing Pads & Shields', ''),
(1193, 'Baby & Toddler
> Nursing & Feeding > Nursing Pillow Covers', ''),
(1194, 'Baby & Toddler > Nursing & Feeding > Nursing Pillows', ''),
(1195, 'Baby & Toddler > Nursing & Feeding > Sippy Cups', ''),
(1196, 'Baby & Toddler > Potty Training > Potty Seats',
''),
(1197, 'Baby & Toddler > Potty Training > Potty Training Kits', ''),
(1198, 'Baby & Toddler > Swaddling & Receiving
Blankets', ''),
(1199, 'Business & Industrial > Advertising & Marketing', ''),
(1200, 'Business & Industrial >
Advertising & Marketing > Brochures', ''),
(1201, 'Business & Industrial > Advertising & Marketing > Trade Show
Counters', ''),
(1202, 'Business & Industrial > Advertising & Marketing > Trade Show Displays', ''),
(1203, 'Business &
Industrial > Agriculture > Animal Husbandry', ''),
(1204, 'Business & Industrial > Agriculture > Animal Husbandry > Egg
Incubators', ''),
(1205, 'Business & Industrial > Agriculture > Animal Husbandry > Livestock Feed', ''),
(1206,
'Business & Industrial > Agriculture > Animal Husbandry > Livestock Feeders & Waterers', ''),
(1207, 'Business &
Industrial > Agriculture > Animal Husbandry > Livestock Halters', ''),
(1208, 'Business & Industrial > Automation
Control Components', ''),
(1209, 'Business & Industrial > Automation Control Components > Programmable Logic
Controllers', ''),
(1210, 'Business & Industrial > Automation Control Components > Variable Frequency & Adjustable Speed
Drives', ''),
(1211, 'Business & Industrial > Construction', ''),
(1212, 'Business & Industrial > Construction >
Surveying', ''),
(1213, 'Business & Industrial > Construction > Traffic Cones & Barrels', ''),
(1214, 'Business &
Industrial > Dentistry > Dental Cement', ''),
(1215, 'Business & Industrial > Dentistry > Dental Tools', ''),
(1216,
'Business & Industrial > Dentistry > Dental Tools > Dappen Dishes', ''),
(1217, 'Business & Industrial > Dentistry >
Dental Tools > Dental Mirrors', ''),
(1218, 'Business & Industrial > Dentistry > Dental Tools > Dental Tool Sets', ''),
(1219, 'Business & Industrial > Dentistry > Dental Tools > Prophy Cups', ''),
(1220, 'Business & Industrial > Dentistry
> Dental Tools > Prophy Heads', ''),
(1221, 'Business & Industrial > Dentistry > Prophy Paste', ''),
(1222, 'Business &
Industrial > Film & Television', ''),
(1223, 'Business & Industrial > Finance & Insurance', ''),
(1224, 'Business &
Industrial > Finance & Insurance > Bullion', ''),
(1225, 'Business & Industrial > Food Service > Bakery Boxes', ''),
(1226, 'Business & Industrial > Food Service > Bus Tubs', ''),
(1227, 'Business & Industrial > Food Service > Check
Presenters', ''),
(1228, 'Business & Industrial > Food Service > Concession Food Containers', ''),
(1229, 'Business &
Industrial > Food Service > Disposable Lids', ''),
(1230, 'Business & Industrial > Food Service > Disposable Serveware',
''),
(1231, 'Business & Industrial > Food Service > Disposable Serveware > Disposable Serving Trays', ''),
(1232,
'Business & Industrial > Food Service > Disposable Tableware', ''),
(1233, 'Business & Industrial > Food Service >
Disposable Tableware > Disposable Bowls', ''),
(1234, 'Business & Industrial > Food Service > Disposable Tableware >
Disposable Cups', ''),
(1235, 'Business & Industrial > Food Service > Disposable Tableware > Disposable Cutlery', ''),
(1236, 'Business & Industrial > Food Service > Disposable Tableware > Disposable Plates', ''),
(1237, 'Business &
Industrial > Food Service > Food Service Baskets', ''),
(1238, 'Business & Industrial > Food Service > Food Service
Carts', ''),
(1239, 'Business & Industrial > Food Service > Food Washers & Dryers', ''),
(1240, 'Business & Industrial >
Food Service > Hot Dog Rollers', ''),
(1241, 'Business & Industrial > Food Service > Ice Bins', ''),
(1242, 'Business &
Industrial > Food Service > Plate & Dish Warmers', ''),
(1243, 'Business & Industrial > Food Service > Sneeze Guards',
''),
(1244, 'Business & Industrial > Food Service > Take-Out Containers', ''),
(1245, 'Business & Industrial > Food
Service > Tilt Skillets', ''),
(1246, 'Business & Industrial > Food Service > Vending Machines', ''),
(1247, 'Business &
Industrial > Forestry & Logging', ''),
(1248, 'Business & Industrial > Hairdressing & Cosmetology', ''),
(1249,
'Business & Industrial > Hairdressing & Cosmetology > Hairdressing Capes & Neck Covers', ''),
(1250, 'Business &
Industrial > Hairdressing & Cosmetology > Pedicure Chairs', ''),
(1251, 'Business & Industrial > Hairdressing &
Cosmetology > Salon Chairs', ''),
(1252, 'Business & Industrial > Heavy Machinery', ''),
(1253, 'Business & Industrial >
Heavy Machinery > Chippers', ''),
(1254, 'Business & Industrial > Hotel & Hospitality', ''),
(1255, 'Business &
Industrial > Industrial Storage > Industrial Cabinets', ''),
(1256, 'Business & Industrial > Industrial Storage >
Industrial Shelving', ''),
(1257, 'Business & Industrial > Industrial Storage > Shipping Containers', ''),
(1258,
'Business & Industrial > Industrial Storage > Wire Partitions,Enclosures & Doors', ''),
(1259, 'Business & Industrial >
Industrial Storage Accessories', ''),
(1260, 'Business & Industrial > Janitorial Carts & Caddies', ''),
(1261, 'Business
& Industrial > Law Enforcement > Cuffs', ''),
(1262, 'Business & Industrial > Law Enforcement > Metal Detectors', ''),
(1263, 'Business & Industrial > Manufacturing', ''),
(1264, 'Business & Industrial > Material Handling > Conveyors',
''),
(1265, 'Business & Industrial > Material Handling > Lifts & Hoists', ''),
(1266, 'Business & Industrial > Material
Handling > Lifts & Hoists > Hoists,Cranes & Trolleys', ''),
(1267, 'Business & Industrial > Material Handling > Lifts &
Hoists > Jacks & Lift Trucks', ''),
(1268, 'Business & Industrial > Material Handling > Lifts & Hoists > Personnel
Lifts', ''),
(1269, 'Business & Industrial > Material Handling > Lifts & Hoists > Pulleys,Blocks & Sheaves', ''),
(1270,
'Business & Industrial > Material Handling > Lifts & Hoists > Winches', ''),
(1271, 'Business & Industrial > Material
Handling > Pallets & Loading Platforms', ''),
(1272, 'Business & Industrial > Medical > Hospital Curtains', ''),
(1273,
'Business & Industrial > Medical > Hospital Gowns', ''),
(1274, 'Business & Industrial > Medical > Medical Bedding',
''),
(1275, 'Business & Industrial > Medical > Medical Equipment', ''),
(1276, 'Business & Industrial > Medical >
Medical Equipment > Automated External Defibrillators', ''),
(1277, 'Business & Industrial > Medical > Medical Equipment
> Gait Belts', ''),
(1278, 'Business & Industrial > Medical > Medical Equipment > Medical Reflex Hammers & Tuning
Forks', ''),
(1279, 'Business & Industrial > Medical > Medical Equipment > Medical Stretchers & Gurneys', ''),
(1280,
'Business & Industrial > Medical > Medical Equipment > Otoscopes & Ophthalmoscopes', ''),
(1281, 'Business & Industrial
> Medical > Medical Equipment > Patient Lifts', ''),
(1282, 'Business & Industrial > Medical > Medical Equipment >
Stethoscopes', ''),
(1283, 'Business & Industrial > Medical > Medical Equipment > Vital Signs Monitor Accessories', ''),
(1284, 'Business & Industrial > Medical > Medical Equipment > Vital Signs Monitors', ''),
(1285, 'Business & Industrial
> Medical > Medical Furniture', ''),
(1286, 'Business & Industrial > Medical > Medical Furniture > Chiropractic Tables',
''),
(1287, 'Business & Industrial > Medical > Medical Furniture > Examination Chairs & Tables', ''),
(1288, 'Business &
Industrial > Medical > Medical Furniture > Homecare & Hospital Beds', ''),
(1289, 'Business & Industrial > Medical >
Medical Furniture > Medical Cabinets', ''),
(1290, 'Business & Industrial > Medical > Medical Furniture > Medical
Carts', ''),
(1291, 'Business & Industrial > Medical > Medical Furniture > Medical Carts > Crash Carts', ''),
(1292,
'Business & Industrial > Medical > Medical Furniture > Medical Carts > IV Poles & Carts', ''),
(1293, 'Business &
Industrial > Medical > Medical Furniture > Surgical Tables', ''),
(1294, 'Business & Industrial > Medical > Medical
Instruments', ''),
(1295, 'Business & Industrial > Medical > Medical Instruments > Medical Forceps', ''),
(1296,
'Business & Industrial > Medical > Medical Instruments > Scalpel Blades', ''),
(1297, 'Business & Industrial > Medical >
Medical Instruments > Scalpels', ''),
(1298, 'Business & Industrial > Medical > Medical Instruments > Surgical Needles &
Sutures', ''),
(1299, 'Business & Industrial > Medical > Medical Supplies', ''),
(1300, 'Business & Industrial > Medical
> Medical Supplies > Disposable Gloves', ''),
(1301, 'Business & Industrial > Medical > Medical Supplies > Finger Cots',
''),
(1302, 'Business & Industrial > Medical > Medical Supplies > Medical Needles & Syringes', ''),
(1303, 'Business &
Industrial > Medical > Medical Supplies > Ostomy Supplies', ''),
(1304, 'Business & Industrial > Medical > Medical
Supplies > Tongue Depressors', ''),
(1305, 'Business & Industrial > Medical > Medical Teaching Equipment', ''),
(1306,
'Business & Industrial > Medical > Medical Teaching Equipment > Medical & Emergency Response Training Mannequins', ''),
(1307, 'Business & Industrial > Medical > Scrub Caps', ''),
(1308, 'Business & Industrial > Medical > Scrubs', ''),
(1309, 'Business & Industrial > Medical > Surgical Gowns', ''),
(1310, 'Business & Industrial > Mining & Quarrying',
''),
(1311, 'Business & Industrial > Piercing & Tattooing > Piercing Supplies', ''),
(1312, 'Business & Industrial >
Piercing & Tattooing > Piercing Supplies > Piercing Needles', ''),
(1313, 'Business & Industrial > Piercing & Tattooing
> Tattooing Supplies', ''),
(1314, 'Business & Industrial > Piercing & Tattooing > Tattooing Supplies > Tattoo Cover-
Ups', ''),
(1315, 'Business & Industrial > Piercing & Tattooing > Tattooing Supplies > Tattooing Inks', ''),
(1316,
'Business & Industrial > Piercing & Tattooing > Tattooing Supplies > Tattooing Machines', ''),
(1317, 'Business &
Industrial > Piercing & Tattooing > Tattooing Supplies > Tattooing Needles', ''),
(1318, 'Business & Industrial > Retail
> Clothing Display Racks', ''),
(1319, 'Business & Industrial > Retail > Display Mannequins', ''),
(1320, 'Business &
Industrial > Retail > Mannequin Parts', ''),
(1321, 'Business & Industrial > Retail > Money Handling', ''),
(1322,
'Business & Industrial > Retail > Money Handling > Banknote Verifiers', ''),
(1323, 'Business & Industrial > Retail >
Money Handling > Cash Register & POS Terminal Accessories > Cash Drawers & Trays', ''),
(1324, 'Business & Industrial >
Retail > Money Handling > Cash Register & POS Terminal Accessories > Credit Card Terminals', ''),
(1325, 'Business &
Industrial > Retail > Money Handling > Cash Register & POS Terminal Accessories > Signature Capture Pads', ''),
(1326,
'Business & Industrial > Retail > Money Handling > Cash Registers & POS Terminals', ''),
(1327, 'Business & Industrial >
Retail > Money Handling > Coin & Bill Counters', ''),
(1328, 'Business & Industrial > Retail > Money Handling > Money
Changers', ''),
(1329, 'Business & Industrial > Retail > Money Handling > Money Deposit Bags', ''),
(1330, 'Business &
Industrial > Retail > Money Handling > Paper Coin Wrappers & Bill Straps', ''),
(1331, 'Business & Industrial > Retail >
Paper & Plastic Shopping Bags', ''),
(1332, 'Business & Industrial > Retail > Pricing Guns', ''),
(1333, 'Business &
Industrial > Retail > Retail Display Cases', ''),
(1334, 'Business & Industrial > Retail > Retail Display Props &
Models', ''),
(1335, 'Business & Industrial > Science & Laboratory > Biochemicals', ''),
(1336, 'Business & Industrial >
Science & Laboratory > Dissection Kits', ''),
(1337, 'Business & Industrial > Science & Laboratory > Laboratory
Chemicals', ''),
(1338, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Autoclaves', ''),
(1339,
'Business & Industrial > Science & Laboratory > Laboratory Equipment > Centrifuges', ''),
(1340, 'Business & Industrial
> Science & Laboratory > Laboratory Equipment > Dry Ice Makers', ''),
(1341, 'Business & Industrial > Science &
Laboratory > Laboratory Equipment > Freeze-Drying Machines', ''),
(1342, 'Business & Industrial > Science & Laboratory >
Laboratory Equipment > Laboratory Blenders', ''),
(1343, 'Business & Industrial > Science & Laboratory > Laboratory
Equipment > Laboratory Freezers', ''),
(1344, 'Business & Industrial > Science & Laboratory > Laboratory Equipment >
Laboratory Funnels', ''),
(1345, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Laboratory Hot
Plates', ''),
(1346, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Laboratory Ovens', ''),
(1347, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Microscope Accessories', ''),
(1348,
'Business & Industrial > Science & Laboratory > Laboratory Equipment > Microscope Accessories > Microscope Cameras',
''),
(1349, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Microscope Accessories > Microscope
Eyepieces & Adapters', ''),
(1350, 'Business & Industrial > Science & Laboratory > Laboratory Equipment > Microscope
Accessories > Microscope Objective Lenses', ''),
(1351, 'Business & Industrial > Science & Laboratory > Laboratory
Equipment > Microscope Accessories > Microscope Replacement Bulbs', ''),
(1352, 'Business & Industrial > Science &
Laboratory > Laboratory Equipment > Microscope Accessories > Microscope Slides', ''),
(1353, 'Business & Industrial >
Science & Laboratory > Laboratory Equipment > Microscopes', ''),
(1354, 'Business & Industrial > Science & Laboratory >
Laboratory Equipment > Microtomes', ''),
(1355, 'Business & Industrial > Science & Laboratory > Laboratory Equipment >
Spectrometer Accessories', ''),
(1356, 'Business & Industrial > Science & Laboratory > Laboratory Equipment >
Spectrometers', ''),
(1357, 'Business & Industrial > Science & Laboratory > Laboratory Specimens', ''),
(1358, 'Business
& Industrial > Science & Laboratory > Laboratory Supplies > Beakers', ''),
(1359, 'Business & Industrial > Science &
Laboratory > Laboratory Supplies > Graduated Cylinders', ''),
(1360, 'Business & Industrial > Science & Laboratory >
Laboratory Supplies > Laboratory Flasks', ''),
(1361, 'Business & Industrial > Science & Laboratory > Laboratory
Supplies > Petri Dishes', ''),
(1362, 'Business & Industrial > Science & Laboratory > Laboratory Supplies > Pipettes',
''),
(1363, 'Business & Industrial > Science & Laboratory > Laboratory Supplies > Test Tube Racks', ''),
(1364,
'Business & Industrial > Science & Laboratory > Laboratory Supplies > Test Tubes', ''),
(1365, 'Business & Industrial >
Science & Laboratory > Laboratory Supplies > Wash Bottles', ''),
(1366, 'Business & Industrial > Signage > Business Hour
Signs', ''),
(1367, 'Business & Industrial > Signage > Digital Signs', ''),
(1368, 'Business & Industrial > Signage >
Electric Signs', ''),
(1369, 'Business & Industrial > Signage > Electric Signs > LED Signs', ''),
(1370, 'Business &
Industrial > Signage > Electric Signs > Neon Signs', ''),
(1371, 'Business & Industrial > Signage > Emergency & Exit
Signs', ''),
(1372, 'Business & Industrial > Signage > Facility Identification Signs', ''),
(1373, 'Business &
Industrial > Signage > Open & Closed Signs', ''),
(1374, 'Business & Industrial > Signage > Parking Signs & Permits',
''),
(1375, 'Business & Industrial > Signage > Policy Signs', ''),
(1376, 'Business & Industrial > Signage > Retail &
Sale Signs', ''),
(1377, 'Business & Industrial > Signage > Road & Traffic Signs', ''),
(1378, 'Business & Industrial >
Signage > Safety & Warning Signs', ''),
(1379, 'Business & Industrial > Signage > Security Signs', ''),
(1380, 'Business
& Industrial > Signage > Sidewalk & Yard Signs', ''),
(1381, 'Business & Industrial > Work Safety Protective Gear >
Bullet Proof Vests', ''),
(1382, 'Business & Industrial > Work Safety Protective Gear > Gas Mask & Respirator
Accessories', ''),
(1383, 'Business & Industrial > Work Safety Protective Gear > Hardhats', ''),
(1384, 'Business &
Industrial > Work Safety Protective Gear > Hazardous Material Suits', ''),
(1385, 'Business & Industrial > Work Safety
Protective Gear > Protective Aprons', ''),
(1386, 'Business & Industrial > Work Safety Protective Gear > Protective
Eyewear', ''),
(1387, 'Business & Industrial > Work Safety Protective Gear > Protective Masks', ''),
(1388, 'Business &
Industrial > Work Safety Protective Gear > Protective Masks > Dust Masks', ''),
(1389, 'Business & Industrial > Work
Safety Protective Gear > Protective Masks > Fireman''s Masks', ''),
(1390, 'Business & Industrial > Work Safety
Protective Gear > Protective Masks > Gas Masks & Respirators', ''),
(1391, 'Business & Industrial > Work Safety
Protective Gear > Protective Masks > Medical Masks', ''),
(1392, 'Business & Industrial > Work Safety Protective Gear >
Safety Gloves', ''),
(1393, 'Business & Industrial > Work Safety Protective Gear > Safety Knee Pads', ''),
(1394,
'Business & Industrial > Work Safety Protective Gear > Welding Helmets', ''),
(1395, 'Business & Industrial > Work
Safety Protective Gear > Work Safety Harnesses', ''),
(1396, 'Business & Industrial > Work Safety Protective Gear > Work
Safety Tethers', ''),
(1397, 'Cameras & Optics > Camera & Optic Accessories > Camera & Video Camera Lenses', ''),
(1398,
'Cameras & Optics > Camera & Optic Accessories > Camera & Video Camera Lenses > Camera Lenses', ''),
(1399, 'Cameras &
Optics > Camera & Optic Accessories > Camera & Video Camera Lenses > Surveillance Camera Lenses', ''),
(1400, 'Cameras &
Optics > Camera & Optic Accessories > Camera & Video Camera Lenses > Video Camera Lenses', ''),
(1401, 'Cameras & Optics
> Camera & Optic Accessories > Camera Lens Accessories > Lens & Filter Adapter Rings', ''),
(1402, 'Cameras & Optics >
Camera & Optic Accessories > Camera Lens Accessories > Lens Bags', ''),
(1403, 'Cameras & Optics > Camera & Optic
Accessories > Camera Lens Accessories > Lens Caps', ''),
(1404, 'Cameras & Optics > Camera & Optic Accessories > Camera
Lens Accessories > Lens Converters', ''),
(1405, 'Cameras & Optics > Camera & Optic Accessories > Camera Lens
Accessories > Lens Filters', ''),
(1406, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories',
''),
(1407, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Accessory Sets', ''),
(1408, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Bags & Cases', ''),
(1409,
'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Body Replacement Panels & Doors',
''),
(1410, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Digital Backs', ''),
(1411, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Film', ''),
(1412, 'Cameras
& Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Flash Accessories', ''),
(1413, 'Cameras &
Optics > Camera & Optic Accessories > Camera Parts & Accessories > Camera Flashes', ''),
(1414, 'Cameras & Optics >
Camera & Optic Accessories > Camera Parts & Accessories > Camera Focus Devices', ''),
(1415, 'Cameras & Optics > Camera
& Optic Accessories > Camera Parts & Accessories > Camera Gears', ''),
(1416, 'Cameras & Optics > Camera & Optic
Accessories > Camera Parts & Accessories > Camera Grips', ''),
(1417, 'Cameras & Optics > Camera & Optic Accessories >
Camera Parts & Accessories > Camera Image Sensors', ''),
(1418, 'Cameras & Optics > Camera & Optic Accessories > Camera
Parts & Accessories > Camera Lens Zoom Units', ''),
(1419, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts
& Accessories > Camera Remote Controls', ''),
(1420, 'Cameras & Optics > Camera & Optic Accessories > Camera Parts &
Accessories > Camera Replacement Buttons & Knobs', ''),
(1421, 'Cameras & Optics > Camera & Optic Accessories > Camera
Parts & Accessories > Camera Replacement Screens & Displays', ''),
(1422, 'Cameras & Optics > Camera & Optic Accessories
> Camera Parts & Accessories > Camera Silencers & Sound Blimps', ''),
(1423, 'Cameras & Optics > Camera & Optic
Accessories > Camera Parts & Accessories > Camera Stabilizers & Supports', ''),
(1424, 'Cameras & Optics > Camera &
Optic Accessories > Camera Parts & Accessories > Camera Straps', ''),
(1425, 'Cameras & Optics > Camera & Optic
Accessories > Camera Parts & Accessories > Camera Sun Hoods & Viewfinder Attachments', ''),
(1426, 'Cameras & Optics >
Camera & Optic Accessories > Camera Parts & Accessories > Flash Brackets', ''),
(1427, 'Cameras & Optics > Camera &
Optic Accessories > Camera Parts & Accessories > On-Camera Monitors', ''),
(1428, 'Cameras & Optics > Camera & Optic
Accessories > Camera Parts & Accessories > Surveillance Camera Accessories', ''),
(1429, 'Cameras & Optics > Camera &
Optic Accessories > Camera Parts & Accessories > Underwater Camera Housing Accessories', ''),
(1430, 'Cameras & Optics >
Camera & Optic Accessories > Camera Parts & Accessories > Underwater Camera Housings', ''),
(1431, 'Cameras & Optics >
Camera & Optic Accessories > Camera Parts & Accessories > Video Camera Lights', ''),
(1432, 'Cameras & Optics > Camera &
Optic Accessories > Optic Accessories > Binocular & Monocular Accessories', ''),
(1433, 'Cameras & Optics > Camera &
Optic Accessories > Optic Accessories > Optics Bags & Cases', ''),
(1434, 'Cameras & Optics > Camera & Optic Accessories
> Optic Accessories > Rangefinder Accessories', ''),
(1435, 'Cameras & Optics > Camera & Optic Accessories > Optic
Accessories > Spotting Scope Accessories', ''),
(1436, 'Cameras & Optics > Camera & Optic Accessories > Optic
Accessories > Telescope Accessories', ''),
(1437, 'Cameras & Optics > Camera & Optic Accessories > Optic Accessories >
Thermal Optic Accessories', ''),
(1438, 'Cameras & Optics > Camera & Optic Accessories > Optic Accessories > Weapon
Scope & Sight Accessories', ''),
(1439, 'Cameras & Optics > Camera & Optic Accessories > Tripod & Monopod Accessories >
Tripod & Monopod Cases', ''),
(1440, 'Cameras & Optics > Camera & Optic Accessories > Tripod & Monopod Accessories >
Tripod & Monopod Heads', ''),
(1441, 'Cameras & Optics > Camera & Optic Accessories > Tripod & Monopod Accessories >
Tripod Collars & Mounts', ''),
(1442, 'Cameras & Optics > Camera & Optic Accessories > Tripod & Monopod Accessories >
Tripod Handles', ''),
(1443, 'Cameras & Optics > Camera & Optic Accessories > Tripod & Monopod Accessories > Tripod
Spreaders', ''),
(1444, 'Cameras & Optics > Camera & Optic Accessories > Tripods & Monopods', ''),
(1445, 'Cameras &
Optics > Cameras > Borescopes', ''),
(1446, 'Cameras & Optics > Cameras > Digital Cameras', ''),
(1447, 'Cameras &
Optics > Cameras > Disposable Cameras', ''),
(1448, 'Cameras & Optics > Cameras > Film Cameras', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (1449,
'Cameras & Optics > Cameras > Surveillance Cameras', ''),
(1450, 'Cameras & Optics > Cameras > Trail Cameras', ''),
(1451, 'Cameras & Optics > Cameras > Video Cameras', ''),
(1452, 'Cameras & Optics > Cameras > Webcams', ''),
(1453,
'Cameras & Optics > Optics > Binoculars', ''),
(1454, 'Cameras & Optics > Optics > Monoculars', ''),
(1455, 'Cameras &
Optics > Optics > Rangefinders', ''),
(1456, 'Cameras & Optics > Optics > Scopes > Spotting Scopes', ''),
(1457,
'Cameras & Optics > Optics > Scopes > Telescopes', ''),
(1458, 'Cameras & Optics > Optics > Scopes > Weapon Scopes &
Sights', ''),
(1459, 'Cameras & Optics > Photography > Darkroom > Developing & Processing Equipment', ''),
(1460,
'Cameras & Optics > Photography > Darkroom > Developing & Processing Equipment > Copystands', ''),
(1461, 'Cameras &
Optics > Photography > Darkroom > Developing & Processing Equipment > Darkroom Sinks', ''),
(1462, 'Cameras & Optics >
Photography > Darkroom > Developing & Processing Equipment > Developing Tanks & Reels', ''),
(1463, 'Cameras & Optics >
Photography > Darkroom > Developing & Processing Equipment > Print Trays,Washers & Dryers', ''),
(1464, 'Cameras &
Optics > Photography > Darkroom > Developing & Processing Equipment > Retouching Equipment & Supplies', ''),
(1465,
'Cameras & Optics > Photography > Darkroom > Enlarging Equipment', ''),
(1466, 'Cameras & Optics > Photography >
Darkroom > Enlarging Equipment > Darkroom Easels', ''),
(1467, 'Cameras & Optics > Photography > Darkroom > Enlarging
Equipment > Darkroom Timers', ''),
(1468, 'Cameras & Optics > Photography > Darkroom > Enlarging Equipment > Focusing
Aids', ''),
(1469, 'Cameras & Optics > Photography > Darkroom > Enlarging Equipment > Photographic Analyzers', ''),
(1470, 'Cameras & Optics > Photography > Darkroom > Enlarging Equipment > Photographic Enlargers', ''),
(1471, 'Cameras
& Optics > Photography > Darkroom > Photographic Chemicals', ''),
(1472, 'Cameras & Optics > Photography > Darkroom >
Photographic Paper', ''),
(1473, 'Cameras & Optics > Photography > Darkroom > Safelights', ''),
(1474, 'Cameras & Optics
> Photography > Lighting & Studio > Light Meter Accessories', ''),
(1475, 'Cameras & Optics > Photography > Lighting &
Studio > Light Meters', ''),
(1476, 'Cameras & Optics > Photography > Lighting & Studio > Studio Backgrounds', ''),
(1477, 'Cameras & Optics > Photography > Lighting & Studio > Studio Light & Flash Accessories', ''),
(1478, 'Cameras &
Optics > Photography > Lighting & Studio > Studio Lighting Controls', ''),
(1479, 'Cameras & Optics > Photography >
Lighting & Studio > Studio Lighting Controls > Flash Diffusers', ''),
(1480, 'Cameras & Optics > Photography > Lighting
& Studio > Studio Lighting Controls > Flash Reflectors', ''),
(1481, 'Cameras & Optics > Photography > Lighting & Studio
> Studio Lighting Controls > Lighting Filters & Gobos', ''),
(1482, 'Cameras & Optics > Photography > Lighting & Studio
> Studio Lighting Controls > Softboxes', ''),
(1483, 'Cameras & Optics > Photography > Lighting & Studio > Studio Lights
& Flashes', ''),
(1484, 'Cameras & Optics > Photography > Lighting & Studio > Studio Stand & Mount Accessories', ''),
(1485, 'Cameras & Optics > Photography > Lighting & Studio > Studio Stands & Mounts', ''),
(1486, 'Cameras & Optics >
Photography > Photo Mounting Supplies', ''),
(1487, 'Cameras & Optics > Photography > Photo Negative & Slide Storage',
''),
(1488, 'Electronics > Arcade Equipment > Basketball Arcade Games', ''),
(1489, 'Electronics > Arcade Equipment >
Pinball Machine Accessories', ''),
(1490, 'Electronics > Arcade Equipment > Pinball Machines', ''),
(1491, 'Electronics
> Arcade Equipment > Skee-Ball Machines', ''),
(1492, 'Electronics > Arcade Equipment > Video Game Arcade Cabinet
Accessories', ''),
(1493, 'Electronics > Audio > Audio Accessories', ''),
(1494, 'Electronics > Audio > Audio
Accessories > Audio & Video Receiver Accessories', ''),
(1495, 'Electronics > Audio > Audio Accessories > Headphone &
Headset Accessories', ''),
(1496, 'Electronics > Audio > Audio Accessories > Headphone & Headset Accessories > Headphone
Cushions & Tips', ''),
(1497, 'Electronics > Audio > Audio Accessories > Karaoke System Accessories', ''),
(1498,
'Electronics > Audio > Audio Accessories > Karaoke System Accessories > Karaoke Chips', ''),
(1499, 'Electronics > Audio
> Audio Accessories > MP3 Player Accessories', ''),
(1500, 'Electronics > Audio > Audio Accessories > MP3 Player
Accessories > MP3 Player & Mobile Phone Accessory Sets', ''),
(1501, 'Electronics > Audio > Audio Accessories > MP3
Player Accessories > MP3 Player Cases', ''),
(1502, 'Electronics > Audio > Audio Accessories > Microphone Accessories',
''),
(1503, 'Electronics > Audio > Audio Accessories > Microphone Stands', ''),
(1504, 'Electronics > Audio > Audio
Accessories > Satellite Radio Accessories', ''),
(1505, 'Electronics > Audio > Audio Accessories > Speaker Accessories',
''),
(1506, 'Electronics > Audio > Audio Accessories > Speaker Accessories > Speaker Bags,Covers & Cases', ''),
(1507,
'Electronics > Audio > Audio Accessories > Speaker Accessories > Speaker Components & Kits', ''),
(1508, 'Electronics >
Audio > Audio Accessories > Speaker Accessories > Speaker Stand Bags', ''),
(1509, 'Electronics > Audio > Audio
Accessories > Speaker Accessories > Speaker Stands & Mounts', ''),
(1510, 'Electronics > Audio > Audio Accessories >
Speaker Accessories > Tactile Transducers', ''),
(1511, 'Electronics > Audio > Audio Accessories > Turntable
Accessories', ''),
(1512, 'Electronics > Audio > Audio Components > Audio & Video Receivers', ''),
(1513, 'Electronics >
Audio > Audio Components > Audio Amplifiers', ''),
(1514, 'Electronics > Audio > Audio Components > Audio Amplifiers >
Headphone Amplifiers', ''),
(1515, 'Electronics > Audio > Audio Components > Audio Amplifiers > Power Amplifiers', ''),
(1516, 'Electronics > Audio > Audio Components > Audio Mixers', ''),
(1517, 'Electronics > Audio > Audio Components >
Audio Transmitters', ''),
(1518, 'Electronics > Audio > Audio Components > Audio Transmitters > Bluetooth Transmitters',
''),
(1519, 'Electronics > Audio > Audio Components > Audio Transmitters > FM Transmitters', ''),
(1520, 'Electronics >
Audio > Audio Components > Channel Strips', ''),
(1521, 'Electronics > Audio > Audio Components > Direct Boxes', ''),
(1522, 'Electronics > Audio > Audio Components > Headphones & Headsets', ''),
(1523, 'Electronics > Audio > Audio
Components > Microphones', ''),
(1524, 'Electronics > Audio > Audio Components > Signal Processors', ''),
(1525,
'Electronics > Audio > Audio Components > Signal Processors > Crossovers', ''),
(1526, 'Electronics > Audio > Audio
Components > Signal Processors > Effects Processors', ''),
(1527, 'Electronics > Audio > Audio Components > Signal
Processors > Equalizers', ''),
(1528, 'Electronics > Audio > Audio Components > Signal Processors > Loudspeaker
Management Systems', ''),
(1529, 'Electronics > Audio > Audio Components > Signal Processors > Microphone Preamps', ''),
(1530, 'Electronics > Audio > Audio Components > Signal Processors > Noise Gates & Compressors', ''),
(1531,
'Electronics > Audio > Audio Components > Signal Processors > Phono Preamps', ''),
(1532, 'Electronics > Audio > Audio
Components > Speakers', ''),
(1533, 'Electronics > Audio > Audio Components > Studio Recording Bundles', ''),
(1534,
'Electronics > Audio > Audio Players & Recorders > Boomboxes', ''),
(1535, 'Electronics > Audio > Audio Players &
Recorders > CD Players & Recorders', ''),
(1536, 'Electronics > Audio > Audio Players & Recorders > Cassette Players &
Recorders', ''),
(1537, 'Electronics > Audio > Audio Players & Recorders > Home Theater Systems', ''),
(1538,
'Electronics > Audio > Audio Players & Recorders > Jukeboxes', ''),
(1539, 'Electronics > Audio > Audio Players &
Recorders > Karaoke Systems', ''),
(1540, 'Electronics > Audio > Audio Players & Recorders > MP3 Players', ''),
(1541,
'Electronics > Audio > Audio Players & Recorders > MiniDisc Players & Recorders', ''),
(1542, 'Electronics > Audio >
Audio Players & Recorders > Multitrack Recorders', ''),
(1543, 'Electronics > Audio > Audio Players & Recorders >
Radios', ''),
(1544, 'Electronics > Audio > Audio Players & Recorders > Reel-to-Reel Tape Players & Recorders', ''),
(1545, 'Electronics > Audio > Audio Players & Recorders > Stereo Systems', ''),
(1546, 'Electronics > Audio > Audio
Players & Recorders > Turntables & Record Players', ''),
(1547, 'Electronics > Audio > Audio Players & Recorders > Voice
Recorders', ''),
(1548, 'Electronics > Audio > Bullhorns', ''),
(1549, 'Electronics > Audio > DJ & Specialty Audio',
''),
(1550, 'Electronics > Audio > DJ & Specialty Audio > DJ CD Players', ''),
(1551, 'Electronics > Audio > DJ &
Specialty Audio > DJ Systems', ''),
(1552, 'Electronics > Audio > Public Address Systems', ''),
(1553, 'Electronics >
Audio > Stage Equipment', ''),
(1554, 'Electronics > Audio > Stage Equipment > Wireless Transmitters', ''),
(1555,
'Electronics > Circuit Boards & Components', ''),
(1556, 'Electronics > Circuit Boards & Components > Circuit Board
Accessories', ''),
(1557, 'Electronics > Circuit Boards & Components > Circuit Decoders & Encoders', ''),
(1558,
'Electronics > Circuit Boards & Components > Circuit Prototyping', ''),
(1559, 'Electronics > Circuit Boards &
Components > Circuit Prototyping > Breadboards', ''),
(1560, 'Electronics > Circuit Boards & Components > Electronic
Filters', ''),
(1561, 'Electronics > Circuit Boards & Components > Passive Circuit Components', ''),
(1562, 'Electronics
> Circuit Boards & Components > Passive Circuit Components > Capacitors', ''),
(1563, 'Electronics > Circuit Boards &
Components > Passive Circuit Components > Electronic Oscillators', ''),
(1564, 'Electronics > Circuit Boards &
Components > Passive Circuit Components > Inductors', ''),
(1565, 'Electronics > Circuit Boards & Components > Passive
Circuit Components > Resistors', ''),
(1566, 'Electronics > Circuit Boards & Components > Printed Circuit Boards', ''),
(1567, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Camera Circuit Boards', ''),
(1568,
'Electronics > Circuit Boards & Components > Printed Circuit Boards > Computer Circuit Boards', ''),
(1569, 'Electronics
> Circuit Boards & Components > Printed Circuit Boards > Computer Circuit Boards > Computer Inverter Boards', ''),
(1570, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Computer Circuit Boards > Hard Drive
Circuit Boards', ''),
(1571, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Computer Circuit
Boards > Motherboards', ''),
(1572, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Development
Boards', ''),
(1573, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Exercise Machine Circuit
Boards', ''),
(1574, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Household Appliance Circuit
Boards', ''),
(1575, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Pool & Spa Circuit Boards',
''),
(1576, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Printer,Copier,& Fax Machine Circuit
Boards', ''),
(1577, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Scanner Circuit Boards', ''),
(1578, 'Electronics > Circuit Boards & Components > Printed Circuit Boards > Television Circuit Boards', ''),
(1579,
'Electronics > Circuit Boards & Components > Semiconductors', ''),
(1580, 'Electronics > Circuit Boards & Components >
Semiconductors > Diodes', ''),
(1581, 'Electronics > Circuit Boards & Components > Semiconductors > Integrated Circuits
& Chips', ''),
(1582, 'Electronics > Circuit Boards & Components > Semiconductors > Microcontrollers', ''),
(1583,
'Electronics > Circuit Boards & Components > Semiconductors > Transistors', ''),
(1584, 'Electronics > Communications >
Answering Machines', ''),
(1585, 'Electronics > Communications > Caller IDs', ''),
(1586, 'Electronics > Communications
> Communication Radio Accessories', ''),
(1587, 'Electronics > Communications > Communication Radios', ''),
(1588,
'Electronics > Communications > Communication Radios > CB Radios', ''),
(1589, 'Electronics > Communications >
Communication Radios > Radio Scanners', ''),
(1590, 'Electronics > Communications > Communication Radios > Two-Way
Radios', ''),
(1591, 'Electronics > Communications > Intercom Accessories', ''),
(1592, 'Electronics > Communications >
Intercoms', ''),
(1593, 'Electronics > Communications > Pagers', ''),
(1594, 'Electronics > Communications > Telephony >
Conference Phones', ''),
(1595, 'Electronics > Communications > Telephony > Corded Phones', ''),
(1596, 'Electronics >
Communications > Telephony > Cordless Phones', ''),
(1597, 'Electronics > Communications > Telephony > Mobile Phone
Accessories > Mobile Phone Camera Accessories', ''),
(1598, 'Electronics > Communications > Telephony > Mobile Phone
Accessories > Mobile Phone Cases', ''),
(1599, 'Electronics > Communications > Telephony > Mobile Phone Accessories >
Mobile Phone Charms & Straps', ''),
(1600, 'Electronics > Communications > Telephony > Mobile Phone Accessories > Mobile
Phone Pre-Paid Cards & SIM Cards', ''),
(1601, 'Electronics > Communications > Telephony > Mobile Phone Accessories >
Mobile Phone Replacement Parts', ''),
(1602, 'Electronics > Communications > Telephony > Mobile Phone Accessories >
Mobile Phone Stands', ''),
(1603, 'Electronics > Communications > Telephony > Mobile Phone Accessories > SIM Card
Ejection Tools', ''),
(1604, 'Electronics > Communications > Telephony > Mobile Phones', ''),
(1605, 'Electronics >
Communications > Telephony > Satellite Phones', ''),
(1606, 'Electronics > Communications > Telephony > Telephone
Accessories', ''),
(1607, 'Electronics > Communications > Telephony > Telephone Accessories > Phone Cards', ''),
(1608,
'Electronics > Communications > Video Conferencing', ''),
(1609, 'Electronics > Components > Accelerometers', ''),
(1610, 'Electronics > Components > Converters', ''),
(1611, 'Electronics > Components > Converters > Audio Converters',
''),
(1612, 'Electronics > Components > Converters > Scan Converters', ''),
(1613, 'Electronics > Components >
Electronics Component Connectors', ''),
(1614, 'Electronics > Components > Modulators', ''),
(1615, 'Electronics >
Components > Splitters', ''),
(1616, 'Electronics > Computers > Barebone Computers', ''),
(1617, 'Electronics >
Computers > Computer Servers', ''),
(1618, 'Electronics > Computers > Desktop Computers', ''),
(1619, 'Electronics >
Computers > Handheld Devices', ''),
(1620, 'Electronics > Computers > Handheld Devices > Data Collectors', ''),
(1621,
'Electronics > Computers > Handheld Devices > E-Book Readers', ''),
(1622, 'Electronics > Computers > Handheld Devices >
PDAs', ''),
(1623, 'Electronics > Computers > Interactive Kiosks', ''),
(1624, 'Electronics > Computers > Laptops', ''),
(1625, 'Electronics > Computers > Smart Glasses', ''),
(1626, 'Electronics > Computers > Tablet Computers', ''),
(1627,
'Electronics > Computers > Thin & Zero Clients', ''),
(1628, 'Electronics > Computers > Touch Table Computers', ''),
(1629, 'Electronics > Electronics Accessories > Adapters', ''),
(1630, 'Electronics > Electronics Accessories > Adapters
> Audio & Video Cable Adapters & Couplers', ''),
(1631, 'Electronics > Electronics Accessories > Adapters > Memory Card
Adapters', ''),
(1632, 'Electronics > Electronics Accessories > Adapters > USB Adapters', ''),
(1633, 'Electronics >
Electronics Accessories > Antenna Accessories', ''),
(1634, 'Electronics > Electronics Accessories > Antenna Accessories
> Antenna Mounts & Brackets', ''),
(1635, 'Electronics > Electronics Accessories > Antenna Accessories > Antenna
Rotators', ''),
(1636, 'Electronics > Electronics Accessories > Antenna Accessories > Satellite LNBs', ''),
(1637,
'Electronics > Electronics Accessories > Antennas', ''),
(1638, 'Electronics > Electronics Accessories > Audio & Video
Splitters & Switches', ''),
(1639, 'Electronics > Electronics Accessories > Audio & Video Splitters & Switches > DVI
Splitters & Switches', ''),
(1640, 'Electronics > Electronics Accessories > Audio & Video Splitters & Switches > HDMI
Splitters & Switches', ''),
(1641, 'Electronics > Electronics Accessories > Audio & Video Splitters & Switches > VGA
Splitters & Switches', ''),
(1642, 'Electronics > Electronics Accessories > Blank Media', ''),
(1643, 'Electronics >
Electronics Accessories > Cable Management > Cable Clips', ''),
(1644, 'Electronics > Electronics Accessories > Cable
Management > Cable Tie Guns', ''),
(1645, 'Electronics > Electronics Accessories > Cable Management > Cable Trays', ''),
(1646, 'Electronics > Electronics Accessories > Cable Management > Patch Panels', ''),
(1647, 'Electronics > Electronics
Accessories > Cable Management > Wire & Cable Identification Markers', ''),
(1648, 'Electronics > Electronics
Accessories > Cable Management > Wire & Cable Sleeves', ''),
(1649, 'Electronics > Electronics Accessories > Cable
Management > Wire & Cable Ties', ''),
(1650, 'Electronics > Electronics Accessories > Cables', ''),
(1651, 'Electronics
> Electronics Accessories > Cables > Audio & Video Cables', ''),
(1652, 'Electronics > Electronics Accessories > Cables
> KVM Cables', ''),
(1653, 'Electronics > Electronics Accessories > Cables > Network Cables', ''),
(1654, 'Electronics >
Electronics Accessories > Cables > Storage & Data Transfer Cables', ''),
(1655, 'Electronics > Electronics Accessories >
Cables > System & Power Cables', ''),
(1656, 'Electronics > Electronics Accessories > Cables > Telephone Cables', ''),
(1657, 'Electronics > Electronics Accessories > Computer Accessories > Computer Accessory Sets', ''),
(1658,
'Electronics > Electronics Accessories > Computer Accessories > Computer Covers & Skins', ''),
(1659, 'Electronics >
Electronics Accessories > Computer Accessories > Computer Risers & Stands', ''),
(1660, 'Electronics > Electronics
Accessories > Computer Accessories > Handheld Device Accessories', ''),
(1661, 'Electronics > Electronics Accessories >
Computer Accessories > Handheld Device Accessories > E-Book Reader Accessories', ''),
(1662, 'Electronics > Electronics
Accessories > Computer Accessories > Handheld Device Accessories > E-Book Reader Accessories > E-Book Reader Cases',
''),
(1663, 'Electronics > Electronics Accessories > Computer Accessories > Handheld Device Accessories > PDA
Accessories', ''),
(1664, 'Electronics > Electronics Accessories > Computer Accessories > Handheld Device Accessories >
PDA Accessories > PDA Cases', ''),
(1665, 'Electronics > Electronics Accessories > Computer Accessories > Keyboard &
Mouse Wrist Rests', ''),
(1666, 'Electronics > Electronics Accessories > Computer Accessories > Keyboard Trays &
Platforms', ''),
(1667, 'Electronics > Electronics Accessories > Computer Accessories > Laptop Docking Stations', ''),
(1668, 'Electronics > Electronics Accessories > Computer Accessories > Mouse Pads', ''),
(1669, 'Electronics >
Electronics Accessories > Computer Accessories > Stylus Pen Nibs & Refills', ''),
(1670, 'Electronics > Electronics
Accessories > Computer Accessories > Stylus Pens', ''),
(1671, 'Electronics > Electronics Accessories > Computer
Accessories > Tablet Computer Docks & Stands', ''),
(1672, 'Electronics > Electronics Accessories > Computer Components
> Blade Server Enclosures', ''),
(1673, 'Electronics > Electronics Accessories > Computer Components > Computer
Backplates & I/O Shields', ''),
(1674, 'Electronics > Electronics Accessories > Computer Components > Computer Power
Supplies', ''),
(1675, 'Electronics > Electronics Accessories > Computer Components > Computer Processors', ''),
(1676,
'Electronics > Electronics Accessories > Computer Components > Computer Racks & Mounts', ''),
(1677, 'Electronics >
Electronics Accessories > Computer Components > Computer Starter Kits', ''),
(1678, 'Electronics > Electronics
Accessories > Computer Components > Computer System Cooling Parts', ''),
(1679, 'Electronics > Electronics Accessories >
Computer Components > Desktop Computer & Server Cases', ''),
(1680, 'Electronics > Electronics Accessories > Computer
Components > E-Book Reader Parts', ''),
(1681, 'Electronics > Electronics Accessories > Computer Components > E-Book
Reader Parts > E-Book Reader Screens & Screen Digitizers', ''),
(1682, 'Electronics > Electronics Accessories > Computer
Components > I/O Cards & Adapters > Audio Cards & Adapters', ''),
(1683, 'Electronics > Electronics Accessories >
Computer Components > I/O Cards & Adapters > Computer Interface Cards & Adapters', ''),
(1684, 'Electronics >
Electronics Accessories > Computer Components > I/O Cards & Adapters > Riser Cards', ''),
(1685, 'Electronics >
Electronics Accessories > Computer Components > I/O Cards & Adapters > TV Tuner Cards & Adapters', ''),
(1686,
'Electronics > Electronics Accessories > Computer Components > I/O Cards & Adapters > Video Cards & Adapters', ''),
(1687, 'Electronics > Electronics Accessories > Computer Components > Input Device Accessories > Barcode Scanner
Stands', ''),
(1688, 'Electronics > Electronics Accessories > Computer Components > Input Device Accessories > Game
Controller Accessories', ''),
(1689, 'Electronics > Electronics Accessories > Computer Components > Input Device
Accessories > Keyboard Keys & Caps', ''),
(1690, 'Electronics > Electronics Accessories > Computer Components > Input
Device Accessories > Mice & Trackball Accessories', ''),
(1691, 'Electronics > Electronics Accessories > Computer
Components > Input Devices > Barcode Scanners', ''),
(1692, 'Electronics > Electronics Accessories > Computer Components
> Input Devices > Digital Note Taking Pens', ''),
(1693, 'Electronics > Electronics Accessories > Computer Components >
Input Devices > Electronic Card Readers', ''),
(1694, 'Electronics > Electronics Accessories > Computer Components >
Input Devices > Fingerprint Readers', ''),
(1695, 'Electronics > Electronics Accessories > Computer Components > Input
Devices > Game Controllers', ''),
(1696, 'Electronics > Electronics Accessories > Computer Components > Input Devices >
Gesture Control Input Devices', ''),
(1697, 'Electronics > Electronics Accessories > Computer Components > Input Devices
> Graphics Tablets', ''),
(1698, 'Electronics > Electronics Accessories > Computer Components > Input Devices > KVM
Switches', ''),
(1699, 'Electronics > Electronics Accessories > Computer Components > Input Devices > Keyboards', ''),
(1700, 'Electronics > Electronics Accessories > Computer Components > Input Devices > Memory Card Readers', ''),
(1701,
'Electronics > Electronics Accessories > Computer Components > Input Devices > Mice & Trackballs', ''),
(1702,
'Electronics > Electronics Accessories > Computer Components > Input Devices > Numeric Keypads', ''),
(1703,
'Electronics > Electronics Accessories > Computer Components > Input Devices > Touchpads', ''),
(1704, 'Electronics >
Electronics Accessories > Computer Components > Laptop Parts > Laptop Hinges', ''),
(1705, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Housings & Trim', ''),
(1706, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Replacement Cables', ''),
(1707, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Replacement Keyboards', ''),
(1708, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Replacement Screens', ''),
(1709, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Replacement Speakers', ''),
(1710, 'Electronics > Electronics
Accessories > Computer Components > Laptop Parts > Laptop Screen Digitizers', ''),
(1711, 'Electronics > Electronics
Accessories > Computer Components > Storage Devices > Disk Duplicators', ''),
(1712, 'Electronics > Electronics
Accessories > Computer Components > Storage Devices > Disk Duplicators > CD/DVD Duplicators', ''),
(1713, 'Electronics >
Electronics Accessories > Computer Components > Storage Devices > Disk Duplicators > Hard Drive Duplicators', ''),
(1714, 'Electronics > Electronics Accessories > Computer Components > Storage Devices > Disk Duplicators > USB Drive
Duplicators', ''),
(1715, 'Electronics > Electronics Accessories > Computer Components > Storage Devices > Floppy
Drives', ''),
(1716, 'Electronics > Electronics Accessories > Computer Components > Storage Devices > Hard Drive
Accessories', ''),
(1717, 'Electronics > Electronics Accessories > Computer Components > Storage Devices > Hard Drive
Accessories > Hard Drive Carrying Cases', ''),
(1718, 'Electronics > Electronics Accessories > Computer Components >
Storage Devices > Hard Drive Accessories > Hard Drive Docks', ''),
(1719, 'Electronics > Electronics Accessories >
Computer Components > Storage Devices > Hard Drive Accessories > Hard Drive Enclosures & Mounts', ''),
(1720,
'Electronics > Electronics Accessories > Computer Components > Storage Devices > Hard Drive Arrays', ''),
(1721,
'Electronics > Electronics Accessories > Computer Components > Storage Devices > Hard Drives', ''),
(1722, 'Electronics
> Electronics Accessories > Computer Components > Storage Devices > Network Storage Systems', ''),
(1723, 'Electronics >
Electronics Accessories > Computer Components > Storage Devices > Optical Drives', ''),
(1724, 'Electronics >
Electronics Accessories > Computer Components > Storage Devices > Tape Drives', ''),
(1725, 'Electronics > Electronics
Accessories > Computer Components > Storage Devices > USB Flash Drives', ''),
(1726, 'Electronics > Electronics
Accessories > Computer Components > Tablet Computer Parts > Tablet Computer Housings & Trim', ''),
(1727, 'Electronics >
Electronics Accessories > Computer Components > Tablet Computer Parts > Tablet Computer Replacement Speakers', ''),
(1728, 'Electronics > Electronics Accessories > Computer Components > Tablet Computer Parts > Tablet Computer Screens &
Screen Digitizers', ''),
(1729, 'Electronics > Electronics Accessories > Computer Components > USB & FireWire Hubs',
''),
(1730, 'Electronics > Electronics Accessories > Electronics Cleaners', ''),
(1731, 'Electronics > Electronics
Accessories > Electronics Films & Shields > Electronics Stickers & Decals', ''),
(1732, 'Electronics > Electronics
Accessories > Electronics Films & Shields > Keyboard Protectors', ''),
(1733, 'Electronics > Electronics Accessories >
Electronics Films & Shields > Privacy Filters', ''),
(1734, 'Electronics > Electronics Accessories > Electronics Films &
Shields > Screen Protectors', ''),
(1735, 'Electronics > Electronics Accessories > Memory > Cache Memory', ''),
(1736,
'Electronics > Electronics Accessories > Memory > Flash Memory', ''),
(1737, 'Electronics > Electronics Accessories >
Memory > Flash Memory > Flash Memory Cards', ''),
(1738, 'Electronics > Electronics Accessories > Memory > RAM', ''),
(1739, 'Electronics > Electronics Accessories > Memory > ROM', ''),
(1740, 'Electronics > Electronics Accessories >
Memory > Video Memory', ''),
(1741, 'Electronics > Electronics Accessories > Memory Accessories', ''),
(1742,
'Electronics > Electronics Accessories > Memory Accessories > Memory Cases', ''),
(1743, 'Electronics > Electronics
Accessories > Mobile Phone & Tablet Tripods & Monopods', ''),
(1744, 'Electronics > Electronics Accessories > Power >
Batteries > Camera Batteries', ''),
(1745, 'Electronics > Electronics Accessories > Power > Batteries > Cordless Phone
Batteries', ''),
(1746, 'Electronics > Electronics Accessories > Power > Batteries > E-Book Reader Batteries', ''),
(1747, 'Electronics > Electronics Accessories > Power > Batteries > General Purpose Batteries', ''),
(1748, 'Electronics
> Electronics Accessories > Power > Batteries > Laptop Batteries', ''),
(1749, 'Electronics > Electronics Accessories >
Power > Batteries > MP3 Player Batteries', ''),
(1750, 'Electronics > Electronics Accessories > Power > Batteries >
Mobile Phone Batteries', ''),
(1751, 'Electronics > Electronics Accessories > Power > Batteries > PDA Batteries', ''),
(1752, 'Electronics > Electronics Accessories > Power > Batteries > Tablet Computer Batteries', ''),
(1753, 'Electronics
> Electronics Accessories > Power > Batteries > UPS Batteries', ''),
(1754, 'Electronics > Electronics Accessories >
Power > Batteries > Video Camera Batteries', ''),
(1755, 'Electronics > Electronics Accessories > Power > Batteries >
Video Game Console & Controller Batteries', ''),
(1756, 'Electronics > Electronics Accessories > Power > Battery
Accessories > Battery Charge Controllers', ''),
(1757, 'Electronics > Electronics Accessories > Power > Battery
Accessories > Battery Holders', ''),
(1758, 'Electronics > Electronics Accessories > Power > Battery Accessories >
Camera Battery Chargers', ''),
(1759, 'Electronics > Electronics Accessories > Power > Battery Accessories > General
Purpose Battery Chargers', ''),
(1760, 'Electronics > Electronics Accessories > Power > Battery Accessories > General
Purpose Battery Testers', ''),
(1761, 'Electronics > Electronics Accessories > Power > Fuel Cells', ''),
(1762,
'Electronics > Electronics Accessories > Power > Power Adapter & Charger Accessories', ''),
(1763, 'Electronics >
Electronics Accessories > Power > Power Adapters & Chargers', ''),
(1764, 'Electronics > Electronics Accessories > Power
> Power Control Units', ''),
(1765, 'Electronics > Electronics Accessories > Power > Power Strips & Surge Suppressors',
''),
(1766, 'Electronics > Electronics Accessories > Power > Power Supply Enclosures', ''),
(1767, 'Electronics >
Electronics Accessories > Power > Surge Protection Devices', ''),
(1768, 'Electronics > Electronics Accessories > Power
> Travel Converters & Adapters', ''),
(1769, 'Electronics > Electronics Accessories > Power > UPS', ''),
(1770,
'Electronics > Electronics Accessories > Power > UPS Accessories', ''),
(1771, 'Electronics > Electronics Accessories >
Remote Controls', ''),
(1772, 'Electronics > Electronics Accessories > Signal Boosters', ''),
(1773, 'Electronics >
Electronics Accessories > Signal Jammers > GPS Jammers', ''),
(1774, 'Electronics > Electronics Accessories > Signal
Jammers > Mobile Phone Jammers', ''),
(1775, 'Electronics > Electronics Accessories > Signal Jammers > Radar Jammers',
''),
(1776, 'Electronics > GPS Accessories > GPS Cases', ''),
(1777, 'Electronics > GPS Accessories > GPS Mounts', ''),
(1778, 'Electronics > GPS Navigation Systems', ''),
(1779, 'Electronics > GPS Tracking Devices', ''),
(1780,
'Electronics > Marine Electronics > Fish Finders', ''),
(1781, 'Electronics > Marine Electronics > Marine Audio & Video
Receivers', ''),
(1782, 'Electronics > Marine Electronics > Marine Chartplotters & GPS', ''),
(1783, 'Electronics >
Marine Electronics > Marine Radar', ''),
(1784, 'Electronics > Marine Electronics > Marine Radios', ''),
(1785,
'Electronics > Marine Electronics > Marine Speakers', ''),
(1786, 'Electronics > Networking > Bridges & Routers', ''),
(1787, 'Electronics > Networking > Bridges & Routers > Network Bridges', ''),
(1788, 'Electronics > Networking > Bridges
& Routers > VoIP Gateways & Routers', ''),
(1789, 'Electronics > Networking > Bridges & Routers > Wireless Access
Points', ''),
(1790, 'Electronics > Networking > Bridges & Routers > Wireless Routers', ''),
(1791, 'Electronics >
Networking > Concentrators & Multiplexers', ''),
(1792, 'Electronics > Networking > Hubs & Switches', ''),
(1793,
'Electronics > Networking > Modem Accessories', ''),
(1794, 'Electronics > Networking > Modems', ''),
(1795,
'Electronics > Networking > Network Cards & Adapters', ''),
(1796, 'Electronics > Networking > Network Security &
Firewall Devices', ''),
(1797, 'Electronics > Networking > Power Over Ethernet Adapters', ''),
(1798, 'Electronics >
Networking > Print Servers', ''),
(1799, 'Electronics > Networking > Repeaters & Transceivers', ''),
(1800, 'Electronics
> Print,Copy,Scan & Fax > 3D Printer Accessories', ''),
(1801, 'Electronics > Print,Copy,Scan & Fax > 3D Printers', ''),
(1802, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories > Printer Consumables', ''),
(1803, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories > Printer Consumables > Printer
Drums & Drum Kits', ''),
(1804, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories >
Printer Consumables > Printer Filters', ''),
(1805, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine
Accessories > Printer Consumables > Printer Maintenance Kits', ''),
(1806, 'Electronics > Print,Copy,Scan & Fax >
Printer,Copier & Fax Machine Accessories > Printer Consumables > Printer Ribbons', ''),
(1807, 'Electronics >
Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories > Printer Consumables > Printheads', ''),
(1808,
'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories > Printer Consumables > Toner & Inkjet
Cartridge Refills', ''),
(1809, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine Accessories >
Printer Consumables > Toner & Inkjet Cartridges', ''),
(1810, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier &
Fax Machine Accessories > Printer Duplexers', ''),
(1811, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax
Machine Accessories > Printer Memory', ''),
(1812, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine
Accessories > Printer Stands', ''),
(1813, 'Electronics > Print,Copy,Scan & Fax > Printer,Copier & Fax Machine
Accessories > Printer,Copier & Fax Machine Replacement Parts', ''),
(1814, 'Electronics > Print,Copy,Scan & Fax >
Printers,Copiers & Fax Machines', ''),
(1815, 'Electronics > Print,Copy,Scan & Fax > Scanner Accessories', ''),
(1816,
'Electronics > Print,Copy,Scan & Fax > Scanners', ''),
(1817, 'Electronics > Radar Detectors', ''),
(1818, 'Electronics
> Speed Radars', ''),
(1819, 'Electronics > Toll Collection Devices', ''),
(1820, 'Electronics > Video > Projectors',
''),
(1821, 'Electronics > Video > Projectors > Multimedia Projectors', ''),
(1822, 'Electronics > Video > Projectors >
Overhead Projectors', ''),
(1823, 'Electronics > Video > Projectors > Slide Projectors', ''),
(1824, 'Electronics >
Video > Satellite & Cable TV > Cable TV Receivers', ''),
(1825, 'Electronics > Video > Satellite & Cable TV > Satellite
Receivers', ''),
(1826, 'Electronics > Video > Televisions', ''),
(1827, 'Electronics > Video > Video Accessories > 3D
Glasses', ''),
(1828, 'Electronics > Video > Video Accessories > Computer Monitor Accessories', ''),
(1829, 'Electronics
> Video > Video Accessories > Computer Monitor Accessories > Color Calibrators', ''),
(1830, 'Electronics > Video >
Video Accessories > Projector Accessories > Projection & Tripod Skirts', ''),
(1831, 'Electronics > Video > Video
Accessories > Projector Accessories > Projection Screen Stands', ''),
(1832, 'Electronics > Video > Video Accessories >
Projector Accessories > Projection Screens', ''),
(1833, 'Electronics > Video > Video Accessories > Projector
Accessories > Projector Mounts', ''),
(1834, 'Electronics > Video > Video Accessories > Projector Accessories >
Projector Replacement Lamps', ''),
(1835, 'Electronics > Video > Video Accessories > Rewinders', ''),
(1836,
'Electronics > Video > Video Accessories > Television Parts & Accessories > TV & Monitor Mounts', ''),
(1837,
'Electronics > Video > Video Accessories > Television Parts & Accessories > TV Converter Boxes', ''),
(1838,
'Electronics > Video > Video Accessories > Television Parts & Accessories > TV Replacement Lamps', ''),
(1839,
'Electronics > Video > Video Accessories > Television Parts & Accessories > TV Replacement Speakers', ''),
(1840,
'Electronics > Video > Video Editing Hardware & Production Equipment', ''),
(1841, 'Electronics > Video > Video
Multiplexers', ''),
(1842, 'Electronics > Video > Video Players & Recorders > DVD & Blu-ray Players', ''),
(1843,
'Electronics > Video > Video Players & Recorders > DVD Recorders', ''),
(1844, 'Electronics > Video > Video Players &
Recorders > Digital Video Recorders', ''),
(1845, 'Electronics > Video > Video Players & Recorders > Streaming & Home
Media Players', ''),
(1846, 'Electronics > Video > Video Players & Recorders > VCRs', ''),
(1847, 'Electronics > Video >
Video Servers', ''),
(1848, 'Electronics > Video > Video Transmitters', ''),
(1849, 'Electronics > Video Game Console
Accessories > Home Game Console Accessories', ''),
(1850, 'Electronics > Video Game Console Accessories > Portable Game
Console Accessories', ''),
(1851, 'Electronics > Video Game Consoles', ''),
(1852, 'Food,Beverages & Tobacco > Beverages
> Buttermilk', ''),
(1853, 'Food,Beverages & Tobacco > Beverages > Coffee', ''),
(1854, 'Food,Beverages & Tobacco >
Beverages > Eggnog', ''),
(1855, 'Food,Beverages & Tobacco > Beverages > Fruit Flavored Drinks', ''),
(1856,
'Food,Beverages & Tobacco > Beverages > Hot Chocolate', '');";

$sql[] = "INSERT INTO
`"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (1857, 'Food,Beverages & Tobacco >
Beverages > Juice', ''),
(1858, 'Food,Beverages & Tobacco > Beverages > Milk', ''),
(1859, 'Food,Beverages & Tobacco >
Beverages > Non-Dairy Milk', ''),
(1860, 'Food,Beverages & Tobacco > Beverages > Powdered Beverage Mixes', ''),
(1861,
'Food,Beverages & Tobacco > Beverages > Soda', ''),
(1862, 'Food,Beverages & Tobacco > Beverages > Sports & Energy
Drinks', ''),
(1863, 'Food,Beverages & Tobacco > Beverages > Tea & Infusions', ''),
(1864, 'Food,Beverages & Tobacco >
Beverages > Vinegar Drinks', ''),
(1865, 'Food,Beverages & Tobacco > Beverages > Water', ''),
(1866, 'Food,Beverages &
Tobacco > Food Items > Bakery > Bagels', ''),
(1867, 'Food,Beverages & Tobacco > Food Items > Bakery > Bakery
Assortments', ''),
(1868, 'Food,Beverages & Tobacco > Food Items > Bakery > Breads & Buns', ''),
(1869, 'Food,Beverages
& Tobacco > Food Items > Bakery > Cakes & Dessert Bars', ''),
(1870, 'Food,Beverages & Tobacco > Food Items > Bakery >
Coffee Cakes', ''),
(1871, 'Food,Beverages & Tobacco > Food Items > Bakery > Cookies', ''),
(1872, 'Food,Beverages &
Tobacco > Food Items > Bakery > Cupcakes', ''),
(1873, 'Food,Beverages & Tobacco > Food Items > Bakery > Donuts', ''),
(1874, 'Food,Beverages & Tobacco > Food Items > Bakery > Fudge', ''),
(1875, 'Food,Beverages & Tobacco > Food Items >
Bakery > Ice Cream Cones', ''),
(1876, 'Food,Beverages & Tobacco > Food Items > Bakery > Muffins', ''),
(1877,
'Food,Beverages & Tobacco > Food Items > Bakery > Pastries & Scones', ''),
(1878, 'Food,Beverages & Tobacco > Food Items
> Bakery > Pies & Tarts', ''),
(1879, 'Food,Beverages & Tobacco > Food Items > Bakery > Taco Shells & Tostadas', ''),
(1880, 'Food,Beverages & Tobacco > Food Items > Bakery > Tortillas & Wraps', ''),
(1881, 'Food,Beverages & Tobacco >
Food Items > Candied & Chocolate Covered Fruit', ''),
(1882, 'Food,Beverages & Tobacco > Food Items > Candy &
Chocolate', ''),
(1883, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Cocktail Sauce', ''),
(1884,
'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Curry Sauce', ''),
(1885, 'Food,Beverages & Tobacco >
Food Items > Condiments & Sauces > Dessert Toppings', ''),
(1886, 'Food,Beverages & Tobacco > Food Items > Condiments &
Sauces > Dessert Toppings > Fruit Toppings', ''),
(1887, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces >
Dessert Toppings > Ice Cream Syrup', ''),
(1888, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Fish
Sauce', ''),
(1889, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Gravy', ''),
(1890, 'Food,Beverages &
Tobacco > Food Items > Condiments & Sauces > Honey', ''),
(1891, 'Food,Beverages & Tobacco > Food Items > Condiments &
Sauces > Horseradish Sauce', ''),
(1892, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Hot Sauce', ''),
(1893, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Ketchup', ''),
(1894, 'Food,Beverages & Tobacco >
Food Items > Condiments & Sauces > Marinades & Grilling Sauces', ''),
(1895, 'Food,Beverages & Tobacco > Food Items >
Condiments & Sauces > Mayonnaise', ''),
(1896, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Mustard',
''),
(1897, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Olives & Capers', ''),
(1898, 'Food,Beverages
& Tobacco > Food Items > Condiments & Sauces > Pasta Sauce', ''),
(1899, 'Food,Beverages & Tobacco > Food Items >
Condiments & Sauces > Pickled Fruits & Vegetables', ''),
(1900, 'Food,Beverages & Tobacco > Food Items > Condiments &
Sauces > Pizza Sauce', ''),
(1901, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Relish & Chutney',
''),
(1902, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Salad Dressing', ''),
(1903, 'Food,Beverages
& Tobacco > Food Items > Condiments & Sauces > Satay Sauce', ''),
(1904, 'Food,Beverages & Tobacco > Food Items >
Condiments & Sauces > Soy Sauce', ''),
(1905, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Sweet and
Sour Sauces', ''),
(1906, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Syrup', ''),
(1907,
'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Tahini', ''),
(1908, 'Food,Beverages & Tobacco > Food
Items > Condiments & Sauces > Tartar Sauce', ''),
(1909, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces >
White & Cream Sauces', ''),
(1910, 'Food,Beverages & Tobacco > Food Items > Condiments & Sauces > Worcestershire Sauce',
''),
(1911, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Baking Chips', ''),
(1912,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Baking Chocolate', ''),
(1913, 'Food,Beverages &
Tobacco > Food Items > Cooking & Baking Ingredients > Baking Flavors & Extracts', ''),
(1914, 'Food,Beverages & Tobacco
> Food Items > Cooking & Baking Ingredients > Baking Mixes', ''),
(1915, 'Food,Beverages & Tobacco > Food Items >
Cooking & Baking Ingredients > Baking Powder', ''),
(1916, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking
Ingredients > Baking Soda', ''),
(1917, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Batter &
Coating Mixes', ''),
(1918, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Bean Paste', ''),
(1919, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Bread Crumbs', ''),
(1920,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Canned & Dry Milk', ''),
(1921, 'Food,Beverages
& Tobacco > Food Items > Cooking & Baking Ingredients > Cookie Decorating Kits', ''),
(1922, 'Food,Beverages & Tobacco >
Food Items > Cooking & Baking Ingredients > Cooking Oils', ''),
(1923, 'Food,Beverages & Tobacco > Food Items > Cooking
& Baking Ingredients > Cooking Starch', ''),
(1924, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking
Ingredients > Cooking Wine', ''),
(1925, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Corn
Syrup', ''),
(1926, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Dough', ''),
(1927,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Dough > Bread & Pastry Dough', ''),
(1928,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Dough > Cookie & Brownie Dough', ''),
(1929,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Dough > Pie Crusts', ''),
(1930, 'Food,Beverages
& Tobacco > Food Items > Cooking & Baking Ingredients > Edible Baking Decorations', ''),
(1931, 'Food,Beverages &
Tobacco > Food Items > Cooking & Baking Ingredients > Floss Sugar', ''),
(1932, 'Food,Beverages & Tobacco > Food Items >
Cooking & Baking Ingredients > Flour', ''),
(1933, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients
> Food Coloring', ''),
(1934, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Frosting & Icing',
''),
(1935, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Lemon & Lime Juice', ''),
(1936,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Marshmallows', ''),
(1937, 'Food,Beverages &
Tobacco > Food Items > Cooking & Baking Ingredients > Meal', ''),
(1938, 'Food,Beverages & Tobacco > Food Items >
Cooking & Baking Ingredients > Molasses', ''),
(1939, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking
Ingredients > Pie & Pastry Fillings', ''),
(1940, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients
> Shortening & Lard', ''),
(1941, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Starter
Cultures', ''),
(1942, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Sugar & Sweeteners', ''),
(1943, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Tapioca Pearls', ''),
(1944,
'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients > Tomato Paste', ''),
(1945, 'Food,Beverages &
Tobacco > Food Items > Cooking & Baking Ingredients > Unflavored Gelatin', ''),
(1946, 'Food,Beverages & Tobacco > Food
Items > Cooking & Baking Ingredients > Vinegar', ''),
(1947, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking
Ingredients > Waffle & Pancake Mixes', ''),
(1948, 'Food,Beverages & Tobacco > Food Items > Cooking & Baking Ingredients
> Yeast', ''),
(1949, 'Food,Beverages & Tobacco > Food Items > Dairy Products > Butter & Margarine', ''),
(1950,
'Food,Beverages & Tobacco > Food Items > Dairy Products > Cheese', ''),
(1951, 'Food,Beverages & Tobacco > Food Items >
Dairy Products > Coffee Creamer', ''),
(1952, 'Food,Beverages & Tobacco > Food Items > Dairy Products > Cottage Cheese',
''),
(1953, 'Food,Beverages & Tobacco > Food Items > Dairy Products > Cream', ''),
(1954, 'Food,Beverages & Tobacco >
Food Items > Dairy Products > Sour Cream', ''),
(1955, 'Food,Beverages & Tobacco > Food Items > Dairy Products > Whipped
Cream', ''),
(1956, 'Food,Beverages & Tobacco > Food Items > Dairy Products > Yogurt', ''),
(1957, 'Food,Beverages &
Tobacco > Food Items > Dips & Spreads > Apple Butter', ''),
(1958, 'Food,Beverages & Tobacco > Food Items > Dips &
Spreads > Cheese Dips & Spreads', ''),
(1959, 'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Cream Cheese',
''),
(1960, 'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Guacamole', ''),
(1961, 'Food,Beverages & Tobacco
> Food Items > Dips & Spreads > Hummus', ''),
(1962, 'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Jams &
Jellies', ''),
(1963, 'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Nut Butters', ''),
(1964,
'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Salsa', ''),
(1965, 'Food,Beverages & Tobacco > Food Items >
Dips & Spreads > Tapenade', ''),
(1966, 'Food,Beverages & Tobacco > Food Items > Dips & Spreads > Vegetable Dip', ''),
(1967, 'Food,Beverages & Tobacco > Food Items > Food Gift Baskets', ''),
(1968, 'Food,Beverages & Tobacco > Food Items >
Frozen Desserts & Novelties > Ice Cream & Frozen Yogurt', ''),
(1969, 'Food,Beverages & Tobacco > Food Items > Frozen
Desserts & Novelties > Ice Cream Novelties', ''),
(1970, 'Food,Beverages & Tobacco > Food Items > Frozen Desserts &
Novelties > Ice Pops', ''),
(1971, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Canned & Jarred
Fruits', ''),
(1972, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Canned & Jarred Vegetables', ''),
(1973, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Canned & Prepared Beans', ''),
(1974,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Dried Fruits', ''),
(1975, 'Food,Beverages & Tobacco >
Food Items > Fruits & Vegetables > Dried Vegetables', ''),
(1976, 'Food,Beverages & Tobacco > Food Items > Fruits &
Vegetables > Dry Beans', ''),
(1977, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Fruits > Apples', ''),
(1978, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits >
Atemoyas', ''),
(1979, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Avocados',
''),
(1980, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Babacos', ''),
(1981,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Bananas', ''),
(1982,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Berries', ''),
(1983,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Breadfruit', ''),
(1984,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Cactus Pears', ''),
(1985,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Cherimoyas', ''),
(1986,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Citrus Fruits', ''),
(1987,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Citrus Fruits > Grapefruits',
''),
(1988, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Citrus Fruits >
Kumquats', ''),
(1989, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Citrus
Fruits > Lemons', ''),
(1990, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits >
Citrus Fruits > Limequats', ''),
(1991, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Fruits > Citrus Fruits > Limes', ''),
(1992, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Fruits > Citrus Fruits > Oranges', ''),
(1993, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables >
Fresh & Frozen Fruits > Citrus Fruits > Tangelos', ''),
(1994, 'Food,Beverages & Tobacco > Food Items > Fruits &
Vegetables > Fresh & Frozen Fruits > Coconuts', ''),
(1995, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables
> Fresh & Frozen Fruits > Dates', ''),
(1996, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Fruits > Feijoas', ''),
(1997, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Fruits > Figs', ''),
(1998, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Fruit
Mixes', ''),
(1999, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Grapes', ''),
(2000, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Guavas', ''),
(2001,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Homely Fruits', ''),
(2002,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Kiwis', ''),
(2003,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Longan', ''),
(2004,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Loquats', ''),
(2005,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Lychees', ''),
(2006,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Madro├▒o', ''),
(2007,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Mamey', ''),
(2008,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Mangosteens', ''),
(2009,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Melons', ''),
(2010,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Papayas', ''),
(2011,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Passion Fruit', ''),
(2012,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Pears', ''),
(2013,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Persimmons', ''),
(2014,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Physalis', ''),
(2015,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Pineapples', ''),
(2016,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Pitahayas', ''),
(2017,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Pomegranates', ''),
(2018,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Quince', ''),
(2019,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Rambutans', ''),
(2020,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Sapodillo', ''),
(2021,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Sapote', ''),
(2022,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Soursops', ''),
(2023,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Starfruits', ''),
(2024,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Stone Fruits', ''),
(2025,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Stone Fruits > Apricots', ''),
(2026, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Stone Fruits > Cherries',
''),
(2027, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Stone Fruits >
Mangoes', ''),
(2028, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Fruits > Stone
Fruits > Peaches & Nectarines', ''),
(2029, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Fruits > Stone Fruits > Plumcots', ''),
(2030, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables >
Fresh & Frozen Fruits > Stone Fruits > Plums', ''),
(2031, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables
> Fresh & Frozen Fruits > Sugar Apples', ''),
(2032, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables >
Fresh & Frozen Fruits > Tamarindo', ''),
(2033, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Arracachas', ''),
(2034, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Artichokes', ''),
(2035, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Asparagus', ''),
(2036, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Beans', ''),
(2037, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Beets', ''),
(2038, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Borage', ''),
(2039, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Broccoli', ''),
(2040, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Brussel Sprouts', ''),
(2041, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Cabbage', ''),
(2042, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Cactus Leaves', ''),
(2043, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Cardoon', ''),
(2044, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Carrots', ''),
(2045, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Cauliflower', ''),
(2046, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Celery', ''),
(2047, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Celery Roots', ''),
(2048, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Corn', ''),
(2049, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables
> Cucumbers', ''),
(2050, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Eggplants', ''),
(2051, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Fennel Bulbs', ''),
(2052, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Fiddlehead Ferns', ''),
(2053, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables
> Gai Choy', ''),
(2054, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Gai
Lan', ''),
(2055, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Garlic',
''),
(2056, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Ginger Root',
''),
(2057, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Gobo Root', ''),
(2058, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens', ''),
(2059,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens > Arugula', ''),
(2060, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens > Beet Greens',
''),
(2061, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens > Bok
Choy', ''),
(2062, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens >
Chard', ''),
(2063, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens >
Chicory', ''),
(2064, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Greens
> Choy Sum', ''),
(2065, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Greens > Kale', ''),
(2066, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Greens > Lettuce', ''),
(2067, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables
> Greens > On Choy', ''),
(2068, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Greens > Salad Mixes', ''),
(2069, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Greens > Spinach', ''),
(2070, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh
& Frozen Vegetables > Greens > Yu Choy', ''),
(2071, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables >
Fresh & Frozen Vegetables > Horseradish Root', ''),
(2072, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables
> Fresh & Frozen Vegetables > Jicama', ''),
(2073, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh
& Frozen Vegetables > Kohlrabi', ''),
(2074, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh &
Frozen Vegetables > Leeks', ''),
(2075, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Lotus Roots', ''),
(2076, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Malangas', ''),
(2077, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Mushrooms', ''),
(2078, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen
Vegetables > Okra', ''),
(2079, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables
> Onions', ''),
(2080, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Parsley Roots', ''),
(2081, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables >
Parsnips', ''),
(2082, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Peas',
''),
(2083, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Peppers', ''),
(2084, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Potatoes', ''),
(2085,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Radishes', ''),
(2086,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Rhubarb', ''),
(2087,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Shallots', ''),
(2088,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Sprouts', ''),
(2089,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Squashes & Gourds', ''),
(2090, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Sugar Cane', ''),
(2091, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Sunchokes', ''),
(2092, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Sweet Potatoes', ''),
(2093, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Tamarillos', ''),
(2094, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Taro Root', ''),
(2095, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Tomatoes', ''),
(2096,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Turnips & Rutabagas', ''),
(2097, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Vegetable Mixes', ''),
(2098, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Water Chestnuts', ''),
(2099, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Watercress', ''),
(2100, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Wheatgrass', ''),
(2101, 'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Yams', ''),
(2102,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fresh & Frozen Vegetables > Yuca Root', ''),
(2103,
'Food,Beverages & Tobacco > Food Items > Fruits & Vegetables > Fruit Sauces', ''),
(2104, 'Food,Beverages & Tobacco >
Food Items > Grains,Rice & Cereal > Amaranth', ''),
(2105, 'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal
> Barley', ''),
(2106, 'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal > Buckwheat', ''),
(2107,
'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal > Cereal & Granola', ''),
(2108, 'Food,Beverages & Tobacco
> Food Items > Grains,Rice & Cereal > Couscous', ''),
(2109, 'Food,Beverages & Tobacco > Food Items > Grains,Rice &
Cereal > Millet', ''),
(2110, 'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal > Oats,Grits & Hot Cereal',
''),
(2111, 'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal > Quinoa', ''),
(2112, 'Food,Beverages &
Tobacco > Food Items > Grains,Rice & Cereal > Rice', ''),
(2113, 'Food,Beverages & Tobacco > Food Items > Grains,Rice &
Cereal > Rye', ''),
(2114, 'Food,Beverages & Tobacco > Food Items > Grains,Rice & Cereal > Wheat', ''),
(2115,
'Food,Beverages & Tobacco > Food Items > Meat,Seafood & Eggs > Eggs', ''),
(2116, 'Food,Beverages & Tobacco > Food Items
> Meat,Seafood & Eggs > Meat > Canned Meats', ''),
(2117, 'Food,Beverages & Tobacco > Food Items > Meat,Seafood & Eggs >
Meat > Fresh & Frozen Meats', ''),
(2118, 'Food,Beverages & Tobacco > Food Items > Meat,Seafood & Eggs > Meat > Lunch &
Deli Meats', ''),
(2119, 'Food,Beverages & Tobacco > Food Items > Meat,Seafood & Eggs > Seafood > Canned Seafood', ''),
(2120, 'Food,Beverages & Tobacco > Food Items > Meat,Seafood & Eggs > Seafood > Fresh & Frozen Seafood', ''),
(2121,
'Food,Beverages & Tobacco > Food Items > Nuts & Seeds', ''),
(2122, 'Food,Beverages & Tobacco > Food Items > Pasta &
Noodles', ''),
(2123, 'Food,Beverages & Tobacco > Food Items > Prepared Foods > Prepared Appetizers & Side Dishes', ''),
(2124, 'Food,Beverages & Tobacco > Food Items > Seasonings & Spices', ''),
(2125, 'Food,Beverages & Tobacco > Food Items
> Seasonings & Spices > Herbs & Spices', ''),
(2126, 'Food,Beverages & Tobacco > Food Items > Seasonings & Spices >
MSG', ''),
(2127, 'Food,Beverages & Tobacco > Food Items > Seasonings & Spices > Pepper', ''),
(2128, 'Food,Beverages &
Tobacco > Food Items > Seasonings & Spices > Salt', ''),
(2129, 'Food,Beverages & Tobacco > Food Items > Snack Foods >
Breadsticks', ''),
(2130, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Cereal & Granola Bars', ''),
(2131,
'Food,Beverages & Tobacco > Food Items > Snack Foods > Cheese Puffs', ''),
(2132, 'Food,Beverages & Tobacco > Food Items
> Snack Foods > Chips', ''),
(2133, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Crackers', ''),
(2134,
'Food,Beverages & Tobacco > Food Items > Snack Foods > Croutons', ''),
(2135, 'Food,Beverages & Tobacco > Food Items >
Snack Foods > Fruit Snacks', ''),
(2136, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Jerky', ''),
(2137,
'Food,Beverages & Tobacco > Food Items > Snack Foods > Popcorn', ''),
(2138, 'Food,Beverages & Tobacco > Food Items >
Snack Foods > Pork Rinds', ''),
(2139, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Pretzels', ''),
(2140,
'Food,Beverages & Tobacco > Food Items > Snack Foods > Pudding & Gelatin Snacks', ''),
(2141, 'Food,Beverages & Tobacco
> Food Items > Snack Foods > Puffed Rice Cakes', ''),
(2142, 'Food,Beverages & Tobacco > Food Items > Snack Foods >
Salad Toppings', ''),
(2143, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Sesame Sticks', ''),
(2144,
'Food,Beverages & Tobacco > Food Items > Snack Foods > Snack Cakes', ''),
(2145, 'Food,Beverages & Tobacco > Food Items
> Snack Foods > Sticky Rice Cakes', ''),
(2146, 'Food,Beverages & Tobacco > Food Items > Snack Foods > Trail & Snack
Mixes', ''),
(2147, 'Food,Beverages & Tobacco > Food Items > Soups & Broths', ''),
(2148, 'Food,Beverages & Tobacco >
Food Items > Tofu,Soy & Vegetarian Products > Cheese Alternatives', ''),
(2149, 'Food,Beverages & Tobacco > Food Items >
Tofu,Soy & Vegetarian Products > Meat Alternatives', ''),
(2150, 'Food,Beverages & Tobacco > Food Items > Tofu,Soy &
Vegetarian Products > Seitan', ''),
(2151, 'Food,Beverages & Tobacco > Food Items > Tofu,Soy & Vegetarian Products >
Tempeh', ''),
(2152, 'Food,Beverages & Tobacco > Food Items > Tofu,Soy & Vegetarian Products > Tofu', ''),
(2153,
'Food,Beverages & Tobacco > Tobacco Products > Chewing Tobacco', ''),
(2154, 'Food,Beverages & Tobacco > Tobacco
Products > Cigarettes', ''),
(2155, 'Food,Beverages & Tobacco > Tobacco Products > Cigars', ''),
(2156, 'Food,Beverages
& Tobacco > Tobacco Products > Loose Tobacco', ''),
(2157, 'Food,Beverages & Tobacco > Tobacco Products > Smoking
Pipes', ''),
(2158, 'Food,Beverages & Tobacco > Tobacco Products > Vaporizers & Electronic Cigarettes', ''),
(2159,
'Furniture > Baby & Toddler Furniture > Baby & Toddler Furniture Sets', ''),
(2160, 'Furniture > Baby & Toddler
Furniture > Bassinet & Cradle Accessories', ''),
(2161, 'Furniture > Baby & Toddler Furniture > Bassinets & Cradles',
''),
(2162, 'Furniture > Baby & Toddler Furniture > Changing Tables', ''),
(2163, 'Furniture > Baby & Toddler Furniture
> Crib & Toddler Bed Accessories', ''),
(2164, 'Furniture > Baby & Toddler Furniture > Crib & Toddler Bed Accessories >
Crib Bumpers & Liners', ''),
(2165, 'Furniture > Baby & Toddler Furniture > Crib & Toddler Bed Accessories > Crib
Conversion Kits', ''),
(2166, 'Furniture > Baby & Toddler Furniture > Cribs & Toddler Beds', ''),
(2167, 'Furniture >
Baby & Toddler Furniture > High Chair & Booster Seat Accessories', ''),
(2168, 'Furniture > Baby & Toddler Furniture >
High Chairs & Booster Seats', ''),
(2169, 'Furniture > Beds & Accessories > Bed & Bed Frame Accessories', ''),
(2170,
'Furniture > Beds & Accessories > Beds & Bed Frames', ''),
(2171, 'Furniture > Beds & Accessories > Headboards &
Footboards', ''),
(2172, 'Furniture > Beds & Accessories > Mattress Foundations', ''),
(2173, 'Furniture > Beds &
Accessories > Mattresses', ''),
(2174, 'Furniture > Benches > Kitchen & Dining Benches', ''),
(2175, 'Furniture >
Benches > Storage & Entryway Benches', ''),
(2176, 'Furniture > Benches > Vanity Benches', ''),
(2177, 'Furniture >
Cabinets & Storage > Armoires & Wardrobes', ''),
(2178, 'Furniture > Cabinets & Storage > Buffets & Sideboards', ''),
(2179, 'Furniture > Cabinets & Storage > China Cabinets & Hutches', ''),
(2180, 'Furniture > Cabinets & Storage >
Dressers', ''),
(2181, 'Furniture > Cabinets & Storage > File Cabinets', ''),
(2182, 'Furniture > Cabinets & Storage >
Ironing Centers', ''),
(2183, 'Furniture > Cabinets & Storage > Kitchen Cabinets', ''),
(2184, 'Furniture > Cabinets &
Storage > Magazine Racks', ''),
(2185, 'Furniture > Cabinets & Storage > Media Storage Cabinets & Racks', ''),
(2186,
'Furniture > Cabinets & Storage > Storage Cabinets & Lockers', ''),
(2187, 'Furniture > Cabinets & Storage > Storage
Chests', ''),
(2188, 'Furniture > Cabinets & Storage > Storage Chests > Hope Chests', ''),
(2189, 'Furniture > Cabinets
& Storage > Storage Chests > Toy Chests', ''),
(2190, 'Furniture > Cabinets & Storage > Vanities', ''),
(2191,
'Furniture > Cabinets & Storage > Vanities > Bathroom Vanities', ''),
(2192, 'Furniture > Cabinets & Storage > Vanities
> Bedroom Vanities', ''),
(2193, 'Furniture > Cabinets & Storage > Wine & Liquor Cabinets', ''),
(2194, 'Furniture >
Cabinets & Storage > Wine Racks', ''),
(2195, 'Furniture > Carts & Islands > Kitchen & Dining Carts', ''),
(2196,
'Furniture > Carts & Islands > Kitchen Islands', ''),
(2197, 'Furniture > Chair Accessories', ''),
(2198, 'Furniture >
Chair Accessories > Hanging Chair Replacement Parts', ''),
(2199, 'Furniture > Chairs > Arm Chairs,Recliners & Sleeper
Chairs', ''),
(2200, 'Furniture > Chairs > Bean Bag Chairs', ''),
(2201, 'Furniture > Chairs > Chaises', ''),
(2202,
'Furniture > Chairs > Electric Massaging Chairs', ''),
(2203, 'Furniture > Chairs > Floor Chairs', ''),
(2204,
'Furniture > Chairs > Folding Chairs & Stools', ''),
(2205, 'Furniture > Chairs > Gaming Chairs', ''),
(2206, 'Furniture
> Chairs > Hanging Chairs', ''),
(2207, 'Furniture > Chairs > Kitchen & Dining Room Chairs', ''),
(2208, 'Furniture >
Chairs > Rocking Chairs', ''),
(2209, 'Furniture > Chairs > Slipper Chairs', ''),
(2210, 'Furniture > Chairs > Table &
Bar Stools', ''),
(2211, 'Furniture > Entertainment Centers & TV Stands', ''),
(2212, 'Furniture > Furniture Sets >
Bathroom Furniture Sets', ''),
(2213, 'Furniture > Furniture Sets > Bedroom Furniture Sets', ''),
(2214, 'Furniture >
Furniture Sets > Kitchen & Dining Furniture Sets', ''),
(2215, 'Furniture > Furniture Sets > Living Room Furniture
Sets', ''),
(2216, 'Furniture > Futon Frames', ''),
(2217, 'Furniture > Futon Pads', ''),
(2218, 'Furniture > Futons',
''),
(2219, 'Furniture > Office Furniture > Desks', ''),
(2220, 'Furniture > Office Furniture > Office Chairs', ''),
(2221, 'Furniture > Office Furniture > Office Furniture Sets', ''),
(2222, 'Furniture > Office Furniture > Workspace
Tables', ''),
(2223, 'Furniture > Office Furniture > Workspace Tables > Art & Drafting Tables', ''),
(2224, 'Furniture >
Office Furniture > Workspace Tables > Conference Room Tables', ''),
(2225, 'Furniture > Office Furniture > Workstations
& Cubicles', ''),
(2226, 'Furniture > Office Furniture Accessories > Desk Parts & Accessories', ''),
(2227, 'Furniture >
Office Furniture Accessories > Office Chair Accessories', ''),
(2228, 'Furniture > Office Furniture Accessories >
Workstation & Cubicle Accessories', ''),
(2229, 'Furniture > Ottomans', ''),
(2230, 'Furniture > Outdoor Furniture >
Outdoor Beds', ''),
(2231, 'Furniture > Outdoor Furniture > Outdoor Furniture Sets', ''),
(2232, 'Furniture > Outdoor
Furniture > Outdoor Ottomans', ''),
(2233, 'Furniture > Outdoor Furniture > Outdoor Seating > Outdoor Benches', ''),
(2234, 'Furniture > Outdoor Furniture > Outdoor Seating > Outdoor Chairs', ''),
(2235, 'Furniture > Outdoor Furniture >
Outdoor Seating > Outdoor Sectional Sofa Units', ''),
(2236, 'Furniture > Outdoor Furniture > Outdoor Seating > Outdoor
Sofas', ''),
(2237, 'Furniture > Outdoor Furniture > Outdoor Seating > Sunloungers', ''),
(2238, 'Furniture > Outdoor
Furniture > Outdoor Storage Boxes', ''),
(2239, 'Furniture > Outdoor Furniture > Outdoor Tables', ''),
(2240, 'Furniture
> Outdoor Furniture Accessories', ''),
(2241, 'Furniture > Outdoor Furniture Accessories > Outdoor Furniture Covers',
''),
(2242, 'Furniture > Room Divider Accessories', ''),
(2243, 'Furniture > Room Dividers', ''),
(2244, 'Furniture >
Shelving > Bookcases & Standing Shelves', ''),
(2245, 'Furniture > Shelving > Wall Shelves & Ledges', ''),
(2246,
'Furniture > Shelving Accessories', ''),
(2247, 'Furniture > Shelving Accessories > Replacement Shelves', ''),
(2248,
'Furniture > Sofa Accessories', ''),
(2249, 'Furniture > Sofa Accessories > Chair & Sofa Supports', ''),
(2250,
'Furniture > Sofa Accessories > Sectional Sofa Units', ''),
(2251, 'Furniture > Sofas', ''),
(2252, 'Furniture > Table
Accessories', ''),
(2253, 'Furniture > Table Accessories > Table Legs', ''),
(2254, 'Furniture > Table Accessories >
Table Tops', ''),
(2255, 'Furniture > Tables > Accent Tables', ''),
(2256, 'Furniture > Tables > Accent Tables > Coffee
Tables', ''),
(2257, 'Furniture > Tables > Accent Tables > End Tables', ''),
(2258, 'Furniture > Tables > Accent Tables
> Sofa Tables', ''),
(2259, 'Furniture > Tables > Activity Tables', ''),
(2260, 'Furniture > Tables > Folding Tables',
'');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (2261,
'Furniture > Tables > Kitchen & Dining Room Tables', ''),
(2262, 'Furniture > Tables > Kotatsu', ''),
(2263, 'Furniture
> Tables > Nightstands', ''),
(2264, 'Furniture > Tables > Poker & Game Tables', ''),
(2265, 'Furniture > Tables >
Sewing Machine Tables', ''),
(2266, 'Hardware > Building Consumables > Chemicals > Acid Neutralizers', ''),
(2267,
'Hardware > Building Consumables > Chemicals > Ammonia', ''),
(2268, 'Hardware > Building Consumables > Chemicals >
Chimney Cleaners', ''),
(2269, 'Hardware > Building Consumables > Chemicals > Concrete & Masonry Cleaners', ''),
(2270,
'Hardware > Building Consumables > Chemicals > De-icers', ''),
(2271, 'Hardware > Building Consumables > Chemicals >
Deck & Fence Cleaners', ''),
(2272, 'Hardware > Building Consumables > Chemicals > Drain Cleaners', ''),
(2273,
'Hardware > Building Consumables > Chemicals > Electrical Freeze Sprays', ''),
(2274, 'Hardware > Building Consumables >
Chemicals > Lighter Fluid', ''),
(2275, 'Hardware > Building Consumables > Chemicals > Septic Tank & Cesspool
Treatments', ''),
(2276, 'Hardware > Building Consumables > Hardware Glue & Adhesives', ''),
(2277, 'Hardware > Building
Consumables > Hardware Tape', ''),
(2278, 'Hardware > Building Consumables > Lubricants', ''),
(2279, 'Hardware >
Building Consumables > Masonry Consumables > Bricks & Concrete Blocks', ''),
(2280, 'Hardware > Building Consumables >
Masonry Consumables > Cement,Mortar & Concrete Mixes', ''),
(2281, 'Hardware > Building Consumables > Masonry
Consumables > Grout', ''),
(2282, 'Hardware > Building Consumables > Painting Consumables > Paint', ''),
(2283,
'Hardware > Building Consumables > Painting Consumables > Paint Binders', ''),
(2284, 'Hardware > Building Consumables >
Painting Consumables > Primers', ''),
(2285, 'Hardware > Building Consumables > Painting Consumables > Stains', ''),
(2286, 'Hardware > Building Consumables > Painting Consumables > Varnishes & Finishes', ''),
(2287, 'Hardware > Building
Consumables > Plumbing Primer', ''),
(2288, 'Hardware > Building Consumables > Protective Coatings & Sealants', ''),
(2289, 'Hardware > Building Consumables > Solder & Flux', ''),
(2290, 'Hardware > Building Consumables >
Solvents,Strippers & Thinners', ''),
(2291, 'Hardware > Building Consumables > Wall Patching Compounds & Plaster', ''),
(2292, 'Hardware > Building Materials > Countertops', ''),
(2293, 'Hardware > Building Materials > Door Hardware > Door
Bells & Chimes', ''),
(2294, 'Hardware > Building Materials > Door Hardware > Door Closers', ''),
(2295, 'Hardware >
Building Materials > Door Hardware > Door Frames', ''),
(2296, 'Hardware > Building Materials > Door Hardware > Door
Keyhole Escutcheons', ''),
(2297, 'Hardware > Building Materials > Door Hardware > Door Knobs & Handles', ''),
(2298,
'Hardware > Building Materials > Door Hardware > Door Knockers', ''),
(2299, 'Hardware > Building Materials > Door
Hardware > Door Push Plates', ''),
(2300, 'Hardware > Building Materials > Door Hardware > Door Stops', ''),
(2301,
'Hardware > Building Materials > Door Hardware > Door Strikes', ''),
(2302, 'Hardware > Building Materials > Doors >
Garage Doors', ''),
(2303, 'Hardware > Building Materials > Doors > Home Doors', ''),
(2304, 'Hardware > Building
Materials > Drywall', ''),
(2305, 'Hardware > Building Materials > Flooring & Carpet', ''),
(2306, 'Hardware > Building
Materials > Glass', ''),
(2307, 'Hardware > Building Materials > Handrails & Railing Systems', ''),
(2308, 'Hardware >
Building Materials > Hatches', ''),
(2309, 'Hardware > Building Materials > Insulation', ''),
(2310, 'Hardware >
Building Materials > Lumber & Sheet Stock', ''),
(2311, 'Hardware > Building Materials > Molding', ''),
(2312, 'Hardware
> Building Materials > Rebar & Remesh', ''),
(2313, 'Hardware > Building Materials > Roofing > Gutter Accessories', ''),
(2314, 'Hardware > Building Materials > Roofing > Gutters', ''),
(2315, 'Hardware > Building Materials > Roofing > Roof
Flashings', ''),
(2316, 'Hardware > Building Materials > Roofing > Roofing Shingles & Tiles', ''),
(2317, 'Hardware >
Building Materials > Shutters', ''),
(2318, 'Hardware > Building Materials > Siding', ''),
(2319, 'Hardware > Building
Materials > Sound Dampening Panels & Foam', ''),
(2320, 'Hardware > Building Materials > Staircases', ''),
(2321,
'Hardware > Building Materials > Wall & Ceiling Tile', ''),
(2322, 'Hardware > Building Materials > Wall Paneling', ''),
(2323, 'Hardware > Building Materials > Weather Stripping & Weatherization Supplies', ''),
(2324, 'Hardware > Building
Materials > Window Hardware', ''),
(2325, 'Hardware > Building Materials > Window Hardware > Window Cranks', ''),
(2326,
'Hardware > Building Materials > Window Hardware > Window Frames', ''),
(2327, 'Hardware > Building Materials >
Windows', ''),
(2328, 'Hardware > Fencing & Barriers > Fence & Gate Accessories', ''),
(2329, 'Hardware > Fencing &
Barriers > Fence Panels', ''),
(2330, 'Hardware > Fencing & Barriers > Fence Pickets', ''),
(2331, 'Hardware > Fencing &
Barriers > Fence Posts & Rails', ''),
(2332, 'Hardware > Fencing & Barriers > Garden Borders & Edging', ''),
(2333,
'Hardware > Fencing & Barriers > Gates', ''),
(2334, 'Hardware > Fencing & Barriers > Lattice', ''),
(2335, 'Hardware >
Fencing & Barriers > Safety & Crowd Control Barriers', ''),
(2336, 'Hardware > Fuel Containers & Tanks', ''),
(2337,
'Hardware > Hardware Accessories > Brackets & Reinforcement Braces', ''),
(2338, 'Hardware > Hardware Accessories >
Cabinet Hardware > Cabinet & Furniture Keyhole Escutcheons', ''),
(2339, 'Hardware > Hardware Accessories > Cabinet
Hardware > Cabinet Backplates', ''),
(2340, 'Hardware > Hardware Accessories > Cabinet Hardware > Cabinet Catches', ''),
(2341, 'Hardware > Hardware Accessories > Cabinet Hardware > Cabinet Doors', ''),
(2342, 'Hardware > Hardware
Accessories > Cabinet Hardware > Cabinet Knobs & Handles', ''),
(2343, 'Hardware > Hardware Accessories > Casters', ''),
(2344, 'Hardware > Hardware Accessories > Chain,Wire & Rope > Bungee Cords', ''),
(2345, 'Hardware > Hardware
Accessories > Chain,Wire & Rope > Chains', ''),
(2346, 'Hardware > Hardware Accessories > Chain,Wire & Rope > Pull
Chains', ''),
(2347, 'Hardware > Hardware Accessories > Chain,Wire & Rope > Ropes & Hardware Cable', ''),
(2348,
'Hardware > Hardware Accessories > Chain,Wire & Rope > Tie Down Straps', ''),
(2349, 'Hardware > Hardware Accessories >
Chain,Wire & Rope > Twine', ''),
(2350, 'Hardware > Hardware Accessories > Chain,Wire & Rope > Utility Wire', ''),
(2351, 'Hardware > Hardware Accessories > Coils', ''),
(2352, 'Hardware > Hardware Accessories > Concrete Molds', ''),
(2353, 'Hardware > Hardware Accessories > Dowel Pins & Rods', ''),
(2354, 'Hardware > Hardware Accessories > Drawer
Slides', ''),
(2355, 'Hardware > Hardware Accessories > Drop Cloths', ''),
(2356, 'Hardware > Hardware Accessories >
Filters & Screens', ''),
(2357, 'Hardware > Hardware Accessories > Flagging & Caution Tape', ''),
(2358, 'Hardware >
Hardware Accessories > Gas Hoses', ''),
(2359, 'Hardware > Hardware Accessories > Ground Spikes', ''),
(2360, 'Hardware
> Hardware Accessories > Hardware Fasteners > Drywall Anchors', ''),
(2361, 'Hardware > Hardware Accessories > Hardware
Fasteners > Nails', ''),
(2362, 'Hardware > Hardware Accessories > Hardware Fasteners > Nuts & Bolts', ''),
(2363,
'Hardware > Hardware Accessories > Hardware Fasteners > Rivets', ''),
(2364, 'Hardware > Hardware Accessories > Hardware
Fasteners > Screw Posts', ''),
(2365, 'Hardware > Hardware Accessories > Hardware Fasteners > Screws', ''),
(2366,
'Hardware > Hardware Accessories > Hardware Fasteners > Threaded Rods', ''),
(2367, 'Hardware > Hardware Accessories >
Hardware Fasteners > Washers', ''),
(2368, 'Hardware > Hardware Accessories > Hinges', ''),
(2369, 'Hardware > Hardware
Accessories > Hooks,Buckles & Fasteners > Chain Connectors & Links', ''),
(2370, 'Hardware > Hardware Accessories >
Hooks,Buckles & Fasteners > Gear Ties', ''),
(2371, 'Hardware > Hardware Accessories > Hooks,Buckles & Fasteners >
Lifting Hooks,Clamps & Shackles', ''),
(2372, 'Hardware > Hardware Accessories > Hooks,Buckles & Fasteners > Utility
Buckles', ''),
(2373, 'Hardware > Hardware Accessories > Lubrication Hoses', ''),
(2374, 'Hardware > Hardware
Accessories > Metal Casting Molds', ''),
(2375, 'Hardware > Hardware Accessories > Moving & Soundproofing Blankets &
Covers', ''),
(2376, 'Hardware > Hardware Accessories > Pneumatic Hoses', ''),
(2377, 'Hardware > Hardware Accessories >
Post Base Plates', ''),
(2378, 'Hardware > Hardware Accessories > Springs', ''),
(2379, 'Hardware > Hardware Accessories
> Tarps', ''),
(2380, 'Hardware > Hardware Accessories > Tool Storage & Organization > Garden Hose Storage', ''),
(2381,
'Hardware > Hardware Accessories > Tool Storage & Organization > Tool & Equipment Belts', ''),
(2382, 'Hardware >
Hardware Accessories > Tool Storage & Organization > Tool Bags', ''),
(2383, 'Hardware > Hardware Accessories > Tool
Storage & Organization > Tool Boxes', ''),
(2384, 'Hardware > Hardware Accessories > Tool Storage & Organization > Tool
Cabinets & Chests', ''),
(2385, 'Hardware > Hardware Accessories > Tool Storage & Organization > Tool Organizer Liners &
Inserts', ''),
(2386, 'Hardware > Hardware Accessories > Tool Storage & Organization > Tool Sheaths', ''),
(2387,
'Hardware > Hardware Accessories > Tool Storage & Organization > Work Benches', ''),
(2388, 'Hardware > Hardware
Accessories > Wall Jacks & Braces', ''),
(2389, 'Hardware > Hardware Pumps > Home Appliance Pumps', ''),
(2390,
'Hardware > Hardware Pumps > Pool,Fountain & Pond Pumps', ''),
(2391, 'Hardware > Hardware Pumps > Sprinkler,Booster &
Irrigation System Pumps', ''),
(2392, 'Hardware > Hardware Pumps > Sump,Sewage & Effluent Pumps', ''),
(2393, 'Hardware
> Hardware Pumps > Utility Pumps', ''),
(2394, 'Hardware > Hardware Pumps > Well Pumps & Systems', ''),
(2395, 'Hardware
> Heating,Ventilation & Air Conditioning > Air & Filter Dryers', ''),
(2396, 'Hardware > Heating,Ventilation & Air
Conditioning > Air Ducts', ''),
(2397, 'Hardware > Heating,Ventilation & Air Conditioning > HVAC Controls', ''),
(2398,
'Hardware > Heating,Ventilation & Air Conditioning > HVAC Controls > Control Panels', ''),
(2399, 'Hardware >
Heating,Ventilation & Air Conditioning > HVAC Controls > Humidistats', ''),
(2400, 'Hardware > Heating,Ventilation & Air
Conditioning > HVAC Controls > Thermostats', ''),
(2401, 'Hardware > Heating,Ventilation & Air Conditioning > Vents &
Flues', ''),
(2402, 'Hardware > Locks & Keys > Key Blanks', ''),
(2403, 'Hardware > Locks & Keys > Key Caps', ''),
(2404, 'Hardware > Locks & Keys > Key Card Entry Systems', ''),
(2405, 'Hardware > Locks & Keys > Locks & Latches', ''),
(2406, 'Hardware > Plumbing > Plumbing Fittings & Supports > Gaskets & O-Rings', ''),
(2407, 'Hardware > Plumbing >
Plumbing Fittings & Supports > In-Wall Carriers & Mounting Frames', ''),
(2408, 'Hardware > Plumbing > Plumbing Fittings
& Supports > Nozzles', ''),
(2409, 'Hardware > Plumbing > Plumbing Fittings & Supports > Pipe Adapters & Bushings', ''),
(2410, 'Hardware > Plumbing > Plumbing Fittings & Supports > Pipe Caps & Plugs', ''),
(2411, 'Hardware > Plumbing >
Plumbing Fittings & Supports > Pipe Connectors', ''),
(2412, 'Hardware > Plumbing > Plumbing Fittings & Supports >
Plumbing Flanges', ''),
(2413, 'Hardware > Plumbing > Plumbing Fittings & Supports > Plumbing Pipe Clamps', ''),
(2414,
'Hardware > Plumbing > Plumbing Fittings & Supports > Plumbing Regulators', ''),
(2415, 'Hardware > Plumbing > Plumbing
Fittings & Supports > Plumbing Valves', ''),
(2416, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Bathtub
Accessories > Bathtub Bases & Feet', ''),
(2417, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Bathtub
Accessories > Bathtub Skirts', ''),
(2418, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Bathtub
Accessories > Bathtub Spouts', ''),
(2419, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Drain Components >
Drain Covers & Strainers', ''),
(2420, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Drain Components >
Drain Frames', ''),
(2421, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Drain Components > Drain Liners',
''),
(2422, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Drain Components > Drain Openers', ''),
(2423,
'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Drain Components > Drain Rods', ''),
(2424, 'Hardware >
Plumbing > Plumbing Fixture Hardware & Parts > Drain Components > Plumbing Traps', ''),
(2425, 'Hardware > Plumbing >
Plumbing Fixture Hardware & Parts > Drain Components > Plumbing Wastes', ''),
(2426, 'Hardware > Plumbing > Plumbing
Fixture Hardware & Parts > Drains', ''),
(2427, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Faucet
Accessories > Faucet Aerators', ''),
(2428, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Faucet
Accessories > Faucet Handles & Controls', ''),
(2429, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Fixture
Plates', ''),
(2430, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Shower Parts > Bathtub & Shower Jets',
''),
(2431, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Shower Parts > Electric & Power Showers', ''),
(2432, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Shower Parts > Shower Arms & Connectors', ''),
(2433,
'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Shower Parts > Shower Bases', ''),
(2434, 'Hardware >
Plumbing > Plumbing Fixture Hardware & Parts > Shower Parts > Shower Columns', ''),
(2435, 'Hardware > Plumbing >
Plumbing Fixture Hardware & Parts > Shower Parts > Shower Doors & Enclosures', ''),
(2436, 'Hardware > Plumbing >
Plumbing Fixture Hardware & Parts > Shower Parts > Shower Heads', ''),
(2437, 'Hardware > Plumbing > Plumbing Fixture
Hardware & Parts > Shower Parts > Shower Walls & Surrounds', ''),
(2438, 'Hardware > Plumbing > Plumbing Fixture
Hardware & Parts > Shower Parts > Shower Water Filters', ''),
(2439, 'Hardware > Plumbing > Plumbing Fixture Hardware &
Parts > Sink Accessories', ''),
(2440, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Sink Accessories >
Sink Legs', ''),
(2441, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Toilet & Bidet Accessories >
Ballcocks & Flappers', ''),
(2442, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Toilet & Bidet Accessories
> Bidet Faucets & Sprayers', ''),
(2443, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Toilet & Bidet
Accessories > Toilet & Bidet Seats', ''),
(2444, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Toilet &
Bidet Accessories > Toilet Seat Covers', ''),
(2445, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts > Toilet &
Bidet Accessories > Toilet Seat Lid Covers', ''),
(2446, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts >
Toilet & Bidet Accessories > Toilet Tank Covers', ''),
(2447, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts >
Toilet & Bidet Accessories > Toilet Tank Levers', ''),
(2448, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts >
Toilet & Bidet Accessories > Toilet Tanks', ''),
(2449, 'Hardware > Plumbing > Plumbing Fixture Hardware & Parts >
Toilet & Bidet Accessories > Toilet Trim', ''),
(2450, 'Hardware > Plumbing > Plumbing Fixtures > Bathroom Suites', ''),
(2451, 'Hardware > Plumbing > Plumbing Fixtures > Bathtubs', ''),
(2452, 'Hardware > Plumbing > Plumbing Fixtures >
Faucets', ''),
(2453, 'Hardware > Plumbing > Plumbing Fixtures > Shower Stalls & Kits', ''),
(2454, 'Hardware > Plumbing
> Plumbing Fixtures > Sinks > Bathroom Sinks', ''),
(2455, 'Hardware > Plumbing > Plumbing Fixtures > Sinks > Kitchen &
Utility Sinks', ''),
(2456, 'Hardware > Plumbing > Plumbing Fixtures > Toilets & Bidets > Bidets', ''),
(2457, 'Hardware
> Plumbing > Plumbing Fixtures > Toilets & Bidets > Toilets', ''),
(2458, 'Hardware > Plumbing > Plumbing Fixtures >
Toilets & Bidets > Urinals', ''),
(2459, 'Hardware > Plumbing > Plumbing Hoses & Supply Lines', ''),
(2460, 'Hardware >
Plumbing > Plumbing Pipes', ''),
(2461, 'Hardware > Plumbing > Plumbing Repair Kits', ''),
(2462, 'Hardware > Plumbing >
Water Dispensing & Filtration > In-Line Water Filters', ''),
(2463, 'Hardware > Plumbing > Water Dispensing & Filtration
> Water Dispensers > Drinking Fountains', ''),
(2464, 'Hardware > Plumbing > Water Dispensing & Filtration > Water
Dispensers > Water Chillers', ''),
(2465, 'Hardware > Plumbing > Water Dispensing & Filtration > Water Distillers', ''),
(2466, 'Hardware > Plumbing > Water Dispensing & Filtration > Water Filtration Accessories', ''),
(2467, 'Hardware >
Plumbing > Water Dispensing & Filtration > Water Filtration Accessories > Water Filter Cartridges', ''),
(2468,
'Hardware > Plumbing > Water Dispensing & Filtration > Water Filtration Accessories > Water Filter Housings', ''),
(2469, 'Hardware > Plumbing > Water Dispensing & Filtration > Water Softener Salt', ''),
(2470, 'Hardware > Plumbing >
Water Dispensing & Filtration > Water Softeners', ''),
(2471, 'Hardware > Plumbing > Water Levelers', ''),
(2472,
'Hardware > Plumbing > Water Timers', ''),
(2473, 'Hardware > Plumbing > Well Supplies', ''),
(2474, 'Hardware > Power &
Electrical Supplies > Armatures,Rotors & Stators', ''),
(2475, 'Hardware > Power & Electrical Supplies > Ballasts &
Starters', ''),
(2476, 'Hardware > Power & Electrical Supplies > Carbon Brushes', ''),
(2477, 'Hardware > Power &
Electrical Supplies > Circuit Breaker Panels', ''),
(2478, 'Hardware > Power & Electrical Supplies > Conduit &
Housings', ''),
(2479, 'Hardware > Power & Electrical Supplies > Conduit & Housings > Electrical Conduit', ''),
(2480,
'Hardware > Power & Electrical Supplies > Conduit & Housings > Heat-Shrink Tubing', ''),
(2481, 'Hardware > Power &
Electrical Supplies > Electrical Motors', ''),
(2482, 'Hardware > Power & Electrical Supplies > Electrical Mount Boxes &
Brackets', ''),
(2483, 'Hardware > Power & Electrical Supplies > Electrical Plug Caps', ''),
(2484, 'Hardware > Power &
Electrical Supplies > Electrical Switches', ''),
(2485, 'Hardware > Power & Electrical Supplies > Electrical Switches >
Light Switches', ''),
(2486, 'Hardware > Power & Electrical Supplies > Electrical Switches > Specialty Electrical
Switches & Relays', ''),
(2487, 'Hardware > Power & Electrical Supplies > Electrical Wires & Cable', ''),
(2488,
'Hardware > Power & Electrical Supplies > Extension Cord Accessories', ''),
(2489, 'Hardware > Power & Electrical
Supplies > Extension Cords', ''),
(2490, 'Hardware > Power & Electrical Supplies > Generator Accessories', ''),
(2491,
'Hardware > Power & Electrical Supplies > Generators', ''),
(2492, 'Hardware > Power & Electrical Supplies > Home
Automation Kits', ''),
(2493, 'Hardware > Power & Electrical Supplies > Phone & Data Jacks', ''),
(2494, 'Hardware >
Power & Electrical Supplies > Power Converters', ''),
(2495, 'Hardware > Power & Electrical Supplies > Power Inlets',
''),
(2496, 'Hardware > Power & Electrical Supplies > Power Inverters', ''),
(2497, 'Hardware > Power & Electrical
Supplies > Power Outlets & Sockets', ''),
(2498, 'Hardware > Power & Electrical Supplies > Solar Energy Kits', ''),
(2499, 'Hardware > Power & Electrical Supplies > Solar Panels', ''),
(2500, 'Hardware > Power & Electrical Supplies >
Voltage Transformers & Regulators', ''),
(2501, 'Hardware > Power & Electrical Supplies > Wall Plates & Covers', ''),
(2502, 'Hardware > Power & Electrical Supplies > Wall Socket Controls & Sensors', ''),
(2503, 'Hardware > Power &
Electrical Supplies > Wire Caps & Nuts', ''),
(2504, 'Hardware > Power & Electrical Supplies > Wire Terminals &
Connectors', ''),
(2505, 'Hardware > Small Engines', ''),
(2506, 'Hardware > Storage Tanks', ''),
(2507, 'Hardware >
Tool Accessories > Abrasive Blaster Accessories', ''),
(2508, 'Hardware > Tool Accessories > Abrasive Blaster
Accessories > Sandblasting Cabinets', ''),
(2509, 'Hardware > Tool Accessories > Axe Accessories > Axe Handles', ''),
(2510, 'Hardware > Tool Accessories > Axe Accessories > Axe Heads', ''),
(2511, 'Hardware > Tool Accessories > Cutter
Accessories', ''),
(2512, 'Hardware > Tool Accessories > Cutter Accessories > Nibbler Dies', ''),
(2513, 'Hardware >
Tool Accessories > Drill & Screwdriver Accessories > Drill & Screwdriver Bits', ''),
(2514, 'Hardware > Tool Accessories
> Drill & Screwdriver Accessories > Drill Bit Extensions', ''),
(2515, 'Hardware > Tool Accessories > Drill &
Screwdriver Accessories > Drill Bit Sharpeners', ''),
(2516, 'Hardware > Tool Accessories > Drill & Screwdriver
Accessories > Drill Chucks', ''),
(2517, 'Hardware > Tool Accessories > Drill & Screwdriver Accessories > Drill Stands &
Guides', ''),
(2518, 'Hardware > Tool Accessories > Drill & Screwdriver Accessories > Hole Saws', ''),
(2519, 'Hardware
> Tool Accessories > Driver Accessories', ''),
(2520, 'Hardware > Tool Accessories > Flashlight Accessories', ''),
(2521, 'Hardware > Tool Accessories > Grinder Accessories', ''),
(2522, 'Hardware > Tool Accessories > Grinder
Accessories > Grinding Wheels & Points', ''),
(2523, 'Hardware > Tool Accessories > Hammer Accessories > Air Hammer
Accessories', ''),
(2524, 'Hardware > Tool Accessories > Hammer Accessories > Hammer Handles', ''),
(2525, 'Hardware >
Tool Accessories > Hammer Accessories > Hammer Heads', ''),
(2526, 'Hardware > Tool Accessories > Industrial Staples',
''),
(2527, 'Hardware > Tool Accessories > Jigs', ''),
(2528, 'Hardware > Tool Accessories > Magnetizers &
Demagnetizers', ''),
(2529, 'Hardware > Tool Accessories > Mattock & Pickaxe Accessories', ''),
(2530, 'Hardware > Tool
Accessories > Mattock & Pickaxe Accessories > Mattock & Pickaxe Handles', ''),
(2531, 'Hardware > Tool Accessories >
Measuring Tool & Sensor Accessories > Electrical Testing Tool Accessories', ''),
(2532, 'Hardware > Tool Accessories >
Measuring Tool & Sensor Accessories > Gas Detector Accessories', ''),
(2533, 'Hardware > Tool Accessories > Measuring
Tool & Sensor Accessories > Measuring Scale Accessories', ''),
(2534, 'Hardware > Tool Accessories > Measuring Tool &
Sensor Accessories > Multimeter Accessories', ''),
(2535, 'Hardware > Tool Accessories > Mixing Tool Paddles', ''),
(2536, 'Hardware > Tool Accessories > Paint Tool Accessories > Airbrush Accessories', ''),
(2537, 'Hardware > Tool
Accessories > Paint Tool Accessories > Paint Brush Cleaning Solutions', ''),
(2538, 'Hardware > Tool Accessories > Paint
Tool Accessories > Paint Roller Accessories', ''),
(2539, 'Hardware > Tool Accessories > Power Tool Batteries', ''),
(2540, 'Hardware > Tool Accessories > Power Tool Chargers', ''),
(2541, 'Hardware > Tool Accessories > Router
Accessories > Router Bits', ''),
(2542, 'Hardware > Tool Accessories > Router Accessories > Router Tables', ''),
(2543,
'Hardware > Tool Accessories > Sanding Accessories', ''),
(2544, 'Hardware > Tool Accessories > Sanding Accessories >
Sandpaper & Sanding Sponges', ''),
(2545, 'Hardware > Tool Accessories > Saw Accessories > Band Saw Accessories', ''),
(2546, 'Hardware > Tool Accessories > Saw Accessories > Handheld Circular Saw Accessories', ''),
(2547, 'Hardware > Tool
Accessories > Saw Accessories > Jigsaw Accessories', ''),
(2548, 'Hardware > Tool Accessories > Saw Accessories > Miter
Saw Accessories', ''),
(2549, 'Hardware > Tool Accessories > Saw Accessories > Table Saw Accessories', ''),
(2550,
'Hardware > Tool Accessories > Shaper Accessories', ''),
(2551, 'Hardware > Tool Accessories > Shaper Accessories >
Shaper Cutters', ''),
(2552, 'Hardware > Tool Accessories > Soldering Iron Accessories > Soldering Iron Stands', ''),
(2553, 'Hardware > Tool Accessories > Soldering Iron Accessories > Soldering Iron Tips', ''),
(2554, 'Hardware > Tool
Accessories > Tool Blades > Cutter & Scraper Blades', ''),
(2555, 'Hardware > Tool Accessories > Tool Blades > Saw
Blades', ''),
(2556, 'Hardware > Tool Accessories > Tool Handle Wedges', ''),
(2557, 'Hardware > Tool Accessories > Tool
Safety Tethers', ''),
(2558, 'Hardware > Tool Accessories > Tool Sockets', ''),
(2559, 'Hardware > Tool Accessories >
Tool Stands', ''),
(2560, 'Hardware > Tool Accessories > Tool Stands > Saw Stands', ''),
(2561, 'Hardware > Tool
Accessories > Wedge Tools', ''),
(2562, 'Hardware > Tool Accessories > Welding Accessories', ''),
(2563, 'Hardware >
Tools > Abrasive Blasters', ''),
(2564, 'Hardware > Tools > Anvils', ''),
(2565, 'Hardware > Tools > Axes', ''),
(2566,
'Hardware > Tools > Carpentry Jointers', ''),
(2567, 'Hardware > Tools > Carving Chisels & Gouges', ''),
(2568,
'Hardware > Tools > Caulking Tools', ''),
(2569, 'Hardware > Tools > Chimney Brushes', ''),
(2570, 'Hardware > Tools >
Compactors', ''),
(2571, 'Hardware > Tools > Compressors', ''),
(2572, 'Hardware > Tools > Concrete Brooms', ''),
(2573,
'Hardware > Tools > Cutters > Bolt Cutters', ''),
(2574, 'Hardware > Tools > Cutters > Glass Cutters', ''),
(2575,
'Hardware > Tools > Cutters > Handheld Metal Shears & Nibblers', ''),
(2576, 'Hardware > Tools > Cutters > Nippers',
''),
(2577, 'Hardware > Tools > Cutters > Pipe Cutters', ''),
(2578, 'Hardware > Tools > Cutters > Rebar Cutters', ''),
(2579, 'Hardware > Tools > Cutters > Tile & Shingle Cutters', ''),
(2580, 'Hardware > Tools > Cutters > Utility Knives',
''),
(2581, 'Hardware > Tools > Deburrers', ''),
(2582, 'Hardware > Tools > Dollies & Hand Trucks', ''),
(2583,
'Hardware > Tools > Drills > Augers', ''),
(2584, 'Hardware > Tools > Drills > Drill Presses', ''),
(2585, 'Hardware >
Tools > Drills > Handheld Power Drills', ''),
(2586, 'Hardware > Tools > Drills > Mortisers', ''),
(2587, 'Hardware >
Tools > Drills > Pneumatic Drills', ''),
(2588, 'Hardware > Tools > Electrician Fish Tape', ''),
(2589, 'Hardware >
Tools > Flashlights & Headlamps', ''),
(2590, 'Hardware > Tools > Grease Guns', ''),
(2591, 'Hardware > Tools >
Grinders', ''),
(2592, 'Hardware > Tools > Grips', ''),
(2593, 'Hardware > Tools > Hammers > Manual Hammers', ''),
(2594, 'Hardware > Tools > Hammers > Powered Hammers', ''),
(2595, 'Hardware > Tools > Handheld Power Mixers', ''),
(2596, 'Hardware > Tools > Hardware Torches', ''),
(2597, 'Hardware > Tools > Heat Guns', ''),
(2598, 'Hardware > Tools
> Impact Wrenches & Drivers', ''),
(2599, 'Hardware > Tools > Industrial Vibrators', ''),
(2600, 'Hardware > Tools >
Inspection Mirrors', ''),
(2601, 'Hardware > Tools > Ladders & Scaffolding > Ladder Carts', ''),
(2602, 'Hardware >
Tools > Ladders & Scaffolding > Ladders', ''),
(2603, 'Hardware > Tools > Ladders & Scaffolding > Scaffolding', ''),
(2604, 'Hardware > Tools > Ladders & Scaffolding > Step Stools', ''),
(2605, 'Hardware > Tools > Ladders & Scaffolding >
Work Platforms', ''),
(2606, 'Hardware > Tools > Lathes', ''),
(2607, 'Hardware > Tools > Light Bulb Changers', ''),
(2608, 'Hardware > Tools > Lighters & Matches', ''),
(2609, 'Hardware > Tools > Log Splitters', ''),
(2610, 'Hardware >
Tools > Magnetic Sweepers', ''),
(2611, 'Hardware > Tools > Marking Tools', ''),
(2612, 'Hardware > Tools > Masonry
Tools > Brick Tools', ''),
(2613, 'Hardware > Tools > Masonry Tools > Cement Mixers', ''),
(2614, 'Hardware > Tools >
Masonry Tools > Construction Lines', ''),
(2615, 'Hardware > Tools > Masonry Tools > Floats', ''),
(2616, 'Hardware >
Tools > Masonry Tools > Grout Sponges', ''),
(2617, 'Hardware > Tools > Masonry Tools > Masonry Edgers & Groovers', ''),
(2618, 'Hardware > Tools > Masonry Tools > Masonry Jointers', ''),
(2619, 'Hardware > Tools > Masonry Tools > Masonry
Trowels', ''),
(2620, 'Hardware > Tools > Masonry Tools > Power Trowels', ''),
(2621, 'Hardware > Tools > Mattocks &
Pickaxes', ''),
(2622, 'Hardware > Tools > Measuring Tools & Sensors > Air Quality Meters', ''),
(2623, 'Hardware >
Tools > Measuring Tools & Sensors > Altimeters', ''),
(2624, 'Hardware > Tools > Measuring Tools & Sensors >
Anemometers', ''),
(2625, 'Hardware > Tools > Measuring Tools & Sensors > Barometers', ''),
(2626, 'Hardware > Tools >
Measuring Tools & Sensors > Calipers', ''),
(2627, 'Hardware > Tools > Measuring Tools & Sensors > Cruising Rods', ''),
(2628, 'Hardware > Tools > Measuring Tools & Sensors > Distance Meters', ''),
(2629, 'Hardware > Tools > Measuring Tools
& Sensors > Dividers', ''),
(2630, 'Hardware > Tools > Measuring Tools & Sensors > Electrical Testing Tools', ''),
(2631, 'Hardware > Tools > Measuring Tools & Sensors > Flow Meters & Controllers', ''),
(2632, 'Hardware > Tools >
Measuring Tools & Sensors > Gas Detectors', ''),
(2633, 'Hardware > Tools > Measuring Tools & Sensors > Gauges', ''),
(2634, 'Hardware > Tools > Measuring Tools & Sensors > Geiger Counters', ''),
(2635, 'Hardware > Tools > Measuring Tools
& Sensors > Hygrometers', ''),
(2636, 'Hardware > Tools > Measuring Tools & Sensors > Infrared Thermometers', ''),
(2637, 'Hardware > Tools > Measuring Tools & Sensors > Knife Guides', ''),
(2638, 'Hardware > Tools > Measuring Tools &
Sensors > Levels', ''),
(2639, 'Hardware > Tools > Measuring Tools & Sensors > Levels > Bubble Levels', ''),
(2640,
'Hardware > Tools > Measuring Tools & Sensors > Levels > Laser Levels', ''),
(2641, 'Hardware > Tools > Measuring Tools
& Sensors > Levels > Sight Levels', ''),
(2642, 'Hardware > Tools > Measuring Tools & Sensors > Measuring Scales', ''),
(2643, 'Hardware > Tools > Measuring Tools & Sensors > Measuring Wheels', ''),
(2644, 'Hardware > Tools > Measuring
Tools & Sensors > Moisture Meters', ''),
(2645, 'Hardware > Tools > Measuring Tools & Sensors > Probes & Finders', ''),
(2646, 'Hardware > Tools > Measuring Tools & Sensors > Protractors', ''),
(2647, 'Hardware > Tools > Measuring Tools &
Sensors > Rebar Locators', ''),
(2648, 'Hardware > Tools > Measuring Tools & Sensors > Rulers', ''),
(2649, 'Hardware >
Tools > Measuring Tools & Sensors > Seismometer', ''),
(2650, 'Hardware > Tools > Measuring Tools & Sensors > Sound
Meters', ''),
(2651, 'Hardware > Tools > Measuring Tools & Sensors > Squares', ''),
(2652, 'Hardware > Tools > Measuring
Tools & Sensors > Straight Edges', ''),
(2653, 'Hardware > Tools > Measuring Tools & Sensors > Stud Sensors', ''),
(2654, 'Hardware > Tools > Measuring Tools & Sensors > Tape Measures', ''),
(2655, 'Hardware > Tools > Measuring Tools &
Sensors > Theodolites', ''),
(2656, 'Hardware > Tools > Measuring Tools & Sensors > Thermal Imaging Cameras', ''),
(2657, 'Hardware > Tools > Measuring Tools & Sensors > Thermocouples & Thermopiles', ''),
(2658, 'Hardware > Tools >
Measuring Tools & Sensors > Transducers', ''),
(2659, 'Hardware > Tools > Measuring Tools & Sensors > UV Light Meters',
''),
(2660, 'Hardware > Tools > Measuring Tools & Sensors > Vibration Meters', ''),
(2661, 'Hardware > Tools > Measuring
Tools & Sensors > Weather Forecasters & Stations', ''),
(2662, 'Hardware > Tools > Measuring Tools & Sensors > pH
Meters', ''),
(2663, 'Hardware > Tools > Milling Machines', ''),
(2664, 'Hardware > Tools > Multifunction Power Tools',
''),
(2665, 'Hardware > Tools > Nail Pullers', ''),
(2666, 'Hardware > Tools > Nailers & Staplers', ''),
(2667,
'Hardware > Tools > Oil Filter Drains', ''),
(2668, 'Hardware > Tools > Paint Tools > Airbrushes', ''),
(2669, 'Hardware
> Tools > Paint Tools > Paint Brushes', ''),
(2670, 'Hardware > Tools > Paint Tools > Paint Edgers', ''),
(2671,
'Hardware > Tools > Paint Tools > Paint Rollers', ''),
(2672, 'Hardware > Tools > Paint Tools > Paint Shakers', ''),
(2673, 'Hardware > Tools > Paint Tools > Paint Sponges', ''),
(2674, 'Hardware > Tools > Paint Tools > Paint Sprayers',
''),
(2675, 'Hardware > Tools > Paint Tools > Paint Strainers', ''),
(2676, 'Hardware > Tools > Paint Tools > Paint
Trays', ''),
(2677, 'Hardware > Tools > Pickup Tools', ''),
(2678, 'Hardware > Tools > Pipe & Bar Benders', ''),
(2679,
'Hardware > Tools > Pipe & Tube Cleaners', ''),
(2680, 'Hardware > Tools > Pipe Brushes', ''),
(2681, 'Hardware > Tools
> Planers', ''),
(2682, 'Hardware > Tools > Planes', ''),
(2683, 'Hardware > Tools > Pliers', ''),
(2684, 'Hardware >
Tools > Plungers', ''),
(2685, 'Hardware > Tools > Polishers & Buffers', ''),
(2686, 'Hardware > Tools > Post Hole
Diggers', ''),
(2687, 'Hardware > Tools > Pry Bars', ''),
(2688, 'Hardware > Tools > Punches & Awls', ''),
(2689,
'Hardware > Tools > Putty Knives & Scrapers', ''),
(2690, 'Hardware > Tools > Reamers', ''),
(2691, 'Hardware > Tools >
Riveting Tools', ''),
(2692, 'Hardware > Tools > Riveting Tools > Rivet Guns', ''),
(2693, 'Hardware > Tools > Riveting
Tools > Rivet Pliers', ''),
(2694, 'Hardware > Tools > Routing Tools', ''),
(2695, 'Hardware > Tools > Sanders', ''),
(2696, 'Hardware > Tools > Sanding Blocks', ''),
(2697, 'Hardware > Tools > Saw Horses', ''),
(2698, 'Hardware > Tools >
Saws > Band Saws', ''),
(2699, 'Hardware > Tools > Saws > Cut-Off Saws', ''),
(2700, 'Hardware > Tools > Saws > Hand
Saws', ''),
(2701, 'Hardware > Tools > Saws > Handheld Circular Saws', ''),
(2702, 'Hardware > Tools > Saws > Jigsaws',
''),
(2703, 'Hardware > Tools > Saws > Masonry & Tile Saws', ''),
(2704, 'Hardware > Tools > Saws > Miter Saws', ''),
(2705, 'Hardware > Tools > Saws > Panel Saws', ''),
(2706, 'Hardware > Tools > Saws > Reciprocating Saws', ''),
(2707,
'Hardware > Tools > Saws > Scroll Saws', ''),
(2708, 'Hardware > Tools > Saws > Table Saws', ''),
(2709, 'Hardware >
Tools > Screwdrivers', ''),
(2710, 'Hardware > Tools > Shapers', ''),
(2711, 'Hardware > Tools > Sharpeners', ''),
(2712, 'Hardware > Tools > Socket Drivers', ''),
(2713, 'Hardware > Tools > Soldering Irons', ''),
(2714, 'Hardware >
Tools > Tap Reseaters', ''),
(2715, 'Hardware > Tools > Taps & Dies', ''),
(2716, 'Hardware > Tools > Threading
Machines', ''),
(2717, 'Hardware > Tools > Tool Clamps & Vises', ''),
(2718, 'Hardware > Tools > Tool Files', ''),
(2719, 'Hardware > Tools > Tool Keys', ''),
(2720, 'Hardware > Tools > Tool Knives', ''),
(2721, 'Hardware > Tools >
Tool Sets > Hand Tool Sets', ''),
(2722, 'Hardware > Tools > Tool Sets > Power Tool Combo Sets', ''),
(2723, 'Hardware >
Tools > Welding Guns & Plasma Cutters', ''),
(2724, 'Hardware > Tools > Wire & Cable Hand Tools', ''),
(2725, 'Hardware
> Tools > Work Lights', ''),
(2726, 'Hardware > Tools > Wrenches', ''),
(2727, 'Health & Beauty > Health Care >
Acupuncture > Acupuncture Models', ''),
(2728, 'Health & Beauty > Health Care > Acupuncture > Acupuncture Needles', ''),
(2729, 'Health & Beauty > Health Care > Bed Pans', ''),
(2730, 'Health & Beauty > Health Care > Biometric Monitor
Accessories > Activity Monitor Accessories', ''),
(2731, 'Health & Beauty > Health Care > Biometric Monitor Accessories
> Blood Glucose Meter Accessories', ''),
(2732, 'Health & Beauty > Health Care > Biometric Monitor Accessories > Blood
Glucose Meter Accessories > Blood Glucose Control Solution', ''),
(2733, 'Health & Beauty > Health Care > Biometric
Monitor Accessories > Blood Glucose Meter Accessories > Blood Glucose Test Strips', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (2734,
'Health & Beauty > Health Care > Biometric Monitor Accessories > Blood Glucose Meter Accessories > Lancing Devices',
''),
(2735, 'Health & Beauty > Health Care > Biometric Monitor Accessories > Blood Pressure Monitor Accessories', ''),
(2736, 'Health & Beauty > Health Care > Biometric Monitor Accessories > Blood Pressure Monitor Accessories > Blood
Pressure Monitor Cuffs', ''),
(2737, 'Health & Beauty > Health Care > Biometric Monitor Accessories > Body Weight Scale
Accessories', ''),
(2738, 'Health & Beauty > Health Care > Biometric Monitors > Activity Monitors', ''),
(2739, 'Health
& Beauty > Health Care > Biometric Monitors > Blood Glucose Meters', ''),
(2740, 'Health & Beauty > Health Care >
Biometric Monitors > Blood Pressure Monitors', ''),
(2741, 'Health & Beauty > Health Care > Biometric Monitors > Body
Fat Analyzers', ''),
(2742, 'Health & Beauty > Health Care > Biometric Monitors > Body Weight Scales', ''),
(2743,
'Health & Beauty > Health Care > Biometric Monitors > Breathalyzers', ''),
(2744, 'Health & Beauty > Health Care >
Biometric Monitors > Cholesterol Analyzers', ''),
(2745, 'Health & Beauty > Health Care > Biometric Monitors > Fertility
Monitors and Ovulation Tests', ''),
(2746, 'Health & Beauty > Health Care > Biometric Monitors > Medical Thermometers',
''),
(2747, 'Health & Beauty > Health Care > Biometric Monitors > Prenatal Heart Rate Monitors', ''),
(2748, 'Health &
Beauty > Health Care > Biometric Monitors > Pulse Oximeters', ''),
(2749, 'Health & Beauty > Health Care > Condoms',
''),
(2750, 'Health & Beauty > Health Care > Conductivity Gels & Lotions', ''),
(2751, 'Health & Beauty > Health Care >
Contraceptive Cases', ''),
(2752, 'Health & Beauty > Health Care > First Aid > Antiseptics & Cleaning Supplies', ''),
(2753, 'Health & Beauty > Health Care > First Aid > Cast & Bandage Protectors', ''),
(2754, 'Health & Beauty > Health
Care > First Aid > Eye Wash Supplies', ''),
(2755, 'Health & Beauty > Health Care > First Aid > First Aid Kits', ''),
(2756, 'Health & Beauty > Health Care > First Aid > Hot & Cold Therapies > Heat Rubs', ''),
(2757, 'Health & Beauty >
Health Care > First Aid > Hot & Cold Therapies > Heating Pads', ''),
(2758, 'Health & Beauty > Health Care > First Aid >
Hot & Cold Therapies > Ice Packs', ''),
(2759, 'Health & Beauty > Health Care > First Aid > Medical Tape & Bandages',
''),
(2760, 'Health & Beauty > Health Care > Fitness & Nutrition > Nutrition Bars', ''),
(2761, 'Health & Beauty >
Health Care > Fitness & Nutrition > Nutrition Drinks & Shakes', ''),
(2762, 'Health & Beauty > Health Care > Fitness &
Nutrition > Nutrition Gels & Chews', ''),
(2763, 'Health & Beauty > Health Care > Fitness & Nutrition > Nutritional Food
Pur├®es', ''),
(2764, 'Health & Beauty > Health Care > Fitness & Nutrition > Tube Feeding Supplements', ''),
(2765,
'Health & Beauty > Health Care > Fitness & Nutrition > Vitamins & Supplements', ''),
(2766, 'Health & Beauty > Health
Care > Hearing Aids', ''),
(2767, 'Health & Beauty > Health Care > Incontinence Aids', ''),
(2768, 'Health & Beauty >
Health Care > Light Therapy Lamps', ''),
(2769, 'Health & Beauty > Health Care > Medical Alarm Systems', ''),
(2770,
'Health & Beauty > Health Care > Medical Identification Tags & Jewelry', ''),
(2771, 'Health & Beauty > Health Care >
Medical Tests > Allergy Test Kits', ''),
(2772, 'Health & Beauty > Health Care > Medical Tests > Blood Typing Test
Kits', ''),
(2773, 'Health & Beauty > Health Care > Medical Tests > Drug Tests', ''),
(2774, 'Health & Beauty > Health
Care > Medical Tests > HIV Tests', ''),
(2775, 'Health & Beauty > Health Care > Medical Tests > Pregnancy Tests', ''),
(2776, 'Health & Beauty > Health Care > Medical Tests > Urinary Tract Infection Tests', ''),
(2777, 'Health & Beauty >
Health Care > Medicine & Drugs', ''),
(2778, 'Health & Beauty > Health Care > Mobility & Accessibility > Accessibility
Equipment > Mobility Scooters', ''),
(2779, 'Health & Beauty > Health Care > Mobility & Accessibility > Accessibility
Equipment > Stair Lifts', ''),
(2780, 'Health & Beauty > Health Care > Mobility & Accessibility > Accessibility
Equipment > Transfer Boards & Sheets', ''),
(2781, 'Health & Beauty > Health Care > Mobility & Accessibility >
Accessibility Equipment > Wheelchairs', ''),
(2782, 'Health & Beauty > Health Care > Mobility & Accessibility >
Accessibility Equipment Accessories', ''),
(2783, 'Health & Beauty > Health Care > Mobility & Accessibility >
Accessibility Furniture & Fixtures', ''),
(2784, 'Health & Beauty > Health Care > Mobility & Accessibility >
Accessibility Furniture & Fixtures > Shower Benches & Seats', ''),
(2785, 'Health & Beauty > Health Care > Mobility &
Accessibility > Walking Aid Accessories', ''),
(2786, 'Health & Beauty > Health Care > Mobility & Accessibility >
Walking Aids > Canes & Walking Sticks', ''),
(2787, 'Health & Beauty > Health Care > Mobility & Accessibility > Walking
Aids > Crutches', ''),
(2788, 'Health & Beauty > Health Care > Mobility & Accessibility > Walking Aids > Walkers', ''),
(2789, 'Health & Beauty > Health Care > Occupational & Physical Therapy Equipment > Electrical Muscle Stimulators', ''),
(2790, 'Health & Beauty > Health Care > Occupational & Physical Therapy Equipment > Therapeutic Swings', ''),
(2791,
'Health & Beauty > Health Care > Pillboxes', ''),
(2792, 'Health & Beauty > Health Care > Respiratory Care >
Nebulizers', ''),
(2793, 'Health & Beauty > Health Care > Respiratory Care > Oxygen Tanks', ''),
(2794, 'Health & Beauty
> Health Care > Respiratory Care > PAP Machines', ''),
(2795, 'Health & Beauty > Health Care > Respiratory Care > PAP
Masks', ''),
(2796, 'Health & Beauty > Health Care > Respiratory Care > Steam Inhalers', ''),
(2797, 'Health & Beauty >
Health Care > Specimen Cups', ''),
(2798, 'Health & Beauty > Health Care > Spermicides', ''),
(2799, 'Health & Beauty >
Health Care > Stump Shrinkers', ''),
(2800, 'Health & Beauty > Health Care > Supports & Braces', ''),
(2801, 'Health &
Beauty > Health Care > Surgical Lubricants', ''),
(2802, 'Health & Beauty > Jewelry Cleaning & Care > Jewelry Cleaning
Solutions & Polishes', ''),
(2803, 'Health & Beauty > Jewelry Cleaning & Care > Jewelry Cleaning Tools', ''),
(2804,
'Health & Beauty > Jewelry Cleaning & Care > Jewelry Holders', ''),
(2805, 'Health & Beauty > Jewelry Cleaning & Care >
Jewelry Steam Cleaners', ''),
(2806, 'Health & Beauty > Jewelry Cleaning & Care > Watch Repair Kits', ''),
(2807,
'Health & Beauty > Personal Care > Back Care', ''),
(2808, 'Health & Beauty > Personal Care > Back Care > Back & Lumbar
Support Cushions', ''),
(2809, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Adult Hygienic Wipes', ''),
(2810, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Bar Soap', ''),
(2811, 'Health & Beauty > Personal
Care > Cosmetics > Bath & Body > Bath Additives', ''),
(2812, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body
> Bath Brushes', ''),
(2813, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Bath Sponges & Loofahs', ''),
(2814, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Body Wash', ''),
(2815, 'Health & Beauty > Personal
Care > Cosmetics > Bath & Body > Hand Sanitizers & Wipes', ''),
(2816, 'Health & Beauty > Personal Care > Cosmetics >
Bath & Body > Liquid Hand Soap', ''),
(2817, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Powdered Hand
Soap', ''),
(2818, 'Health & Beauty > Personal Care > Cosmetics > Bath & Body > Shower Caps', ''),
(2819, 'Health &
Beauty > Personal Care > Cosmetics > Bath & Body Gift Sets', ''),
(2820, 'Health & Beauty > Personal Care > Cosmetics >
Cosmetic Sets', ''),
(2821, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tool Cleansers', ''),
(2822, 'Health
& Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > Double Eyelid Glue & Tape', ''),
(2823, 'Health &
Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > Eyebrow Stencils', ''),
(2824, 'Health & Beauty >
Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > Eyelash Curler Refills', ''),
(2825, 'Health & Beauty >
Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > Eyelash Curlers', ''),
(2826, 'Health & Beauty > Personal
Care > Cosmetics > Cosmetic Tools > Makeup Tools > Face Mirrors', ''),
(2827, 'Health & Beauty > Personal Care >
Cosmetics > Cosmetic Tools > Makeup Tools > Facial Blotting Paper', ''),
(2828, 'Health & Beauty > Personal Care >
Cosmetics > Cosmetic Tools > Makeup Tools > False Eyelash Accessories > False Eyelash Adhesive', ''),
(2829, 'Health &
Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > False Eyelash Accessories > False Eyelash
Applicators', ''),
(2830, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > False Eyelash
Accessories > False Eyelash Remover', ''),
(2831, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup
Tools > Makeup Brushes', ''),
(2832, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools >
Makeup Sponges', ''),
(2833, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Makeup Tools > Refillable
Makeup Palettes & Cases', ''),
(2834, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools >
Cuticle Pushers', ''),
(2835, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Cuticle
Scissors', ''),
(2836, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Manicure & Pedicure
Spacers', ''),
(2837, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Manicure Tool Sets',
''),
(2838, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Nail Buffers', ''),
(2839,
'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Nail Clippers', ''),
(2840, 'Health &
Beauty > Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Nail Drill Accessories', ''),
(2841, 'Health & Beauty
> Personal Care > Cosmetics > Cosmetic Tools > Nail Tools > Nail Drills', ''),
(2842, 'Health & Beauty > Personal Care >
Cosmetics > Cosmetic Tools > Nail Tools > Nail Dryers', ''),
(2843, 'Health & Beauty > Personal Care > Cosmetics >
Cosmetic Tools > Nail Tools > Nail Files & Emery Boards', ''),
(2844, 'Health & Beauty > Personal Care > Cosmetics >
Cosmetic Tools > Skin Care Tools > Facial Saunas', ''),
(2845, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic
Tools > Skin Care Tools > Foot Files', ''),
(2846, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Skin
Care Tools > Lotion & Sunscreen Applicators', ''),
(2847, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools
> Skin Care Tools > Pumice Stones', ''),
(2848, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Skin
Care Tools > Skin Care Extractors', ''),
(2849, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Skin
Care Tools > Skin Care Rollers', ''),
(2850, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Skin Care
Tools > Skin Cleansing Brush Heads', ''),
(2851, 'Health & Beauty > Personal Care > Cosmetics > Cosmetic Tools > Skin
Care Tools > Skin Cleansing Brushes & Systems', ''),
(2852, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Body
Makeup > Body & Hair Glitter', ''),
(2853, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Body Makeup > Body
Paint & Foundation', ''),
(2854, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Costume & Stage Makeup', ''),
(2855, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Eye Makeup > Eye Primer', ''),
(2856, 'Health & Beauty >
Personal Care > Cosmetics > Makeup > Eye Makeup > Eye Shadow', ''),
(2857, 'Health & Beauty > Personal Care > Cosmetics
> Makeup > Eye Makeup > Eyebrow Enhancers', ''),
(2858, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Eye
Makeup > Eyeliner', ''),
(2859, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Eye Makeup > False Eyelashes',
''),
(2860, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Eye Makeup > Lash & Brow Growth Treatments', ''),
(2861, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Eye Makeup > Mascara', ''),
(2862, 'Health & Beauty >
Personal Care > Cosmetics > Makeup > Eye Makeup > Mascara Primer', ''),
(2863, 'Health & Beauty > Personal Care >
Cosmetics > Makeup > Face Makeup > Blushes & Bronzers', ''),
(2864, 'Health & Beauty > Personal Care > Cosmetics >
Makeup > Face Makeup > Face Powder', ''),
(2865, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Face Makeup >
Face Primer', ''),
(2866, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Face Makeup > Foundations &
Concealers', ''),
(2867, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Face Makeup > Highlighters &
Luminizers', ''),
(2868, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Lip Makeup > Lip & Cheek Stains', ''),
(2869, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Lip Makeup > Lip Gloss', ''),
(2870, 'Health & Beauty >
Personal Care > Cosmetics > Makeup > Lip Makeup > Lip Liner', ''),
(2871, 'Health & Beauty > Personal Care > Cosmetics >
Makeup > Lip Makeup > Lip Primer', ''),
(2872, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Lip Makeup >
Lipstick', ''),
(2873, 'Health & Beauty > Personal Care > Cosmetics > Makeup > Makeup Finishing Sprays', ''),
(2874,
'Health & Beauty > Personal Care > Cosmetics > Makeup > Temporary Tattoos', ''),
(2875, 'Health & Beauty > Personal Care
> Cosmetics > Mens', ''),
(2876, 'Health & Beauty > Personal Care > Cosmetics > Nail Care > Cuticle Cream & Oil', ''),
(2877, 'Health & Beauty > Personal Care > Cosmetics > Nail Care > False Nails', ''),
(2878, 'Health & Beauty > Personal
Care > Cosmetics > Nail Care > Manicure Glue', ''),
(2879, 'Health & Beauty > Personal Care > Cosmetics > Nail Care >
Nail Art Kits & Accessories', ''),
(2880, 'Health & Beauty > Personal Care > Cosmetics > Nail Care > Nail Polish Drying
Drops & Sprays', ''),
(2881, 'Health & Beauty > Personal Care > Cosmetics > Nail Care > Nail Polish Removers', ''),
(2882, 'Health & Beauty > Personal Care > Cosmetics > Nail Care > Nail Polish Thinners', ''),
(2883, 'Health & Beauty >
Personal Care > Cosmetics > Nail Care > Nail Polishes', ''),
(2884, 'Health & Beauty > Personal Care > Cosmetics >
Perfume & Cologne > Adult (unisex)', ''),
(2885, 'Health & Beauty > Personal Care > Cosmetics > Perfume & Cologne >
Mens', ''),
(2886, 'Health & Beauty > Personal Care > Cosmetics > Perfume & Cologne > Womens', ''),
(2887, 'Health &
Beauty > Personal Care > Cosmetics > Skin Care > Acne Treatments & Kits', ''),
(2888, 'Health & Beauty > Personal Care >
Cosmetics > Skin Care > Anti-Aging Skin Care Kits', ''),
(2889, 'Health & Beauty > Personal Care > Cosmetics > Skin Care
> Body Oil', ''),
(2890, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Body Powder', ''),
(2891, 'Health &
Beauty > Personal Care > Cosmetics > Skin Care > Compressed Skin Care Mask Sheets', ''),
(2892, 'Health & Beauty >
Personal Care > Cosmetics > Skin Care > Facial Cleansers', ''),
(2893, 'Health & Beauty > Personal Care > Cosmetics >
Skin Care > Facial Cleansing Kits', ''),
(2894, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Facial Pore
Strips', ''),
(2895, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Lip Balms & Treatments', ''),
(2896,
'Health & Beauty > Personal Care > Cosmetics > Skin Care > Lotion & Moisturizer', ''),
(2897, 'Health & Beauty >
Personal Care > Cosmetics > Skin Care > Makeup Removers', ''),
(2898, 'Health & Beauty > Personal Care > Cosmetics >
Skin Care > Petroleum Jelly', ''),
(2899, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Care Masks &
Peels', ''),
(2900, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Skin Insect Repellent', ''),
(2901,
'Health & Beauty > Personal Care > Cosmetics > Skin Care > Sunscreen', ''),
(2902, 'Health & Beauty > Personal Care >
Cosmetics > Skin Care > Tanning Products', ''),
(2903, 'Health & Beauty > Personal Care > Cosmetics > Skin Care >
Tanning Products > Self Tanner', ''),
(2904, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Tanning Products
> Tanning Oil & Lotion', ''),
(2905, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Toners & Astringents',
''),
(2906, 'Health & Beauty > Personal Care > Cosmetics > Skin Care > Wart Removers', ''),
(2907, 'Health & Beauty >
Personal Care > Cotton Balls', ''),
(2908, 'Health & Beauty > Personal Care > Cotton Swabs', ''),
(2909, 'Health &
Beauty > Personal Care > Deodorant & Anti-Perspirant', ''),
(2910, 'Health & Beauty > Personal Care > Ear Care > Ear
Candles', ''),
(2911, 'Health & Beauty > Personal Care > Ear Care > Ear Drops', ''),
(2912, 'Health & Beauty > Personal
Care > Ear Care > Ear Dryers', ''),
(2913, 'Health & Beauty > Personal Care > Ear Care > Ear Picks & Spoons', ''),
(2914, 'Health & Beauty > Personal Care > Ear Care > Ear Syringes', ''),
(2915, 'Health & Beauty > Personal Care > Ear
Care > Ear Wax Removal Kits', ''),
(2916, 'Health & Beauty > Personal Care > Ear Care > Earplug Dispensers', ''),
(2917,
'Health & Beauty > Personal Care > Ear Care > Earplugs', ''),
(2918, 'Health & Beauty > Personal Care > Enema Kits &
Supplies', ''),
(2919, 'Health & Beauty > Personal Care > Feminine Sanitary Supplies > Feminine Deodorant', ''),
(2920,
'Health & Beauty > Personal Care > Feminine Sanitary Supplies > Feminine Douches & Creams', ''),
(2921, 'Health & Beauty
> Personal Care > Feminine Sanitary Supplies > Feminine Pads & Protectors', ''),
(2922, 'Health & Beauty > Personal Care
> Feminine Sanitary Supplies > Menstrual Cups', ''),
(2923, 'Health & Beauty > Personal Care > Feminine Sanitary
Supplies > Tampons', ''),
(2924, 'Health & Beauty > Personal Care > Foot Care > Bunion Care Supplies', ''),
(2925,
'Health & Beauty > Personal Care > Foot Care > Corn & Callus Care Supplies', ''),
(2926, 'Health & Beauty > Personal
Care > Foot Care > Foot Odor Removers', ''),
(2927, 'Health & Beauty > Personal Care > Foot Care > Insoles & Inserts',
''),
(2928, 'Health & Beauty > Personal Care > Foot Care > Toe Spacers', ''),
(2929, 'Health & Beauty > Personal Care >
Hair Care > Hair Care Kits', ''),
(2930, 'Health & Beauty > Personal Care > Hair Care > Hair Color', ''),
(2931, 'Health
& Beauty > Personal Care > Hair Care > Hair Color Removers', ''),
(2932, 'Health & Beauty > Personal Care > Hair Care >
Hair Coloring Accessories', ''),
(2933, 'Health & Beauty > Personal Care > Hair Care > Hair Loss Concealers', ''),
(2934, 'Health & Beauty > Personal Care > Hair Care > Hair Loss Treatments', ''),
(2935, 'Health & Beauty > Personal
Care > Hair Care > Hair Permanents & Straighteners', ''),
(2936, 'Health & Beauty > Personal Care > Hair Care > Hair
Shears', ''),
(2937, 'Health & Beauty > Personal Care > Hair Care > Hair Steamers & Heat Caps', ''),
(2938, 'Health &
Beauty > Personal Care > Hair Care > Hair Styling Products', ''),
(2939, 'Health & Beauty > Personal Care > Hair Care >
Hair Styling Tool Accessories > Hair Curler Clips & Pins', ''),
(2940, 'Health & Beauty > Personal Care > Hair Care >
Hair Styling Tool Accessories > Hair Dryer Accessories', ''),
(2941, 'Health & Beauty > Personal Care > Hair Care > Hair
Styling Tool Accessories > Hair Iron Accessories', ''),
(2942, 'Health & Beauty > Personal Care > Hair Care > Hair
Styling Tools > Combs & Brushes', ''),
(2943, 'Health & Beauty > Personal Care > Hair Care > Hair Styling Tools >
Curling Irons', ''),
(2944, 'Health & Beauty > Personal Care > Hair Care > Hair Styling Tools > Hair Curlers', ''),
(2945, 'Health & Beauty > Personal Care > Hair Care > Hair Styling Tools > Hair Dryers', ''),
(2946, 'Health & Beauty >
Personal Care > Hair Care > Hair Styling Tools > Hair Straighteners', ''),
(2947, 'Health & Beauty > Personal Care >
Hair Care > Hair Styling Tools > Hair Styling Tool Sets', ''),
(2948, 'Health & Beauty > Personal Care > Hair Care >
Shampoo & Conditioner', ''),
(2949, 'Health & Beauty > Personal Care > Massage & Relaxation > Back Scratchers', ''),
(2950, 'Health & Beauty > Personal Care > Massage & Relaxation > Eye Pillows', ''),
(2951, 'Health & Beauty > Personal
Care > Massage & Relaxation > Massage Chairs', ''),
(2952, 'Health & Beauty > Personal Care > Massage & Relaxation >
Massage Oil', ''),
(2953, 'Health & Beauty > Personal Care > Massage & Relaxation > Massage Stone Warmers', ''),
(2954,
'Health & Beauty > Personal Care > Massage & Relaxation > Massage Stones', ''),
(2955, 'Health & Beauty > Personal Care
> Massage & Relaxation > Massage Tables', ''),
(2956, 'Health & Beauty > Personal Care > Massage & Relaxation >
Massagers', ''),
(2957, 'Health & Beauty > Personal Care > Oral Care > Breath Spray', ''),
(2958, 'Health & Beauty >
Personal Care > Oral Care > Dental Floss', ''),
(2959, 'Health & Beauty > Personal Care > Oral Care > Dental
Mouthguards', ''),
(2960, 'Health & Beauty > Personal Care > Oral Care > Dental Water Jet Replacement Tips', ''),
(2961,
'Health & Beauty > Personal Care > Oral Care > Dental Water Jets', ''),
(2962, 'Health & Beauty > Personal Care > Oral
Care > Denture Adhesives', ''),
(2963, 'Health & Beauty > Personal Care > Oral Care > Denture Cleaners', ''),
(2964,
'Health & Beauty > Personal Care > Oral Care > Denture Repair Kits', ''),
(2965, 'Health & Beauty > Personal Care > Oral
Care > Dentures', ''),
(2966, 'Health & Beauty > Personal Care > Oral Care > Gum Stimulators', ''),
(2967, 'Health &
Beauty > Personal Care > Oral Care > Mouthwash', ''),
(2968, 'Health & Beauty > Personal Care > Oral Care > Orthodontic
Appliance Cases', ''),
(2969, 'Health & Beauty > Personal Care > Oral Care > Power Flossers', ''),
(2970, 'Health &
Beauty > Personal Care > Oral Care > Teeth Whiteners', ''),
(2971, 'Health & Beauty > Personal Care > Oral Care > Tongue
Scrapers', ''),
(2972, 'Health & Beauty > Personal Care > Oral Care > Toothbrush Accessories > Toothbrush Covers', ''),
(2973, 'Health & Beauty > Personal Care > Oral Care > Toothbrush Accessories > Toothbrush Replacement Heads', ''),
(2974, 'Health & Beauty > Personal Care > Oral Care > Toothbrush Accessories > Toothbrush Sanitizers', ''),
(2975,
'Health & Beauty > Personal Care > Oral Care > Toothbrushes', ''),
(2976, 'Health & Beauty > Personal Care > Oral Care >
Toothpaste', ''),
(2977, 'Health & Beauty > Personal Care > Oral Care > Toothpaste Squeezers & Dispensers', ''),
(2978,
'Health & Beauty > Personal Care > Oral Care > Toothpicks', ''),
(2979, 'Health & Beauty > Personal Care > Personal
Lubricants', ''),
(2980, 'Health & Beauty > Personal Care > Shaving & Grooming > Aftershave', ''),
(2981, 'Health &
Beauty > Personal Care > Shaving & Grooming > Body & Facial Hair Bleach', ''),
(2982, 'Health & Beauty > Personal Care >
Shaving & Grooming > Electric Razor Accessories', ''),
(2983, 'Health & Beauty > Personal Care > Shaving & Grooming >
Electric Razors', ''),
(2984, 'Health & Beauty > Personal Care > Shaving & Grooming > Hair Clipper & Trimmer
Accessories', ''),
(2985, 'Health & Beauty > Personal Care > Shaving & Grooming > Hair Clippers & Trimmers', ''),
(2986,
'Health & Beauty > Personal Care > Shaving & Grooming > Hair Removal > Depilatories', ''),
(2987, 'Health & Beauty >
Personal Care > Shaving & Grooming > Hair Removal > Electrolysis Devices', ''),
(2988, 'Health & Beauty > Personal Care
> Shaving & Grooming > Hair Removal > Epilators', ''),
(2989, 'Health & Beauty > Personal Care > Shaving & Grooming >
Hair Removal > Hair Removal Wax Warmers', ''),
(2990, 'Health & Beauty > Personal Care > Shaving & Grooming > Hair
Removal > Laser & IPL Hair Removal Devices', ''),
(2991, 'Health & Beauty > Personal Care > Shaving & Grooming > Hair
Removal > Waxing Kits & Supplies', ''),
(2992, 'Health & Beauty > Personal Care > Shaving & Grooming > Razors & Razor
Blades', ''),
(2993, 'Health & Beauty > Personal Care > Shaving & Grooming > Shaving Bowls & Mugs', ''),
(2994, 'Health
& Beauty > Personal Care > Shaving & Grooming > Shaving Brushes', ''),
(2995, 'Health & Beauty > Personal Care > Shaving
& Grooming > Shaving Cream', ''),
(2996, 'Health & Beauty > Personal Care > Shaving & Grooming > Shaving Kits', ''),
(2997, 'Health & Beauty > Personal Care > Shaving & Grooming > Styptic Pencils', ''),
(2998, 'Health & Beauty > Personal
Care > Sleeping Aids > Eye Masks', ''),
(2999, 'Health & Beauty > Personal Care > Sleeping Aids > Snoring & Sleep Apnea
Aids', ''),
(3000, 'Health & Beauty > Personal Care > Sleeping Aids > Travel Pillows', ''),
(3001, 'Health & Beauty >
Personal Care > Sleeping Aids > White Noise Machines', ''),
(3002, 'Health & Beauty > Personal Care > Spray Tanning
Tents', ''),
(3003, 'Health & Beauty > Personal Care > Tanning Beds', ''),
(3004, 'Health & Beauty > Personal Care >
Tweezers', ''),
(3005, 'Health & Beauty > Personal Care > Vision Care > Contact Lens Care > Contact Lens Care Kits',
''),
(3006, 'Health & Beauty > Personal Care > Vision Care > Contact Lens Care > Contact Lens Cases', ''),
(3007,
'Health & Beauty > Personal Care > Vision Care > Contact Lens Care > Contact Lens Solution', ''),
(3008, 'Health &
Beauty > Personal Care > Vision Care > Contact Lenses', ''),
(3009, 'Health & Beauty > Personal Care > Vision Care > Eye
Drops & Lubricants', ''),
(3010, 'Health & Beauty > Personal Care > Vision Care > Eyeglass Lenses', ''),
(3011, 'Health
& Beauty > Personal Care > Vision Care > Eyeglasses', ''),
(3012, 'Health & Beauty > Personal Care > Vision Care >
Eyewear Accessories > Eyewear Cases & Holders', ''),
(3013, 'Health & Beauty > Personal Care > Vision Care > Eyewear
Accessories > Eyewear Lens Cleaning Solutions', ''),
(3014, 'Health & Beauty > Personal Care > Vision Care > Eyewear
Accessories > Eyewear Straps & Chains', ''),
(3015, 'Health & Beauty > Personal Care > Vision Care > Sunglass Lenses',
''),
(3016, 'Home & Garden > Bathroom Accessories > Bath Caddies', ''),
(3017, 'Home & Garden > Bathroom Accessories >
Bath Mats & Rugs', ''),
(3018, 'Home & Garden > Bathroom Accessories > Bath Pillows', ''),
(3019, 'Home & Garden >
Bathroom Accessories > Bathroom Accessory Mounts', ''),
(3020, 'Home & Garden > Bathroom Accessories > Bathroom
Accessory Sets', ''),
(3021, 'Home & Garden > Bathroom Accessories > Facial Tissue Holders', ''),
(3022, 'Home & Garden
> Bathroom Accessories > Hand Dryer Accessories', ''),
(3023, 'Home & Garden > Bathroom Accessories > Hand Dryers', ''),
(3024, 'Home & Garden > Bathroom Accessories > Medicine Cabinets', ''),
(3025, 'Home & Garden > Bathroom Accessories >
Robe Hooks', ''),
(3026, 'Home & Garden > Bathroom Accessories > Safety Grab Bars', ''),
(3027, 'Home & Garden >
Bathroom Accessories > Shower Curtain Rings', ''),
(3028, 'Home & Garden > Bathroom Accessories > Shower Curtains', ''),
(3029, 'Home & Garden > Bathroom Accessories > Shower Rods', ''),
(3030, 'Home & Garden > Bathroom Accessories > Soap &
Lotion Dispensers', ''),
(3031, 'Home & Garden > Bathroom Accessories > Soap Dishes & Holders', ''),
(3032, 'Home &
Garden > Bathroom Accessories > Toilet Brush Replacement Heads', ''),
(3033, 'Home & Garden > Bathroom Accessories >
Toilet Brushes & Holders', ''),
(3034, 'Home & Garden > Bathroom Accessories > Toilet Paper Holders', ''),
(3035, 'Home
& Garden > Bathroom Accessories > Toothbrush Holders', ''),
(3036, 'Home & Garden > Bathroom Accessories > Towel Racks &
Holders', ''),
(3037, 'Home & Garden > Business & Home Security > Dummy Surveillance Cameras', ''),
(3038, 'Home &
Garden > Business & Home Security > Home Alarm Systems', ''),
(3039, 'Home & Garden > Business & Home Security > Motion
Sensors', ''),
(3040, 'Home & Garden > Business & Home Security > Safety & Security Mirrors', ''),
(3041, 'Home & Garden
> Business & Home Security > Security Lights', ''),
(3042, 'Home & Garden > Business & Home Security > Security Monitors
& Recorders', ''),
(3043, 'Home & Garden > Business & Home Security > Security Safe Accessories', ''),
(3044, 'Home &
Garden > Business & Home Security > Security Safes', ''),
(3045, 'Home & Garden > Business & Home Security > Security
System Sensors', ''),
(3046, 'Home & Garden > Decor > Address Signs', ''),
(3047, 'Home & Garden > Decor > Artificial
Flora', ''),
(3048, 'Home & Garden > Decor > Artificial Food', ''),
(3049, 'Home & Garden > Decor > Artwork > Decorative
Tapestries', ''),
(3050, 'Home & Garden > Decor > Artwork > Posters,Prints,& Visual Artwork', ''),
(3051, 'Home & Garden
> Decor > Artwork > Sculptures & Statues', ''),
(3052, 'Home & Garden > Decor > Backrest Pillows', ''),
(3053, 'Home &
Garden > Decor > Baskets', ''),
(3054, 'Home & Garden > Decor > Bird & Wildlife Feeder Accessories', ''),
(3055, 'Home &
Garden > Decor > Bird & Wildlife Feeders > Bird Feeders', ''),
(3056, 'Home & Garden > Decor > Bird & Wildlife Feeders >
Butterfly Feeders', ''),
(3057, 'Home & Garden > Decor > Bird & Wildlife Feeders > Squirrel Feeders', ''),
(3058, 'Home
& Garden > Decor > Bird & Wildlife House Accessories', ''),
(3059, 'Home & Garden > Decor > Bird & Wildlife Houses > Bat
Houses', ''),
(3060, 'Home & Garden > Decor > Bird & Wildlife Houses > Birdhouses', ''),
(3061, 'Home & Garden > Decor >
Bird & Wildlife Houses > Butterfly Houses', ''),
(3062, 'Home & Garden > Decor > Bird Baths', ''),
(3063, 'Home & Garden
> Decor > Bookends', ''),
(3064, 'Home & Garden > Decor > Cardboard Cutouts', ''),
(3065, 'Home & Garden > Decor > Chair
& Sofa Cushions', ''),
(3066, 'Home & Garden > Decor > Clock Parts', ''),
(3067, 'Home & Garden > Decor > Clocks > Alarm
Clocks', ''),
(3068, 'Home & Garden > Decor > Clocks > Desk & Shelf Clocks', ''),
(3069, 'Home & Garden > Decor > Clocks
> Floor & Grandfather Clocks', ''),
(3070, 'Home & Garden > Decor > Clocks > Wall Clocks', ''),
(3071, 'Home & Garden >
Decor > Coat & Hat Racks', ''),
(3072, 'Home & Garden > Decor > Decorative Bells', ''),
(3073, 'Home & Garden > Decor >
Decorative Bottles', ''),
(3074, 'Home & Garden > Decor > Decorative Bowls', ''),
(3075, 'Home & Garden > Decor >
Decorative Jars', ''),
(3076, 'Home & Garden > Decor > Decorative Plaques', ''),
(3077, 'Home & Garden > Decor >
Decorative Plates', ''),
(3078, 'Home & Garden > Decor > Decorative Trays', ''),
(3079, 'Home & Garden > Decor > Door
Mats', ''),
(3080, 'Home & Garden > Decor > Dreamcatchers', ''),
(3081, 'Home & Garden > Decor > Dried Flowers', ''),
(3082, 'Home & Garden > Decor > Ecospheres', ''),
(3083, 'Home & Garden > Decor > Figurines', ''),
(3084, 'Home & Garden
> Decor > Finials', ''),
(3085, 'Home & Garden > Decor > Flag & Windsock Accessories > Flag & Windsock Pole Lights',
''),
(3086, 'Home & Garden > Decor > Flag & Windsock Accessories > Flag & Windsock Pole Mounting Hardware & Kits', ''),
(3087, 'Home & Garden > Decor > Flag & Windsock Accessories > Flag & Windsock Poles', ''),
(3088, 'Home & Garden > Decor
> Flags & Windsocks', ''),
(3089, 'Home & Garden > Decor > Flameless Candles', ''),
(3090, 'Home & Garden > Decor >
Fountains & Ponds > Fountain & Pond Accessories', ''),
(3091, 'Home & Garden > Decor > Fountains & Ponds > Fountains &
Waterfalls', ''),
(3092, 'Home & Garden > Decor > Fountains & Ponds > Ponds', ''),
(3093, 'Home & Garden > Decor >
Garden & Stepping Stones', ''),
(3094, 'Home & Garden > Decor > Growth Charts', ''),
(3095, 'Home & Garden > Decor >
Home Decor Decals', ''),
(3096, 'Home & Garden > Decor > Home Fragrance Accessories > Candle & Oil Warmers', ''),
(3097,
'Home & Garden > Decor > Home Fragrance Accessories > Candle Holders', ''),
(3098, 'Home & Garden > Decor > Home
Fragrance Accessories > Candle Snuffers', ''),
(3099, 'Home & Garden > Decor > Home Fragrance Accessories > Incense
Holders', ''),
(3100, 'Home & Garden > Decor > Home Fragrances > Air Fresheners', ''),
(3101, 'Home & Garden > Decor >
Home Fragrances > Candles', ''),
(3102, 'Home & Garden > Decor > Home Fragrances > Fragrance Oil', ''),
(3103, 'Home &
Garden > Decor > Home Fragrances > Incense', ''),
(3104, 'Home & Garden > Decor > Home Fragrances > Potpourri', ''),
(3105, 'Home & Garden > Decor > Home Fragrances > Wax Tarts', ''),
(3106, 'Home & Garden > Decor > Hourglasses', ''),
(3107, 'Home & Garden > Decor > House Numbers & Letters', ''),
(3108, 'Home & Garden > Decor > Lawn Ornaments & Garden
Sculptures', ''),
(3109, 'Home & Garden > Decor > Mail Slots', ''),
(3110, 'Home & Garden > Decor > Mailbox Accessories
> Mailbox Covers', ''),
(3111, 'Home & Garden > Decor > Mailbox Accessories > Mailbox Enclosures', ''),
(3112, 'Home &
Garden > Decor > Mailbox Accessories > Mailbox Flags', ''),
(3113, 'Home & Garden > Decor > Mailbox Accessories >
Mailbox Posts', ''),
(3114, 'Home & Garden > Decor > Mailbox Accessories > Mailbox Replacement Doors', ''),
(3115, 'Home
& Garden > Decor > Mailboxes', ''),
(3116, 'Home & Garden > Decor > Mirrors', ''),
(3117, 'Home & Garden > Decor > Music
Boxes', ''),
(3118, 'Home & Garden > Decor > Napkin Rings', ''),
(3119, 'Home & Garden > Decor > Novelty Signs', ''),
(3120, 'Home & Garden > Decor > Ottoman Cushions', ''),
(3121, 'Home & Garden > Decor > Picture Frames', ''),
(3122,
'Home & Garden > Decor > Piggy Banks & Money Jars', ''),
(3123, 'Home & Garden > Decor > Rain Chains', ''),
(3124, 'Home
& Garden > Decor > Rain Gauges', ''),
(3125, 'Home & Garden > Decor > Refrigerator Magnets', ''),
(3126, 'Home & Garden
> Decor > Rugs', ''),
(3127, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Advent Calendars', ''),
(3128,
'Home & Garden > Decor > Seasonal & Holiday Decorations > Christmas Tree Skirts', ''),
(3129, 'Home & Garden > Decor >
Seasonal & Holiday Decorations > Christmas Tree Stands', ''),
(3130, 'Home & Garden > Decor > Seasonal & Holiday
Decorations > Easter Egg Decorating Kits', ''),
(3131, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Holiday
Ornament Displays & Stands', ''),
(3132, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Holiday Ornament
Hooks', ''),
(3133, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Holiday Ornaments', ''),
(3134, 'Home &
Garden > Decor > Seasonal & Holiday Decorations > Holiday Stocking Hangers', ''),
(3135, 'Home & Garden > Decor >
Seasonal & Holiday Decorations > Holiday Stockings', ''),
(3136, 'Home & Garden > Decor > Seasonal & Holiday Decorations
> Japanese Traditional Dolls', ''),
(3137, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Nativity Sets',
''),
(3138, 'Home & Garden > Decor > Seasonal & Holiday Decorations > Seasonal Village Sets & Accessories', ''),
(3139,
'Home & Garden > Decor > Shadow Boxes', ''),
(3140, 'Home & Garden > Decor > Slipcovers', ''),
(3141, 'Home & Garden >
Decor > Snow Globes', ''),
(3142, 'Home & Garden > Decor > Suncatchers', ''),
(3143, 'Home & Garden > Decor > Sundials',
''),
(3144, 'Home & Garden > Decor > Throw Pillows', ''),
(3145, 'Home & Garden > Decor > Trunks', ''),
(3146, 'Home &
Garden > Decor > Vase Fillers & Table Scatters', ''),
(3147, 'Home & Garden > Decor > Vases', ''),
(3148, 'Home & Garden
> Decor > Wallpaper', ''),
(3149, 'Home & Garden > Decor > Weather Vanes & Roof Decor', ''),
(3150, 'Home & Garden >
Decor > Wind Chimes', ''),
(3151, 'Home & Garden > Decor > Wind Wheels & Spinners', ''),
(3152, 'Home & Garden > Decor >
Window Magnets', ''),
(3153, 'Home & Garden > Decor > Window Treatment Accessories > Curtain & Drape Rings', ''),
(3154,
'Home & Garden > Decor > Window Treatment Accessories > Curtain & Drape Rods', ''),
(3155, 'Home & Garden > Decor >
Window Treatment Accessories > Curtain Holdbacks & Tassels', ''),
(3156, 'Home & Garden > Decor > Window Treatment
Accessories > Window Treatment Replacement Parts', ''),
(3157, 'Home & Garden > Decor > Window Treatments > Curtains &
Drapes', ''),
(3158, 'Home & Garden > Decor > Window Treatments > Stained Glass Panels', ''),
(3159, 'Home & Garden >
Decor > Window Treatments > Window Blinds & Shades', ''),
(3160, 'Home & Garden > Decor > Window Treatments > Window
Films', ''),
(3161, 'Home & Garden > Decor > Window Treatments > Window Screens', ''),
(3162, 'Home & Garden > Decor >
Window Treatments > Window Valances & Cornices', ''),
(3163, 'Home & Garden > Decor > World Globes', ''),
(3164, 'Home &
Garden > Decor > Wreaths & Garlands', ''),
(3165, 'Home & Garden > Emergency Preparedness > Earthquake Alarms', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (3166,
'Home & Garden > Emergency Preparedness > Emergency Blankets', ''),
(3167, 'Home & Garden > Emergency Preparedness >
Emergency Food Kits', ''),
(3168, 'Home & Garden > Emergency Preparedness > Emergency Tools & Kits', ''),
(3169, 'Home &
Garden > Emergency Preparedness > Furniture Anchors', ''),
(3170, 'Home & Garden > Fireplace & Wood Stove Accessories >
Bellows', ''),
(3171, 'Home & Garden > Fireplace & Wood Stove Accessories > Fireplace & Wood Stove Grates', ''),
(3172,
'Home & Garden > Fireplace & Wood Stove Accessories > Fireplace Andirons', ''),
(3173, 'Home & Garden > Fireplace & Wood
Stove Accessories > Fireplace Reflectors', ''),
(3174, 'Home & Garden > Fireplace & Wood Stove Accessories > Fireplace
Screens', ''),
(3175, 'Home & Garden > Fireplace & Wood Stove Accessories > Fireplace Tools', ''),
(3176, 'Home & Garden
> Fireplace & Wood Stove Accessories > Firewood & Fuel', ''),
(3177, 'Home & Garden > Fireplace & Wood Stove Accessories
> Hearth Pads', ''),
(3178, 'Home & Garden > Fireplace & Wood Stove Accessories > Log Rack & Carrier Accessories', ''),
(3179, 'Home & Garden > Fireplace & Wood Stove Accessories > Log Racks & Carriers', ''),
(3180, 'Home & Garden >
Fireplace & Wood Stove Accessories > Wood Stove Fans & Blowers', ''),
(3181, 'Home & Garden > Fireplaces', ''),
(3182,
'Home & Garden > Flood,Fire & Gas Safety > Fire Alarm Control Panels', ''),
(3183, 'Home & Garden > Flood,Fire & Gas
Safety > Fire Alarms', ''),
(3184, 'Home & Garden > Flood,Fire & Gas Safety > Fire Extinguisher & Equipment Storage',
''),
(3185, 'Home & Garden > Flood,Fire & Gas Safety > Fire Extinguishers', ''),
(3186, 'Home & Garden > Flood,Fire &
Gas Safety > Fire Sprinklers', ''),
(3187, 'Home & Garden > Flood,Fire & Gas Safety > Heat Detectors', ''),
(3188, 'Home
& Garden > Flood,Fire & Gas Safety > Smoke & Carbon Monoxide Detectors', ''),
(3189, 'Home & Garden > Flood,Fire & Gas
Safety > Water & Flood Detectors', ''),
(3190, 'Home & Garden > Household Appliance Accessories > Air Conditioner
Accessories > Air Conditioner Covers', ''),
(3191, 'Home & Garden > Household Appliance Accessories > Air Conditioner
Accessories > Air Conditioner Filters', ''),
(3192, 'Home & Garden > Household Appliance Accessories > Air Purifier
Accessories', ''),
(3193, 'Home & Garden > Household Appliance Accessories > Air Purifier Accessories > Air Purifier
Filters', ''),
(3194, 'Home & Garden > Household Appliance Accessories > Dehumidifier Accessories', ''),
(3195, 'Home &
Garden > Household Appliance Accessories > Fan Accessories', ''),
(3196, 'Home & Garden > Household Appliance
Accessories > Floor & Steam Cleaner Accessories', ''),
(3197, 'Home & Garden > Household Appliance Accessories > Furnace
& Boiler Accessories', ''),
(3198, 'Home & Garden > Household Appliance Accessories > Heating Radiator Accessories',
''),
(3199, 'Home & Garden > Household Appliance Accessories > Heating Radiator Accessories > Heating Radiator
Reflectors', ''),
(3200, 'Home & Garden > Household Appliance Accessories > Humidifier Accessories', ''),
(3201, 'Home &
Garden > Household Appliance Accessories > Humidifier Accessories > Humidifier Filters', ''),
(3202, 'Home & Garden >
Household Appliance Accessories > Laundry Appliance Accessories > Garment Steamer Accessories', ''),
(3203, 'Home &
Garden > Household Appliance Accessories > Laundry Appliance Accessories > Iron Accessories', ''),
(3204, 'Home & Garden
> Household Appliance Accessories > Laundry Appliance Accessories > Steam Press Accessories', ''),
(3205, 'Home & Garden
> Household Appliance Accessories > Laundry Appliance Accessories > Washer & Dryer Accessories', ''),
(3206, 'Home &
Garden > Household Appliance Accessories > Patio Heater Accessories', ''),
(3207, 'Home & Garden > Household Appliance
Accessories > Patio Heater Accessories > Patio Heater Covers', ''),
(3208, 'Home & Garden > Household Appliance
Accessories > Vacuum Accessories', ''),
(3209, 'Home & Garden > Household Appliance Accessories > Water Heater
Accessories > Anode Rods', ''),
(3210, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Hot
Water Tanks', ''),
(3211, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Water Heater
Elements', ''),
(3212, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Water Heater
Expansion Tanks', ''),
(3213, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Water Heater
Pans', ''),
(3214, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Water Heater Stacks',
''),
(3215, 'Home & Garden > Household Appliance Accessories > Water Heater Accessories > Water Heater Vents', ''),
(3216, 'Home & Garden > Household Appliances > Climate Control Appliances > Air Conditioners', ''),
(3217, 'Home &
Garden > Household Appliances > Climate Control Appliances > Air Purifiers', ''),
(3218, 'Home & Garden > Household
Appliances > Climate Control Appliances > Dehumidifiers', ''),
(3219, 'Home & Garden > Household Appliances > Climate
Control Appliances > Duct Heaters', ''),
(3220, 'Home & Garden > Household Appliances > Climate Control Appliances >
Evaporative Coolers', ''),
(3221, 'Home & Garden > Household Appliances > Climate Control Appliances > Fans > Ceiling
Fans', ''),
(3222, 'Home & Garden > Household Appliances > Climate Control Appliances > Fans > Desk & Pedestal Fans',
''),
(3223, 'Home & Garden > Household Appliances > Climate Control Appliances > Fans > Powered Hand Fans & Misters',
''),
(3224, 'Home & Garden > Household Appliances > Climate Control Appliances > Fans > Ventilation Fans', ''),
(3225,
'Home & Garden > Household Appliances > Climate Control Appliances > Fans > Wall Mount Fans', ''),
(3226, 'Home & Garden
> Household Appliances > Climate Control Appliances > Furnaces & Boilers', ''),
(3227, 'Home & Garden > Household
Appliances > Climate Control Appliances > Heating Radiators', ''),
(3228, 'Home & Garden > Household Appliances >
Climate Control Appliances > Humidifiers', ''),
(3229, 'Home & Garden > Household Appliances > Climate Control
Appliances > Outdoor Misting Systems', ''),
(3230, 'Home & Garden > Household Appliances > Climate Control Appliances >
Patio Heaters', ''),
(3231, 'Home & Garden > Household Appliances > Climate Control Appliances > Space Heaters', ''),
(3232, 'Home & Garden > Household Appliances > Floor & Carpet Dryers', ''),
(3233, 'Home & Garden > Household Appliances
> Floor & Steam Cleaners', ''),
(3234, 'Home & Garden > Household Appliances > Floor Polishers & Buffers', ''),
(3235,
'Home & Garden > Household Appliances > Futon Dryers', ''),
(3236, 'Home & Garden > Household Appliances > Garage Door
Keypads & Remotes', ''),
(3237, 'Home & Garden > Household Appliances > Garage Door Openers', ''),
(3238, 'Home & Garden
> Household Appliances > Laundry Appliances > Dryers', ''),
(3239, 'Home & Garden > Household Appliances > Laundry
Appliances > Garment Steamers', ''),
(3240, 'Home & Garden > Household Appliances > Laundry Appliances > Irons & Ironing
Systems', ''),
(3241, 'Home & Garden > Household Appliances > Laundry Appliances > Laundry Combo Units', ''),
(3242,
'Home & Garden > Household Appliances > Laundry Appliances > Steam Presses', ''),
(3243, 'Home & Garden > Household
Appliances > Laundry Appliances > Washing Machines', ''),
(3244, 'Home & Garden > Household Appliances > Ultrasonic
Cleaners', ''),
(3245, 'Home & Garden > Household Appliances > Vacuums', ''),
(3246, 'Home & Garden > Household
Appliances > Wallpaper Steamers', ''),
(3247, 'Home & Garden > Household Appliances > Water Heaters', ''),
(3248, 'Home
& Garden > Household Supplies > Drawer & Shelf Liners', ''),
(3249, 'Home & Garden > Household Supplies > Floor
Protection Films & Runners', ''),
(3250, 'Home & Garden > Household Supplies > Furniture Floor Protectors', ''),
(3251,
'Home & Garden > Household Supplies > Garage Floor Mats', ''),
(3252, 'Home & Garden > Household Supplies > Garbage
Bags', ''),
(3253, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Broom & Mop Handles', ''),
(3254,
'Home & Garden > Household Supplies > Household Cleaning Supplies > Broom Heads', ''),
(3255, 'Home & Garden > Household
Supplies > Household Cleaning Supplies > Brooms', ''),
(3256, 'Home & Garden > Household Supplies > Household Cleaning
Supplies > Buckets', ''),
(3257, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Carpet Sweepers',
''),
(3258, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Cleaning Gloves', ''),
(3259, 'Home &
Garden > Household Supplies > Household Cleaning Supplies > Duster Refills', ''),
(3260, 'Home & Garden > Household
Supplies > Household Cleaning Supplies > Dusters', ''),
(3261, 'Home & Garden > Household Supplies > Household Cleaning
Supplies > Dustpans', ''),
(3262, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Fabric &
Upholstery Protectors', ''),
(3263, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Household
Cleaning Products > All-Purpose Cleaners', ''),
(3264, 'Home & Garden > Household Supplies > Household Cleaning Supplies
> Household Cleaning Products > Carpet Cleaners', ''),
(3265, 'Home & Garden > Household Supplies > Household Cleaning
Supplies > Household Cleaning Products > Descalers & Decalcifiers', ''),
(3266, 'Home & Garden > Household Supplies >
Household Cleaning Supplies > Household Cleaning Products > Dish Detergent & Soap', ''),
(3267, 'Home & Garden >
Household Supplies > Household Cleaning Supplies > Household Cleaning Products > Dishwasher Cleaners', ''),
(3268, 'Home
& Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning Products > Fabric & Upholstery
Cleaners', ''),
(3269, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning Products >
Floor Cleaners', ''),
(3270, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning
Products > Furniture Cleaners & Polish', ''),
(3271, 'Home & Garden > Household Supplies > Household Cleaning Supplies >
Household Cleaning Products > Glass & Surface Cleaners', ''),
(3272, 'Home & Garden > Household Supplies > Household
Cleaning Supplies > Household Cleaning Products > Household Disinfectants', ''),
(3273, 'Home & Garden > Household
Supplies > Household Cleaning Supplies > Household Cleaning Products > Oven & Grill Cleaners', ''),
(3274, 'Home &
Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning Products > Pet Odor & Stain Removers',
''),
(3275, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning Products > Rinse
Aids', ''),
(3276, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Household Cleaning Products >
Stainless Steel Cleaners & Polishes', ''),
(3277, 'Home & Garden > Household Supplies > Household Cleaning Supplies >
Household Cleaning Products > Toilet Bowl Cleaners', ''),
(3278, 'Home & Garden > Household Supplies > Household
Cleaning Supplies > Household Cleaning Products > Tub & Tile Cleaners', ''),
(3279, 'Home & Garden > Household Supplies
> Household Cleaning Supplies > Household Cleaning Products > Washing Machine Cleaners', ''),
(3280, 'Home & Garden >
Household Supplies > Household Cleaning Supplies > Mop Heads & Refills', ''),
(3281, 'Home & Garden > Household Supplies
> Household Cleaning Supplies > Mops', ''),
(3282, 'Home & Garden > Household Supplies > Household Cleaning Supplies >
Scrub Brush Heads & Refills', ''),
(3283, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Scrub
Brushes', ''),
(3284, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Shop Towels & General-Purpose
Cleaning Cloths', ''),
(3285, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Sponges & Scouring
Pads', ''),
(3286, 'Home & Garden > Household Supplies > Household Cleaning Supplies > Squeegees', ''),
(3287, 'Home &
Garden > Household Supplies > Household Paper Products > Facial Tissues', ''),
(3288, 'Home & Garden > Household
Supplies > Household Paper Products > Paper Napkins', ''),
(3289, 'Home & Garden > Household Supplies > Household Paper
Products > Paper Towels', ''),
(3290, 'Home & Garden > Household Supplies > Household Paper Products > Toilet Paper',
''),
(3291, 'Home & Garden > Household Supplies > Household Thermometers', ''),
(3292, 'Home & Garden > Household
Supplies > Laundry Supplies > Bleach', ''),
(3293, 'Home & Garden > Household Supplies > Laundry Supplies >
Clothespins', ''),
(3294, 'Home & Garden > Household Supplies > Laundry Supplies > Dry Cleaning Kits', ''),
(3295, 'Home
& Garden > Household Supplies > Laundry Supplies > Drying Racks & Hangers', ''),
(3296, 'Home & Garden > Household
Supplies > Laundry Supplies > Fabric Refreshers', ''),
(3297, 'Home & Garden > Household Supplies > Laundry Supplies >
Fabric Shavers', ''),
(3298, 'Home & Garden > Household Supplies > Laundry Supplies > Fabric Softeners & Dryer Sheets',
''),
(3299, 'Home & Garden > Household Supplies > Laundry Supplies > Fabric Stain Removers', ''),
(3300, 'Home & Garden
> Household Supplies > Laundry Supplies > Fabric Starch', ''),
(3301, 'Home & Garden > Household Supplies > Laundry
Supplies > Garment Shields', ''),
(3302, 'Home & Garden > Household Supplies > Laundry Supplies > Iron Rests', ''),
(3303, 'Home & Garden > Household Supplies > Laundry Supplies > Ironing Board Pads & Covers', ''),
(3304, 'Home & Garden
> Household Supplies > Laundry Supplies > Ironing Board Replacement Parts', ''),
(3305, 'Home & Garden > Household
Supplies > Laundry Supplies > Ironing Boards', ''),
(3306, 'Home & Garden > Household Supplies > Laundry Supplies >
Laundry Balls', ''),
(3307, 'Home & Garden > Household Supplies > Laundry Supplies > Laundry Baskets', ''),
(3308, 'Home
& Garden > Household Supplies > Laundry Supplies > Laundry Detergent', ''),
(3309, 'Home & Garden > Household Supplies >
Laundry Supplies > Laundry Wash Bags & Frames', ''),
(3310, 'Home & Garden > Household Supplies > Laundry Supplies >
Lint Rollers', ''),
(3311, 'Home & Garden > Household Supplies > Laundry Supplies > Wrinkle Releasers & Anti-Static
Sprays', ''),
(3312, 'Home & Garden > Household Supplies > Moisture Absorbers', ''),
(3313, 'Home & Garden > Household
Supplies > Pest Control > Fly Swatters', ''),
(3314, 'Home & Garden > Household Supplies > Pest Control > Pest Control
Traps', ''),
(3315, 'Home & Garden > Household Supplies > Pest Control > Pesticides', ''),
(3316, 'Home & Garden >
Household Supplies > Pest Control > Repellents > Animal & Pet Repellents', ''),
(3317, 'Home & Garden > Household
Supplies > Pest Control > Repellents > Household Insect Repellents', ''),
(3318, 'Home & Garden > Household Supplies >
Rug Pads', ''),
(3319, 'Home & Garden > Household Supplies > Shoe Care & Tools > Boot Pulls', ''),
(3320, 'Home & Garden
> Household Supplies > Shoe Care & Tools > Shoe Bags', ''),
(3321, 'Home & Garden > Household Supplies > Shoe Care &
Tools > Shoe Brushes', ''),
(3322, 'Home & Garden > Household Supplies > Shoe Care & Tools > Shoe Care Kits', ''),
(3323, 'Home & Garden > Household Supplies > Shoe Care & Tools > Shoe Dryers', ''),
(3324, 'Home & Garden > Household
Supplies > Shoe Care & Tools > Shoe Horns & Dressing Aids', ''),
(3325, 'Home & Garden > Household Supplies > Shoe Care
& Tools > Shoe Polishers', ''),
(3326, 'Home & Garden > Household Supplies > Shoe Care & Tools > Shoe Polishes & Waxes',
''),
(3327, 'Home & Garden > Household Supplies > Shoe Care & Tools > Shoe Scrapers', ''),
(3328, 'Home & Garden >
Household Supplies > Shoe Care & Tools > Shoe Treatments & Dyes', ''),
(3329, 'Home & Garden > Household Supplies > Shoe
Care & Tools > Shoe Trees & Shapers', ''),
(3330, 'Home & Garden > Household Supplies > Stair Treads', ''),
(3331, 'Home
& Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Charging Valets', ''),
(3332, 'Home
& Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Closet Organizers & Garment Racks',
''),
(3333, 'Home & Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Clothes Valets',
''),
(3334, 'Home & Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Hangers', ''),
(3335, 'Home & Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Hat Boxes', ''),
(3336, 'Home & Garden > Household Supplies > Storage & Organization > Clothing & Closet Storage > Shoe Racks &
Organizers', ''),
(3337, 'Home & Garden > Household Supplies > Storage & Organization > Flatware Chests', ''),
(3338,
'Home & Garden > Household Supplies > Storage & Organization > Household Drawer Organizer Inserts', ''),
(3339, 'Home &
Garden > Household Supplies > Storage & Organization > Household Storage Bags', ''),
(3340, 'Home & Garden > Household
Supplies > Storage & Organization > Household Storage Caddies', ''),
(3341, 'Home & Garden > Household Supplies >
Storage & Organization > Household Storage Containers', ''),
(3342, 'Home & Garden > Household Supplies > Storage &
Organization > Household Storage Drawers', ''),
(3343, 'Home & Garden > Household Supplies > Storage & Organization >
Photo Storage > Photo Albums', ''),
(3344, 'Home & Garden > Household Supplies > Storage & Organization > Photo Storage
> Photo Storage Boxes', ''),
(3345, 'Home & Garden > Household Supplies > Storage & Organization > Storage Hooks & Racks
> Ironing Board Hooks & Racks', ''),
(3346, 'Home & Garden > Household Supplies > Storage & Organization > Storage Hooks
& Racks > Umbrella Stands & Racks', ''),
(3347, 'Home & Garden > Household Supplies > Storage & Organization > Storage
Hooks & Racks > Utility Hooks', ''),
(3348, 'Home & Garden > Household Supplies > Trash Compactor Accessories', ''),
(3349, 'Home & Garden > Household Supplies > Waste Containment > Dumpsters', ''),
(3350, 'Home & Garden > Household
Supplies > Waste Containment > Hazardous Waste Containers', ''),
(3351, 'Home & Garden > Household Supplies > Waste
Containment > Recycling Containers', ''),
(3352, 'Home & Garden > Household Supplies > Waste Containment > Trash Cans &
Wastebaskets', ''),
(3353, 'Home & Garden > Household Supplies > Waste Containment Accessories > Waste Container Carts',
''),
(3354, 'Home & Garden > Household Supplies > Waste Containment Accessories > Waste Container Enclosures', ''),
(3355, 'Home & Garden > Household Supplies > Waste Containment Accessories > Waste Container Labels & Signs', ''),
(3356, 'Home & Garden > Household Supplies > Waste Containment Accessories > Waste Container Lids', ''),
(3357, 'Home &
Garden > Household Supplies > Waste Containment Accessories > Waste Container Wheels', ''),
(3358, 'Home & Garden >
Kitchen & Dining > Barware > Absinthe Fountains', ''),
(3359, 'Home & Garden > Kitchen & Dining > Barware > Beer
Dispensers & Taps', ''),
(3360, 'Home & Garden > Kitchen & Dining > Barware > Beverage Chilling Cubes & Sticks', ''),
(3361, 'Home & Garden > Kitchen & Dining > Barware > Beverage Tubs & Chillers', ''),
(3362, 'Home & Garden > Kitchen &
Dining > Barware > Bottle Caps', ''),
(3363, 'Home & Garden > Kitchen & Dining > Barware > Bottle Stoppers & Savers',
''),
(3364, 'Home & Garden > Kitchen & Dining > Barware > Coaster Holders', ''),
(3365, 'Home & Garden > Kitchen &
Dining > Barware > Coasters', ''),
(3366, 'Home & Garden > Kitchen & Dining > Barware > Cocktail & Barware Tool Sets',
''),
(3367, 'Home & Garden > Kitchen & Dining > Barware > Cocktail Shakers & Tools > Bar Ice Picks', ''),
(3368, 'Home &
Garden > Kitchen & Dining > Barware > Cocktail Shakers & Tools > Bottle Openers', ''),
(3369, 'Home & Garden > Kitchen &
Dining > Barware > Cocktail Shakers & Tools > Cocktail Shakers', ''),
(3370, 'Home & Garden > Kitchen & Dining > Barware
> Cocktail Shakers & Tools > Cocktail Strainers', ''),
(3371, 'Home & Garden > Kitchen & Dining > Barware > Cocktail
Shakers & Tools > Muddlers', ''),
(3372, 'Home & Garden > Kitchen & Dining > Barware > Corkscrews', ''),
(3373, 'Home &
Garden > Kitchen & Dining > Barware > Decanters', ''),
(3374, 'Home & Garden > Kitchen & Dining > Barware > Foil
Cutters', ''),
(3375, 'Home & Garden > Kitchen & Dining > Barware > Wine Aerators', ''),
(3376, 'Home & Garden > Kitchen
& Dining > Barware > Wine Bottle Holders', ''),
(3377, 'Home & Garden > Kitchen & Dining > Barware > Wine Glass Charms',
''),
(3378, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware > Bakeware Sets', ''),
(3379, 'Home &
Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware > Baking & Cookie Sheets', ''),
(3380, 'Home & Garden >
Kitchen & Dining > Cookware & Bakeware > Bakeware > Bread Pans & Molds', ''),
(3381, 'Home & Garden > Kitchen & Dining >
Cookware & Bakeware > Bakeware > Broiling Pans', ''),
(3382, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware >
Bakeware > Cake Pans & Molds', ''),
(3383, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware > Muffin &
Pastry Pans', ''),
(3384, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware > Pie & Quiche Pans', ''),
(3385, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware > Pizza Pans', ''),
(3386, 'Home & Garden >
Kitchen & Dining > Cookware & Bakeware > Bakeware > Pizza Stones', ''),
(3387, 'Home & Garden > Kitchen & Dining >
Cookware & Bakeware > Bakeware > Ramekins & Souffle Dishes', ''),
(3388, 'Home & Garden > Kitchen & Dining > Cookware &
Bakeware > Bakeware > Roasting Pans', ''),
(3389, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware
Accessories > Baking Mats & Liners', ''),
(3390, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware
Accessories > Baking Weights', ''),
(3391, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Bakeware
Accessories > Roasting Pan Racks', ''),
(3392, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware &
Bakeware Combo Sets', ''),
(3393, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Casserole
Dishes', ''),
(3394, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Cookware Sets', ''),
(3395,
'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Cr├¬pe & Blini Pans', ''),
(3396, 'Home & Garden >
Kitchen & Dining > Cookware & Bakeware > Cookware > Double Boilers', ''),
(3397, 'Home & Garden > Kitchen & Dining >
Cookware & Bakeware > Cookware > Dutch Ovens', ''),
(3398, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware >
Cookware > Fermentation & Pickling Crocks', ''),
(3399, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware >
Cookware > Griddles & Grill Pans', ''),
(3400, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware >
Grill Presses', ''),
(3401, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Paella Pans', ''),
(3402, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Pressure Cookers & Canners', ''),
(3403,
'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Saucepans', ''),
(3404, 'Home & Garden > Kitchen &
Dining > Cookware & Bakeware > Cookware > Saut├® Pans', ''),
(3405, 'Home & Garden > Kitchen & Dining > Cookware &
Bakeware > Cookware > Skillets & Frying Pans', ''),
(3406, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware >
Cookware > Stock Pots', ''),
(3407, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Stovetop
Kettles', ''),
(3408, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Tagines & Clay Cooking Pots',
''),
(3409, 'Home & Garden > Kitchen & Dining > Cookware & Bakeware > Cookware > Woks', ''),
(3410, 'Home & Garden >
Kitchen & Dining > Cookware & Bakeware > Cookware Accessories > Pot & Pan Handles', ''),
(3411, 'Home & Garden > Kitchen
& Dining > Cookware & Bakeware > Cookware Accessories > Pot & Pan Lids', ''),
(3412, 'Home & Garden > Kitchen & Dining >
Cookware & Bakeware > Cookware Accessories > Pressure Cooker & Canner Accessories', ''),
(3413, 'Home & Garden > Kitchen
& Dining > Cookware & Bakeware > Cookware Accessories > Steamer Baskets', ''),
(3414, 'Home & Garden > Kitchen & Dining
> Cookware & Bakeware > Cookware Accessories > Wok Accessories > Wok Brushes', ''),
(3415, 'Home & Garden > Kitchen &
Dining > Cookware & Bakeware > Cookware Accessories > Wok Accessories > Wok Rings', ''),
(3416, 'Home & Garden > Kitchen
& Dining > Food & Beverage Carriers > Airpots', ''),
(3417, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers
> Canteens', ''),
(3418, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers > Coolers', ''),
(3419, 'Home &
Garden > Kitchen & Dining > Food & Beverage Carriers > Drink Sleeves', ''),
(3420, 'Home & Garden > Kitchen & Dining >
Food & Beverage Carriers > Drink Sleeves > Can & Bottle Sleeves', ''),
(3421, 'Home & Garden > Kitchen & Dining > Food &
Beverage Carriers > Drink Sleeves > Cup Sleeves', ''),
(3422, 'Home & Garden > Kitchen & Dining > Food & Beverage
Carriers > Flasks', ''),
(3423, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers > Insulated Bags', ''),
(3424, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers > Lunch Boxes & Totes', ''),
(3425, 'Home & Garden >
Kitchen & Dining > Food & Beverage Carriers > Picnic Baskets', ''),
(3426, 'Home & Garden > Kitchen & Dining > Food &
Beverage Carriers > Replacement Drink Lids', ''),
(3427, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers >
Thermoses', ''),
(3428, 'Home & Garden > Kitchen & Dining > Food & Beverage Carriers > Water Bottles', ''),
(3429, 'Home
& Garden > Kitchen & Dining > Food & Beverage Carriers > Wine Carrier Bags', ''),
(3430, 'Home & Garden > Kitchen &
Dining > Food Storage > Bread Boxes & Bags', ''),
(3431, 'Home & Garden > Kitchen & Dining > Food Storage > Candy
Buckets', ''),
(3432, 'Home & Garden > Kitchen & Dining > Food Storage > Cookie Jars', ''),
(3433, 'Home & Garden >
Kitchen & Dining > Food Storage > Food Container Covers', ''),
(3434, 'Home & Garden > Kitchen & Dining > Food Storage >
Food Storage Bags', ''),
(3435, 'Home & Garden > Kitchen & Dining > Food Storage > Food Storage Containers', ''),
(3436,
'Home & Garden > Kitchen & Dining > Food Storage > Food Wraps > Foil', ''),
(3437, 'Home & Garden > Kitchen & Dining >
Food Storage > Food Wraps > Parchment Paper', ''),
(3438, 'Home & Garden > Kitchen & Dining > Food Storage > Food Wraps
> Plastic Wrap', ''),
(3439, 'Home & Garden > Kitchen & Dining > Food Storage > Food Wraps > Wax Paper', ''),
(3440,
'Home & Garden > Kitchen & Dining > Food Storage > Honey Jars', ''),
(3441, 'Home & Garden > Kitchen & Dining > Food
Storage Accessories > Food & Beverage Labels', ''),
(3442, 'Home & Garden > Kitchen & Dining > Food Storage Accessories
> Food Wrap Dispensers', ''),
(3443, 'Home & Garden > Kitchen & Dining > Food Storage Accessories > Oxygen Absorbers',
''),
(3444, 'Home & Garden > Kitchen & Dining > Food Storage Accessories > Twist Ties & Bag Clips', ''),
(3445, 'Home &
Garden > Kitchen & Dining > Kitchen Appliance Accessories > Breadmaker Accessories', ''),
(3446, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso Machine Accessories > Coffee Decanter
Warmers', ''),
(3447, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso
Machine Accessories > Coffee Decanters', ''),
(3448, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories >
Coffee Maker & Espresso Machine Accessories > Coffee Filter Baskets', ''),
(3449, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Coffee Maker & Espresso Machine Accessories > Coffee Filters', ''),
(3450, 'Home &
Garden > Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso Machine Accessories > Coffee Grinder
Accessories', ''),
(3451, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso
Machine Accessories > Coffee Grinders', ''),
(3452, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories >
Coffee Maker & Espresso Machine Accessories > Coffee Maker & Espresso Machine Replacement Parts', ''),
(3453, 'Home &
Garden > Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso Machine Accessories > Coffee Maker
Water Filters', ''),
(3454, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Coffee Maker & Espresso
Machine Accessories > Frothing Pitchers', ''),
(3455, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories
> Coffee Maker & Espresso Machine Accessories > Portafilters', ''),
(3456, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Cooktop,Oven & Range Accessories', ''),
(3457, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Cotton Candy Machine Accessories', ''),
(3458, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Deep Fryer Accessories', ''),
(3459, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Dishwasher Parts & Accessories', ''),
(3460, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Electric Kettle Accessories', ''),
(3461, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Electric Skillet & Wok Accessories', ''),
(3462, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Fondue Set Accessories > Cooking Gel Fuels', ''),
(3463, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Fondue Set Accessories > Fondue Forks', ''),
(3464, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Fondue Set Accessories > Fondue Pot Stands', ''),
(3465, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Food Dehydrator Accessories > Food Dehydrator Sheets', ''),
(3466, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Food Dehydrator Accessories > Food Dehydrator Trays', ''),
(3467,
'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Food Grinder Accessories', ''),
(3468, 'Home &
Garden > Kitchen & Dining > Kitchen Appliance Accessories > Food Mixer & Blender Accessories', ''),
(3469, 'Home &
Garden > Kitchen & Dining > Kitchen Appliance Accessories > Freezer Accessories', ''),
(3470, 'Home & Garden > Kitchen &
Dining > Kitchen Appliance Accessories > Garbage Disposal Accessories', ''),
(3471, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Ice Cream Maker Accessories', ''),
(3472, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Ice Cream Maker Accessories > Ice Cream Maker Freezer Bowls', ''),
(3473, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Ice Crusher & Shaver Accessories', ''),
(3474, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Ice Maker Accessories', ''),
(3475, 'Home & Garden > Kitchen & Dining
> Kitchen Appliance Accessories > Juicer Accessories', ''),
(3476, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Microwave Oven Accessories', ''),
(3477, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories
> Outdoor Grill Accessories > Charcoal Briquettes', ''),
(3478, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Outdoor Grill Accessories > Charcoal Chimneys', ''),
(3479, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Outdoor Grill Accessories > Outdoor Grill Carts', ''),
(3480, 'Home & Garden > Kitchen & Dining
> Kitchen Appliance Accessories > Outdoor Grill Accessories > Outdoor Grill Covers', ''),
(3481, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Outdoor Grill Accessories > Outdoor Grill Racks & Toppers', ''),
(3482, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Outdoor Grill Accessories > Outdoor Grill
Replacement Parts', ''),
(3483, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Outdoor Grill
Accessories > Outdoor Grill Spits & Baskets', ''),
(3484, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Outdoor Grill Accessories > Outdoor Grilling Planks', ''),
(3485, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Outdoor Grill Accessories > Smoking Chips & Pellets', ''),
(3486, 'Home & Garden >
Kitchen & Dining > Kitchen Appliance Accessories > Pasta Maker Accessories', ''),
(3487, 'Home & Garden > Kitchen &
Dining > Kitchen Appliance Accessories > Popcorn Maker Accessories', ''),
(3488, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Portable Cooking Stove Accessories', ''),
(3489, 'Home & Garden > Kitchen & Dining >
Kitchen Appliance Accessories > Range Hood Accessories', ''),
(3490, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Refrigerator Accessories', ''),
(3491, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Soda Maker Accessories', ''),
(3492, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories >
Steam Table Accessories > Steam Table Pan Covers', ''),
(3493, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Steam Table Accessories > Steam Table Pans', ''),
(3494, 'Home & Garden > Kitchen & Dining > Kitchen
Appliance Accessories > Toaster Accessories', ''),
(3495, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Vacuum Sealer Accessories', ''),
(3496, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories
> Vacuum Sealer Accessories > Vacuum Sealer Bags', ''),
(3497, 'Home & Garden > Kitchen & Dining > Kitchen Appliance
Accessories > Waffle Iron Accessories', ''),
(3498, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories >
Water Cooler Accessories', ''),
(3499, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Water Cooler
Accessories > Water Cooler Bottles', ''),
(3500, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories >
Wine Fridge Accessories', ''),
(3501, 'Home & Garden > Kitchen & Dining > Kitchen Appliance Accessories > Yogurt Maker
Accessories', ''),
(3502, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Beverage Warmers', ''),
(3503, 'Home
& Garden > Kitchen & Dining > Kitchen Appliances > Breadmakers', ''),
(3504, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Chocolate Tempering Machines', ''),
(3505, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Coffee
Makers & Espresso Machines > Drip Coffee Makers', ''),
(3506, 'Home & Garden > Kitchen & Dining > Kitchen Appliances >
Coffee Makers & Espresso Machines > Electric & Stovetop Espresso Pots', ''),
(3507, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Coffee Makers & Espresso Machines > Espresso Machines', ''),
(3508, 'Home & Garden > Kitchen &
Dining > Kitchen Appliances > Coffee Makers & Espresso Machines > French Presses', ''),
(3509, 'Home & Garden > Kitchen
& Dining > Kitchen Appliances > Coffee Makers & Espresso Machines > Percolators', ''),
(3510, 'Home & Garden > Kitchen &
Dining > Kitchen Appliances > Coffee Makers & Espresso Machines > Vacuum Coffee Makers', ''),
(3511, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Cooktops', ''),
(3512, 'Home & Garden > Kitchen & Dining > Kitchen Appliances >
Cotton Candy Machines', ''),
(3513, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Deep Fryers', ''),
(3514,
'Home & Garden > Kitchen & Dining > Kitchen Appliances > Deli Slicers', ''),
(3515, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Dishwashers', ''),
(3516, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Electric
Griddles & Grills', ''),
(3517, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Electric Kettles', ''),
(3518,
'Home & Garden > Kitchen & Dining > Kitchen Appliances > Electric Skillets & Woks', ''),
(3519, 'Home & Garden > Kitchen
& Dining > Kitchen Appliances > Fondue Pots & Sets', ''),
(3520, 'Home & Garden > Kitchen & Dining > Kitchen Appliances
> Food Cookers & Steamers > Egg Cookers', ''),
(3521, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food
Cookers & Steamers > Food Steamers', ''),
(3522, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Cookers &
Steamers > Rice Cookers', ''),
(3523, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Cookers & Steamers >
Slow Cookers', ''),
(3524, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Cookers & Steamers > Thermal
Cookers', ''),
(3525, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Cookers & Steamers > Water Ovens',
''),
(3526, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Dehydrators', ''),
(3527, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Food Grinders & Mills', ''),
(3528, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Food Mixers & Blenders', ''),
(3529, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food
Smokers', ''),
(3530, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Warmers > Chafing Dishes', ''),
(3531, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Food Warmers > Food Heat Lamps', ''),
(3532, 'Home &
Garden > Kitchen & Dining > Kitchen Appliances > Food Warmers > Rice Keepers', ''),
(3533, 'Home & Garden > Kitchen &
Dining > Kitchen Appliances > Food Warmers > Steam Tables', ''),
(3534, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Freezers', ''),
(3535, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Frozen Drink Makers', ''),
(3536, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Garbage Disposals', ''),
(3537, 'Home & Garden > Kitchen
& Dining > Kitchen Appliances > Gas Griddles', ''),
(3538, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Hot
Drink Makers', ''),
(3539, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Hot Plates', ''),
(3540, 'Home &
Garden > Kitchen & Dining > Kitchen Appliances > Ice Cream Makers', ''),
(3541, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Ice Crushers & Shavers', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (3542,
'Home & Garden > Kitchen & Dining > Kitchen Appliances > Ice Makers', ''),
(3543, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Juicers', ''),
(3544, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Knife Sharpeners',
''),
(3545, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Microwave Ovens', ''),
(3546, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Milk Frothers & Steamers', ''),
(3547, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Mochi Makers', ''),
(3548, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Outdoor
Grills', ''),
(3549, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Ovens', ''),
(3550, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Pasta Makers', ''),
(3551, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Popcorn Makers', ''),
(3552, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Portable Cooking
Stoves', ''),
(3553, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Range Hoods', ''),
(3554, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Ranges', ''),
(3555, 'Home & Garden > Kitchen & Dining > Kitchen Appliances >
Refrigerators', ''),
(3556, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Roaster Ovens & Rotisseries', ''),
(3557, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Soda Makers', ''),
(3558, 'Home & Garden > Kitchen &
Dining > Kitchen Appliances > Soy Milk Makers', ''),
(3559, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Tea
Makers', ''),
(3560, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Countertop & Toaster
Ovens', ''),
(3561, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Donut Makers', ''),
(3562, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Muffin & Cupcake Makers', ''),
(3563, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Pizza Makers & Ovens', ''),
(3564,
'Home & Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Pizzelle Makers', ''),
(3565, 'Home &
Garden > Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Pretzel Makers', ''),
(3566, 'Home & Garden >
Kitchen & Dining > Kitchen Appliances > Toasters & Grills > Sandwich Makers', ''),
(3567, 'Home & Garden > Kitchen &
Dining > Kitchen Appliances > Toasters & Grills > Toasters', ''),
(3568, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Toasters & Grills > Tortilla & Flatbread Makers', ''),
(3569, 'Home & Garden > Kitchen & Dining > Kitchen
Appliances > Toasters & Grills > Waffle Irons', ''),
(3570, 'Home & Garden > Kitchen & Dining > Kitchen Appliances >
Trash Compactors', ''),
(3571, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Vacuum Sealers', ''),
(3572,
'Home & Garden > Kitchen & Dining > Kitchen Appliances > Water Coolers', ''),
(3573, 'Home & Garden > Kitchen & Dining >
Kitchen Appliances > Water Filters', ''),
(3574, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Wine Fridges',
''),
(3575, 'Home & Garden > Kitchen & Dining > Kitchen Appliances > Yogurt Makers', ''),
(3576, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Aprons', ''),
(3577, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Baking Peels', ''),
(3578, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Basters', ''),
(3579, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Basting Brushes', ''),
(3580, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Beverage Dispensers', ''),
(3581, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Cake Decorating Supplies', ''),
(3582, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Cake Servers', ''),
(3583, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Can Crushers', ''),
(3584, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Can Openers', ''),
(3585, 'Home & Garden > Kitchen
& Dining > Kitchen Tools & Utensils > Carving Forks', ''),
(3586, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Channel Knives', ''),
(3587, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Colanders &
Strainers', ''),
(3588, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Condiment Dispensers', ''),
(3589, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Cookie Cutters', ''),
(3590, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Cookie Presses', ''),
(3591, 'Home & Garden > Kitchen & Dining > Kitchen
Tools & Utensils > Cooking Thermometer Accessories', ''),
(3592, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Cooking Thermometers', ''),
(3593, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Cooking
Timers', ''),
(3594, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Cooking Torches', ''),
(3595, 'Home
& Garden > Kitchen & Dining > Kitchen Tools & Utensils > Cooling Racks', ''),
(3596, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Cutting Boards', ''),
(3597, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils >
Dish Racks & Drain Boards', ''),
(3598, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Dough Wheels',
''),
(3599, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Electric Knife Accessories', ''),
(3600,
'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Electric Knife Accessories > Electric Knife Replacement
Blades', ''),
(3601, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Electric Knives', ''),
(3602, 'Home
& Garden > Kitchen & Dining > Kitchen Tools & Utensils > Flour Sifters', ''),
(3603, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Food & Drink Stencils', ''),
(3604, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Food Crackers', ''),
(3605, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Crackers >
Lobster & Crab Crackers', ''),
(3606, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Crackers >
Nutcrackers', ''),
(3607, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Crackers > Nutcrackers >
Decorative Nutcrackers', ''),
(3608, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Dispensers',
''),
(3609, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Graters & Zesters', ''),
(3610, 'Home &
Garden > Kitchen & Dining > Kitchen Tools & Utensils > Food Peelers & Corers', ''),
(3611, 'Home & Garden > Kitchen &
Dining > Kitchen Tools & Utensils > Food Steaming Bags', ''),
(3612, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Food Sticks & Skewers', ''),
(3613, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Funnels',
''),
(3614, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Garlic Presses', ''),
(3615, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Gelatin Molds', ''),
(3616, 'Home & Garden > Kitchen & Dining > Kitchen
Tools & Utensils > Ice Cube Trays', ''),
(3617, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Jerky
Guns', ''),
(3618, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Knives', ''),
(3619, 'Home &
Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Molds', ''),
(3620, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Kitchen Organizers > Can Organizers', ''),
(3621, 'Home & Garden > Kitchen & Dining > Kitchen
Tools & Utensils > Kitchen Organizers > Drinkware Holders', ''),
(3622, 'Home & Garden > Kitchen & Dining > Kitchen
Tools & Utensils > Kitchen Organizers > Kitchen Cabinet Organizers', ''),
(3623, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Kitchen Organizers > Kitchen Counter & Beverage Station Organizers', ''),
(3624, 'Home &
Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Kitchen Utensil Holders & Racks', ''),
(3625, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Knife Blocks & Holders', ''),
(3626, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Napkin Holders & Dispensers',
''),
(3627, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Paper Towel Holders &
Dispensers', ''),
(3628, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Pot Racks',
''),
(3629, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Spice Organizers', ''),
(3630, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Straw Holders & Dispensers',
''),
(3631, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Sugar Caddies', ''),
(3632, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Toothpick Holders &
Dispensers', ''),
(3633, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Organizers > Utensil &
Flatware Trays', ''),
(3634, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Scrapers > Bench
Scrapers', ''),
(3635, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Scrapers > Bowl Scrapers',
''),
(3636, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Scrapers > Grill Scrapers', ''),
(3637, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Shears', ''),
(3638, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Kitchen Slicers', ''),
(3639, 'Home & Garden > Kitchen & Dining > Kitchen
Tools & Utensils > Kitchen Utensil Sets', ''),
(3640, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils >
Ladles', ''),
(3641, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Mashers', ''),
(3642, 'Home & Garden
> Kitchen & Dining > Kitchen Tools & Utensils > Measuring Cups & Spoons', ''),
(3643, 'Home & Garden > Kitchen & Dining
> Kitchen Tools & Utensils > Meat Tenderizers', ''),
(3644, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils
> Mixing Bowls', ''),
(3645, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Mortars & Pestles', ''),
(3646, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Oil & Vinegar Dispensers', ''),
(3647, 'Home &
Garden > Kitchen & Dining > Kitchen Tools & Utensils > Oven Bags', ''),
(3648, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Oven Mitts & Pot Holders', ''),
(3649, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Pasta Molds & Stamps', ''),
(3650, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Pastry
Blenders', ''),
(3651, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Pastry Cloths', ''),
(3652, 'Home
& Garden > Kitchen & Dining > Kitchen Tools & Utensils > Pizza Cutter Accessories', ''),
(3653, 'Home & Garden > Kitchen
& Dining > Kitchen Tools & Utensils > Pizza Cutters', ''),
(3654, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Ricers', ''),
(3655, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Rolling Pin Accessories >
Rolling Pin Covers & Sleeves', ''),
(3656, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Rolling Pin
Accessories > Rolling Pin Rings', ''),
(3657, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Rolling
Pins', ''),
(3658, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Salad Dressing Mixers & Shakers', ''),
(3659, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Salad Spinners', ''),
(3660, 'Home & Garden >
Kitchen & Dining > Kitchen Tools & Utensils > Scoops > Ice Cream Scoops', ''),
(3661, 'Home & Garden > Kitchen & Dining
> Kitchen Tools & Utensils > Scoops > Ice Scoops', ''),
(3662, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Scoops > Melon Ballers', ''),
(3663, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Scoops >
Popcorn & French Fry Scoops', ''),
(3664, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Sink Caddies',
''),
(3665, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Sink Mats & Grids', ''),
(3666, 'Home &
Garden > Kitchen & Dining > Kitchen Tools & Utensils > Slotted Spoons', ''),
(3667, 'Home & Garden > Kitchen & Dining >
Kitchen Tools & Utensils > Spatulas', ''),
(3668, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Spice
Grinder Accessories', ''),
(3669, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Spice Grinders', ''),
(3670, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Spoon Rests', ''),
(3671, 'Home & Garden > Kitchen
& Dining > Kitchen Tools & Utensils > Sugar Dispensers', ''),
(3672, 'Home & Garden > Kitchen & Dining > Kitchen Tools &
Utensils > Sushi Mats', ''),
(3673, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Tea Strainers', ''),
(3674, 'Home & Garden > Kitchen & Dining > Kitchen Tools & Utensils > Tongs', ''),
(3675, 'Home & Garden > Kitchen &
Dining > Kitchen Tools & Utensils > Whisks', ''),
(3676, 'Home & Garden > Kitchen & Dining > Prefabricated Kitchens &
Kitchenettes', ''),
(3677, 'Home & Garden > Kitchen & Dining > Tableware > Coffee & Tea Sets', ''),
(3678, 'Home &
Garden > Kitchen & Dining > Tableware > Coffee Servers & Tea Pots', ''),
(3679, 'Home & Garden > Kitchen & Dining >
Tableware > Dinnerware > Bowls', ''),
(3680, 'Home & Garden > Kitchen & Dining > Tableware > Dinnerware > Dinnerware
Sets', ''),
(3681, 'Home & Garden > Kitchen & Dining > Tableware > Dinnerware > Plates', ''),
(3682, 'Home & Garden >
Kitchen & Dining > Tableware > Drinkware > Beer Glasses', ''),
(3683, 'Home & Garden > Kitchen & Dining > Tableware >
Drinkware > Coffee & Tea Cups', ''),
(3684, 'Home & Garden > Kitchen & Dining > Tableware > Drinkware > Coffee & Tea
Saucers', ''),
(3685, 'Home & Garden > Kitchen & Dining > Tableware > Drinkware > Drinkware Sets', ''),
(3686, 'Home &
Garden > Kitchen & Dining > Tableware > Drinkware > Mugs', ''),
(3687, 'Home & Garden > Kitchen & Dining > Tableware >
Drinkware > Shot Glasses', ''),
(3688, 'Home & Garden > Kitchen & Dining > Tableware > Drinkware > Stemware', ''),
(3689, 'Home & Garden > Kitchen & Dining > Tableware > Drinkware > Tumblers', ''),
(3690, 'Home & Garden > Kitchen &
Dining > Tableware > Flatware > Chopstick Accessories', ''),
(3691, 'Home & Garden > Kitchen & Dining > Tableware >
Flatware > Chopsticks', ''),
(3692, 'Home & Garden > Kitchen & Dining > Tableware > Flatware > Flatware Sets', ''),
(3693, 'Home & Garden > Kitchen & Dining > Tableware > Flatware > Forks', ''),
(3694, 'Home & Garden > Kitchen & Dining
> Tableware > Flatware > Spoons', ''),
(3695, 'Home & Garden > Kitchen & Dining > Tableware > Flatware > Table Knives',
''),
(3696, 'Home & Garden > Kitchen & Dining > Tableware > Salt & Pepper Shakers', ''),
(3697, 'Home & Garden > Kitchen
& Dining > Tableware > Serveware > Butter Dishes', ''),
(3698, 'Home & Garden > Kitchen & Dining > Tableware > Serveware
> Cake Boards', ''),
(3699, 'Home & Garden > Kitchen & Dining > Tableware > Serveware > Cake Stands', ''),
(3700, 'Home
& Garden > Kitchen & Dining > Tableware > Serveware > Egg Cups', ''),
(3701, 'Home & Garden > Kitchen & Dining >
Tableware > Serveware > Gravy Boats', ''),
(3702, 'Home & Garden > Kitchen & Dining > Tableware > Serveware > Punch
Bowls', ''),
(3703, 'Home & Garden > Kitchen & Dining > Tableware > Serveware > Serving Pitchers & Carafes', ''),
(3704,
'Home & Garden > Kitchen & Dining > Tableware > Serveware > Serving Platters', ''),
(3705, 'Home & Garden > Kitchen &
Dining > Tableware > Serveware > Serving Trays', ''),
(3706, 'Home & Garden > Kitchen & Dining > Tableware > Serveware >
Sugar Bowls & Creamers', ''),
(3707, 'Home & Garden > Kitchen & Dining > Tableware > Serveware > Tureens', ''),
(3708,
'Home & Garden > Kitchen & Dining > Tableware > Serveware Accessories > Punch Bowl Stands', ''),
(3709, 'Home & Garden >
Kitchen & Dining > Tableware > Serveware Accessories > Tureen Lids', ''),
(3710, 'Home & Garden > Kitchen & Dining >
Tableware > Serveware Accessories > Tureen Stands', ''),
(3711, 'Home & Garden > Kitchen & Dining > Tableware >
Tablecloth Clips & Weights', ''),
(3712, 'Home & Garden > Kitchen & Dining > Tableware > Trivets', ''),
(3713, 'Home &
Garden > Lawn & Garden > Gardening > Composting > Compost', ''),
(3714, 'Home & Garden > Lawn & Garden > Gardening >
Composting > Compost Aerators', ''),
(3715, 'Home & Garden > Lawn & Garden > Gardening > Composting > Composters', ''),
(3716, 'Home & Garden > Lawn & Garden > Gardening > Disease Control', ''),
(3717, 'Home & Garden > Lawn & Garden >
Gardening > Fertilizers', ''),
(3718, 'Home & Garden > Lawn & Garden > Gardening > Garden Pot Saucers & Trays', ''),
(3719, 'Home & Garden > Lawn & Garden > Gardening > Gardening Accessories > Gardening Scooters,Seats & Kneelers', ''),
(3720, 'Home & Garden > Lawn & Garden > Gardening > Gardening Accessories > Gardening Totes', ''),
(3721, 'Home & Garden
> Lawn & Garden > Gardening > Gardening Accessories > Potting Benches', ''),
(3722, 'Home & Garden > Lawn & Garden >
Gardening > Gardening Tool Accessories > Gardening Tool Handles', ''),
(3723, 'Home & Garden > Lawn & Garden > Gardening
> Gardening Tool Accessories > Gardening Tool Heads', ''),
(3724, 'Home & Garden > Lawn & Garden > Gardening > Gardening
Tool Accessories > Wheelbarrow Parts', ''),
(3725, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Bulb
Planting Tools', ''),
(3726, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Cultivating Tools', ''),
(3727, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Gardening Forks', ''),
(3728, 'Home & Garden >
Lawn & Garden > Gardening > Gardening Tools > Gardening Sickles & Machetes', ''),
(3729, 'Home & Garden > Lawn & Garden
> Gardening > Gardening Tools > Gardening Trowels', ''),
(3730, 'Home & Garden > Lawn & Garden > Gardening > Gardening
Tools > Lawn & Garden Sprayers', ''),
(3731, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Lawn
Rollers', ''),
(3732, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Pruning Saws', ''),
(3733, 'Home &
Garden > Lawn & Garden > Gardening > Gardening Tools > Pruning Shears', ''),
(3734, 'Home & Garden > Lawn & Garden >
Gardening > Gardening Tools > Rakes', ''),
(3735, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Shovels
& Spades', ''),
(3736, 'Home & Garden > Lawn & Garden > Gardening > Gardening Tools > Spreaders', ''),
(3737, 'Home &
Garden > Lawn & Garden > Gardening > Gardening Tools > Wheelbarrows', ''),
(3738, 'Home & Garden > Lawn & Garden >
Gardening > Greenhouses', ''),
(3739, 'Home & Garden > Lawn & Garden > Gardening > Herbicides', ''),
(3740, 'Home &
Garden > Lawn & Garden > Gardening > Landscape Fabric', ''),
(3741, 'Home & Garden > Lawn & Garden > Gardening >
Landscape Fabric Accessories > Landscape Fabric Staples & Pins', ''),
(3742, 'Home & Garden > Lawn & Garden > Gardening
> Landscape Fabric Accessories > Landscape Fabric Tape', ''),
(3743, 'Home & Garden > Lawn & Garden > Gardening >
Mulch', ''),
(3744, 'Home & Garden > Lawn & Garden > Gardening > Plant Cages & Supports', ''),
(3745, 'Home & Garden >
Lawn & Garden > Gardening > Plant Stands', ''),
(3746, 'Home & Garden > Lawn & Garden > Gardening > Pot & Planter
Liners', ''),
(3747, 'Home & Garden > Lawn & Garden > Gardening > Pots & Planters', ''),
(3748, 'Home & Garden > Lawn &
Garden > Gardening > Rain Barrels', ''),
(3749, 'Home & Garden > Lawn & Garden > Gardening > Sands & Soils', ''),
(3750,
'Home & Garden > Lawn & Garden > Outdoor Living > Awning Accessories', ''),
(3751, 'Home & Garden > Lawn & Garden >
Outdoor Living > Awnings', ''),
(3752, 'Home & Garden > Lawn & Garden > Outdoor Living > Hammock Parts & Accessories',
''),
(3753, 'Home & Garden > Lawn & Garden > Outdoor Living > Hammocks', ''),
(3754, 'Home & Garden > Lawn & Garden >
Outdoor Living > Outdoor Blankets > Beach Mats', ''),
(3755, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor
Blankets > Picnic Blankets', ''),
(3756, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Blankets > Poncho
Liners', ''),
(3757, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Structures > Canopies & Gazebos', ''),
(3758, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Structures > Canopy & Gazebo Accessories > Canopy &
Gazebo Enclosure Kits', ''),
(3759, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Structures > Canopy &
Gazebo Accessories > Canopy & Gazebo Frames', ''),
(3760, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor
Structures > Canopy & Gazebo Accessories > Canopy & Gazebo Tops', ''),
(3761, 'Home & Garden > Lawn & Garden > Outdoor
Living > Outdoor Structures > Canopy & Gazebo Accessories > Canopy Poles', ''),
(3762, 'Home & Garden > Lawn & Garden >
Outdoor Living > Outdoor Structures > Canopy & Gazebo Accessories > Canopy Weights', ''),
(3763, 'Home & Garden > Lawn &
Garden > Outdoor Living > Outdoor Structures > Garden Arches,Trellises,Arbors & Pergolas', ''),
(3764, 'Home & Garden >
Lawn & Garden > Outdoor Living > Outdoor Structures > Garden Bridges', ''),
(3765, 'Home & Garden > Lawn & Garden >
Outdoor Living > Outdoor Structures > Sheds,Garages & Carports', ''),
(3766, 'Home & Garden > Lawn & Garden > Outdoor
Living > Outdoor Umbrella & Sunshade Accessories > Outdoor Umbrella & Sunshade Fabric', ''),
(3767, 'Home & Garden >
Lawn & Garden > Outdoor Living > Outdoor Umbrella & Sunshade Accessories > Outdoor Umbrella Bases', ''),
(3768, 'Home &
Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrella & Sunshade Accessories > Outdoor Umbrella Covers', ''),
(3769, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrella & Sunshade Accessories > Outdoor Umbrella
Enclosure Kits', ''),
(3770, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrella & Sunshade Accessories >
Outdoor Umbrella Lights', ''),
(3771, 'Home & Garden > Lawn & Garden > Outdoor Living > Outdoor Umbrellas & Sunshades',
''),
(3772, 'Home & Garden > Lawn & Garden > Outdoor Living > Porch Swing Accessories', ''),
(3773, 'Home & Garden >
Lawn & Garden > Outdoor Living > Porch Swings', ''),
(3774, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment >
Chainsaws', ''),
(3775, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Grass Edgers', ''),
(3776, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment > Hedge Trimmers', ''),
(3777, 'Home & Garden > Lawn & Garden > Outdoor
Power Equipment > Lawn Aerators & Dethatchers', ''),
(3778, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment >
Lawn Mowers > Riding Mowers', ''),
(3779, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Lawn Mowers >
Robotic Mowers', ''),
(3780, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Lawn Mowers > Tow-Behind
Mowers', ''),
(3781, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Lawn Mowers > Walk-Behind Mowers', ''),
(3782, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Lawn Vacuums', ''),
(3783, 'Home & Garden > Lawn &
Garden > Outdoor Power Equipment > Leaf Blowers', ''),
(3784, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment >
Outdoor Power Equipment Base Units', ''),
(3785, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Outdoor
Power Equipment Sets', ''),
(3786, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Power Sweepers', ''),
(3787, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Power Tillers & Cultivators', ''),
(3788, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment > Pressure Washers', ''),
(3789, 'Home & Garden > Lawn & Garden >
Outdoor Power Equipment > Snow Blowers', ''),
(3790, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment >
Tractors', ''),
(3791, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment > Weed Trimmers', ''),
(3792, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Chainsaw Accessories > Chainsaw Bars', ''),
(3793, 'Home
& Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Chainsaw Accessories > Chainsaw Chains', ''),
(3794,
'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Grass Edger Accessories', ''),
(3795, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Hedge Trimmer Accessories', ''),
(3796, 'Home & Garden >
Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Brush Mower Attachments', ''),
(3797,
'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Mower Bags', ''),
(3798, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Mower
Belts', ''),
(3799, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn
Mower Blades', ''),
(3800, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories
> Lawn Mower Covers', ''),
(3801, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower
Accessories > Lawn Mower Mulch Kits', ''),
(3802, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories >
Lawn Mower Accessories > Lawn Mower Mulch Plugs & Plates', ''),
(3803, 'Home & Garden > Lawn & Garden > Outdoor Power
Equipment Accessories > Lawn Mower Accessories > Lawn Mower Pulleys & Idlers', ''),
(3804, 'Home & Garden > Lawn &
Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Mower Tire Tubes', ''),
(3805, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Mower Tires', ''),
(3806,
'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Mower Wheels', ''),
(3807, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn Striping
Kits', ''),
(3808, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Lawn Mower Accessories > Lawn
Sweepers', ''),
(3809, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Leaf Blower Accessories',
''),
(3810, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Leaf Blower Accessories > Leaf Blower
Tubes', ''),
(3811, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Multifunction Outdoor Power
Equipment Attachments > Grass Edger Attachments', ''),
(3812, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment
Accessories > Multifunction Outdoor Power Equipment Attachments > Ground & Leaf Blower Attachments', ''),
(3813, 'Home &
Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Multifunction Outdoor Power Equipment Attachments > Hedge
Trimmer Attachments', ''),
(3814, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Multifunction
Outdoor Power Equipment Attachments > Pole Saw Attachments', ''),
(3815, 'Home & Garden > Lawn & Garden > Outdoor Power
Equipment Accessories > Multifunction Outdoor Power Equipment Attachments > Tiller & Cultivator Attachments', ''),
(3816, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories > Multifunction Outdoor Power Equipment
Attachments > Weed Trimmer Attachments', ''),
(3817, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment
Accessories > Outdoor Power Equipment Batteries', ''),
(3818, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment
Accessories > Pressure Washer Accessories', ''),
(3819, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment
Accessories > Snow Blower Accessories', ''),
(3820, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories
> Tractor Parts & Accessories', ''),
(3821, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment Accessories >
Tractor Parts & Accessories > Tractor Tires', ''),
(3822, 'Home & Garden > Lawn & Garden > Outdoor Power Equipment
Accessories > Tractor Parts & Accessories > Tractor Wheels', ''),
(3823, 'Home & Garden > Lawn & Garden > Outdoor Power
Equipment Accessories > Weed Trimmer Accessories > Weed Trimmer Blades & Spools', ''),
(3824, 'Home & Garden > Lawn &
Garden > Outdoor Power Equipment Accessories > Weed Trimmer Accessories > Weed Trimmer Spool Covers', ''),
(3825, 'Home
& Garden > Lawn & Garden > Snow Removal > Ice Scrapers & Snow Brushes', ''),
(3826, 'Home & Garden > Lawn & Garden >
Snow Removal > Snow Shovels', ''),
(3827, 'Home & Garden > Lawn & Garden > Watering & Irrigation > Garden Hose Fittings
& Valves', ''),
(3828, 'Home & Garden > Lawn & Garden > Watering & Irrigation > Garden Hose Spray Nozzles', ''),
(3829,
'Home & Garden > Lawn & Garden > Watering & Irrigation > Garden Hoses', ''),
(3830, 'Home & Garden > Lawn & Garden >
Watering & Irrigation > Sprinkler Accessories > Sprinkler Controls', ''),
(3831, 'Home & Garden > Lawn & Garden >
Watering & Irrigation > Sprinkler Accessories > Sprinkler Valves', ''),
(3832, 'Home & Garden > Lawn & Garden > Watering
& Irrigation > Sprinklers & Sprinkler Heads', ''),
(3833, 'Home & Garden > Lawn & Garden > Watering & Irrigation >
Watering Can Accesssories', ''),
(3834, 'Home & Garden > Lawn & Garden > Watering & Irrigation > Watering Cans', ''),
(3835, 'Home & Garden > Lawn & Garden > Watering & Irrigation > Watering Globes & Spikes', ''),
(3836, 'Home & Garden >
Lighting > Emergency Lighting', ''),
(3837, 'Home & Garden > Lighting > Floating & Submersible Lights', ''),
(3838,
'Home & Garden > Lighting > Flood & Spot Lights', ''),
(3839, 'Home & Garden > Lighting > In-Ground Lights', ''),
(3840,
'Home & Garden > Lighting > Lamps', ''),
(3841, 'Home & Garden > Lighting > Landscape Pathway Lighting', ''),
(3842,
'Home & Garden > Lighting > Light Bulbs > Compact Fluorescent Lamps', ''),
(3843, 'Home & Garden > Lighting > Light
Bulbs > Fluorescent Tubes', ''),
(3844, 'Home & Garden > Lighting > Light Bulbs > Incandescent Light Bulbs', ''),
(3845,
'Home & Garden > Lighting > Light Bulbs > LED Light Bulbs', ''),
(3846, 'Home & Garden > Lighting > Light Ropes &
Strings', ''),
(3847, 'Home & Garden > Lighting > Lighting Fixtures > Cabinet Light Fixtures', ''),
(3848, 'Home &
Garden > Lighting > Lighting Fixtures > Ceiling Light Fixtures', ''),
(3849, 'Home & Garden > Lighting > Lighting
Fixtures > Chandeliers', ''),
(3850, 'Home & Garden > Lighting > Lighting Fixtures > Wall Light Fixtures', ''),
(3851,
'Home & Garden > Lighting > Night Lights & Ambient Lighting', ''),
(3852, 'Home & Garden > Lighting > Picture Lights',
''),
(3853, 'Home & Garden > Lighting > Tiki Torches & Oil Lamps', ''),
(3854, 'Home & Garden > Lighting > Track
Lighting > Track Lighting Accessories', ''),
(3855, 'Home & Garden > Lighting > Track Lighting > Track Lighting
Fixtures', ''),
(3856, 'Home & Garden > Lighting > Track Lighting > Track Lighting Rails', ''),
(3857, 'Home & Garden >
Lighting Accessories > Lamp Post Bases', ''),
(3858, 'Home & Garden > Lighting Accessories > Lamp Post Mounts', ''),
(3859, 'Home & Garden > Lighting Accessories > Lamp Shades', ''),
(3860, 'Home & Garden > Lighting Accessories >
Lighting Timers', ''),
(3861, 'Home & Garden > Lighting Accessories > Oil Lamp Fuel', ''),
(3862, 'Home & Garden >
Linens & Bedding > Bedding > Bed Canopies', ''),
(3863, 'Home & Garden > Linens & Bedding > Bedding > Bed Sheets', ''),
(3864, 'Home & Garden > Linens & Bedding > Bedding > Bedskirts', ''),
(3865, 'Home & Garden > Linens & Bedding > Bedding
> Blankets', ''),
(3866, 'Home & Garden > Linens & Bedding > Bedding > Duvet Covers', ''),
(3867, 'Home & Garden >
Linens & Bedding > Bedding > Mattress Protectors > Mattress Encasements', ''),
(3868, 'Home & Garden > Linens & Bedding
> Bedding > Mattress Protectors > Mattress Pads', ''),
(3869, 'Home & Garden > Linens & Bedding > Bedding > Nap Mats',
''),
(3870, 'Home & Garden > Linens & Bedding > Bedding > Pillowcases & Shams', ''),
(3871, 'Home & Garden > Linens &
Bedding > Bedding > Pillows', ''),
(3872, 'Home & Garden > Linens & Bedding > Bedding > Quilts & Comforters', ''),
(3873, 'Home & Garden > Linens & Bedding > Kitchen Linens Sets', ''),
(3874, 'Home & Garden > Linens & Bedding > Table
Linens > Cloth Napkins', ''),
(3875, 'Home & Garden > Linens & Bedding > Table Linens > Doilies', ''),
(3876, 'Home &
Garden > Linens & Bedding > Table Linens > Placemats', ''),
(3877, 'Home & Garden > Linens & Bedding > Table Linens >
Table Runners', ''),
(3878, 'Home & Garden > Linens & Bedding > Table Linens > Table Skirts', ''),
(3879, 'Home & Garden
> Linens & Bedding > Table Linens > Tablecloths', ''),
(3880, 'Home & Garden > Linens & Bedding > Towels > Bath Towels &
Washcloths', ''),
(3881, 'Home & Garden > Linens & Bedding > Towels > Beach Towels', ''),
(3882, 'Home & Garden > Linens
& Bedding > Towels > Kitchen Towels', ''),
(3883, 'Home & Garden > Parasols & Rain Umbrellas', ''),
(3884, 'Home &
Garden > Plants > Aquatic Plants', ''),
(3885, 'Home & Garden > Plants > Flowers', ''),
(3886, 'Home & Garden > Plants >
Indoor & Outdoor Plants', ''),
(3887, 'Home & Garden > Plants > Plant & Herb Growing Kits', ''),
(3888, 'Home & Garden >
Plants > Seeds', ''),
(3889, 'Home & Garden > Plants > Trees', ''),
(3890, 'Home & Garden > Pool & Spa > Pool & Spa
Accessories', ''),
(3891, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Diving Boards', ''),
(3892, 'Home &
Garden > Pool & Spa > Pool & Spa Accessories > Pool & Spa Chlorine Generators', ''),
(3893, 'Home & Garden > Pool & Spa
> Pool & Spa Accessories > Pool & Spa Filters', ''),
(3894, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool
& Spa Maintenance Kits', ''),
(3895, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Brushes & Brooms', ''),
(3896, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Cleaner Hoses', ''),
(3897, 'Home & Garden > Pool &
Spa > Pool & Spa Accessories > Pool Cleaners & Chemicals', ''),
(3898, 'Home & Garden > Pool & Spa > Pool & Spa
Accessories > Pool Cover Accessories', ''),
(3899, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Covers &
Ground Cloths', ''),
(3900, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Deck Kits', ''),
(3901, 'Home &
Garden > Pool & Spa > Pool & Spa Accessories > Pool Floats & Loungers', ''),
(3902, 'Home & Garden > Pool & Spa > Pool &
Spa Accessories > Pool Heaters', ''),
(3903, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Ladders,Steps &
Ramps', ''),
(3904, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Liners', ''),
(3905, 'Home & Garden >
Pool & Spa > Pool & Spa Accessories > Pool Skimmers', ''),
(3906, 'Home & Garden > Pool & Spa > Pool & Spa Accessories >
Pool Sweeps & Vacuums', ''),
(3907, 'Home & Garden > Pool & Spa > Pool & Spa Accessories > Pool Toys', ''),
(3908, 'Home
& Garden > Pool & Spa > Pool & Spa Accessories > Pool Water Slides', ''),
(3909, 'Home & Garden > Pool & Spa > Saunas',
''),
(3910, 'Home & Garden > Pool & Spa > Spas', ''),
(3911, 'Home & Garden > Pool & Spa > Swimming Pools', ''),
(3912,
'Home & Garden > Smoking Accessories > Ashtrays', ''),
(3913, 'Home & Garden > Smoking Accessories > Cigar Cases', ''),
(3914, 'Home & Garden > Smoking Accessories > Cigar Cutters & Punches', ''),
(3915, 'Home & Garden > Smoking Accessories
> Cigarette Cases', ''),
(3916, 'Home & Garden > Smoking Accessories > Cigarette Holders', ''),
(3917, 'Home & Garden >
Smoking Accessories > Humidor Accessories', ''),
(3918, 'Home & Garden > Smoking Accessories > Humidors', ''),
(3919,
'Home & Garden > Umbrella Sleeves & Cases', ''),
(3920, 'Home & Garden > Wood Stoves', ''),
(3921, 'Luggage & Bags >
Backpacks', ''),
(3922, 'Luggage & Bags > Briefcases', ''),
(3923, 'Luggage & Bags > Cosmetic & Toiletry Bags', ''),
(3924, 'Luggage & Bags > Diaper Bags', ''),
(3925, 'Luggage & Bags > Dry Boxes', ''),
(3926, 'Luggage & Bags > Duffel
Bags', ''),
(3927, 'Luggage & Bags > Fanny Packs', ''),
(3928, 'Luggage & Bags > Garment Bags', ''),
(3929, 'Luggage &
Bags > Luggage Accessories > Dry Box Liners & Inserts', ''),
(3930, 'Luggage & Bags > Luggage Accessories > Luggage
Covers', ''),
(3931, 'Luggage & Bags > Luggage Accessories > Luggage Racks & Stands', ''),
(3932, 'Luggage & Bags >
Luggage Accessories > Luggage Straps', ''),
(3933, 'Luggage & Bags > Luggage Accessories > Luggage Tags', ''),
(3934,
'Luggage & Bags > Luggage Accessories > Packing Organizers', ''),
(3935, 'Luggage & Bags > Luggage Accessories > Travel
Bottles & Containers', ''),
(3936, 'Luggage & Bags > Luggage Accessories > Travel Pouches', ''),
(3937, 'Luggage & Bags
> Messenger Bags', ''),
(3938, 'Luggage & Bags > Shopping Totes', ''),
(3939, 'Luggage & Bags > Suitcases', ''),
(3940,
'Luggage & Bags > Train Cases', ''),
(3941, 'Mature > Erotic > Erotic Books', ''),
(3942, 'Mature > Erotic > Erotic
Clothing', ''),
(3943, 'Mature > Erotic > Erotic DVDs & Videos', ''),
(3944, 'Mature > Erotic > Erotic Food & Edibles',
''),
(3945, 'Mature > Erotic > Erotic Games', ''),
(3946, 'Mature > Erotic > Erotic Magazines', ''),
(3947, 'Mature >
Erotic > Pole Dancing Kits', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` ) VALUES (3948,
'Mature > Erotic > Sex Toys', ''),
(3949, 'Mature > Weapons > Brass Knuckles', ''),
(3950, 'Mature > Weapons > Clubs &
Batons', ''),
(3951, 'Mature > Weapons > Combat Knives', ''),
(3952, 'Mature > Weapons > Gun Care & Accessories >
Ammunition', ''),
(3953, 'Mature > Weapons > Gun Care & Accessories > Ammunition Cases & Holders', ''),
(3954, 'Mature >
Weapons > Gun Care & Accessories > Gun Cases & Range Bags', ''),
(3955, 'Mature > Weapons > Gun Care & Accessories > Gun
Cleaning > Gun Cleaning Cloths & Swabs', ''),
(3956, 'Mature > Weapons > Gun Care & Accessories > Gun Cleaning > Gun
Cleaning Patches', ''),
(3957, 'Mature > Weapons > Gun Care & Accessories > Gun Cleaning > Gun Cleaning Solvents', ''),
(3958, 'Mature > Weapons > Gun Care & Accessories > Gun Grips', ''),
(3959, 'Mature > Weapons > Gun Care & Accessories >
Gun Holsters', ''),
(3960, 'Mature > Weapons > Gun Care & Accessories > Gun Lights', ''),
(3961, 'Mature > Weapons > Gun
Care & Accessories > Gun Rails', ''),
(3962, 'Mature > Weapons > Gun Care & Accessories > Gun Slings', ''),
(3963,
'Mature > Weapons > Gun Care & Accessories > Reloading Supplies & Equipment', ''),
(3964, 'Mature > Weapons > Gun Care &
Accessories > Reloading Supplies & Equipment > Ammunition Reloading Presses', ''),
(3965, 'Mature > Weapons > Guns',
''),
(3966, 'Mature > Weapons > Mace & Pepper Spray', ''),
(3967, 'Mature > Weapons > Nunchucks', ''),
(3968, 'Mature >
Weapons > Spears', ''),
(3969, 'Mature > Weapons > Staff & Stick Weapons', ''),
(3970, 'Mature > Weapons > Stun Guns &
Tasers', ''),
(3971, 'Mature > Weapons > Swords', ''),
(3972, 'Mature > Weapons > Throwing Stars', ''),
(3973, 'Mature >
Weapons > Whips', ''),
(3974, 'Media > Books > Art,Architecture & Photography', ''),
(3975, 'Media > Books > Biography',
''),
(3976, 'Media > Books > Business,Finance & Law', ''),
(3977, 'Media > Books > Childrens Books', ''),
(3978, 'Media
> Books > Computing & Internet', ''),
(3979, 'Media > Books > Crime,Mystery & Thrillers', ''),
(3980, 'Media > Books >
Drama,Poetry & Classics', ''),
(3981, 'Media > Books > Education', ''),
(3982, 'Media > Books > Fiction', ''),
(3983,
'Media > Books > Food & Drink', ''),
(3984, 'Media > Books > Health,Family & Lifestyle', ''),
(3985, 'Media > Books >
History', ''),
(3986, 'Media > Books > Home & Garden', ''),
(3987, 'Media > Books > Humour', ''),
(3988, 'Media > Books
> Mind,Body & Spirit', ''),
(3989, 'Media > Books > Music,Stage & Screen', ''),
(3990, 'Media > Books > Reference', ''),
(3991, 'Media > Books > Religion', ''),
(3992, 'Media > Books > Science Fiction & Fantasy', ''),
(3993, 'Media > Books >
Science,Medicine & Nature', ''),
(3994, 'Media > Books > Society & Politics', ''),
(3995, 'Media > Books > Sports &
Hobbies', ''),
(3996, 'Media > Books > Travel & Holiday', ''),
(3997, 'Media > Carpentry & Woodworking Project Plans',
''),
(3998, 'Media > DVDs & Videos', ''),
(3999, 'Media > Magazines & Newspapers', ''),
(4000, 'Media > Music & Sound
Recordings', ''),
(4001, 'Media > Product Manuals > Camera & Optics Manuals', ''),
(4002, 'Media > Product Manuals >
Electronics Manuals', ''),
(4003, 'Media > Product Manuals > Exercise & Fitness Equipment Manuals', ''),
(4004, 'Media >
Product Manuals > Household Appliance Manuals', ''),
(4005, 'Media > Product Manuals > Kitchen Appliance Manuals', ''),
(4006, 'Media > Product Manuals > Model & Toys Manuals', ''),
(4007, 'Media > Product Manuals > Office Supply Manuals',
''),
(4008, 'Media > Product Manuals > Power Tool & Equipment Manuals', ''),
(4009, 'Media > Product Manuals > Vehicle
Service Manuals', ''),
(4010, 'Media > Sheet Music', ''),
(4011, 'Office Supplies > Book Accessories > Book Covers',
''),
(4012, 'Office Supplies > Book Accessories > Book Lights', ''),
(4013, 'Office Supplies > Book Accessories > Book
Stands & Rests', ''),
(4014, 'Office Supplies > Book Accessories > Bookmarks', ''),
(4015, 'Office Supplies > Desk Pads
& Blotters', ''),
(4016, 'Office Supplies > Filing & Organization > Address Books', ''),
(4017, 'Office Supplies >
Filing & Organization > Binding Supplies > Binder Accessories', ''),
(4018, 'Office Supplies > Filing & Organization >
Binding Supplies > Binder Accessories > Binder Rings', ''),
(4019, 'Office Supplies > Filing & Organization > Binding
Supplies > Binder Accessories > Index Dividers', ''),
(4020, 'Office Supplies > Filing & Organization > Binding Supplies
> Binder Accessories > Sheet Protectors', ''),
(4021, 'Office Supplies > Filing & Organization > Binding Supplies >
Binders', ''),
(4022, 'Office Supplies > Filing & Organization > Binding Supplies > Binding Combs & Spines', ''),
(4023,
'Office Supplies > Filing & Organization > Binding Supplies > Binding Machines', ''),
(4024, 'Office Supplies > Filing &
Organization > Business Card Books', ''),
(4025, 'Office Supplies > Filing & Organization > Business Card Stands', ''),
(4026, 'Office Supplies > Filing & Organization > CD/DVD Cases & Organizers', ''),
(4027, 'Office Supplies > Filing &
Organization > Calendars,Organizers & Planners', ''),
(4028, 'Office Supplies > Filing & Organization > Card Files',
''),
(4029, 'Office Supplies > Filing & Organization > Card Sleeves', ''),
(4030, 'Office Supplies > Filing &
Organization > Cash Boxes', ''),
(4031, 'Office Supplies > Filing & Organization > Desk Organizers', ''),
(4032, 'Office
Supplies > Filing & Organization > File Boxes', ''),
(4033, 'Office Supplies > Filing & Organization > File Folders',
''),
(4034, 'Office Supplies > Filing & Organization > Folders & Report Covers', ''),
(4035, 'Office Supplies > Filing &
Organization > Greeting Card Organizers', ''),
(4036, 'Office Supplies > Filing & Organization > Mail Sorters', ''),
(4037, 'Office Supplies > Filing & Organization > Pen & Pencil Cases', ''),
(4038, 'Office Supplies > Filing &
Organization > Portfolios & Padfolios', ''),
(4039, 'Office Supplies > Filing & Organization > Recipe Card Boxes', ''),
(4040, 'Office Supplies > General Office Supplies > Brass Fasteners', ''),
(4041, 'Office Supplies > General Office
Supplies > Correction Fluids,Pens & Tapes', ''),
(4042, 'Office Supplies > General Office Supplies > Erasers', ''),
(4043, 'Office Supplies > General Office Supplies > Labels & Tags > Address Labels', ''),
(4044, 'Office Supplies >
General Office Supplies > Labels & Tags > Folder Tabs', ''),
(4045, 'Office Supplies > General Office Supplies > Labels
& Tags > Label Clips', ''),
(4046, 'Office Supplies > General Office Supplies > Labels & Tags > Label Tapes & Refill
Rolls', ''),
(4047, 'Office Supplies > General Office Supplies > Labels & Tags > Shipping Labels', ''),
(4048, 'Office
Supplies > General Office Supplies > Labels & Tags > Shipping Tags', ''),
(4049, 'Office Supplies > General Office
Supplies > Laminating Film,Pouches & Sheets', ''),
(4050, 'Office Supplies > General Office Supplies > Mounting Putty',
''),
(4051, 'Office Supplies > General Office Supplies > Office Tape', ''),
(4052, 'Office Supplies > General Office
Supplies > Paper Clips & Clamps', ''),
(4053, 'Office Supplies > General Office Supplies > Paper Products > Binder
Paper', ''),
(4054, 'Office Supplies > General Office Supplies > Paper Products > Blank ID Cards', ''),
(4055, 'Office
Supplies > General Office Supplies > Paper Products > Business Cards', ''),
(4056, 'Office Supplies > General Office
Supplies > Paper Products > Business Forms & Receipts', ''),
(4057, 'Office Supplies > General Office Supplies > Paper
Products > Checks', ''),
(4058, 'Office Supplies > General Office Supplies > Paper Products > Cover Paper', ''),
(4059,
'Office Supplies > General Office Supplies > Paper Products > Envelopes', ''),
(4060, 'Office Supplies > General Office
Supplies > Paper Products > Index Cards', ''),
(4061, 'Office Supplies > General Office Supplies > Paper Products >
Notebooks & Notepads', ''),
(4062, 'Office Supplies > General Office Supplies > Paper Products > Post Cards', ''),
(4063, 'Office Supplies > General Office Supplies > Paper Products > Printer & Copier Paper', ''),
(4064, 'Office
Supplies > General Office Supplies > Paper Products > Receipt & Adding Machine Paper Rolls', ''),
(4065, 'Office
Supplies > General Office Supplies > Paper Products > Stationery', ''),
(4066, 'Office Supplies > General Office
Supplies > Paper Products > Sticky Notes', ''),
(4067, 'Office Supplies > General Office Supplies > Rubber Bands', ''),
(4068, 'Office Supplies > General Office Supplies > Staples', ''),
(4069, 'Office Supplies > General Office Supplies >
Tacks & Pushpins', ''),
(4070, 'Office Supplies > Impulse Sealers', ''),
(4071, 'Office Supplies > Lap Desks', ''),
(4072, 'Office Supplies > Name Plates', ''),
(4073, 'Office Supplies > Office & Chair Mats > Anti-Fatigue Mats', ''),
(4074, 'Office Supplies > Office & Chair Mats > Chair Mats', ''),
(4075, 'Office Supplies > Office & Chair Mats > Office
Mats', ''),
(4076, 'Office Supplies > Office Carts > AV Carts', ''),
(4077, 'Office Supplies > Office Carts > Book
Carts', ''),
(4078, 'Office Supplies > Office Carts > File Carts', ''),
(4079, 'Office Supplies > Office Carts > Mail
Carts', ''),
(4080, 'Office Supplies > Office Carts > Utility Carts', ''),
(4081, 'Office Supplies > Office Equipment >
Calculator Accessories', ''),
(4082, 'Office Supplies > Office Equipment > Calculators', ''),
(4083, 'Office Supplies >
Office Equipment > Electronic Dictionaries & Translators', ''),
(4084, 'Office Supplies > Office Equipment > Label
Makers', ''),
(4085, 'Office Supplies > Office Equipment > Laminators', ''),
(4086, 'Office Supplies > Office Equipment
> Office Shredders', ''),
(4087, 'Office Supplies > Office Equipment > Postage Meters', ''),
(4088, 'Office Supplies >
Office Equipment > Time & Attendance Clocks', ''),
(4089, 'Office Supplies > Office Equipment > Transcribers & Dictation
Systems', ''),
(4090, 'Office Supplies > Office Equipment > Typewriters', ''),
(4091, 'Office Supplies > Office
Instruments > Call Bells', ''),
(4092, 'Office Supplies > Office Instruments > Clipboards', ''),
(4093, 'Office Supplies
> Office Instruments > Letter Openers', ''),
(4094, 'Office Supplies > Office Instruments > Magnifiers', ''),
(4095,
'Office Supplies > Office Instruments > Office Rubber Stamps', ''),
(4096, 'Office Supplies > Office Instruments >
Pencil Sharpeners', ''),
(4097, 'Office Supplies > Office Instruments > Staple Removers', ''),
(4098, 'Office Supplies >
Office Instruments > Staplers', ''),
(4099, 'Office Supplies > Office Instruments > Tape Dispensers', ''),
(4100,
'Office Supplies > Office Instruments > Writing & Drawing Instrument Accessories > Marker & Highlighter Ink Refills',
''),
(4101, 'Office Supplies > Office Instruments > Writing & Drawing Instrument Accessories > Pen Ink & Refills', ''),
(4102, 'Office Supplies > Office Instruments > Writing & Drawing Instrument Accessories > Pencil Lead & Refills', ''),
(4103, 'Office Supplies > Office Instruments > Writing & Drawing Instruments > Art Charcoals', ''),
(4104, 'Office
Supplies > Office Instruments > Writing & Drawing Instruments > Chalk', ''),
(4105, 'Office Supplies > Office
Instruments > Writing & Drawing Instruments > Crayons', ''),
(4106, 'Office Supplies > Office Instruments > Writing &
Drawing Instruments > Markers & Highlighters', ''),
(4107, 'Office Supplies > Office Instruments > Writing & Drawing
Instruments > Multifunction Writing Instruments', ''),
(4108, 'Office Supplies > Office Instruments > Writing & Drawing
Instruments > Pastels', ''),
(4109, 'Office Supplies > Office Instruments > Writing & Drawing Instruments > Pens &
Pencils > Pen & Pencil Sets', ''),
(4110, 'Office Supplies > Office Instruments > Writing & Drawing Instruments > Pens &
Pencils > Pencils', ''),
(4111, 'Office Supplies > Office Instruments > Writing & Drawing Instruments > Pens & Pencils >
Pencils > Art Pencils', ''),
(4112, 'Office Supplies > Office Instruments > Writing & Drawing Instruments > Pens &
Pencils > Pencils > Writing Pencils', ''),
(4113, 'Office Supplies > Office Instruments > Writing & Drawing Instruments
> Pens & Pencils > Pens', ''),
(4114, 'Office Supplies > Paper Handling > Fingertip Grips', ''),
(4115, 'Office Supplies
> Paper Handling > Hole Punches', ''),
(4116, 'Office Supplies > Paper Handling > Paper Folding Machines', ''),
(4117,
'Office Supplies > Paper Handling > Paper Joggers', ''),
(4118, 'Office Supplies > Paper Handling > Paperweights', ''),
(4119, 'Office Supplies > Paper Handling > Pencil Boards', ''),
(4120, 'Office Supplies > Presentation Supplies >
Chalkboards', ''),
(4121, 'Office Supplies > Presentation Supplies > Display Boards > Bulletin Board Accessories', ''),
(4122, 'Office Supplies > Presentation Supplies > Display Boards > Bulletin Board Accessories > Bulletin Board Trim',
''),
(4123, 'Office Supplies > Presentation Supplies > Display Boards > Bulletin Boards', ''),
(4124, 'Office Supplies >
Presentation Supplies > Display Boards > Foam Boards', ''),
(4125, 'Office Supplies > Presentation Supplies > Display
Boards > Mounting Boards', ''),
(4126, 'Office Supplies > Presentation Supplies > Display Boards > Poster Boards', ''),
(4127, 'Office Supplies > Presentation Supplies > Document Cameras', ''),
(4128, 'Office Supplies > Presentation
Supplies > Dry-Erase Boards', ''),
(4129, 'Office Supplies > Presentation Supplies > Easel Pads', ''),
(4130, 'Office
Supplies > Presentation Supplies > Easels', ''),
(4131, 'Office Supplies > Presentation Supplies > Laser Pointers', ''),
(4132, 'Office Supplies > Presentation Supplies > Lecterns', ''),
(4133, 'Office Supplies > Presentation Supplies >
Transparencies', ''),
(4134, 'Office Supplies > Presentation Supplies > Wireless Presenters', ''),
(4135, 'Office
Supplies > Shipping Supplies > Moving & Shipping Boxes', ''),
(4136, 'Office Supplies > Shipping Supplies > Packing
Materials', ''),
(4137, 'Office Supplies > Shipping Supplies > Packing Tape', ''),
(4138, 'Religious & Ceremonial >
Memorial Ceremony Supplies', ''),
(4139, 'Religious & Ceremonial > Memorial Ceremony Supplies > Memorial Urns', ''),
(4140, 'Religious & Ceremonial > Religious Items', ''),
(4141, 'Religious & Ceremonial > Religious Items > Prayer
Beads', ''),
(4142, 'Religious & Ceremonial > Religious Items > Prayer Cards', ''),
(4143, 'Religious & Ceremonial >
Religious Items > Religious Altars', ''),
(4144, 'Religious & Ceremonial > Religious Items > Religious Veils', ''),
(4145, 'Religious & Ceremonial > Religious Items > Tarot Cards', ''),
(4146, 'Religious & Ceremonial > Wedding Ceremony
Supplies', ''),
(4147, 'Religious & Ceremonial > Wedding Ceremony Supplies > Aisle Runners', ''),
(4148, 'Religious &
Ceremonial > Wedding Ceremony Supplies > Flower Girl Baskets', ''),
(4149, 'Religious & Ceremonial > Wedding Ceremony
Supplies > Ring Pillows & Holders', ''),
(4150, 'Software > Computer Software > Antivirus & Security Software', ''),
(4151, 'Software > Computer Software > Business & Productivity Software', ''),
(4152, 'Software > Computer Software >
Compilers & Programming Tools', ''),
(4153, 'Software > Computer Software > Computer Utilities & Maintenance Software',
''),
(4154, 'Software > Computer Software > Dictionary & Translation Software', ''),
(4155, 'Software > Computer
Software > Educational Software', ''),
(4156, 'Software > Computer Software > Financial,Tax & Accounting Software', ''),
(4157, 'Software > Computer Software > GPS Map Data & Software', ''),
(4158, 'Software > Computer Software > Handheld &
PDA Software', ''),
(4159, 'Software > Computer Software > Multimedia & Design Software > 3D Modeling Software', ''),
(4160, 'Software > Computer Software > Multimedia & Design Software > Animation Editing Software', ''),
(4161, 'Software
> Computer Software > Multimedia & Design Software > Graphic Design & Illustration Software', ''),
(4162, 'Software >
Computer Software > Multimedia & Design Software > Home & Interior Design Software', ''),
(4163, 'Software > Computer
Software > Multimedia & Design Software > Home Publishing Software', ''),
(4164, 'Software > Computer Software >
Multimedia & Design Software > Media Viewing Software', ''),
(4165, 'Software > Computer Software > Multimedia & Design
Software > Music Composition Software', ''),
(4166, 'Software > Computer Software > Multimedia & Design Software > Sound
Editing Software', ''),
(4167, 'Software > Computer Software > Multimedia & Design Software > Video Editing Software',
''),
(4168, 'Software > Computer Software > Multimedia & Design Software > Web Design Software', ''),
(4169, 'Software >
Computer Software > Network Software', ''),
(4170, 'Software > Computer Software > Office Application Software', ''),
(4171, 'Software > Computer Software > Operating Systems', ''),
(4172, 'Software > Computer Software > Restore Disks',
''),
(4173, 'Software > Digital Goods & Currency > Computer Icons', ''),
(4174, 'Software > Digital Goods & Currency >
Desktop Wallpaper', ''),
(4175, 'Software > Digital Goods & Currency > Digital Artwork', ''),
(4176, 'Software > Digital
Goods & Currency > Document Templates', ''),
(4177, 'Software > Digital Goods & Currency > Fonts', ''),
(4178, 'Software
> Digital Goods & Currency > Stock Photographs & Video Footage', ''),
(4179, 'Software > Digital Goods & Currency >
Virtual Currency', ''),
(4180, 'Software > Video Game Software', ''),
(4181, 'Sporting Goods > Athletics > Baseball &
Softball > Baseball & Softball Batting Gloves > Boys', ''),
(4182, 'Sporting Goods > Athletics > Baseball & Softball >
Baseball & Softball Batting Gloves > Girls', ''),
(4183, 'Sporting Goods > Athletics > Baseball & Softball > Baseball &
Softball Batting Gloves > Mens', ''),
(4184, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball
Batting Gloves > Womens', ''),
(4185, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Gloves &
Mitts > Boys', ''),
(4186, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Gloves & Mitts >
Girls', ''),
(4187, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Gloves & Mitts > Mens', ''),
(4188, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Gloves & Mitts > Womens', ''),
(4189,
'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Baseball & Softball Batting
Helmets > Boys', ''),
(4190, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear >
Baseball & Softball Batting Helmets > Girls', ''),
(4191, 'Sporting Goods > Athletics > Baseball & Softball > Baseball &
Softball Protective Gear > Baseball & Softball Batting Helmets > Mens', ''),
(4192, 'Sporting Goods > Athletics >
Baseball & Softball > Baseball & Softball Protective Gear > Baseball & Softball Batting Helmets > Womens', ''),
(4193,
'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Baseball & Softball Chest
Protectors > Boys', ''),
(4194, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear
> Baseball & Softball Chest Protectors > Girls', ''),
(4195, 'Sporting Goods > Athletics > Baseball & Softball >
Baseball & Softball Protective Gear > Baseball & Softball Chest Protectors > Mens', ''),
(4196, 'Sporting Goods >
Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Baseball & Softball Chest Protectors > Womens',
''),
(4197, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Baseball &
Softball Leg Guards > Boys', ''),
(4198, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball
Protective Gear > Baseball & Softball Leg Guards > Girls', ''),
(4199, 'Sporting Goods > Athletics > Baseball & Softball
> Baseball & Softball Protective Gear > Baseball & Softball Leg Guards > Mens', ''),
(4200, 'Sporting Goods > Athletics
> Baseball & Softball > Baseball & Softball Protective Gear > Baseball & Softball Leg Guards > Womens', ''),
(4201,
'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Catchers Equipment Sets >
Boys', ''),
(4202, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Catchers
Equipment Sets > Girls', ''),
(4203, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective
Gear > Catchers Equipment Sets > Mens', ''),
(4204, 'Sporting Goods > Athletics > Baseball & Softball > Baseball &
Softball Protective Gear > Catchers Equipment Sets > Womens', ''),
(4205, 'Sporting Goods > Athletics > Baseball &
Softball > Baseball & Softball Protective Gear > Catchers Helmets & Masks > Boys', ''),
(4206, 'Sporting Goods >
Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Catchers Helmets & Masks > Girls', ''),
(4207,
'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Catchers Helmets & Masks >
Mens', ''),
(4208, 'Sporting Goods > Athletics > Baseball & Softball > Baseball & Softball Protective Gear > Catchers
Helmets & Masks > Womens', ''),
(4209, 'Sporting Goods > Athletics > Baseball & Softball > Baseball Bats > Adult
(unisex)', ''),
(4210, 'Sporting Goods > Athletics > Baseball & Softball > Baseball Bats > Kids (unisex)', ''),
(4211,
'Sporting Goods > Athletics > Baseball & Softball > Baseballs > Adult (unisex)', ''),
(4212, 'Sporting Goods > Athletics
> Baseball & Softball > Baseballs > Kids (unisex)', ''),
(4213, 'Sporting Goods > Athletics > Baseball & Softball >
Softball Bats > Adult (unisex)', ''),
(4214, 'Sporting Goods > Athletics > Baseball & Softball > Softball Bats > Kids
(unisex)', ''),
(4215, 'Sporting Goods > Athletics > Baseball & Softball > Softballs > Adult (unisex)', ''),
(4216,
'Sporting Goods > Athletics > Baseball & Softball > Softballs > Kids (unisex)', ''),
(4217, 'Sporting Goods > Athletics
> Basketball > Basketball Training Aids > Adult (unisex)', ''),
(4218, 'Sporting Goods > Athletics > Basketball >
Basketball Training Aids > Kids (unisex)', ''),
(4219, 'Sporting Goods > Athletics > Basketball > Basketballs > Adult
(unisex)', ''),
(4220, 'Sporting Goods > Athletics > Basketball > Basketballs > Kids (unisex)', ''),
(4221, 'Sporting
Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & MMA Hand Wraps > Boys',
''),
(4222, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & MMA
Hand Wraps > Girls', ''),
(4223, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective
Gear > Boxing & MMA Hand Wraps > Mens', ''),
(4224, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing &
Martial Arts Protective Gear > Boxing & MMA Hand Wraps > Womens', ''),
(4225, 'Sporting Goods > Athletics > Boxing &
Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Arm Guards > Boys', ''),
(4226, 'Sporting
Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Arm Guards >
Girls', ''),
(4227, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing
& Martial Arts Arm Guards > Mens', ''),
(4228, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial
Arts Protective Gear > Boxing & Martial Arts Arm Guards > Womens', ''),
(4229, 'Sporting Goods > Athletics > Boxing &
Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Body Protectors > Boys', ''),
(4230,
'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Body
Protectors > Girls', ''),
(4231, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective
Gear > Boxing & Martial Arts Body Protectors > Mens', ''),
(4232, 'Sporting Goods > Athletics > Boxing & Martial Arts >
Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Body Protectors > Womens', ''),
(4233, 'Sporting Goods >
Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Headgear > Boys', ''),
(4234, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial
Arts Headgear > Girls', ''),
(4235, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts
Protective Gear > Boxing & Martial Arts Headgear > Mens', ''),
(4236, 'Sporting Goods > Athletics > Boxing & Martial
Arts > Boxing & Martial Arts Protective Gear > Boxing & Martial Arts Headgear > Womens', ''),
(4237, 'Sporting Goods >
Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing Gloves & Mitts > Boys', ''),
(4238,
'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing Gloves & Mitts >
Girls', ''),
(4239, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > Boxing
Gloves & Mitts > Mens', ''),
(4240, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts
Protective Gear > Boxing Gloves & Mitts > Womens', ''),
(4241, 'Sporting Goods > Athletics > Boxing & Martial Arts >
Boxing & Martial Arts Protective Gear > MMA Shin Guards > Boys', ''),
(4242, 'Sporting Goods > Athletics > Boxing &
Martial Arts > Boxing & Martial Arts Protective Gear > MMA Shin Guards > Girls', ''),
(4243, 'Sporting Goods > Athletics
> Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > MMA Shin Guards > Mens', ''),
(4244, 'Sporting Goods >
Athletics > Boxing & Martial Arts > Boxing & Martial Arts Protective Gear > MMA Shin Guards > Womens', ''),
(4245,
'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Training Equipment > Boxing & MMA Punch
Mitts > Adult (unisex)', ''),
(4246, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts
Training Equipment > Boxing & MMA Punch Mitts > Kids (unisex)', ''),
(4247, 'Sporting Goods > Athletics > Boxing &
Martial Arts > Boxing & Martial Arts Training Equipment > Grappling Dummies > Adult (unisex)', ''),
(4248, 'Sporting
Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Training Equipment > Grappling Dummies > Kids
(unisex)', ''),
(4249, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Training Equipment >
Punching & Training Bag Accessories > Adult (unisex)', ''),
(4250, 'Sporting Goods > Athletics > Boxing & Martial Arts >
Boxing & Martial Arts Training Equipment > Punching & Training Bag Accessories > Kids (unisex)', ''),
(4251, 'Sporting
Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Training Equipment > Punching & Training Bags > Adult
(unisex)', ''),
(4252, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing & Martial Arts Training Equipment >
Punching & Training Bags > Kids (unisex)', ''),
(4253, 'Sporting Goods > Athletics > Boxing & Martial Arts > Boxing &
Martial Arts Training Equipment > Strike Shields > Adult (unisex)', ''),
(4254, 'Sporting Goods > Athletics > Boxing &
Martial Arts > Boxing & Martial Arts Training Equipment > Strike Shields > Kids (unisex)', ''),
(4255, 'Sporting Goods >
Athletics > Boxing & Martial Arts > Martial Arts Belts > Adult (unisex)', ''),
(4256, 'Sporting Goods > Athletics >
Boxing & Martial Arts > Martial Arts Belts > Kids (unisex)', ''),
(4257, 'Sporting Goods > Athletics > Boxing & Martial
Arts > Martial Arts Weapons > Adult (unisex)', ''),
(4258, 'Sporting Goods > Athletics > Boxing & Martial Arts > Martial
Arts Weapons > Kids (unisex)', ''),
(4259, 'Sporting Goods > Athletics > Broomball Equipment > Boys', ''),
(4260,
'Sporting Goods > Athletics > Broomball Equipment > Girls', ''),
(4261, 'Sporting Goods > Athletics > Broomball
Equipment > Mens', ''),
(4262, 'Sporting Goods > Athletics > Broomball Equipment > Womens', ''),
(4263, 'Sporting Goods
> Athletics > Cheerleading > Cheerleading Pom Poms > Adult (unisex)', ''),
(4264, 'Sporting Goods > Athletics >
Cheerleading > Cheerleading Pom Poms > Kids (unisex)', ''),
(4265, 'Sporting Goods > Athletics > Cricket > Cricket Balls
> Adult (unisex)', ''),
(4266, 'Sporting Goods > Athletics > Cricket > Cricket Balls > Kids (unisex)', ''),
(4267,
'Sporting Goods > Athletics > Cricket > Cricket Bat Accessories > Cricket Bat Grips > Adult (unisex)', ''),
(4268,
'Sporting Goods > Athletics > Cricket > Cricket Bat Accessories > Cricket Bat Grips > Kids (unisex)', ''),
(4269,
'Sporting Goods > Athletics > Cricket > Cricket Bats > Boys', ''),
(4270, 'Sporting Goods > Athletics > Cricket >
Cricket Bats > Girls', ''),
(4271, 'Sporting Goods > Athletics > Cricket > Cricket Bats > Mens', ''),
(4272, 'Sporting
Goods > Athletics > Cricket > Cricket Bats > Womens', ''),
(4273, 'Sporting Goods > Athletics > Cricket > Cricket
Equipment Sets > Adult (unisex)', ''),
(4274, 'Sporting Goods > Athletics > Cricket > Cricket Equipment Sets > Kids
(unisex)', ''),
(4275, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Gloves > Boys', ''),
(4276, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Gloves > Girls', ''),
(4277, 'Sporting
Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Gloves > Mens', ''),
(4278, 'Sporting Goods > Athletics
> Cricket > Cricket Protective Gear > Cricket Gloves > Womens', ''),
(4279, 'Sporting Goods > Athletics > Cricket >
Cricket Protective Gear > Cricket Helmets > Boys', ''),
(4280, 'Sporting Goods > Athletics > Cricket > Cricket
Protective Gear > Cricket Helmets > Girls', ''),
(4281, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear
> Cricket Helmets > Mens', ''),
(4282, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Helmets
> Womens', ''),
(4283, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Leg Guards > Boys',
''),
(4284, 'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Leg Guards > Girls', ''),
(4285,
'Sporting Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Leg Guards > Mens', ''),
(4286, 'Sporting
Goods > Athletics > Cricket > Cricket Protective Gear > Cricket Leg Guards > Womens', ''),
(4287, 'Sporting Goods >
Athletics > Fencing > Fencing Protective Gear > Fencing Gloves & Cuffs > Boys', ''),
(4288, 'Sporting Goods > Athletics
> Fencing > Fencing Protective Gear > Fencing Gloves & Cuffs > Girls', ''),
(4289, 'Sporting Goods > Athletics > Fencing
> Fencing Protective Gear > Fencing Gloves & Cuffs > Mens', ''),
(4290, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Gloves & Cuffs > Womens', ''),
(4291, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Jackets & Lam├®s > Boys', ''),
(4292, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Jackets & Lam├®s > Girls', ''),
(4293, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Jackets & Lam├®s > Mens', ''),
(4294, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Jackets & Lam├®s > Womens', ''),
(4295, 'Sporting Goods > Athletics > Fencing > Fencing
Protective Gear > Fencing Masks > Boys', ''),
(4296, 'Sporting Goods > Athletics > Fencing > Fencing Protective Gear >
Fencing Masks > Girls', ''),
(4297, 'Sporting Goods > Athletics > Fencing > Fencing Protective Gear > Fencing Masks >
Mens', ''),
(4298, 'Sporting Goods > Athletics > Fencing > Fencing Protective Gear > Fencing Masks > Womens', ''),
(4299, 'Sporting Goods > Athletics > Fencing > Fencing Weapons > Boys', ''),
(4300, 'Sporting Goods > Athletics >
Fencing > Fencing Weapons > Girls', ''),
(4301, 'Sporting Goods > Athletics > Fencing > Fencing Weapons > Mens', ''),
(4302, 'Sporting Goods > Athletics > Fencing > Fencing Weapons > Womens', ''),
(4303, 'Sporting Goods > Athletics >
Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Gloves > Boys', ''),
(4304,
'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey &
Lacrosse Gloves > Girls', ''),
(4305, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse
Protective Gear > Field Hockey & Lacrosse Gloves > Mens', ''),
(4306, 'Sporting Goods > Athletics > Field Hockey &
Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Gloves > Womens', ''),
(4307, 'Sporting
Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Helmets
> Boys', ''),
(4308, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear >
Field Hockey & Lacrosse Helmets > Girls', ''),
(4309, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field
Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Helmets > Mens', ''),
(4310, 'Sporting Goods > Athletics >
Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Helmets > Womens', ''),
(4311, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey &
Lacrosse Masks & Goggles > Boys', ''),
(4312, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey &
Lacrosse Protective Gear > Field Hockey & Lacrosse Masks & Goggles > Girls', ''),
(4313, 'Sporting Goods > Athletics >
Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Masks & Goggles > Mens',
''),
(4314, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field
Hockey & Lacrosse Masks & Goggles > Womens', ''),
(4315, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field
Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Pads > Boys', ''),
(4316, 'Sporting Goods > Athletics >
Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey & Lacrosse Pads > Girls', ''),
(4317,
'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse Protective Gear > Field Hockey &
Lacrosse Pads > Mens', ''),
(4318, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey & Lacrosse
Protective Gear > Field Hockey & Lacrosse Pads > Womens', ''),
(4319, 'Sporting Goods > Athletics > Field Hockey &
Lacrosse > Field Hockey Balls > Adult (unisex)', ''),
(4320, 'Sporting Goods > Athletics > Field Hockey & Lacrosse >
Field Hockey Balls > Kids (unisex)', ''),
(4321, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey
Sticks > Boys', ''),
(4322, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey Sticks > Girls', ''),
(4323, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Field Hockey Sticks > Mens', ''),
(4324, 'Sporting Goods
> Athletics > Field Hockey & Lacrosse > Field Hockey Sticks > Womens', ''),
(4325, 'Sporting Goods > Athletics > Field
Hockey & Lacrosse > Lacrosse Balls > Adult (unisex)', ''),
(4326, 'Sporting Goods > Athletics > Field Hockey & Lacrosse
> Lacrosse Balls > Kids (unisex)', ''),
(4327, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse
Equipment Sets > Boys', ''),
(4328, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Equipment Sets >
Girls', ''),
(4329, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Equipment Sets > Mens', ''),
(4330,
'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Equipment Sets > Womens', ''),
(4331, 'Sporting Goods >
Athletics > Field Hockey & Lacrosse > Lacrosse Stick Parts > Lacrosse Mesh & String > Adult (unisex)', ''),
(4332,
'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Stick Parts > Lacrosse Mesh & String > Kids (unisex)',
''),
(4333, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Stick Parts > Lacrosse Stick Heads > Adult
(unisex)', ''),
(4334, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Stick Parts > Lacrosse Stick
Heads > Kids (unisex)', ''),
(4335, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Stick Parts >
Lacrosse Stick Shafts > Adult (unisex)', ''),
(4336, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse
Stick Parts > Lacrosse Stick Shafts > Kids (unisex)', ''),
(4337, 'Sporting Goods > Athletics > Field Hockey & Lacrosse
> Lacrosse Sticks > Boys', ''),
(4338, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Sticks > Girls',
''),
(4339, 'Sporting Goods > Athletics > Field Hockey & Lacrosse > Lacrosse Sticks > Mens', ''),
(4340, 'Sporting Goods
> Athletics > Field Hockey & Lacrosse > Lacrosse Sticks > Womens', ''),
(4341, 'Sporting Goods > Athletics > Field
Hockey & Lacrosse > Lacrosse Training Aids > Adult (unisex)', ''),
(4342, 'Sporting Goods > Athletics > Field Hockey &
Lacrosse > Lacrosse Training Aids > Kids (unisex)', ''),
(4343, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Protective Gear > Hockey Elbow Pads > Boys', ''),
(4344, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Protective Gear > Hockey Elbow Pads > Girls', ''),
(4345, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Protective Gear > Hockey Elbow Pads > Mens', ''),
(4346, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Protective Gear > Hockey Elbow Pads > Womens', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` )
VALUES (4347, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Hockey Protective Gear > Hockey Gloves > Boys', ''),
(4348, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Hockey Protective Gear > Hockey Gloves > Girls', ''),
(4349, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Hockey Protective Gear > Hockey Gloves > Mens', ''),
(4350, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Hockey Protective Gear > Hockey Gloves > Womens', ''),
(4351, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Hockey Protective Gear > Hockey Goalie Equipment Sets > Boys', ''),
(4352, 'Sporting Goods >
Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Goalie Equipment Sets > Girls', ''),
(4353,
'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Goalie Equipment Sets > Mens',
''),
(4354, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Goalie Equipment
Sets > Womens', ''),
(4355, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Helmets > Boys', ''),
(4356, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Helmets > Girls', ''),
(4357, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Helmets > Mens', ''),
(4358, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Helmets > Womens', ''),
(4359, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Pants > Boys', ''),
(4360, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Pants
> Girls', ''),
(4361, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Pants >
Mens', ''),
(4362, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Pants >
Womens', ''),
(4363, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Shin Guards
& Leg Pads > Boys', ''),
(4364, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Shin Guards & Leg Pads > Girls', ''),
(4365, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective
Gear > Hockey Shin Guards & Leg Pads > Mens', ''),
(4366, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey
Protective Gear > Hockey Shin Guards & Leg Pads > Womens', ''),
(4367, 'Sporting Goods > Athletics > Figure Skating &
Hockey > Hockey Protective Gear > Hockey Shoulder Pads & Chest Protectors > Boys', ''),
(4368, 'Sporting Goods >
Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Shoulder Pads & Chest Protectors > Girls', ''),
(4369, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey Shoulder Pads & Chest
Protectors > Mens', ''),
(4370, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Protective Gear > Hockey
Shoulder Pads & Chest Protectors > Womens', ''),
(4371, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey
Protective Gear > Hockey Suspenders & Belts > Boys', ''),
(4372, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Protective Gear > Hockey Suspenders & Belts > Girls', ''),
(4373, 'Sporting Goods > Athletics > Figure Skating &
Hockey > Hockey Protective Gear > Hockey Suspenders & Belts > Mens', ''),
(4374, 'Sporting Goods > Athletics > Figure
Skating & Hockey > Hockey Protective Gear > Hockey Suspenders & Belts > Womens', ''),
(4375, 'Sporting Goods > Athletics
> Figure Skating & Hockey > Hockey Sledges > Adult (unisex)', ''),
(4376, 'Sporting Goods > Athletics > Figure Skating &
Hockey > Hockey Sledges > Kids (unisex)', ''),
(4377, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey
Stick Care > Adult (unisex)', ''),
(4378, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Stick Care >
Kids (unisex)', ''),
(4379, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Stick Parts > Hockey Stick
Blades > Adult (unisex)', ''),
(4380, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Stick Parts >
Hockey Stick Blades > Kids (unisex)', ''),
(4381, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Stick
Parts > Hockey Stick Shafts > Adult (unisex)', ''),
(4382, 'Sporting Goods > Athletics > Figure Skating & Hockey >
Hockey Stick Parts > Hockey Stick Shafts > Kids (unisex)', ''),
(4383, 'Sporting Goods > Athletics > Figure Skating &
Hockey > Hockey Sticks > Boys', ''),
(4384, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Sticks >
Girls', ''),
(4385, 'Sporting Goods > Athletics > Figure Skating & Hockey > Hockey Sticks > Mens', ''),
(4386, 'Sporting
Goods > Athletics > Figure Skating & Hockey > Hockey Sticks > Womens', ''),
(4387, 'Sporting Goods > Athletics > Figure
Skating & Hockey > Ice Skate Parts & Accessories > Figure Skate Boots > Boys', ''),
(4388, 'Sporting Goods > Athletics >
Figure Skating & Hockey > Ice Skate Parts & Accessories > Figure Skate Boots > Girls', ''),
(4389, 'Sporting Goods >
Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Figure Skate Boots > Mens', ''),
(4390, 'Sporting
Goods > Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Figure Skate Boots > Womens', ''),
(4391,
'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Ice Skate Blades > Boys', ''),
(4392, 'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Ice Skate Blades >
Girls', ''),
(4393, 'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Ice Skate
Blades > Mens', ''),
(4394, 'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skate Parts & Accessories > Ice
Skate Blades > Womens', ''),
(4395, 'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skates > Boys', ''),
(4396, 'Sporting Goods > Athletics > Figure Skating & Hockey > Ice Skates > Girls', ''),
(4397, 'Sporting Goods >
Athletics > Figure Skating & Hockey > Ice Skates > Mens', ''),
(4398, 'Sporting Goods > Athletics > Figure Skating &
Hockey > Ice Skates > Womens', ''),
(4399, 'Sporting Goods > Athletics > Football > Football Gloves > Boys', ''),
(4400,
'Sporting Goods > Athletics > Football > Football Gloves > Girls', ''),
(4401, 'Sporting Goods > Athletics > Football >
Football Gloves > Mens', ''),
(4402, 'Sporting Goods > Athletics > Football > Football Gloves > Womens', ''),
(4403,
'Sporting Goods > Athletics > Football > Football Protective Gear > Football Girdles > Boys', ''),
(4404, 'Sporting
Goods > Athletics > Football > Football Protective Gear > Football Girdles > Girls', ''),
(4405, 'Sporting Goods >
Athletics > Football > Football Protective Gear > Football Girdles > Mens', ''),
(4406, 'Sporting Goods > Athletics >
Football > Football Protective Gear > Football Girdles > Womens', ''),
(4407, 'Sporting Goods > Athletics > Football >
Football Protective Gear > Football Helmet Accessories > Football Chin Straps > Boys', ''),
(4408, 'Sporting Goods >
Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Chin Straps > Girls', ''),
(4409, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Chin
Straps > Mens', ''),
(4410, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet
Accessories > Football Chin Straps > Womens', ''),
(4411, 'Sporting Goods > Athletics > Football > Football Protective
Gear > Football Helmet Accessories > Football Face Masks > Boys', ''),
(4412, 'Sporting Goods > Athletics > Football >
Football Protective Gear > Football Helmet Accessories > Football Face Masks > Girls', ''),
(4413, 'Sporting Goods >
Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Face Masks > Mens', ''),
(4414,
'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Face Masks >
Womens', ''),
(4415, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet Accessories >
Football Helmet Padding > Boys', ''),
(4416, 'Sporting Goods > Athletics > Football > Football Protective Gear >
Football Helmet Accessories > Football Helmet Padding > Girls', ''),
(4417, 'Sporting Goods > Athletics > Football >
Football Protective Gear > Football Helmet Accessories > Football Helmet Padding > Mens', ''),
(4418, 'Sporting Goods >
Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Helmet Padding > Womens', ''),
(4419,
'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet Accessories > Football Helmet
Visors > Boys', ''),
(4420, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Helmet
Accessories > Football Helmet Visors > Girls', ''),
(4421, 'Sporting Goods > Athletics > Football > Football Protective
Gear > Football Helmet Accessories > Football Helmet Visors > Mens', ''),
(4422, 'Sporting Goods > Athletics > Football
> Football Protective Gear > Football Helmet Accessories > Football Helmet Visors > Womens', ''),
(4423, 'Sporting Goods
> Athletics > Football > Football Protective Gear > Football Helmets > Boys', ''),
(4424, 'Sporting Goods > Athletics >
Football > Football Protective Gear > Football Helmets > Girls', ''),
(4425, 'Sporting Goods > Athletics > Football >
Football Protective Gear > Football Helmets > Mens', ''),
(4426, 'Sporting Goods > Athletics > Football > Football
Protective Gear > Football Helmets > Womens', ''),
(4427, 'Sporting Goods > Athletics > Football > Football Protective
Gear > Football Neck Rolls > Boys', ''),
(4428, 'Sporting Goods > Athletics > Football > Football Protective Gear >
Football Neck Rolls > Girls', ''),
(4429, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football
Neck Rolls > Mens', ''),
(4430, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Neck Rolls
> Womens', ''),
(4431, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Rib Protection
Shirts & Vests > Boys', ''),
(4432, 'Sporting Goods > Athletics > Football > Football Protective Gear > Football Rib
Protection Shirts & Vests > Girls', ''),
(4433, 'Sporting Goods > Athletics > Football > Football Protective Gear >
Football Rib Protection Shirts & Vests > Mens', ''),
(4434, 'Sporting Goods > Athletics > Football > Football Protective
Gear > Football Rib Protection Shirts & Vests > Womens', ''),
(4435, 'Sporting Goods > Athletics > Football > Football
Protective Gear > Football Shoulder Pads > Boys', ''),
(4436, 'Sporting Goods > Athletics > Football > Football
Protective Gear > Football Shoulder Pads > Girls', ''),
(4437, 'Sporting Goods > Athletics > Football > Football
Protective Gear > Football Shoulder Pads > Mens', ''),
(4438, 'Sporting Goods > Athletics > Football > Football
Protective Gear > Football Shoulder Pads > Womens', ''),
(4439, 'Sporting Goods > Athletics > Football > Football
Training Equipment > Football Dummies & Sleds > Adult (unisex)', ''),
(4440, 'Sporting Goods > Athletics > Football >
Football Training Equipment > Football Dummies & Sleds > Kids (unisex)', ''),
(4441, 'Sporting Goods > Athletics >
Football > Footballs > Adult (unisex)', ''),
(4442, 'Sporting Goods > Athletics > Football > Footballs > Kids (unisex)',
''),
(4443, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Altitude Training Masks > Adult
(unisex)', ''),
(4444, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Altitude Training Masks > Kids
(unisex)', ''),
(4445, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Athletic Cups > Adult
(unisex)', ''),
(4446, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Athletic Cups > Kids
(unisex)', ''),
(4447, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Sports Mouthguards > Boys',
''),
(4448, 'Sporting Goods > Athletics > General Purpose Athletic Equipment > Sports Mouthguards > Girls', ''),
(4449,
'Sporting Goods > Athletics > General Purpose Athletic Equipment > Sports Mouthguards > Mens', ''),
(4450, 'Sporting
Goods > Athletics > General Purpose Athletic Equipment > Sports Mouthguards > Womens', ''),
(4451, 'Sporting Goods >
Athletics > Gymnastics > Gymnastics Protective Gear > Gymnastics Grips > Adult (unisex)', ''),
(4452, 'Sporting Goods >
Athletics > Gymnastics > Gymnastics Protective Gear > Gymnastics Grips > Kids (unisex)', ''),
(4453, 'Sporting Goods >
Athletics > Racquetball & Squash > Racquetball & Squash Eyewear > Boys', ''),
(4454, 'Sporting Goods > Athletics >
Racquetball & Squash > Racquetball & Squash Eyewear > Girls', ''),
(4455, 'Sporting Goods > Athletics > Racquetball &
Squash > Racquetball & Squash Eyewear > Mens', ''),
(4456, 'Sporting Goods > Athletics > Racquetball & Squash >
Racquetball & Squash Eyewear > Womens', ''),
(4457, 'Sporting Goods > Athletics > Racquetball & Squash > Racquetball &
Squash Gloves > Boys', ''),
(4458, 'Sporting Goods > Athletics > Racquetball & Squash > Racquetball & Squash Gloves >
Girls', ''),
(4459, 'Sporting Goods > Athletics > Racquetball & Squash > Racquetball & Squash Gloves > Mens', ''),
(4460, 'Sporting Goods > Athletics > Racquetball & Squash > Racquetball & Squash Gloves > Womens', ''),
(4461, 'Sporting
Goods > Athletics > Racquetball & Squash > Racquetball Racquets > Boys', ''),
(4462, 'Sporting Goods > Athletics >
Racquetball & Squash > Racquetball Racquets > Girls', ''),
(4463, 'Sporting Goods > Athletics > Racquetball & Squash >
Racquetball Racquets > Mens', ''),
(4464, 'Sporting Goods > Athletics > Racquetball & Squash > Racquetball Racquets >
Womens', ''),
(4465, 'Sporting Goods > Athletics > Racquetball & Squash > Squash Racquets > Boys', ''),
(4466, 'Sporting
Goods > Athletics > Racquetball & Squash > Squash Racquets > Girls', ''),
(4467, 'Sporting Goods > Athletics >
Racquetball & Squash > Squash Racquets > Mens', ''),
(4468, 'Sporting Goods > Athletics > Racquetball & Squash > Squash
Racquets > Womens', ''),
(4469, 'Sporting Goods > Athletics > Rounders > Rounders Bats > Adult (unisex)', ''),
(4470,
'Sporting Goods > Athletics > Rounders > Rounders Bats > Kids (unisex)', ''),
(4471, 'Sporting Goods > Athletics >
Rounders > Rounders Gloves > Boys', ''),
(4472, 'Sporting Goods > Athletics > Rounders > Rounders Gloves > Girls', ''),
(4473, 'Sporting Goods > Athletics > Rounders > Rounders Gloves > Mens', ''),
(4474, 'Sporting Goods > Athletics >
Rounders > Rounders Gloves > Womens', ''),
(4475, 'Sporting Goods > Athletics > Rugby > Rugby Balls > Adult (unisex)',
''),
(4476, 'Sporting Goods > Athletics > Rugby > Rugby Balls > Kids (unisex)', ''),
(4477, 'Sporting Goods > Athletics
> Rugby > Rugby Gloves > Boys', ''),
(4478, 'Sporting Goods > Athletics > Rugby > Rugby Gloves > Girls', ''),
(4479,
'Sporting Goods > Athletics > Rugby > Rugby Gloves > Mens', ''),
(4480, 'Sporting Goods > Athletics > Rugby > Rugby
Gloves > Womens', ''),
(4481, 'Sporting Goods > Athletics > Rugby > Rugby Protective Gear > Rugby Headgear > Boys', ''),
(4482, 'Sporting Goods > Athletics > Rugby > Rugby Protective Gear > Rugby Headgear > Girls', ''),
(4483, 'Sporting
Goods > Athletics > Rugby > Rugby Protective Gear > Rugby Headgear > Mens', ''),
(4484, 'Sporting Goods > Athletics >
Rugby > Rugby Protective Gear > Rugby Headgear > Womens', ''),
(4485, 'Sporting Goods > Athletics > Rugby > Rugby
Training Aids > Adult (unisex)', ''),
(4486, 'Sporting Goods > Athletics > Rugby > Rugby Training Aids > Kids (unisex)',
''),
(4487, 'Sporting Goods > Athletics > Soccer > Soccer Balls > Adult (unisex)', ''),
(4488, 'Sporting Goods >
Athletics > Soccer > Soccer Balls > Kids (unisex)', ''),
(4489, 'Sporting Goods > Athletics > Soccer > Soccer Gloves >
Boys', ''),
(4490, 'Sporting Goods > Athletics > Soccer > Soccer Gloves > Girls', ''),
(4491, 'Sporting Goods >
Athletics > Soccer > Soccer Gloves > Mens', ''),
(4492, 'Sporting Goods > Athletics > Soccer > Soccer Gloves > Womens',
''),
(4493, 'Sporting Goods > Athletics > Soccer > Soccer Protective Gear > Soccer Shin Guards > Boys', ''),
(4494,
'Sporting Goods > Athletics > Soccer > Soccer Protective Gear > Soccer Shin Guards > Girls', ''),
(4495, 'Sporting Goods
> Athletics > Soccer > Soccer Protective Gear > Soccer Shin Guards > Mens', ''),
(4496, 'Sporting Goods > Athletics >
Soccer > Soccer Protective Gear > Soccer Shin Guards > Womens', ''),
(4497, 'Sporting Goods > Athletics > Team Handball
> Handballs > Adult (unisex)', ''),
(4498, 'Sporting Goods > Athletics > Team Handball > Handballs > Kids (unisex)',
''),
(4499, 'Sporting Goods > Athletics > Tennis > Tennis Balls > Adult (unisex)', ''),
(4500, 'Sporting Goods >
Athletics > Tennis > Tennis Balls > Kids (unisex)', ''),
(4501, 'Sporting Goods > Athletics > Tennis > Tennis Nets >
Adult (unisex)', ''),
(4502, 'Sporting Goods > Athletics > Tennis > Tennis Nets > Kids (unisex)', ''),
(4503, 'Sporting
Goods > Athletics > Tennis > Tennis Racquet Accessories > Tennis Racquet Bags > Adult (unisex)', ''),
(4504, 'Sporting
Goods > Athletics > Tennis > Tennis Racquet Accessories > Tennis Racquet Bags > Kids (unisex)', ''),
(4505, 'Sporting
Goods > Athletics > Tennis > Tennis Racquets > Boys', ''),
(4506, 'Sporting Goods > Athletics > Tennis > Tennis Racquets
> Girls', ''),
(4507, 'Sporting Goods > Athletics > Tennis > Tennis Racquets > Mens', ''),
(4508, 'Sporting Goods >
Athletics > Tennis > Tennis Racquets > Womens', ''),
(4509, 'Sporting Goods > Athletics > Track & Field > Discus >
Boys', ''),
(4510, 'Sporting Goods > Athletics > Track & Field > Discus > Girls', ''),
(4511, 'Sporting Goods >
Athletics > Track & Field > Discus > Mens', ''),
(4512, 'Sporting Goods > Athletics > Track & Field > Discus > Womens',
''),
(4513, 'Sporting Goods > Athletics > Track & Field > Javelins > Boys', ''),
(4514, 'Sporting Goods > Athletics >
Track & Field > Javelins > Girls', ''),
(4515, 'Sporting Goods > Athletics > Track & Field > Javelins > Mens', ''),
(4516, 'Sporting Goods > Athletics > Track & Field > Javelins > Womens', ''),
(4517, 'Sporting Goods > Athletics > Track
& Field > Shot Puts > Boys', ''),
(4518, 'Sporting Goods > Athletics > Track & Field > Shot Puts > Girls', ''),
(4519,
'Sporting Goods > Athletics > Track & Field > Shot Puts > Mens', ''),
(4520, 'Sporting Goods > Athletics > Track & Field
> Shot Puts > Womens', ''),
(4521, 'Sporting Goods > Athletics > Track & Field > Throwing Hammers > Boys', ''),
(4522,
'Sporting Goods > Athletics > Track & Field > Throwing Hammers > Girls', ''),
(4523, 'Sporting Goods > Athletics > Track
& Field > Throwing Hammers > Mens', ''),
(4524, 'Sporting Goods > Athletics > Track & Field > Throwing Hammers >
Womens', ''),
(4525, 'Sporting Goods > Athletics > Track & Field > Track Hurdles > Boys', ''),
(4526, 'Sporting Goods >
Athletics > Track & Field > Track Hurdles > Girls', ''),
(4527, 'Sporting Goods > Athletics > Track & Field > Track
Hurdles > Mens', ''),
(4528, 'Sporting Goods > Athletics > Track & Field > Track Hurdles > Womens', ''),
(4529,
'Sporting Goods > Athletics > Track & Field > Vaulting Poles > Boys', ''),
(4530, 'Sporting Goods > Athletics > Track &
Field > Vaulting Poles > Girls', ''),
(4531, 'Sporting Goods > Athletics > Track & Field > Vaulting Poles > Mens', ''),
(4532, 'Sporting Goods > Athletics > Track & Field > Vaulting Poles > Womens', ''),
(4533, 'Sporting Goods > Athletics >
Volleyball > Volleyball Protective Gear > Volleyball Knee Pads > Boys', ''),
(4534, 'Sporting Goods > Athletics >
Volleyball > Volleyball Protective Gear > Volleyball Knee Pads > Girls', ''),
(4535, 'Sporting Goods > Athletics >
Volleyball > Volleyball Protective Gear > Volleyball Knee Pads > Mens', ''),
(4536, 'Sporting Goods > Athletics >
Volleyball > Volleyball Protective Gear > Volleyball Knee Pads > Womens', ''),
(4537, 'Sporting Goods > Athletics >
Volleyball > Volleyball Training Aids > Adult (unisex)', ''),
(4538, 'Sporting Goods > Athletics > Volleyball >
Volleyball Training Aids > Kids (unisex)', ''),
(4539, 'Sporting Goods > Athletics > Volleyball > Volleyballs > Adult
(unisex)', ''),
(4540, 'Sporting Goods > Athletics > Volleyball > Volleyballs > Kids (unisex)', ''),
(4541, 'Sporting
Goods > Athletics > Water Polo > Water Polo Balls > Adult (unisex)', ''),
(4542, 'Sporting Goods > Athletics > Water
Polo > Water Polo Balls > Kids (unisex)', ''),
(4543, 'Sporting Goods > Athletics > Water Polo > Water Polo Caps >
Boys', ''),
(4544, 'Sporting Goods > Athletics > Water Polo > Water Polo Caps > Girls', ''),
(4545, 'Sporting Goods >
Athletics > Water Polo > Water Polo Caps > Mens', ''),
(4546, 'Sporting Goods > Athletics > Water Polo > Water Polo Caps
> Womens', ''),
(4547, 'Sporting Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Headgear > Boys',
''),
(4548, 'Sporting Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Headgear > Girls', ''),
(4549, 'Sporting Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Headgear > Mens', ''),
(4550,
'Sporting Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Headgear > Womens', ''),
(4551,
'Sporting Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Knee Pads > Boys', ''),
(4552, 'Sporting
Goods > Athletics > Wrestling > Wrestling Protective Gear > Wrestling Knee Pads > Girls', ''),
(4553, 'Sporting Goods >
Athletics > Wrestling > Wrestling Protective Gear > Wrestling Knee Pads > Mens', ''),
(4554, 'Sporting Goods > Athletics
> Wrestling > Wrestling Protective Gear > Wrestling Knee Pads > Womens', ''),
(4555, 'Sporting Goods > Exercise &
Fitness > Ab Wheels & Rollers', ''),
(4556, 'Sporting Goods > Exercise & Fitness > Aerobic Steps', ''),
(4557, 'Sporting
Goods > Exercise & Fitness > Balance Trainers', ''),
(4558, 'Sporting Goods > Exercise & Fitness > Cardio > Cardio
Machine Accessories > Elliptical Trainer Accessories', ''),
(4559, 'Sporting Goods > Exercise & Fitness > Cardio >
Cardio Machine Accessories > Exercise Bike Accessories', ''),
(4560, 'Sporting Goods > Exercise & Fitness > Cardio >
Cardio Machine Accessories > Rowing Machine Accessories', ''),
(4561, 'Sporting Goods > Exercise & Fitness > Cardio >
Cardio Machine Accessories > Stair Climber & Stepper Accessories', ''),
(4562, 'Sporting Goods > Exercise & Fitness >
Cardio > Cardio Machine Accessories > Treadmill Accessories', ''),
(4563, 'Sporting Goods > Exercise & Fitness > Cardio
> Cardio Machines > Elliptical Trainers', ''),
(4564, 'Sporting Goods > Exercise & Fitness > Cardio > Cardio Machines >
Exercise Bikes', ''),
(4565, 'Sporting Goods > Exercise & Fitness > Cardio > Cardio Machines > Rowing Machines', ''),
(4566, 'Sporting Goods > Exercise & Fitness > Cardio > Cardio Machines > Stair Climbers & Steppers', ''),
(4567,
'Sporting Goods > Exercise & Fitness > Cardio > Cardio Machines > Treadmills', ''),
(4568, 'Sporting Goods > Exercise &
Fitness > Cardio > Jump Ropes', ''),
(4569, 'Sporting Goods > Exercise & Fitness > Exercise Balls', ''),
(4570,
'Sporting Goods > Exercise & Fitness > Exercise Bands', ''),
(4571, 'Sporting Goods > Exercise & Fitness > Exercise
Benches', ''),
(4572, 'Sporting Goods > Exercise & Fitness > Exercise Equipment Mats', ''),
(4573, 'Sporting Goods >
Exercise & Fitness > Exercise Machine & Equipment Sets', ''),
(4574, 'Sporting Goods > Exercise & Fitness > Exercise
Wedges', ''),
(4575, 'Sporting Goods > Exercise & Fitness > Foam Roller Accessories', ''),
(4576, 'Sporting Goods >
Exercise & Fitness > Foam Roller Accessories > Foam Roller Storage Bags', ''),
(4577, 'Sporting Goods > Exercise &
Fitness > Foam Rollers', ''),
(4578, 'Sporting Goods > Exercise & Fitness > Hand Exercisers', ''),
(4579, 'Sporting
Goods > Exercise & Fitness > Inversion Tables & Systems', ''),
(4580, 'Sporting Goods > Exercise & Fitness > Medicine
Balls', ''),
(4581, 'Sporting Goods > Exercise & Fitness > Power Towers', ''),
(4582, 'Sporting Goods > Exercise &
Fitness > Push Up & Pull Up Bars', ''),
(4583, 'Sporting Goods > Exercise & Fitness > Reaction Balls', ''),
(4584,
'Sporting Goods > Exercise & Fitness > Speed & Resistance Parachutes', ''),
(4585, 'Sporting Goods > Exercise & Fitness
> Sport Safety Lights & Reflectors', ''),
(4586, 'Sporting Goods > Exercise & Fitness > Stopwatches', ''),
(4587,
'Sporting Goods > Exercise & Fitness > Suspension Trainers', ''),
(4588, 'Sporting Goods > Exercise & Fitness >
Vibration Exercise Machines', ''),
(4589, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Free Weight
Accessories > Free Weight Storage Racks', ''),
(4590, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Free
Weight Accessories > Weight Bar Collars', ''),
(4591, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Free
Weight Accessories > Weight Bars', ''),
(4592, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Free Weights',
''),
(4593, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight Lifting Belts > Boys', ''),
(4594, 'Sporting
Goods > Exercise & Fitness > Weight Lifting > Weight Lifting Belts > Girls', ''),
(4595, 'Sporting Goods > Exercise &
Fitness > Weight Lifting > Weight Lifting Belts > Mens', ''),
(4596, 'Sporting Goods > Exercise & Fitness > Weight
Lifting > Weight Lifting Belts > Womens', ''),
(4597, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight
Lifting Gloves & Hand Supports > Boys', ''),
(4598, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight
Lifting Gloves & Hand Supports > Girls', ''),
(4599, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight
Lifting Gloves & Hand Supports > Mens', ''),
(4600, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight
Lifting Gloves & Hand Supports > Womens', ''),
(4601, 'Sporting Goods > Exercise & Fitness > Weight Lifting > Weight
Lifting Machine & Exercise Bench Accessories', ''),
(4602, 'Sporting Goods > Exercise & Fitness > Weight Lifting >
Weight Lifting Machines & Racks', ''),
(4603, 'Sporting Goods > Exercise & Fitness > Weighted Clothing > Boys', ''),
(4604, 'Sporting Goods > Exercise & Fitness > Weighted Clothing > Girls', ''),
(4605, 'Sporting Goods > Exercise &
Fitness > Weighted Clothing > Mens', ''),
(4606, 'Sporting Goods > Exercise & Fitness > Weighted Clothing > Womens',
''),
(4607, 'Sporting Goods > Exercise & Fitness > Yoga & Pilates > Pilates Machines', ''),
(4608, 'Sporting Goods >
Exercise & Fitness > Yoga & Pilates > Yoga & Pilates Blocks', ''),
(4609, 'Sporting Goods > Exercise & Fitness > Yoga &
Pilates > Yoga & Pilates Mats', ''),
(4610, 'Sporting Goods > Exercise & Fitness > Yoga & Pilates > Yoga & Pilates
Towels', ''),
(4611, 'Sporting Goods > Exercise & Fitness > Yoga & Pilates > Yoga Mat Bags & Straps', ''),
(4612,
'Sporting Goods > Indoor Games > Billiards > Billiard Cue Accessories > Billiard Cue Cases > Adult (unisex)', ''),
(4613, 'Sporting Goods > Indoor Games > Billiards > Billiard Cue Accessories > Billiard Cue Cases > Kids (unisex)', ''),
(4614, 'Sporting Goods > Indoor Games > Billiards > Billiard Cues & Bridges > Adult (unisex)', ''),
(4615, 'Sporting
Goods > Indoor Games > Billiards > Billiard Cues & Bridges > Kids (unisex)', ''),
(4616, 'Sporting Goods > Indoor Games
> Billiards > Billiard Gloves > Boys', ''),
(4617, 'Sporting Goods > Indoor Games > Billiards > Billiard Gloves >
Girls', ''),
(4618, 'Sporting Goods > Indoor Games > Billiards > Billiard Gloves > Mens', ''),
(4619, 'Sporting Goods >
Indoor Games > Billiards > Billiard Gloves > Womens', ''),
(4620, 'Sporting Goods > Indoor Games > Bowling > Bowling
Ball Bags > Boys', ''),
(4621, 'Sporting Goods > Indoor Games > Bowling > Bowling Ball Bags > Girls', ''),
(4622,
'Sporting Goods > Indoor Games > Bowling > Bowling Ball Bags > Mens', ''),
(4623, 'Sporting Goods > Indoor Games >
Bowling > Bowling Ball Bags > Womens', ''),
(4624, 'Sporting Goods > Indoor Games > Bowling > Bowling Balls > Boys',
''),
(4625, 'Sporting Goods > Indoor Games > Bowling > Bowling Balls > Girls', ''),
(4626, 'Sporting Goods > Indoor
Games > Bowling > Bowling Balls > Mens', ''),
(4627, 'Sporting Goods > Indoor Games > Bowling > Bowling Balls > Womens',
''),
(4628, 'Sporting Goods > Indoor Games > Bowling > Bowling Gloves > Boys', ''),
(4629, 'Sporting Goods > Indoor
Games > Bowling > Bowling Gloves > Girls', ''),
(4630, 'Sporting Goods > Indoor Games > Bowling > Bowling Gloves >
Mens', ''),
(4631, 'Sporting Goods > Indoor Games > Bowling > Bowling Gloves > Womens', ''),
(4632, 'Sporting Goods >
Indoor Games > Bowling > Bowling Wrist Supports > Boys', ''),
(4633, 'Sporting Goods > Indoor Games > Bowling > Bowling
Wrist Supports > Girls', ''),
(4634, 'Sporting Goods > Indoor Games > Bowling > Bowling Wrist Supports > Mens', ''),
(4635, 'Sporting Goods > Indoor Games > Bowling > Bowling Wrist Supports > Womens', ''),
(4636, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Adult (unisex)', ''),
(4637, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Rafting > Boating Gloves > Boys', ''),
(4638, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Rafting > Boating Gloves > Girls', ''),
(4639, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Rafting > Boating Gloves > Mens', ''),
(4640, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Rafting > Boating Gloves > Womens', ''),
(4641, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Kayaks > Adult (unisex)', ''),
(4642, 'Sporting Goods
> Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Kayaks > Kids (unisex)', ''),
(4643, 'Sporting Goods
> Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Kids (unisex)', ''),
(4644, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Paddles & Oars > Adult (unisex)', ''),
(4645,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Paddles & Oars > Kids (unisex)',
''),
(4646, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Row Boats > Adult
(unisex)', ''),
(4647, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Rafting > Row Boats >
Kids (unisex)', ''),
(4648, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport
Apparel > Drysuits > Boys', ''),
(4649, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water
Sport Apparel > Drysuits > Girls', ''),
(4650, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating &
Water Sport Apparel > Drysuits > Mens', ''),
(4651, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Boating & Water Sport Apparel > Drysuits > Womens', ''),
(4652, 'Sporting Goods > Outdoor Recreation > Boating & Water
Sports > Boating & Water Sport Apparel > Life Jackets > Boys', ''),
(4653, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Boating & Water Sport Apparel > Life Jackets > Girls', ''),
(4654, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Life Jackets > Mens', ''),
(4655, 'Sporting Goods
> Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Life Jackets > Womens', ''),
(4656,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Rash Guards & Swim
Shirts > Boys', ''),
(4657, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport
Apparel > Rash Guards & Swim Shirts > Girls', ''),
(4658, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports
> Boating & Water Sport Apparel > Rash Guards & Swim Shirts > Mens', ''),
(4659, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Boating & Water Sport Apparel > Rash Guards & Swim Shirts > Womens', ''),
(4660, 'Sporting
Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Water Sport Helmets > Boys', ''),
(4661, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Water Sport
Helmets > Girls', ''),
(4662, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport
Apparel > Water Sport Helmets > Mens', ''),
(4663, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Boating & Water Sport Apparel > Water Sport Helmets > Womens', ''),
(4664, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Bottoms > Boys', ''),
(4665, 'Sporting
Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Bottoms >
Girls', ''),
(4666, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel >
Wetsuit Pieces > Wetsuit Bottoms > Mens', ''),
(4667, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Bottoms > Womens', ''),
(4668, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Hoods,Gloves & Boots >
Boys', ''),
(4669, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel >
Wetsuit Pieces > Wetsuit Hoods,Gloves & Boots > Girls', ''),
(4670, 'Sporting Goods > Outdoor Recreation > Boating &
Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Hoods,Gloves & Boots > Mens', ''),
(4671,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit
Hoods,Gloves & Boots > Womens', ''),
(4672, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating &
Water Sport Apparel > Wetsuit Pieces > Wetsuit Tops > Boys', ''),
(4673, 'Sporting Goods > Outdoor Recreation > Boating
& Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Tops > Girls', ''),
(4674, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit Pieces > Wetsuit Tops > Mens',
''),
(4675, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating & Water Sport Apparel > Wetsuit
Pieces > Wetsuit Tops > Womens', ''),
(4676, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Boating &
Water Sport Apparel > Wetsuits > Boys', ''),
(4677, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Boating & Water Sport Apparel > Wetsuits > Girls', ''),
(4678, 'Sporting Goods > Outdoor Recreation > Boating & Water
Sports > Boating & Water Sport Apparel > Wetsuits > Mens', ''),
(4679, 'Sporting Goods > Outdoor Recreation > Boating &
Water Sports > Boating & Water Sport Apparel > Wetsuits > Womens', ''),
(4680, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Diving & Snorkeling > Diving & Snorkeling Equipment Sets > Adult (unisex)', ''),
(4681,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Diving & Snorkeling > Diving & Snorkeling Equipment Sets
> Kids (unisex)', ''),
(4682, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Diving & Snorkeling >
Diving & Snorkeling Fins > Adult (unisex)', ''),
(4683, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Diving & Snorkeling > Diving & Snorkeling Fins > Kids (unisex)', ''),
(4684, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Diving & Snorkeling > Diving & Snorkeling Masks > Adult (unisex)', ''),
(4685, 'Sporting Goods
> Outdoor Recreation > Boating & Water Sports > Diving & Snorkeling > Diving & Snorkeling Masks > Kids (unisex)', ''),
(4686, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Diving & Snorkeling > Snorkels > Adult (unisex)',
''),
(4687, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Diving & Snorkeling > Snorkels > Kids
(unisex)', ''),
(4688, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Kitesurfing > Kiteboards > Adult
(unisex)', ''),
(4689, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Kitesurfing > Kiteboards > Kids
(unisex)', ''),
(4690, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Kitesurfing > Kitesurfing &
Windsurfing Harnesses > Adult (unisex)', ''),
(4691, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Kitesurfing > Kitesurfing & Windsurfing Harnesses > Kids (unisex)', ''),
(4692, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Kitesurfing > Kitesurfing Kites > Adult (unisex)', ''),
(4693, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Kitesurfing > Kitesurfing Kites > Kids (unisex)', ''),
(4694, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Bodyboards > Adult (unisex)', ''),
(4695, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Bodyboards > Kids (unisex)', ''),
(4696, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Paddleboards > Adult (unisex)', ''),
(4697, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Paddleboards > Kids (unisex)', ''),
(4698, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Skimboards > Adult (unisex)', ''),
(4699, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Skimboards > Kids (unisex)', ''),
(4700, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Surfboard Cases & Bags > Adult (unisex)', ''),
(4701, 'Sporting
Goods > Outdoor Recreation > Boating & Water Sports > Surfing > Surfboard Cases & Bags > Kids (unisex)', ''),
(4702,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Surfing > Surfboards > Adult (unisex)', ''),
(4703,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Surfing > Surfboards > Kids (unisex)', ''),
(4704,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Surfing > Surfing Gloves > Boys', ''),
(4705, 'Sporting
Goods > Outdoor Recreation > Boating & Water Sports > Surfing > Surfing Gloves > Girls', ''),
(4706, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Surfing > Surfing Gloves > Mens', ''),
(4707, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Surfing > Surfing Gloves > Womens', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list` (`id`,`name`,`mapped_categories` )
VALUES (4708, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Child Swimming Aids > Boys', ''),
(4709, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Child Swimming Aids > Girls', ''),
(4710, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Swim Caps > Adult (unisex)', ''),
(4711, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Swim Caps > Kids (unisex)', ''),
(4712, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Swim Gloves > Boys', ''),
(4713, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swim Gloves > Girls', ''),
(4714, 'Sporting Goods > Outdoor Recreation > Boating &
Water Sports > Swimming > Swim Gloves > Mens', ''),
(4715, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports
> Swimming > Swim Gloves > Womens', ''),
(4716, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Swimming
> Swim Goggle & Mask Accessories > Boys', ''),
(4717, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Swimming > Swim Goggle & Mask Accessories > Girls', ''),
(4718, 'Sporting Goods > Outdoor Recreation > Boating & Water
Sports > Swimming > Swim Goggle & Mask Accessories > Mens', ''),
(4719, 'Sporting Goods > Outdoor Recreation > Boating &
Water Sports > Swimming > Swim Goggle & Mask Accessories > Womens', ''),
(4720, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swim Goggles & Masks > Boys', ''),
(4721, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swim Goggles & Masks > Girls', ''),
(4722, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swim Goggles & Masks > Mens', ''),
(4723, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swim Goggles & Masks > Womens', ''),
(4724, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Swimming > Swimming Fins > Monofins > Adult (unisex)', ''),
(4725, 'Sporting Goods > Outdoor
Recreation > Boating & Water Sports > Swimming > Swimming Fins > Monofins > Kids (unisex)', ''),
(4726, 'Sporting Goods
> Outdoor Recreation > Boating & Water Sports > Swimming > Swimming Fins > Training Fins > Adult (unisex)', ''),
(4727,
'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Swimming > Swimming Fins > Training Fins > Kids
(unisex)', ''),
(4728, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Swimming > Swimming Nose Clips >
Adult (unisex)', ''),
(4729, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Swimming > Swimming Nose
Clips > Kids (unisex)', ''),
(4730, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Towed Water Sports >
Towed Water Sport Gloves > Adult (unisex)', ''),
(4731, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Towed Water Sports > Towed Water Sport Gloves > Kids (unisex)', ''),
(4732, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Towed Water Sports > Wakeboarding > Wakeboards > Adult (unisex)', ''),
(4733, 'Sporting Goods >
Outdoor Recreation > Boating & Water Sports > Towed Water Sports > Wakeboarding > Wakeboards > Kids (unisex)', ''),
(4734, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Towed Water Sports > Water Skiing > Water Skis >
Adult (unisex)', ''),
(4735, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports > Towed Water Sports > Water
Skiing > Water Skis > Kids (unisex)', ''),
(4736, 'Sporting Goods > Outdoor Recreation > Boating & Water Sports >
Windsurfing > Windsurfing Boards > Adult (unisex)', ''),
(4737, 'Sporting Goods > Outdoor Recreation > Boating & Water
Sports > Windsurfing > Windsurfing Boards > Kids (unisex)', ''),
(4738, 'Sporting Goods > Outdoor Recreation > Boating &
Water Sports > Windsurfing > Windsurfing Sails > Adult (unisex)', ''),
(4739, 'Sporting Goods > Outdoor Recreation >
Boating & Water Sports > Windsurfing > Windsurfing Sails > Kids (unisex)', ''),
(4740, 'Sporting Goods > Outdoor
Recreation > Camping & Hiking > Sleeping Bags > Adult (unisex)', ''),
(4741, 'Sporting Goods > Outdoor Recreation >
Camping & Hiking > Sleeping Bags > Kids (unisex)', ''),
(4742, 'Sporting Goods > Outdoor Recreation > Camping & Hiking >
Tents > Adult (unisex)', ''),
(4743, 'Sporting Goods > Outdoor Recreation > Camping & Hiking > Tents > Kids (unisex)',
''),
(4744, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Gloves > Boys',
''),
(4745, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Gloves > Girls',
''),
(4746, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Gloves > Mens',
''),
(4747, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Gloves >
Womens', ''),
(4748, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Helmets
> Boys', ''),
(4749, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing Helmets
> Girls', ''),
(4750, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing
Helmets > Mens', ''),
(4751, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories > Climbing
Helmets > Womens', ''),
(4752, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories >
Crampons > Boys', ''),
(4753, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories >
Crampons > Girls', ''),
(4754, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories >
Crampons > Mens', ''),
(4755, 'Sporting Goods > Outdoor Recreation > Climbing > Climbing Apparel & Accessories >
Crampons > Womens', ''),
(4756, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories > Bicycle Bags &
Panniers > Adult (unisex)', ''),
(4757, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories > Bicycle
Bags & Panniers > Kids (unisex)', ''),
(4758, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories >
Bicycle Baskets > Adult (unisex)', ''),
(4759, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycle Accessories >
Bicycle Baskets > Kids (unisex)', ''),
(4760, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycles > Boys', ''),
(4761, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycles > Girls', ''),
(4762, 'Sporting Goods > Outdoor
Recreation > Cycling > Bicycles > Mens', ''),
(4763, 'Sporting Goods > Outdoor Recreation > Cycling > Bicycles >
Womens', ''),
(4764, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleat
Accessories > Bicycle Cleat Bolts > Boys', ''),
(4765, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel
& Accessories > Bicycle Cleat Accessories > Bicycle Cleat Bolts > Girls', ''),
(4766, 'Sporting Goods > Outdoor
Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle Cleat Bolts > Mens', ''),
(4767, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleat Accessories >
Bicycle Cleat Bolts > Womens', ''),
(4768, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel &
Accessories > Bicycle Cleat Accessories > Bicycle Cleat Covers > Boys', ''),
(4769, 'Sporting Goods > Outdoor Recreation
> Cycling > Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle Cleat Covers > Girls', ''),
(4770,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle
Cleat Covers > Mens', ''),
(4771, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories >
Bicycle Cleat Accessories > Bicycle Cleat Covers > Womens', ''),
(4772, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle Cleat Shims & Wedges > Boys', ''),
(4773, 'Sporting
Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle Cleat Shims &
Wedges > Girls', ''),
(4774, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle
Cleat Accessories > Bicycle Cleat Shims & Wedges > Mens', ''),
(4775, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Cleat Accessories > Bicycle Cleat Shims & Wedges > Womens', ''),
(4776,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleats > Boys', ''),
(4777,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleats > Girls', ''),
(4778,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleats > Mens', ''),
(4779,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Cleats > Womens', ''),
(4780,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Gloves > Boys', ''),
(4781,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Gloves > Girls', ''),
(4782,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Gloves > Mens', ''),
(4783,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Gloves > Womens', ''),
(4784,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Helmet Parts & Accessories >
Boys', ''),
(4785, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Helmet Parts
& Accessories > Girls', ''),
(4786, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories >
Bicycle Helmet Parts & Accessories > Mens', ''),
(4787, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel
& Accessories > Bicycle Helmet Parts & Accessories > Womens', ''),
(4788, 'Sporting Goods > Outdoor Recreation > Cycling
> Cycling Apparel & Accessories > Bicycle Helmets > Boys', ''),
(4789, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Helmets > Girls', ''),
(4790, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Helmets > Mens', ''),
(4791, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Helmets > Womens', ''),
(4792, 'Sporting Goods > Outdoor Recreation > Cycling >
Cycling Apparel & Accessories > Bicycle Protective Pads > Boys', ''),
(4793, 'Sporting Goods > Outdoor Recreation >
Cycling > Cycling Apparel & Accessories > Bicycle Protective Pads > Girls', ''),
(4794, 'Sporting Goods > Outdoor
Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Protective Pads > Mens', ''),
(4795, 'Sporting Goods >
Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Protective Pads > Womens', ''),
(4796, 'Sporting
Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Shoe Covers > Boys', ''),
(4797,
'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Shoe Covers > Girls', ''),
(4798, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Shoe Covers > Mens',
''),
(4799, 'Sporting Goods > Outdoor Recreation > Cycling > Cycling Apparel & Accessories > Bicycle Shoe Covers >
Womens', ''),
(4800, 'Sporting Goods > Outdoor Recreation > Cycling > Tricycles > Adult (unisex)', ''),
(4801, 'Sporting
Goods > Outdoor Recreation > Cycling > Tricycles > Kids (unisex)', ''),
(4802, 'Sporting Goods > Outdoor Recreation >
Cycling > Unicycles > Adult (unisex)', ''),
(4803, 'Sporting Goods > Outdoor Recreation > Cycling > Unicycles > Kids
(unisex)', ''),
(4804, 'Sporting Goods > Outdoor Recreation > Equestrian > Horse Care > Boys', ''),
(4805, 'Sporting
Goods > Outdoor Recreation > Equestrian > Horse Care > Girls', ''),
(4806, 'Sporting Goods > Outdoor Recreation >
Equestrian > Horse Care > Mens', ''),
(4807, 'Sporting Goods > Outdoor Recreation > Equestrian > Horse Care > Womens',
''),
(4808, 'Sporting Goods > Outdoor Recreation > Equestrian > Horse Tack > Saddles > Boys', ''),
(4809, 'Sporting
Goods > Outdoor Recreation > Equestrian > Horse Tack > Saddles > Girls', ''),
(4810, 'Sporting Goods > Outdoor
Recreation > Equestrian > Horse Tack > Saddles > Mens', ''),
(4811, 'Sporting Goods > Outdoor Recreation > Equestrian >
Horse Tack > Saddles > Womens', ''),
(4812, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel &
Accessories > Equestrian Gloves > Boys', ''),
(4813, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel
& Accessories > Equestrian Gloves > Girls', ''),
(4814, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding
Apparel & Accessories > Equestrian Gloves > Mens', ''),
(4815, 'Sporting Goods > Outdoor Recreation > Equestrian >
Riding Apparel & Accessories > Equestrian Gloves > Womens', ''),
(4816, 'Sporting Goods > Outdoor Recreation >
Equestrian > Riding Apparel & Accessories > Equestrian Helmets > Boys', ''),
(4817, 'Sporting Goods > Outdoor Recreation
> Equestrian > Riding Apparel & Accessories > Equestrian Helmets > Girls', ''),
(4818, 'Sporting Goods > Outdoor
Recreation > Equestrian > Riding Apparel & Accessories > Equestrian Helmets > Mens', ''),
(4819, 'Sporting Goods >
Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Equestrian Helmets > Womens', ''),
(4820, 'Sporting
Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Crops & Whips > Adult (unisex)', ''),
(4821, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Crops & Whips > Kids
(unisex)', ''),
(4822, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Pants >
Boys', ''),
(4823, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Pants >
Girls', ''),
(4824, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Pants >
Mens', ''),
(4825, 'Sporting Goods > Outdoor Recreation > Equestrian > Riding Apparel & Accessories > Riding Pants >
Womens', ''),
(4826, 'Sporting Goods > Outdoor Recreation > Fishing > Fishing Nets > Adult (unisex)', ''),
(4827,
'Sporting Goods > Outdoor Recreation > Fishing > Fishing Nets > Kids (unisex)', ''),
(4828, 'Sporting Goods > Outdoor
Recreation > Fishing > Fishing Reels > Adult (unisex)', ''),
(4829, 'Sporting Goods > Outdoor Recreation > Fishing >
Fishing Reels > Kids (unisex)', ''),
(4830, 'Sporting Goods > Outdoor Recreation > Fishing > Fishing Rods > Adult
(unisex)', ''),
(4831, 'Sporting Goods > Outdoor Recreation > Fishing > Fishing Rods > Kids (unisex)', ''),
(4832,
'Sporting Goods > Outdoor Recreation > Golf > Golf Bag Accessories > Golf Bag Carts > Adult (unisex)', ''),
(4833,
'Sporting Goods > Outdoor Recreation > Golf > Golf Bag Accessories > Golf Bag Carts > Kids (unisex)', ''),
(4834,
'Sporting Goods > Outdoor Recreation > Golf > Golf Bag Accessories > Golf Bag Covers & Cases > Adult (unisex)', ''),
(4835, 'Sporting Goods > Outdoor Recreation > Golf > Golf Bag Accessories > Golf Bag Covers & Cases > Kids (unisex)',
''),
(4836, 'Sporting Goods > Outdoor Recreation > Golf > Golf Bags > Boys', ''),
(4837, 'Sporting Goods > Outdoor
Recreation > Golf > Golf Bags > Girls', ''),
(4838, 'Sporting Goods > Outdoor Recreation > Golf > Golf Bags > Mens',
''),
(4839, 'Sporting Goods > Outdoor Recreation > Golf > Golf Bags > Womens', ''),
(4840, 'Sporting Goods > Outdoor
Recreation > Golf > Golf Balls > Boys', ''),
(4841, 'Sporting Goods > Outdoor Recreation > Golf > Golf Balls > Girls',
''),
(4842, 'Sporting Goods > Outdoor Recreation > Golf > Golf Balls > Mens', ''),
(4843, 'Sporting Goods > Outdoor
Recreation > Golf > Golf Balls > Womens', ''),
(4844, 'Sporting Goods > Outdoor Recreation > Golf > Golf Club Parts &
Accessories > Golf Club Grips > Boys', ''),
(4845, 'Sporting Goods > Outdoor Recreation > Golf > Golf Club Parts &
Accessories > Golf Club Grips > Girls', ''),
(4846, 'Sporting Goods > Outdoor Recreation > Golf > Golf Club Parts &
Accessories > Golf Club Grips > Mens', ''),
(4847, 'Sporting Goods > Outdoor Recreation > Golf > Golf Club Parts &
Accessories > Golf Club Grips > Womens', ''),
(4848, 'Sporting Goods > Outdoor Recreation > Golf > Golf Club Parts &
Accessories > Golf Club Headcovers > Adult (unisex)', ''),
(4849, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Club Parts & Accessories > Golf Club Headcovers > Kids (unisex)', ''),
(4850, 'Sporting Goods > Outdoor Recreation >
Golf > Golf Club Parts & Accessories > Golf Club Shafts > Boys', ''),
(4851, 'Sporting Goods > Outdoor Recreation > Golf
> Golf Club Parts & Accessories > Golf Club Shafts > Girls', ''),
(4852, 'Sporting Goods > Outdoor Recreation > Golf >
Golf Club Parts & Accessories > Golf Club Shafts > Mens', ''),
(4853, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Club Parts & Accessories > Golf Club Shafts > Womens', ''),
(4854, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Clubs > Boys', ''),
(4855, 'Sporting Goods > Outdoor Recreation > Golf > Golf Clubs > Girls', ''),
(4856, 'Sporting
Goods > Outdoor Recreation > Golf > Golf Clubs > Mens', ''),
(4857, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Clubs > Womens', ''),
(4858, 'Sporting Goods > Outdoor Recreation > Golf > Golf Gloves > Boys', ''),
(4859, 'Sporting
Goods > Outdoor Recreation > Golf > Golf Gloves > Girls', ''),
(4860, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Gloves > Mens', ''),
(4861, 'Sporting Goods > Outdoor Recreation > Golf > Golf Gloves > Womens', ''),
(4862, 'Sporting
Goods > Outdoor Recreation > Golf > Golf Towels > Boys', ''),
(4863, 'Sporting Goods > Outdoor Recreation > Golf > Golf
Towels > Girls', ''),
(4864, 'Sporting Goods > Outdoor Recreation > Golf > Golf Towels > Mens', ''),
(4865, 'Sporting
Goods > Outdoor Recreation > Golf > Golf Towels > Womens', ''),
(4866, 'Sporting Goods > Outdoor Recreation > Golf >
Golf Training Aids > Adult (unisex)', ''),
(4867, 'Sporting Goods > Outdoor Recreation > Golf > Golf Training Aids >
Kids (unisex)', ''),
(4868, 'Sporting Goods > Outdoor Recreation > Hang Gliding & Skydiving > Air Suits > Boys', ''),
(4869, 'Sporting Goods > Outdoor Recreation > Hang Gliding & Skydiving > Air Suits > Girls', ''),
(4870, 'Sporting Goods
> Outdoor Recreation > Hang Gliding & Skydiving > Air Suits > Mens', ''),
(4871, 'Sporting Goods > Outdoor Recreation >
Hang Gliding & Skydiving > Air Suits > Womens', ''),
(4872, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting >
Archery > Archery Armguards > Boys', ''),
(4873, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery >
Archery Armguards > Girls', ''),
(4874, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery
Armguards > Mens', ''),
(4875, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery Armguards >
Womens', ''),
(4876, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery Gloves & Releases >
Boys', ''),
(4877, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery Gloves & Releases >
Girls', ''),
(4878, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery Gloves & Releases >
Mens', ''),
(4879, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Archery > Archery Gloves & Releases >
Womens', ''),
(4880, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear >
Boys', ''),
(4881, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear >
Girls', ''),
(4882, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear >
Hunting & Shooting Gloves > Boys', ''),
(4883, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting &
Shooting Protective Gear > Hunting & Shooting Gloves > Girls', ''),
(4884, 'Sporting Goods > Outdoor Recreation >
Hunting & Shooting > Hunting & Shooting Protective Gear > Hunting & Shooting Gloves > Mens', ''),
(4885, 'Sporting Goods
> Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear > Hunting & Shooting Gloves > Womens',
''),
(4886, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear > Hunting &
Shooting Jackets > Boys', ''),
(4887, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting
Protective Gear > Hunting & Shooting Jackets > Girls', ''),
(4888, 'Sporting Goods > Outdoor Recreation > Hunting &
Shooting > Hunting & Shooting Protective Gear > Hunting & Shooting Jackets > Mens', ''),
(4889, 'Sporting Goods >
Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear > Hunting & Shooting Jackets > Womens',
''),
(4890, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear > Mens', ''),
(4891, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Hunting & Shooting Protective Gear > Womens', ''),
(4892, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Airsoft > Airsoft Guns > Adult
(unisex)', ''),
(4893, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Airsoft >
Airsoft Guns > Kids (unisex)', ''),
(4894, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball &
Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Gloves > Boys', ''),
(4895, 'Sporting Goods >
Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball &
Airsoft Gloves > Girls', ''),
(4896, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft >
Paintball & Airsoft Protective Gear > Paintball & Airsoft Gloves > Mens', ''),
(4897, 'Sporting Goods > Outdoor
Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Gloves
> Womens', ''),
(4898, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball &
Airsoft Protective Gear > Paintball & Airsoft Goggles & Masks > Boys', ''),
(4899, 'Sporting Goods > Outdoor Recreation
> Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Goggles & Masks >
Girls', ''),
(4900, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball &
Airsoft Protective Gear > Paintball & Airsoft Goggles & Masks > Mens', ''),
(4901, 'Sporting Goods > Outdoor Recreation
> Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Goggles & Masks >
Womens', ''),
(4902, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball &
Airsoft Protective Gear > Paintball & Airsoft Pads > Boys', ''),
(4903, 'Sporting Goods > Outdoor Recreation > Hunting &
Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Pads > Girls', ''),
(4904,
'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear >
Paintball & Airsoft Pads > Mens', ''),
(4905, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball &
Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Pads > Womens', ''),
(4906, 'Sporting Goods >
Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball &
Airsoft Vests > Boys', ''),
(4907, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft >
Paintball & Airsoft Protective Gear > Paintball & Airsoft Vests > Girls', ''),
(4908, 'Sporting Goods > Outdoor
Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball & Airsoft Protective Gear > Paintball & Airsoft Vests
> Mens', ''),
(4909, 'Sporting Goods > Outdoor Recreation > Hunting & Shooting > Paintball & Airsoft > Paintball &
Airsoft Protective Gear > Paintball & Airsoft Vests > Womens', ''),
(4910, 'Sporting Goods > Outdoor Recreation > Inline
& Roller Skating > Inline & Roller Skating Protective Gear > Roller Skating Pads > Boys', ''),
(4911, 'Sporting Goods >
Outdoor Recreation > Inline & Roller Skating > Inline & Roller Skating Protective Gear > Roller Skating Pads > Girls',
''),
(4912, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Inline & Roller Skating Protective Gear >
Roller Skating Pads > Mens', ''),
(4913, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Inline &
Roller Skating Protective Gear > Roller Skating Pads > Womens', ''),
(4914, 'Sporting Goods > Outdoor Recreation >
Inline & Roller Skating > Inline Skates > Boys', ''),
(4915, 'Sporting Goods > Outdoor Recreation > Inline & Roller
Skating > Inline Skates > Girls', ''),
(4916, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Inline
Skates > Mens', ''),
(4917, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Inline Skates > Womens',
''),
(4918, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Roller Skates > Boys', ''),
(4919,
'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Roller Skates > Girls', ''),
(4920, 'Sporting Goods >
Outdoor Recreation > Inline & Roller Skating > Roller Skates > Mens', ''),
(4921, 'Sporting Goods > Outdoor Recreation >
Inline & Roller Skating > Roller Skates > Womens', ''),
(4922, 'Sporting Goods > Outdoor Recreation > Inline & Roller
Skating > Roller Skis > Boys', ''),
(4923, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Roller Skis
> Girls', ''),
(4924, 'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Roller Skis > Mens', ''),
(4925,
'Sporting Goods > Outdoor Recreation > Inline & Roller Skating > Roller Skis > Womens', ''),
(4926, 'Sporting Goods >
Outdoor Recreation > Kite Buggying > Kite Buggies > Adult (unisex)', ''),
(4927, 'Sporting Goods > Outdoor Recreation >
Kite Buggying > Kite Buggies > Kids (unisex)', ''),
(4928, 'Sporting Goods > Outdoor Recreation > Kite Buggying > Kite
Buggy Accessories > Adult (unisex)', ''),
(4929, 'Sporting Goods > Outdoor Recreation > Kite Buggying > Kite Buggy
Accessories > Kids (unisex)', ''),
(4930, 'Sporting Goods > Outdoor Recreation > Outdoor Games > Badminton > Badminton
Racquets & Sets > Boys', ''),
(4931, 'Sporting Goods > Outdoor Recreation > Outdoor Games > Badminton > Badminton
Racquets & Sets > Girls', ''),
(4932, 'Sporting Goods > Outdoor Recreation > Outdoor Games > Badminton > Badminton
Racquets & Sets > Mens', ''),
(4933, 'Sporting Goods > Outdoor Recreation > Outdoor Games > Badminton > Badminton
Racquets & Sets > Womens', ''),
(4934, 'Sporting Goods > Outdoor Recreation > Riding Scooters > Adult (unisex)', ''),
(4935, 'Sporting Goods > Outdoor Recreation > Riding Scooters > Kids (unisex)', ''),
(4936, 'Sporting Goods > Outdoor
Recreation > Skateboarding > Skateboard Parts > Skateboard Decks > Adult (unisex)', ''),
(4937, 'Sporting Goods >
Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Decks > Kids (unisex)', ''),
(4938, 'Sporting Goods >
Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Small Parts > Adult (unisex)', ''),
(4939, 'Sporting
Goods > Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Small Parts > Kids (unisex)', ''),
(4940,
'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Trucks > Adult (unisex)', ''),
(4941, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Trucks > Kids (unisex)',
''),
(4942, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Wheels > Adult
(unisex)', ''),
(4943, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboard Parts > Skateboard Wheels >
Kids (unisex)', ''),
(4944, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear > Skate
Helmets > Boys', ''),
(4945, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear >
Skate Helmets > Girls', ''),
(4946, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear
> Skate Helmets > Mens', ''),
(4947, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective
Gear > Skate Helmets > Womens', ''),
(4948, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding
Protective Gear > Skateboarding Gloves > Boys', ''),
(4949, 'Sporting Goods > Outdoor Recreation > Skateboarding >
Skateboarding Protective Gear > Skateboarding Gloves > Girls', ''),
(4950, 'Sporting Goods > Outdoor Recreation >
Skateboarding > Skateboarding Protective Gear > Skateboarding Gloves > Mens', ''),
(4951, 'Sporting Goods > Outdoor
Recreation > Skateboarding > Skateboarding Protective Gear > Skateboarding Gloves > Womens', ''),
(4952, 'Sporting Goods
> Outdoor Recreation > Skateboarding > Skateboarding Protective Gear > Skateboarding Pads > Boys', ''),
(4953, 'Sporting
Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear > Skateboarding Pads > Girls', ''),
(4954,
'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear > Skateboarding Pads > Mens', ''),
(4955, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboarding Protective Gear > Skateboarding Pads >
Womens', ''),
(4956, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboards > Boys', ''),
(4957, 'Sporting
Goods > Outdoor Recreation > Skateboarding > Skateboards > Girls', ''),
(4958, 'Sporting Goods > Outdoor Recreation >
Skateboarding > Skateboards > Mens', ''),
(4959, 'Sporting Goods > Outdoor Recreation > Skateboarding > Skateboards >
Womens', ''),
(4960, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski &
Snowboard Bags > Boys', ''),
(4961, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Ski & Snowboard Bags > Girls', ''),
(4962, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Ski & Snowboard Bags > Mens', ''),
(4963, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Bags > Womens', ''),
(4964, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Goggle Accessories > Ski &
Snowboard Goggle Lenses > Boys', ''),
(4965, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing
& Snowboarding > Ski & Snowboard Goggle Accessories > Ski & Snowboard Goggle Lenses > Girls', ''),
(4966, 'Sporting
Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Goggle Accessories >
Ski & Snowboard Goggle Lenses > Mens', ''),
(4967, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities >
Skiing & Snowboarding > Ski & Snowboard Goggle Accessories > Ski & Snowboard Goggle Lenses > Womens', ''),
(4968,
'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Goggles >
Boys', ''),
(4969, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski &
Snowboard Goggles > Girls', ''),
(4970, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Ski & Snowboard Goggles > Mens', ''),
(4971, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Ski & Snowboard Goggles > Womens', ''),
(4972, 'Sporting Goods > Outdoor Recreation
> Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Helmets > Boys', ''),
(4973, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Helmets > Girls', ''),
(4974,
'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski & Snowboard Helmets >
Mens', ''),
(4975, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski &
Snowboard Helmets > Womens', ''),
(4976, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Ski Binding Parts > Boys', ''),
(4977, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities
> Skiing & Snowboarding > Ski Binding Parts > Girls', ''),
(4978, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Ski Binding Parts > Mens', ''),
(4979, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Skiing & Snowboarding > Ski Binding Parts > Womens', ''),
(4980, 'Sporting Goods > Outdoor
Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Bindings > Boys', ''),
(4981, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Bindings > Girls', ''),
(4982, 'Sporting
Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Bindings > Mens', ''),
(4983,
'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Bindings > Womens', ''),
(4984, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Boots > Boys',
''),
(4985, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski Boots >
Girls', ''),
(4986, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Ski
Boots > Mens', ''),
(4987, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding >
Ski Boots > Womens', ''),
(4988, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Ski Poles > Boys', ''),
(4989, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing
& Snowboarding > Ski Poles > Girls', ''),
(4990, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities >
Skiing & Snowboarding > Ski Poles > Mens', ''),
(4991, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities
> Skiing & Snowboarding > Ski Poles > Womens', ''),
(4992, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Skis > Cross-Country Skis > Boys', ''),
(4993, 'Sporting Goods > Outdoor Recreation
> Winter Sports & Activities > Skiing & Snowboarding > Skis > Cross-Country Skis > Girls', ''),
(4994, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Skis > Cross-Country Skis > Mens', ''),
(4995,
'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Skis > Cross-Country Skis >
Womens', ''),
(4996, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Skis >
Downhill Skis > Boys', ''),
(4997, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Skis > Downhill Skis > Girls', ''),
(4998, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Skis > Downhill Skis > Mens', ''),
(4999, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Skiing & Snowboarding > Skis > Downhill Skis > Womens', ''),
(5000, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard Binding Parts > Boys', ''),
(5001,
'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard Binding Parts >
Girls', ''),
(5002, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding >
Snowboard Binding Parts > Mens', ''),
(5003, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing
& Snowboarding > Snowboard Binding Parts > Womens', ''),
(5004, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Snowboard Bindings > Boys', ''),
(5005, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Skiing & Snowboarding > Snowboard Bindings > Girls', ''),
(5006, 'Sporting Goods > Outdoor
Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard Bindings > Mens', ''),
(5007, 'Sporting
Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard Bindings > Womens', ''),
(5008, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard Boots >
Boys', ''),
(5009, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding > Snowboard
Boots > Girls', ''),
(5010, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing & Snowboarding >
Snowboard Boots > Mens', ''),
(5011, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities > Skiing &
Snowboarding > Snowboard Boots > Womens', ''),
(5012, 'Sporting Goods > Outdoor Recreation > Winter Sports & Activities
> Skiing & Snowboarding > Snowboards > Boys', ''),
(5013, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Skiing & Snowboarding > Snowboards > Girls', ''),
(5014, 'Sporting Goods > Outdoor Recreation > Winter
Sports & Activities > Skiing & Snowboarding > Snowboards > Mens', ''),
(5015, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Skiing & Snowboarding > Snowboards > Womens', ''),
(5016, 'Sporting Goods > Outdoor
Recreation > Winter Sports & Activities > Sleds > Adult (unisex)', ''),
(5017, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Sleds > Kids (unisex)', ''),
(5018, 'Sporting Goods > Outdoor Recreation > Winter Sports &
Activities > Snowshoeing > Snowshoe Bindings > Adult (unisex)', ''),
(5019, 'Sporting Goods > Outdoor Recreation >
Winter Sports & Activities > Snowshoeing > Snowshoe Bindings > Kids (unisex)', ''),
(5020, 'Sporting Goods > Outdoor
Recreation > Winter Sports & Activities > Snowshoeing > Snowshoes > Adult (unisex)', ''),
(5021, 'Sporting Goods >
Outdoor Recreation > Winter Sports & Activities > Snowshoeing > Snowshoes > Kids (unisex)', ''),
(5022, 'Toys & Games >
Games > Battle Top Accessories', ''),
(5023, 'Toys & Games > Games > Battle Tops', ''),
(5024, 'Toys & Games > Games >
Bingo Sets', ''),
(5025, 'Toys & Games > Games > Blackjack & Craps Sets', ''),
(5026, 'Toys & Games > Games > Board
Games', ''),
(5027, 'Toys & Games > Games > Card Game Accessories', ''),
(5028, 'Toys & Games > Games > Card Games',
''),
(5029, 'Toys & Games > Games > Dexterity Games', ''),
(5030, 'Toys & Games > Games > Dice Sets & Games', ''),
(5031, 'Toys & Games > Games > Poker Chip Accessories', ''),
(5032, 'Toys & Games > Games > Poker Chip Accessories >
Poker Chip Carriers & Trays', ''),
(5033, 'Toys & Games > Games > Poker Chips & Sets', ''),
(5034, 'Toys & Games > Games
> Portable Electronic Games', ''),
(5035, 'Toys & Games > Games > Roulette Wheels & Sets', ''),
(5036, 'Toys & Games >
Games > Slot Machines', ''),
(5037, 'Toys & Games > Games > Tile Games', ''),
(5038, 'Toys & Games > Outdoor Play
Equipment > Inflatable Bouncer Accessories', ''),
(5039, 'Toys & Games > Outdoor Play Equipment > Inflatable Bouncers',
''),
(5040, 'Toys & Games > Outdoor Play Equipment > Play Swings', ''),
(5041, 'Toys & Games > Outdoor Play Equipment >
Play Tents & Tunnels', '');";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_category_list`
(`id`,`name`,`mapped_categories` )
VALUES (5042, 'Toys & Games > Outdoor Play Equipment > Playhouses', ''),
(5043, 'Toys
& Games > Outdoor Play Equipment > Pogo Sticks', ''),
(5044, 'Toys & Games > Outdoor Play Equipment > Sandboxes', ''),
(5045, 'Toys & Games > Outdoor Play Equipment > See Saws', ''),
(5046, 'Toys & Games > Outdoor Play Equipment > Slides',
''),
(5047, 'Toys & Games > Outdoor Play Equipment > Stilts', ''),
(5048, 'Toys & Games > Outdoor Play Equipment > Swing
Set & Playset Accessories', ''),
(5049, 'Toys & Games > Outdoor Play Equipment > Swing Sets & Playsets', ''),
(5050,
'Toys & Games > Outdoor Play Equipment > Trampoline Accessories', ''),
(5051, 'Toys & Games > Outdoor Play Equipment >
Trampolines', ''),
(5052, 'Toys & Games > Outdoor Play Equipment > Water Play Equipment', ''),
(5053, 'Toys & Games >
Outdoor Play Equipment > Water Play Equipment > Play Sprinkers', ''),
(5054, 'Toys & Games > Outdoor Play Equipment >
Water Play Equipment > Water Parks & Slides', ''),
(5055, 'Toys & Games > Outdoor Play Equipment > Water Play Equipment
> Water Tables', ''),
(5056, 'Toys & Games > Puzzles > Jigsaw Puzzle Accessories', ''),
(5057, 'Toys & Games > Puzzles >
Jigsaw Puzzles', ''),
(5058, 'Toys & Games > Puzzles > Mechanical Puzzles', ''),
(5059, 'Toys & Games > Puzzles > Wooden
& Pegged Puzzles', ''),
(5060, 'Toys & Games > Toys > Activity Toys > Ball & Cup Games', ''),
(5061, 'Toys & Games >
Toys > Activity Toys > Bouncy Balls', ''),
(5062, 'Toys & Games > Toys > Activity Toys > Bubble Blowing Solution', ''),
(5063, 'Toys & Games > Toys > Activity Toys > Bubble Blowing Toys', ''),
(5064, 'Toys & Games > Toys > Activity Toys >
Coiled Spring Toys', ''),
(5065, 'Toys & Games > Toys > Activity Toys > Marbles', ''),
(5066, 'Toys & Games > Toys >
Activity Toys > Paddle Ball Toys', ''),
(5067, 'Toys & Games > Toys > Activity Toys > Ribbon & Streamer Toys', ''),
(5068, 'Toys & Games > Toys > Activity Toys > Spinning Tops', ''),
(5069, 'Toys & Games > Toys > Activity Toys > Toy
Jacks', ''),
(5070, 'Toys & Games > Toys > Activity Toys > Yo-Yo Parts & Accessories', ''),
(5071, 'Toys & Games > Toys
> Activity Toys > Yo-Yos', ''),
(5072, 'Toys & Games > Toys > Art & Drawing Toys', ''),
(5073, 'Toys & Games > Toys >
Art & Drawing Toys > Play Dough & Putty', ''),
(5074, 'Toys & Games > Toys > Art & Drawing Toys > Toy Drawing Tablets',
''),
(5075, 'Toys & Games > Toys > Ball Pit Accessories', ''),
(5076, 'Toys & Games > Toys > Ball Pit Accessories > Ball
Pit Balls', ''),
(5077, 'Toys & Games > Toys > Ball Pits', ''),
(5078, 'Toys & Games > Toys > Bath Toys', ''),
(5079,
'Toys & Games > Toys > Beach & Sand Toys', ''),
(5080, 'Toys & Games > Toys > Building Toys > Construction Set Toys',
''),
(5081, 'Toys & Games > Toys > Building Toys > Foam Blocks', ''),
(5082, 'Toys & Games > Toys > Building Toys >
Interlocking Blocks', ''),
(5083, 'Toys & Games > Toys > Building Toys > Marble Track Sets', ''),
(5084, 'Toys & Games >
Toys > Building Toys > Wooden Blocks', ''),
(5085, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures > Action & Toy
Figures', ''),
(5086, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures > Bobblehead Figures', ''),
(5087, 'Toys &
Games > Toys > Dolls,Playsets & Toy Figures > Doll & Action Figure Accessories', ''),
(5088, 'Toys & Games > Toys >
Dolls,Playsets & Toy Figures > Dollhouse Accessories', ''),
(5089, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures >
Dollhouses', ''),
(5090, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures > Dolls', ''),
(5091, 'Toys & Games > Toys
> Dolls,Playsets & Toy Figures > Paper & Magnetic Dolls', ''),
(5092, 'Toys & Games > Toys > Dolls,Playsets & Toy
Figures > Puppet & Puppet Theater Accessories', ''),
(5093, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures > Puppet
Theaters', ''),
(5094, 'Toys & Games > Toys > Dolls,Playsets & Toy Figures > Puppets & Marionettes', ''),
(5095, 'Toys &
Games > Toys > Dolls,Playsets & Toy Figures > Stuffed Animals', ''),
(5096, 'Toys & Games > Toys > Dolls,Playsets & Toy
Figures > Toy Playsets', ''),
(5097, 'Toys & Games > Toys > Educational Toys > Ant Farms', ''),
(5098, 'Toys & Games >
Toys > Educational Toys > Astronomy Toys & Models', ''),
(5099, 'Toys & Games > Toys > Educational Toys > Bug Collecting
Kits', ''),
(5100, 'Toys & Games > Toys > Educational Toys > Educational Flash Cards', ''),
(5101, 'Toys & Games > Toys
> Educational Toys > Reading Toys', ''),
(5102, 'Toys & Games > Toys > Educational Toys > Science & Exploration Sets',
''),
(5103, 'Toys & Games > Toys > Educational Toys > Toy Abacuses', ''),
(5104, 'Toys & Games > Toys > Executive Toys',
''),
(5105, 'Toys & Games > Toys > Executive Toys > Magnet Toys', ''),
(5106, 'Toys & Games > Toys > Flying Toy
Accessories', ''),
(5107, 'Toys & Games > Toys > Flying Toy Accessories > Kite Accessories', ''),
(5108, 'Toys & Games >
Toys > Flying Toy Accessories > Kite Accessories > Kite Line Reels & Winders', ''),
(5109, 'Toys & Games > Toys > Flying
Toys > Air & Water Rockets', ''),
(5110, 'Toys & Games > Toys > Flying Toys > Kites', ''),
(5111, 'Toys & Games > Toys >
Flying Toys > Toy Gliders', ''),
(5112, 'Toys & Games > Toys > Flying Toys > Toy Parachutes', ''),
(5113, 'Toys & Games
> Toys > Musical Toys', ''),
(5114, 'Toys & Games > Toys > Musical Toys > Toy Instruments', ''),
(5115, 'Toys & Games >
Toys > Play Vehicle Accessories', ''),
(5116, 'Toys & Games > Toys > Play Vehicle Accessories > Toy Race Car & Track
Accessories', ''),
(5117, 'Toys & Games > Toys > Play Vehicle Accessories > Toy Train Accessories', ''),
(5118, 'Toys &
Games > Toys > Play Vehicles > Toy Airplanes', ''),
(5119, 'Toys & Games > Toys > Play Vehicles > Toy Boats', ''),
(5120, 'Toys & Games > Toys > Play Vehicles > Toy Cars', ''),
(5121, 'Toys & Games > Toys > Play Vehicles > Toy
Helicopters', ''),
(5122, 'Toys & Games > Toys > Play Vehicles > Toy Motorcycles', ''),
(5123, 'Toys & Games > Toys >
Play Vehicles > Toy Race Car & Track Sets', ''),
(5124, 'Toys & Games > Toys > Play Vehicles > Toy Spaceships', ''),
(5125, 'Toys & Games > Toys > Play Vehicles > Toy Trains & Train Sets', ''),
(5126, 'Toys & Games > Toys > Play Vehicles
> Toy Trucks & Construction Vehicles', ''),
(5127, 'Toys & Games > Toys > Pretend Play > Play Money & Banking', ''),
(5128, 'Toys & Games > Toys > Pretend Play > Pretend Electronics', ''),
(5129, 'Toys & Games > Toys > Pretend Play >
Pretend Housekeeping', ''),
(5130, 'Toys & Games > Toys > Pretend Play > Pretend Lawn & Garden', ''),
(5131, 'Toys &
Games > Toys > Pretend Play > Pretend Professions & Role Playing', ''),
(5132, 'Toys & Games > Toys > Pretend Play >
Pretend Shopping & Grocery', ''),
(5133, 'Toys & Games > Toys > Pretend Play > Toy Kitchens & Play Food', ''),
(5134,
'Toys & Games > Toys > Pretend Play > Toy Tools', ''),
(5135, 'Toys & Games > Toys > Remote Control Toy Accessories',
''),
(5136, 'Toys & Games > Toys > Remote Control Toys > Remote Control Airships & Blimps', ''),
(5137, 'Toys & Games >
Toys > Remote Control Toys > Remote Control Boats & Watercraft', ''),
(5138, 'Toys & Games > Toys > Remote Control Toys
> Remote Control Cars & Trucks', ''),
(5139, 'Toys & Games > Toys > Remote Control Toys > Remote Control Helicopters',
''),
(5140, 'Toys & Games > Toys > Remote Control Toys > Remote Control Motorcycles', ''),
(5141, 'Toys & Games > Toys >
Remote Control Toys > Remote Control Planes', ''),
(5142, 'Toys & Games > Toys > Remote Control Toys > Remote Control
Robots', ''),
(5143, 'Toys & Games > Toys > Remote Control Toys > Remote Control Tanks', ''),
(5144, 'Toys & Games >
Toys > Riding Toy Accessories', ''),
(5145, 'Toys & Games > Toys > Riding Toys > Electric Riding Vehicles', ''),
(5146,
'Toys & Games > Toys > Riding Toys > Hobby Horses', ''),
(5147, 'Toys & Games > Toys > Riding Toys > Push & Pedal Riding
Vehicles', ''),
(5148, 'Toys & Games > Toys > Riding Toys > Rocking & Spring Riding Toys', ''),
(5149, 'Toys & Games >
Toys > Riding Toys > Wagons', ''),
(5150, 'Toys & Games > Toys > Robotic Toys', ''),
(5151, 'Toys & Games > Toys >
Sports Toy Accessories', ''),
(5152, 'Toys & Games > Toys > Sports Toy Accessories > Fitness Toy Accessories', ''),
(5153, 'Toys & Games > Toys > Sports Toy Accessories > Fitness Toy Accessories > Hula Hoop Accessories', ''),
(5154,
'Toys & Games > Toys > Sports Toys > Baseball Toys', ''),
(5155, 'Toys & Games > Toys > Sports Toys > Basketball Toys',
''),
(5156, 'Toys & Games > Toys > Sports Toys > Boomerangs', ''),
(5157, 'Toys & Games > Toys > Sports Toys > Bowling
Toys', ''),
(5158, 'Toys & Games > Toys > Sports Toys > Fingerboards & Fingerboard Sets', ''),
(5159, 'Toys & Games >
Toys > Sports Toys > Fishing Toys', ''),
(5160, 'Toys & Games > Toys > Sports Toys > Fitness Toys', ''),
(5161, 'Toys &
Games > Toys > Sports Toys > Fitness Toys > Hula Hoops', ''),
(5162, 'Toys & Games > Toys > Sports Toys > Flying Discs',
''),
(5163, 'Toys & Games > Toys > Sports Toys > Footbags', ''),
(5164, 'Toys & Games > Toys > Sports Toys > Golf Toys',
''),
(5165, 'Toys & Games > Toys > Sports Toys > Hockey Toys', ''),
(5166, 'Toys & Games > Toys > Sports Toys >
Playground Balls', ''),
(5167, 'Toys & Games > Toys > Sports Toys > Racquet Sport Toys', ''),
(5168, 'Toys & Games >
Toys > Sports Toys > Toy Footballs', ''),
(5169, 'Toys & Games > Toys > Toy Gift Baskets', ''),
(5170, 'Toys & Games >
Toys > Toy Weapon & Gadget Accessories', ''),
(5171, 'Toys & Games > Toys > Toy Weapons & Gadgets', ''),
(5172, 'Toys &
Games > Toys > Visual Toys', ''),
(5173, 'Toys & Games > Toys > Visual Toys > Kaleidoscopes', ''),
(5174, 'Toys & Games
> Toys > Visual Toys > Prisms', ''),
(5175, 'Toys & Games > Toys > Wind-Up Toys', ''),
(5176, 'Vehicles & Parts >
Vehicle Parts & Accessories > Aircraft Parts & Accessories', ''),
(5177, 'Vehicles & Parts > Vehicle Parts & Accessories
> Motor Vehicle Electronics > Motor Vehicle A/V Players & In-Dash Systems', ''),
(5178, 'Vehicles & Parts > Vehicle
Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Amplifiers', ''),
(5179, 'Vehicles & Parts > Vehicle
Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Cassette Adapters', ''),
(5180, 'Vehicles & Parts >
Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Cassette Players', ''),
(5181, 'Vehicles & Parts
> Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Equalizers & Crossovers', ''),
(5182,
'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Parking Cameras', ''),
(5183, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Speakerphones', ''),
(5184, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Speakers', ''),
(5185, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Subwoofers', ''),
(5186, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Electronics > Motor Vehicle Video Monitor
Mounts', ''),
(5187, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Braking',
''),
(5188, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Carpet & Upholstery',
''),
(5189, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Climate Control', ''),
(5190, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Controls', ''),
(5191,
'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Engine Oil Circulation', ''),
(5192, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Engine Parts', ''),
(5193,
'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Engines', ''),
(5194, 'Vehicles &
Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Exhaust', ''),
(5195, 'Vehicles & Parts >
Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Frame & Body Parts', ''),
(5196, 'Vehicles & Parts >
Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Fuel Systems', ''),
(5197, 'Vehicles & Parts > Vehicle
Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Interior Fittings', ''),
(5198, 'Vehicles & Parts > Vehicle
Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Lighting', ''),
(5199, 'Vehicles & Parts > Vehicle Parts &
Accessories > Motor Vehicle Parts > Motor Vehicle Mirrors', ''),
(5200, 'Vehicles & Parts > Vehicle Parts & Accessories
> Motor Vehicle Parts > Motor Vehicle Power & Electrical Systems', ''),
(5201, 'Vehicles & Parts > Vehicle Parts &
Accessories > Motor Vehicle Parts > Motor Vehicle Seating', ''),
(5202, 'Vehicles & Parts > Vehicle Parts & Accessories
> Motor Vehicle Parts > Motor Vehicle Sensors & Gauges', ''),
(5203, 'Vehicles & Parts > Vehicle Parts & Accessories >
Motor Vehicle Parts > Motor Vehicle Suspension Parts', ''),
(5204, 'Vehicles & Parts > Vehicle Parts & Accessories >
Motor Vehicle Parts > Motor Vehicle Towing', ''),
(5205, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle
Parts > Motor Vehicle Transmission & Drivetrain Parts', ''),
(5206, 'Vehicles & Parts > Vehicle Parts & Accessories >
Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle Rims & Wheels', ''),
(5207, 'Vehicles & Parts >
Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle Rims & Wheels >
Automotive Rims & Wheels', ''),
(5208, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor
Vehicle Wheel Systems > Motor Vehicle Rims & Wheels > Motorcycle Rims & Wheels', ''),
(5209, 'Vehicles & Parts > Vehicle
Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle Rims & Wheels > Off-Road and
All-Terrain Vehicle Rims & Wheels', ''),
(5210, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts >
Motor Vehicle Wheel Systems > Motor Vehicle Tire Accessories', ''),
(5211, 'Vehicles & Parts > Vehicle Parts &
Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle Tires', ''),
(5212, 'Vehicles & Parts >
Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle Tires > Automotive
Tires', ''),
(5213, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems
> Motor Vehicle Tires > Motorcycle Tires', ''),
(5214, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle
Parts > Motor Vehicle Wheel Systems > Motor Vehicle Tires > Off-Road and All-Terrain Vehicle Tires', ''),
(5215,
'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Wheel Systems > Motor Vehicle
Wheel Parts', ''),
(5216, 'Vehicles & Parts > Vehicle Parts & Accessories > Motor Vehicle Parts > Motor Vehicle Window
Parts & Accessories', ''),
(5217, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Portable Fuel Cans', ''),
(5218, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Vehicle Cleaning > Car Wash Brushes', ''),
(5219, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Cleaning > Car Wash Solutions', ''),
(5220, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Cleaning > Vehicle Carpet & Upholstery Cleaners', ''),
(5221,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Cleaning > Vehicle Fuel
Injection Cleaning Kits', ''),
(5222, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor
> Vehicle Cleaning > Vehicle Glass Cleaners', ''),
(5223, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Cleaning > Vehicle Waxes,Polishes & Protectants', ''),
(5224, 'Vehicles & Parts >
Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Golf Cart Enclosures', ''),
(5225,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Motor Vehicle
Windshield Covers', ''),
(5226, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Vehicle Covers > Tonneau Covers', ''),
(5227, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care
& Decor > Vehicle Covers > Vehicle Hardtops', ''),
(5228, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Covers > Vehicle Soft Tops', ''),
(5229, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Vehicle Storage Covers', ''),
(5230, 'Vehicles & Parts
> Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Vehicle Storage Covers > Automotive
Storage Covers', ''),
(5231, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Vehicle Covers > Vehicle Storage Covers > Golf Cart Storage Covers', ''),
(5232, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Vehicle Storage Covers > Motorcycle Storage Covers',
''),
(5233, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers >
Vehicle Storage Covers > Recreational Vehicle Storage Covers', ''),
(5234, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Covers > Vehicle Storage Covers > Watercraft Storage Covers',
''),
(5235, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Bumper
Stickers', ''),
(5236, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle
Decor > Vehicle Air Fresheners', ''),
(5237, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care
& Decor > Vehicle Decor > Vehicle Antenna Balls', ''),
(5238, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Decor > Vehicle Dashboard Accessories', ''),
(5239, 'Vehicles & Parts > Vehicle Parts
& Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle Decals', ''),
(5240, 'Vehicles & Parts >
Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle Decor Accessory Sets', ''),
(5241, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle
Display Flags', ''),
(5242, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle
Decor > Vehicle Emblems & Hood Ornaments', ''),
(5243, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Decor > Vehicle Hitch Covers', ''),
(5244, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle License Plate Covers', ''),
(5245, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle License Plate Frames',
''),
(5246, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle
License Plate Mounts & Holders', ''),
(5247, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care
& Decor > Vehicle Decor > Vehicle License Plates', ''),
(5248, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Decor > Vehicle Magnets', ''),
(5249, 'Vehicles & Parts > Vehicle Parts & Accessories
> Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle Rear View Mirror Ornaments', ''),
(5250, 'Vehicles & Parts
> Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle Shift Boots', ''),
(5251,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor > Vehicle Shift
Knobs', ''),
(5252, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Decor >
Vehicle Steering Wheel Covers', ''),
(5253, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care &
Decor > Vehicle Fluids', ''),
(5254, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor
> Vehicle Fluids > Vehicle Antifreeze', ''),
(5255, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Fluids > Vehicle Brake Fluid', ''),
(5256, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle Cooling System Additives', ''),
(5257,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle Engine
Degreasers', ''),
(5258, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle
Fluids > Vehicle Fuel System Cleaners', ''),
(5259, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Fluids > Vehicle Greases', ''),
(5260, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle Hydraulic Clutch Fluid', ''),
(5261, 'Vehicles
& Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle Motor Oil', ''),
(5262, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle
Performance Additives', ''),
(5263, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Vehicle Fluids > Vehicle Power Steering Fluid', ''),
(5264, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Maintenance,Care & Decor > Vehicle Fluids > Vehicle Transmission Fluid', ''),
(5265, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Fluids > Vehicle Windshield Fluid', ''),
(5266, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Paint > Motor Vehicle Body Paint', ''),
(5267, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Paint > Motor
Vehicle Brake Caliper Paint', ''),
(5268, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care &
Decor > Vehicle Repair & Specialty Tools > Motor Vehicle Brake Service Kits', ''),
(5269, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty Tools > Motor Vehicle Clutch
Alignment & Removal Tools', ''),
(5270, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care &
Decor > Vehicle Repair & Specialty Tools > Vehicle Battery Chargers', ''),
(5271, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty Tools > Vehicle Battery Testers', ''),
(5272, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty
Tools > Vehicle Body Filler', ''),
(5273, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care &
Decor > Vehicle Repair & Specialty Tools > Vehicle Diagnostic Scanners', ''),
(5274, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty Tools > Vehicle Jump Starters', ''),
(5275,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty Tools >
Vehicle Jumper Cables', ''),
(5276, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Maintenance,Care & Decor >
Vehicle Repair & Specialty Tools > Vehicle Tire Repair & Tire Changing Tools', ''),
(5277, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Maintenance,Care & Decor > Vehicle Repair & Specialty Tools > Windshield Repair Kits',
''),
(5278, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Motorcycle Protective Gear >
Motorcycle Chest & Back Protectors', ''),
(5279, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety &
Security > Motorcycle Protective Gear > Motorcycle Elbow & Wrist Guards', ''),
(5280, 'Vehicles & Parts > Vehicle Parts
& Accessories > Vehicle Safety & Security > Motorcycle Protective Gear > Motorcycle Gloves', ''),
(5281, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Motorcycle Protective Gear > Motorcycle Goggles', ''),
(5282, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Motorcycle Protective Gear >
Motorcycle Hand Guards', ''),
(5283, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security >
Motorcycle Protective Gear > Motorcycle Helmet Parts & Accessories', ''),
(5284, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Safety & Security > Motorcycle Protective Gear > Motorcycle Helmets', ''),
(5285, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Motorcycle Protective Gear > Motorcycle Kidney Belts',
''),
(5286, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Motorcycle Protective Gear >
Motorcycle Knee & Shin Guards', ''),
(5287, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security
> Motorcycle Protective Gear > Motorcycle Neck Braces', ''),
(5288, 'Vehicles & Parts > Vehicle Parts & Accessories >
Vehicle Safety & Security > Off-Road & All-Terrain Vehicle Protective Gear', ''),
(5289, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Safety & Security > Off-Road & All-Terrain Vehicle Protective Gear > ATV & UTV Bar Pads',
''),
(5290, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Alarms & Locks >
Automotive Alarm Accessories', ''),
(5291, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security >
Vehicle Alarms & Locks > Automotive Alarm Systems', ''),
(5292, 'Vehicles & Parts > Vehicle Parts & Accessories >
Vehicle Safety & Security > Vehicle Alarms & Locks > Motorcycle Alarms & Locks', ''),
(5293, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Safety & Security > Vehicle Alarms & Locks > Vehicle Door Locks & Parts > Vehicle Door
Lock Actuators', ''),
(5294, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle
Alarms & Locks > Vehicle Door Locks & Parts > Vehicle Door Lock Knobs', ''),
(5295, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Safety & Security > Vehicle Alarms & Locks > Vehicle Door Locks & Parts > Vehicle Door Locks &
Locking Systems', ''),
(5296, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle
Alarms & Locks > Vehicle Hitch Locks', ''),
(5297, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety &
Security > Vehicle Alarms & Locks > Vehicle Immobilizers', ''),
(5298, 'Vehicles & Parts > Vehicle Parts & Accessories >
Vehicle Safety & Security > Vehicle Alarms & Locks > Vehicle Remote Keyless Systems', ''),
(5299, 'Vehicles & Parts >
Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Alarms & Locks > Vehicle Steering Wheel Locks', ''),
(5300, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Alarms & Locks > Vehicle
Wheel Clamps', ''),
(5301, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Safety
Equipment > Car Window Nets', ''),
(5302, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security >
Vehicle Safety Equipment > Emergency Road Flares', ''),
(5303, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Safety & Security > Vehicle Safety Equipment > Motor Vehicle Airbag Parts', ''),
(5304, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Safety & Security > Vehicle Safety Equipment > Motor Vehicle Roll Cages & Bars', ''),
(5305, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Safety Equipment > Vehicle
Seat Belt Buckles', ''),
(5306, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle
Safety Equipment > Vehicle Seat Belt Covers', ''),
(5307, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Safety & Security > Vehicle Safety Equipment > Vehicle Seat Belt Straps', ''),
(5308, 'Vehicles & Parts > Vehicle Parts
& Accessories > Vehicle Safety & Security > Vehicle Safety Equipment > Vehicle Seat Belts', ''),
(5309, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Safety Equipment > Vehicle Warning Whips',
''),
(5310, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Safety & Security > Vehicle Safety Equipment >
Vehicle Wheel Chocks', ''),
(5311, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor
Vehicle Cargo Nets', ''),
(5312, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor
Vehicle Carrying Rack Accessories', ''),
(5313, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage &
Cargo > Motor Vehicle Carrying Rack Accessories > Vehicle Bicycle Rack Accessories', ''),
(5314, 'Vehicles & Parts >
Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying Rack Accessories > Vehicle Ski &
Snowboard Rack Accessories', ''),
(5315, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo >
Motor Vehicle Carrying Racks > Vehicle Base Rack Systems', ''),
(5316, 'Vehicles & Parts > Vehicle Parts & Accessories >
Vehicle Storage & Cargo > Motor Vehicle Carrying Racks > Vehicle Bicycle Racks', ''),
(5317, 'Vehicles & Parts > Vehicle
Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying Racks > Vehicle Boat Racks', ''),
(5318,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying Racks > Vehicle Cargo
Racks', ''),
(5319, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying
Racks > Vehicle Fishing Rod Racks', ''),
(5320, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage &
Cargo > Motor Vehicle Carrying Racks > Vehicle Gun Racks', ''),
(5321, 'Vehicles & Parts > Vehicle Parts & Accessories >
Vehicle Storage & Cargo > Motor Vehicle Carrying Racks > Vehicle Motorcycle & Scooter Racks', ''),
(5322, 'Vehicles &
Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying Racks > Vehicle Ski & Snowboard
Racks', ''),
(5323, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Carrying
Racks > Vehicle Water Sport Board Racks', ''),
(5324, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage
& Cargo > Motor Vehicle Loading Ramps', ''),
(5325, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage &
Cargo > Motor Vehicle Trailers > Boat Trailers', ''),
(5326, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle
Storage & Cargo > Motor Vehicle Trailers > Horse & Livestock Trailers', ''),
(5327, 'Vehicles & Parts > Vehicle Parts &
Accessories > Vehicle Storage & Cargo > Motor Vehicle Trailers > Travel Trailers', ''),
(5328, 'Vehicles & Parts >
Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motor Vehicle Trailers > Utility & Cargo Trailers', ''),
(5329,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Motorcycle Bags & Panniers', ''),
(5330,
'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Truck Bed Storage Boxes & Organizers', ''),
(5331, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Vehicle Headrest Hangers & Hooks',
''),
(5332, 'Vehicles & Parts > Vehicle Parts & Accessories > Vehicle Storage & Cargo > Vehicle Organizers', ''),
(5333,
'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Docking & Anchoring > Anchor Chains',
''),
(5334, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Docking & Anchoring >
Anchor Lines & Ropes', ''),
(5335, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories >
Docking & Anchoring > Anchor Windlasses', ''),
(5336, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts
& Accessories > Docking & Anchoring > Anchors', ''),
(5337, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft
Parts & Accessories > Docking & Anchoring > Boat Hooks', ''),
(5338, 'Vehicles & Parts > Vehicle Parts & Accessories >
Watercraft Parts & Accessories > Docking & Anchoring > Boat Ladders', ''),
(5339, 'Vehicles & Parts > Vehicle Parts &
Accessories > Watercraft Parts & Accessories > Docking & Anchoring > Dock Cleats', ''),
(5340, 'Vehicles & Parts >
Vehicle Parts & Accessories > Watercraft Parts & Accessories > Docking & Anchoring > Dock Steps', ''),
(5341, 'Vehicles
& Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Sailboat Parts', ''),
(5342, 'Vehicles & Parts
> Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Care', ''),
(5343, 'Vehicles & Parts >
Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Care > Watercraft Cleaners', ''),
(5344,
'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Care > Watercraft
Polishes', ''),
(5345, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft
Engine Parts > Watercraft Alternators', ''),
(5346, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts &
Accessories > Watercraft Engine Parts > Watercraft Carburetors & Parts', ''),
(5347, 'Vehicles & Parts > Vehicle Parts &
Accessories > Watercraft Parts & Accessories > Watercraft Engine Parts > Watercraft Engine Controls', ''),
(5348,
'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Engine Parts > Watercraft
Ignition Parts', ''),
(5349, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories >
Watercraft Engine Parts > Watercraft Impellers', ''),
(5350, 'Vehicles & Parts > Vehicle Parts & Accessories >
Watercraft Parts & Accessories > Watercraft Engine Parts > Watercraft Motor Locks', ''),
(5351, 'Vehicles & Parts >
Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Engine Parts > Watercraft Motor Mounts', ''),
(5352, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Engine Parts >
Watercraft Pistons & Parts', ''),
(5353, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts &
Accessories > Watercraft Engine Parts > Watercraft Propellers', ''),
(5354, 'Vehicles & Parts > Vehicle Parts &
Accessories > Watercraft Parts & Accessories > Watercraft Engines & Motors', ''),
(5355, 'Vehicles & Parts > Vehicle
Parts & Accessories > Watercraft Parts & Accessories > Watercraft Exhaust Parts > Watercraft Manifolds', ''),
(5356,
'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Exhaust Parts > Watercraft
Mufflers & Parts', ''),
(5357, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories >
Watercraft Fuel Systems > Watercraft Fuel Lines & Parts', ''),
(5358, 'Vehicles & Parts > Vehicle Parts & Accessories >
Watercraft Parts & Accessories > Watercraft Fuel Systems > Watercraft Fuel Meters', ''),
(5359, 'Vehicles & Parts >
Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Fuel Systems > Watercraft Fuel Pumps & Parts',
''),
(5360, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts & Accessories > Watercraft Fuel Systems >
Watercraft Fuel Tanks & Parts', ''),
(5361, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts &
Accessories > Watercraft Lighting', ''),
(5362, 'Vehicles & Parts > Vehicle Parts & Accessories > Watercraft Parts &
Accessories > Watercraft Steering Parts > Watercraft Steering Cables', ''),
(5363, 'Vehicles & Parts > Vehicle Parts &
Accessories > Watercraft Parts & Accessories > Watercraft Steering Parts > Watercraft Steering Wheels', ''),
(5364,
'Vehicles & Parts > Vehicles > Aircraft', ''),
(5365, 'Vehicles & Parts > Vehicles > Motor Vehicles > Cars,Trucks &
Vans', ''),
(5366, 'Vehicles & Parts > Vehicles > Motor Vehicles > Golf Carts', ''),
(5367, 'Vehicles & Parts > Vehicles
> Motor Vehicles > Motorcycles & Scooters', ''),
(5368, 'Vehicles & Parts > Vehicles > Motor Vehicles > Off-Road and
All-Terrain Vehicles', ''),
(5369, 'Vehicles & Parts > Vehicles > Motor Vehicles > Off-Road and All-Terrain Vehicles >
ATVs & UTVs', ''),
(5370, 'Vehicles & Parts > Vehicles > Motor Vehicles > Off-Road and All-Terrain Vehicles > Go Karts &
Dune Buggies', ''),
(5371, 'Vehicles & Parts > Vehicles > Motor Vehicles > Recreational Vehicles', ''),
(5372, 'Vehicles
& Parts > Vehicles > Motor Vehicles > Snowmobiles', ''),
(5373, 'Vehicles & Parts > Vehicles > Watercraft > Motor
Boats', ''),
(5374, 'Vehicles & Parts > Vehicles > Watercraft > Personal Watercraft', ''),
(5375, 'Vehicles & Parts >
Vehicles > Watercraft > Sailboats', ''),
(5376, 'Vehicles & Parts > Vehicles > Watercraft > Yachts', '');";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_products` (   
`id` int(11) NOT NULL AUTO_INCREMENT,
`product_id` int(11) NOT NULL,   
`attributes` longtext NOT NULL,   
`fruugo_status` text NOT NULL,   
`error_message` text NOT NULL,   
`fruugoSkuId` bigint(20) NOT NULL,   
PRIMARY KEY  (`id`)
 ) ;";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_default_values` (   
`id` int(11) NOT NULL AUTO_INCREMENT,   
`fruugo_attribute` longtext NOT NULL,   
`default_value` longtext NOT NULL,   
PRIMARY KEY  (`id`) 
) ;";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_country_currency` (   
`id` int(11) NOT NULL AUTO_INCREMENT,   
`country` text NOT NULL,   
`country_code` text NOT NULL,   
`language` text NOT NULL,   
`currency_code` text NOT NULL,   
`eu_member` text NOT NULL,   
PRIMARY KEY  (`id`) 
) ;";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_product_variations` (   
`id` int(11) NOT NULL AUTO_INCREMENT,   
`product_id` int(11) NOT NULL,   
`fruugo_status` text NOT NULL,   
`error_message` text NOT NULL,
`fruugoSkuId` bigint(20) NOT NULL,   
`sku` text NOT NULL,   
`combination` text NOT NULL,    
PRIMARY KEY  (`id`) 
);";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_order` (   
`id` int(11) NOT NULL AUTO_INCREMENT,
`prestashop_order_id` int(11) NOT NULL,   
`fruugo_order_id` text NOT NULL,   
`order_data` longtext NOT NULL,
`order_place_date` datetime NOT NULL,   
`status` text NOT NULL,   
`shipment_data` longtext NOT NULL,
`shipment_request_data` text NOT NULL,    
PRIMARY KEY  (`id`) 
);";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_order_error` (   
`id` int(11) NOT NULL AUTO_INCREMENT,
`merchant_sku` text NOT NULL,   
`fruugo_order_id` text NOT NULL,   
`order_data` longtext NOT NULL,   
`reason` text NOT NULL,   
`cancel_qty` int(10),
 PRIMARY KEY  (`id`) 
 );";

$sql[] = "CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "fruugo_logs` (   
`id` int(11) NOT NULL AUTO_INCREMENT,   
`method` text NOT NULL,   
`type` varchar(150) NOT NULL,
`message` text NOT NULL,   
`data` longtext NOT NULL,   
`created_at` datetime default current_timestamp,   
 PRIMARY KEY (`id`) 
 );";

$sql[] = "INSERT INTO `"._DB_PREFIX_."fruugo_country_currency`  (`id`, `country`, `country_code`, `language`,
`currency_code`, `eu_member`)
VALUES (1, 'United Kingdom', 'GB', 'en', 'GBP', 'Yes'),
(2, 'Republic of Ireland', 'IE',
'en', 'EUR', 'Yes'),
(3, 'France', 'FR', 'fr', 'EUR', 'Yes'),
(4, 'France', 'FR', 'en', 'EUR', 'Yes'),
(5, 'Germany',
'DE', 'de', 'EUR', 'Yes'),
(6, 'Germany', 'DE', 'en', 'EUR', 'Yes'),
(7, 'Spain', 'ES', 'es', 'EUR', 'Yes'),
(8,
'Spain', 'ES', 'en', 'EUR', 'Yes'),
(9, 'Portugal', 'PT', 'en', 'EUR', 'Yes'),
(10, 'Portugal', 'PT', 'pt', 'EUR',
'Yes'),
(11, 'Belgium', 'BE', 'de', 'EUR', 'Yes'),
(12, 'Belgium', 'BE', 'fr', 'EUR', 'Yes'),
(13, 'Belgium', 'BE',
'nl', 'EUR', 'Yes'),
(14, 'Belgium', 'BE', 'en', 'EUR', 'Yes'),
(15, 'Netherlands', 'NL', 'en', 'EUR', 'Yes'),
(16,
'Netherlands', 'NL', 'nl', 'EUR', 'Yes'),
(17, 'Luxembourg', 'LU', 'en', 'EUR', 'Yes'),
(18, 'Luxembourg', 'LU', 'de',
'EUR', 'Yes'),
(19, 'Luxembourg', 'LU', 'fr', 'EUR', 'Yes'),
(20, 'Poland', 'PL', 'en', 'PLN', 'Yes'),
(21, 'Poland',
'PL', 'pl', 'PLN', 'Yes'),
(22, 'Austria', 'AT', 'en', 'EUR', 'Yes'),
(23, 'Austria', 'AT', 'de', 'EUR', 'Yes'),
(24,
'Italy', 'IT', 'en', 'EUR', 'Yes'),
(25, 'Italy', 'IT', 'it', 'EUR', 'Yes'),
(26, 'Denmark', 'DK', 'da', 'DKK', 'Yes'),
(27, 'Denmark', 'DK', 'en', 'DKK', 'Yes'),
(28, 'Sweden', 'SE', 'sv', 'SEK', 'Yes'),
(29, 'Sweden', 'SE', 'fi  ', 'SEK',
'Yes'),
(30, 'Sweden', 'SE', 'en', 'SEK', 'Yes'),
(31, 'Finland', 'FI', 'fi', 'EUR', 'Yes'),
(32, 'Finland', 'FI', 'sv
', 'EUR', 'Yes'),
(33, 'Finland', 'FI', 'en', 'EUR', 'Yes'),
(34, 'Norway', 'NO', 'no', 'NOK', 'No'),
(35, 'Norway',
'NO', 'en', 'NOK', 'No'),
(36, 'Switzerland', 'CH', 'de', 'CHF', 'No'),
(37, 'Switzerland', 'CH', 'it', 'CHF', 'No'),
(38, 'Switzerland', 'CH', 'de', 'CHF', 'No'),
(39, 'Switzerland', 'CH', 'en', 'CHF', 'No'),
(40, 'Russia', 'RU', 'ru',
'RUB', 'No'),
(41, 'Russia', 'RU', 'en', 'RUB', 'No'),
(42, 'South Africa', 'ZA', 'nl', 'ZAR', 'No'),
(43, 'South
Africa', 'ZA', 'en', 'ZAR', 'No'),
(44, 'Canada', 'CA', 'fr', 'CAD', 'No'),
(45, 'Canada', 'CA', 'en', 'CAD', 'No'),
(46, 'Australia', 'AU', 'en', 'AUD', 'No'),
(47, 'New Zealand', 'NZ', 'en', 'NZD', 'No'),
(48, 'China', 'CN', 'zh',
'CNY', 'No'),
(49, 'China', 'CN', 'en', 'CNY', 'No'),
(50, 'Japan', 'JP', 'jp', 'JPY', 'No'),
(51, 'Japan', 'JP', 'en',
'JPY', 'No'),
(52, 'India', 'IN', 'hi', 'INR', 'No'),
(53, 'Saudi Arabia', 'SA', 'ar', 'SAR', 'No'),
(54, 'Saudi
Arabia', 'SA', 'en', 'SAR', 'No'),
(55, 'Qatar', 'QA', 'ar', 'QAR', 'No'),
(56, 'Qatar', 'QA', 'en', 'QAR', 'No'),
(57,
'Bahrain', 'BH', 'ar', 'BHD', 'No'),
(58, 'Bahrain', 'BH', 'en', 'BHD', 'No'),
(59, 'United Arab Emirates', 'AE', 'ar',
'AED', 'No'),
(60, 'United Arab Emirates', 'AE', 'en', 'AED', 'No'),
(61, 'Egypt', 'EG', 'ar', 'EGP', 'No'),
(62,
'Egypt', 'EG', 'en', 'EGP', 'No'),
(63, 'Kuwait', 'KW', 'ar', 'KWD', 'No'),
(64, 'Kuwait', 'KW', 'en', 'KWD', 'No');";

foreach ($sql as $query) {
    if ($db->execute($query) == false) {
        return false;
    }
}
