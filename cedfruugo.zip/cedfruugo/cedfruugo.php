<?php
 /**
  * CedCommerce
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the End User License Agreement(EULA)
  * that is bundled with this package in the file LICENSE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://cedcommerce.com/license-agreement.txt
  *
  * @author    CedCommerce Core Team <connect@cedcommerce.com>
  * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
  * @license   http://cedcommerce.com/license-agreement.txt
  * @category  Ced
  * @package   CedFruugo
  */

if (!defined('_PS_VERSION_')) {
    exit;
}
include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoHelper.php';
include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoProduct.php';
include_once  _PS_MODULE_DIR_.'cedfruugo/classes/CedfruugoOrder.php';
class Cedfruugo extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'cedfruugo';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Cedcommerce';
        $this->need_instance = 0;
        $this->db =  Db::getInstance();
        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->module_key = '634e216f748740b75991d6460de21b87';
        $this->bootstrap = true;
        $this->secure_key = Tools::encrypt($this->name);
        parent::__construct();

        $this->displayName = $this->l('Fruugo Integration');
        $this->description = $this->l(
            'Fruugo Integration By Cedcommerce Is a connector module for prestashop and Fruugo.'
        );

        $this->confirmUninstall = $this->l('Do you want to uninstall Fruugo Integration');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
//        require_once  _PS_MODULE_DIR_.'cedfruugo/sql/sql_install.php';
        Configuration::updateValue('CEDFRUUGO_LIVE_MODE', false);
        if (count($this->db->ExecuteS("SHOW TABLES LIKE '"._DB_PREFIX_."fruugo_category_list%'"))==0) {
            require_once  _PS_MODULE_DIR_.'cedfruugo/sql/sql_install.php';
        }

        $shop_email =  Configuration::get('PS_SHOP_EMAIL');
        $shop_url =  Context::getContext()->shop->getBaseURL(true);
        $require_data =  array('domain'=>$shop_url, 'email'=>$shop_email, 'framework'=>'PrestaShop');
        $cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-fruugo-info/create?'
            .http_build_query($require_data);

        $ch = curl_init($cedcommerce_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);

        // Check if any error occurred
        if (curl_errno($ch)) {
            $cedfruugoHelper = new CedfruugoHelper;
            $cedfruugoHelper->log(
                __METHOD__,
                'Warning',
                'Install Message curl error',
                curl_errno($ch)
            );
        }

        // Close handle
        curl_close($ch);

        return parent::install() &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('actionUpdateQuantity') &&
            $this->registerHook('actionProductDelete') &&
            $this->installTab(
                'AdminCedfruugo',
                'Fruugo Integration',
                0
            ) &&
            $this->installTab(
                'AdminCedfruugoCategory',
                'Fruugo Category',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoAttribute',
                'Fruugo Attribute',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoProducts',
                'Fruugo Products',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoDefault',
                'Fruugo Default Values',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoOrders',
                'Fruugo Orders',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoFailedorder',
                'Fruugo Failed Orders',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoStock',
                'Fruugo Stock',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoUploadall',
                'Fruugo Upload All',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoLogs',
                'Fruugo Logs',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->installTab(
                'AdminCedfruugoConfig',
                'Fruugo Configuration',
                (int) Tab::getIdFromClassName('AdminCedfruugo')
            ) &&
            $this->registerHook('actionOrderStatusPostUpdate');
    }
    public function installTab($class_name, $tab_name, $parent)
    {
        // Create new admin tab
        $tab = new Tab();
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tab_name;
        }
        if ($parent == 0 && _PS_VERSION_ >= '1.7') {
            $tab->id_parent = (int)Tab::getIdFromClassName('SELL');
            $tab->icon = 'CF';
        } else {
            $tab->id_parent = $parent;
        }
//        $tab->id_parent = (int) Tab::getIdFromClassName($parent);
//        $tab->icon = 'CF';
        $tab->class_name = $class_name;
        $tab->module = $this->name;
        $tab->active = 1;
        return $tab->add();
    }
    public function uninstallTab($class_name)
    {
        $id_tab = (int)Tab::getIdFromClassName($class_name);
        if ($id_tab) {
            try {
                $tab = new Tab($id_tab);
                return $tab->delete();
            } catch (\Exception $e) {
                return false;
            }
        } else {
            return false;
        }
    }
    public function uninstall()
    {
        Configuration::deleteByName('CEDFRUUGO_LIVE_MODE');

        return parent::uninstall() && $this->uninstallTab('AdminCedfruugo') &&
            $this->uninstallTab('AdminCedfruugoCategory') &&
            $this->uninstallTab('AdminCedfruugoProducts') &&
            $this->uninstallTab('AdminCedfruugoOrders') &&
            $this->uninstallTab('AdminCedfruugoDefault') &&
            $this->uninstallTab('AdminCedfruugoStock') &&
            $this->uninstallTab('AdminCedfruugoUploadall') &&
            $this->uninstallTab('AdminCedfruugoConfig') &&
            $this->uninstallTab('AdminCedfruugoLogs') &&
            $this->uninstallTab('AdminCedfruugoFailedorder') &&
            $this->unregisterHook('displayBackOfficeHeader') &&
            $this->unregisterHook('actionUpdateQuantity') &&
            $this->unregisterHook('actionProductDelete') &&
            $this->unregisterHook('actionProductDelete') &&
            $this->unregisterHook('actionOrderStatusPostUpdate');
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        $output = '';
        if (((bool)Tools::isSubmit('submitCedfruugoModule')) == true) {
            $this->postProcess();
            if (Tools::getValue('CEDFRUUGO_CONSUMER_ID') == ''
                || Tools::getValue('CEDFRUUGO_CONSUMER_ID') == null) {
                $output .= $this->displayError('Please Fill Fruugo User Name');
            }
            if (Tools::getValue('CEDFRUUGO_CONSUMER_PASSWORD') == ''
                || Tools::getValue('CEDFRUUGO_CONSUMER_PASSWORD') == null) {
                $output .= $this->displayError('Please Fill Fruugo User Password');
            }
            if (Tools::getValue('CEDFRUUGO_CUSTOMER_ID')
                && !empty(Tools::getValue('CEDFRUUGO_CUSTOMER_ID'))) {
                if (!Validate::isInt(Tools::getValue('CEDFRUUGO_CUSTOMER_ID'))) {
                    $output .= $this->displayError($this->l('Customer Id must be numeric'));
                    Configuration::updateValue('CEDFRUUGO_CUSTOMER_ID', '');
                }
            }

            if ($output =='') {
                $output .= $this->displayConfirmation($this->l('Fruugo Configuration saved  successfully'));
            }
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        $output1 = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');

        return $output. $output1.$this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $fields_form = array();
        $fields_form[0]['form'] = $this->getGeneralSettingForm();
        $fields_form[1]['form'] = $this->getProductSettingForm();
        $fields_form[2]['form'] = $this->getOrderSettingForm();
        $fields_form[3]['form'] = $this->getCronInfoForm();
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitCedfruugoModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm($fields_form);
    }

    public function getGeneralSettingForm()
    {
        $store_languages = array();

        $store_languages_list = Language::getLanguages(true);

        foreach ($store_languages_list as $languages) {
            if (isset($languages['id_lang']) && $languages['id_lang']
                && isset($languages['name']) && $languages['name']
                && isset($languages['active']) && $languages['active']) {
                array_push($store_languages, array('id'=>$languages['id_lang'], 'name'=>$languages['name']));
            }
        }
        return  array(
           'legend' => array(
               'title' => $this->l('General Settings'),
               'icon' => 'icon-cogs',
           ),
           'input' => array(
               array(
                   'type' => 'switch',
                   'label' => $this->l('Enable'),
                   'name' => 'CEDFRUUGO_LIVE_MODE',
                   'is_bool' => true,
                   'desc' => $this->l('Enable this module.'),
                   'values' => array(
                       array(
                           'id' => 'active_on',
                           'value' => true,
                           'label' => $this->l('Yes')
                       ),
                       array(
                           'id' => 'active_off',
                           'value' => false,
                           'label' => $this->l('No')
                       )
                   ),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('API URL OF FRUUGO SELLER i.e. "https://www.fruugo.com/".'),
                   'name' => 'CEDFRUUGO_API_URL',
                   'readonly' => true,
                   'default_value' => 'https://www.fruugo.com/',
                   'label' => $this->l('API Url'),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('Fruugo User Name.'),
                   'name' => 'CEDFRUUGO_CONSUMER_ID',
                   'required' => true,
                   'label' => $this->l('Fruugo User Name'),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('Fruugo User Name.'),
                   'name' => 'CEDFRUUGO_CONSUMER_PASSWORD',
                   'required' => true,
                   'label' => $this->l('Fruugo User Password.'),
               ),
               array(
                   'type' => 'select',
                   'label' => $this->l('Store Language'),
                   'desc' => $this->l('Store Language to be used in this module.'),
                   'name' => 'CEDFRUUGO_LANGUAGE_STORE',
                   'required' => false,
                   'default_value' => '',
                   'options' => array(
                       'query' => $store_languages,
                       'id' => 'id',
                       'name' => 'name',
                   )
               ),
               array(
                   'type' => 'switch',
                   'label' => $this->l('Debug.'),
                   'name' => 'CEDFRUUGO_DEBUG_ENABLE',
                   'is_bool' => true,
                   'desc' => $this->l('Log data while request sends on fruugo.'),
                   'values' => array(
                       array(
                           'id' => 'active_on',
                           'value' => true,
                           'label' => $this->l('Yes')
                       ),
                       array(
                           'id' => 'active_off',
                           'value' => false,
                           'label' => $this->l('No')
                       )
                   ),
               ),
           )
        );
    }
    public function getProductSettingForm()
    {
        $categories = array();
        $cedfruugoProduct = new CedfruugoProduct();
        $categories = $cedfruugoProduct->getAllFruugoCategory();
        return array(
            'legend' => array(
                'title' => $this->l('Product Settings'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'readonly' => true,
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Products Feed url which is to be shared with fruugo.'),
                    'name' => 'CEDFRUUGO_FEED_URL',
                    'label' => $this->l('Products Feed Url'),
                ),
                array(
                    'type' => 'select',
                    'col' => 6,
                    'label' => $this->l('Is Manufacturer'),
                    'name' => 'CEDFRUUGO_IS_MANUFACTURER',
                    'desc' => $this->l('If merchant is manufacturer too in this 
                        case product "EAN" is not required at Fruugo.'),
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 0, 'label' => 'No'),
                            array('value' => 1, 'label' => 'Yes'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Price variant Type'),
                    'name' => 'CEDFRUUGO_PRICE_VARIANT_TYPE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 0, 'label' => '--  Select Price Variation --'),
                            array('value' => 1, 'label' => 'Regular Price'),
                            array('value' => 2, 'label' => 'Increase Fixed Amount'),
                            array('value' => 3, 'label' => 'Decrease Fix Amount'),
                            array('value' => 4, 'label' => 'Increase Fix Percent'),
                            array('value' => 5, 'label' => 'Decrease Fix Percent'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'col' => 3,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Amount to be variate on the basis of Increment or Decrement value.'),
                    'name' => 'CEDFRUUGO_PRICE_VARIANT_AMOUNT',
                    'label' => $this->l('Price Variant Value'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Fruugo Price Type'),
                    'name' => 'CEDFRUUGO_PRICE_TYPE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 'NormalPriceWithoutVAT', 'label' => 'Normal Price Without VAT'),
                            array('value' => 'NormalPriceWithVAT', 'label' => 'Normal Price With VAT'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),

                array(
                    'type' => 'select',
                    'col' =>'9',
                    'label' => $this->l('Disabled Product Upload'),
                    'name' => 'CEDFRUUGO_UPLOAD_DISABLE_PRODUCT',
                    'desc' => $this->l('Disabled Product to be upload or not at 
                        the time of Product upload on Fruugo.'),
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => '0', 'label' => 'Skip Disbaled Product'),
                            array('value' => '1', 'label' => 'Upload With "OUT OF STOCK" Status'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Map All Category'),
                    'name' => 'CEDFRUUGO_CATEGORY_MAP_ALL',
                    'required' => false,
                    'class' => 'co',
                    'default_value' => '',
                    'options' => array(
                        'query' => $categories,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Auto Sync Inventory and Price By Cron'),
                    'name' => 'CEDFRUUGO_AUTO_SYNC_INVENTRY_PRICE_CRON',
                    'is_bool' => true,
                    'desc' => $this->l('If enable then QUANTITY AND PRICE will be automatically 
                        SYNCHRONIZED By Cron.'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => true,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => false,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Update Price on Product Edit.'),
                    'name' => 'CEDFRUUGO_UPDATE_PRICE_PRODUCT_EDIT',
                    'is_bool' => true,
                    'desc' => $this->l('Update price on fruugo when you edit product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => true,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => false,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Update Inventory on Product Edit.'),
                    'name' => 'CEDFRUUGO_UPDATE_INVENTRY_PRODUCT_EDIT',
                    'is_bool' => true,
                    'desc' => $this->l('Update Inventory on fruugo when you edit product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => true,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => false,
                            'label' => $this->l('No')
                        )
                    ),
                ),
                array(
                    'type' => 'switch',
                    'label' => $this->l('Delete Product Data on Product Delete.'),
                    'name' => 'CEDFRUUGO_AUTO_DELETE_PRODUCT',
                    'is_bool' => true,
                    'desc' => $this->l('Delete PRODUCT DATA on fruugo when you delete product on store .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => true,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => false,
                            'label' => $this->l('No')
                        )
                    ),
                ),
            )
        );
    }
    public function getOrderSettingForm()
    {
        $id_lang = ((int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFRUUGO_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $order_states = $this->db->ExecuteS("SELECT `id_order_state`,`name` 
                        FROM `"._DB_PREFIX_."order_state_lang` where `id_lang` = '".(int)$id_lang."'");

        $order_carriers = $this->db->ExecuteS("SELECT `id_carrier`,`name` 
        FROM `"._DB_PREFIX_."carrier` where `active` = '1' and `deleted` = '0'");

        $payment_methods = array();

        $modules_list = Module::getPaymentModules();

        foreach ($modules_list as $module) {
            $module_obj = Module::getInstanceById($module['id_module']);
            if ($module_obj) {
                array_push($payment_methods, array('id'=>$module_obj->name,'name'=>$module_obj->displayName));
            }
        }
        return array(
            'legend' => array(
                'title' => $this->l(' Order Settings'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Default Customer Id to create order on store which are imported form fruugo.'),
                    'name' => 'CEDFRUUGO_CUSTOMER_ID',
                    'label' => $this->l('Customer Id'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Import Status'),
                    'desc' => $this->l('Order Status when imported from Fruugo.'),
                    'name' => 'CEDFRUUGO_ORDER_STATE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Accept Status'),
                    'desc' => $this->l('Order Status in Prestashop when accepted at Fruugo.'),
                    'name' => 'CEDFRUUGO_ORDER_STATE_ACKNOWLEDGE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Shipped Status'),
                    'desc' => $this->l('Order Status in Prestashop when Shipped at Fruugo.'),
                    'name' => 'CEDFRUUGO_ORDER_STATE_SHIPPED',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Cancelled Status'),
                    'desc' => $this->l('Order Status in Prestashop when Cancelled at Fruugo.'),
                    'name' => 'CEDFRUUGO_ORDER_STATE_CANCELLED',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Carrier'),
                    'desc' => $this->l('Carrier used to import Order from fruugo.'),
                    'name' => 'CEDFRUUGO_CARRIER_ID',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_carriers,
                        'id' => 'id_carrier',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Payment'),
                    'desc' => $this->l('Payment method used to import Order from fruugo.'),
                    'name' => 'CEDFRUUGO_ORDER_PAYMENT',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $payment_methods,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),

                array(
                    'type' => 'switch',
                    'label' => $this->l('Auto Order Accept/Reject'),
                    'name' => 'CEDFRUUGO_AUTO_ORDER_PROCESS',
                    'is_bool' => true,
                    'desc' => $this->l('If enable then order will be automatically accepted or
                         rejected based on fulfillment status .'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => true,
                            'label' => $this->l('Yes')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => false,
                            'label' => $this->l('No')
                        )
                    ),
                ),
            )
        );
    }
    public function getCronInfoForm()
    {
        $this->context->smarty->assign(array(
            'base_url' => Context::getContext()->shop->getBaseURL(true),
            'cron_secure_key' => Configuration::get('CEDFRUUGO_CRON_SECURE_KEY')
        ));
        $cron_html = $this->display(
            __FILE__,
            'views/templates/admin/configuration/cron_table.tpl'
        );
        return array(
            'legend' => array(
                'title' => $this->l('Cron Info'),
                'icon' => 'icon-info',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('This cron secure key need to set in 
                    the parameters of following cron urls'),
                    'name' => 'CEDFRUUGO_CRON_SECURE_KEY',
                    'label' => $this->l('Cron Secure Key'),
                ),

                array(
                    'type'  => 'html',
                    'col' => 12,
                    'label'  => $this->l(''),
                    'name' => $cron_html,
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            ),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue(trim($key), Tools::getValue($key));
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookDisplayBackOfficeHeader($params)
    {
        if (!Module::isEnabled($this->name)) {
            return false;
        }
        if (method_exists($this->context->controller, 'addCSS')) {
            $this->context->controller->addCSS($this->_path.'views/css/tab.css');
        }
    }

    public function hookActionProductDelete($params)
    {
        if (Configuration::get('CEDFRUUGO_LIVE_MODE')
            && Configuration::get('CEDFRUUGO_AUTO_DELETE_PRODUCT')) {
            $cedfruugoHelper = new CedfruugoHelper;
            $cedfruugoProduct= new CedfruugoProduct();
            try {
                $product_id = $params['id_product'];
                $response = $cedfruugoProduct->deleteProductAtFruugo(array($product_id));
                $cedfruugoHelper->log(
                    __METHOD__,
                    'Info',
                    'HookActionProductDelete',
                    Tools::jsonEncode($response)
                );
            } catch (\Exception $e) {
                $cedfruugoHelper->log(
                    'cedfruugo::hookActionProductDelete',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
            }
        }
    }

    public function hookActionUpdateQuantity($params)
    {
        $cedfruugoHelper = new CedfruugoHelper;
        $cedfruugoProduct= new CedfruugoProduct();
        try {
            $cedfruugoHelper->log(
                __METHOD__,
                'Info',
                'Update Quantity Hook Running',
                ''
            );
            if (Configuration::get('CEDFRUUGO_LIVE_MODE')
                && Configuration::get('CEDFRUUGO_UPDATE_INVENTRY_PRODUCT_EDIT')) {
                $status = $cedfruugoProduct->updateStock(array($params['id_product']));
                $cedfruugoHelper->log(
                    __METHOD__,
                    'Info',
                    'Update Quantity Hook Response',
                    Tools::jsonEncode($status)
                );
            }
        } catch (\Exception $e) {
            $cedfruugoHelper->log(
                'cedfruugo::hookActionUpdateQuantity',
                'Exception',
                $e->getMessage(),
                Tools::jsonEncode($e->getMessage()),
                true
            );
        }
    }
//    public function hookActionOrderStatusPostUpdate($params)
//    {
//        $cedfruugoHelper = new CedfruugoHelper;
//        $cedfruugoOrder = new CedfruugoOrder;
//        try {
//            $params = (array)$params;
//            $id_order = $params['id_order'];
//            $data  = (array)new Order($id_order);
//            $current_order_status = (int)$data['current_state'];
//            $order_state_when_shipped = (int)Configuration::get('CEDFRUUGO_ORDER_STATE_SHIPPED');
//
//            if ($current_order_status == $order_state_when_shipped) {
//                $tracking_number = (int)$data['shipping_number'];
//                if (isset($tracking_number) && !empty($tracking_number)) {
//                    $id_carrier = (int)$data['id_carrier'];
//                    if ($id_carrier) {
//                        $carrier_data = (array)new Carrier($id_carrier);
//                        if (!empty($carrier_data)) {
//                            $tracking_url = $carrier_data['url'];
//                            if (isset($tracking_url) && !empty($tracking_url)) {
//                                $db = Db::getInstance();
//                                $sql = "SELECT `fruugo_order_id` FROM `"._DB_PREFIX_."fruugo_order`
//                                        WHERE `prestashop_order_id` = ".$id_order."";
//                                $res = $db->executeS($sql);
//                                if (is_array($res) && !empty($res)) {
//                                    $fruugo_order_id = $res[0]['fruugo_order_id'];
//                                    if ($fruugo_order_id) {
//                                        $result = $cedfruugoOrder->shipCompleteOrder(
//                                            $fruugo_order_id,
//                                            '',
//                                            '',
//                                            $tracking_number,
//                                            $tracking_url
//                                        );
//                                        if (isset($result['success'])
//                                            && $result['success'] && isset($result['response'])) {
//                                            $data = $cedfruugoHelper->xml2array($result['response']);
//                                            $cedfruugoOrder->updatefruugoOrderData(
//                                                $fruugo_order_id,
//                                                $data['o:orders']['o:order']
//                                            );
//                                            $cedfruugoOrder->updateOrderStatus(
//                                                $fruugo_order_id,
//                                                'CEDFRUUGO_ORDER_STATE_SHIPPED'
//                                            );
//                                        } else {
//                                            $error_res = 'Some Error While Shipment.';
//                                            if (isset($result['message'])) {
//                                                $error_res = $result['message'];
//                                            }
//                                            $cedfruugoHelper->log($error_res, true);
//                                        }
//                                    }
//                                }
//                            } else {
//                            }
//                        } else {
//                        }
//                    }
//                } else {
//                }
//            } else {
//            }
//        } catch (\Exception $e) {
//        }
//    }

    public function getConfigFormValues()
    {
        return array(
            'CEDFRUUGO_LIVE_MODE' => Configuration::get('CEDFRUUGO_LIVE_MODE'),
            'CEDFRUUGO_API_URL' => Configuration::get('CEDFRUUGO_API_URL') ?
                Configuration::get('CEDFRUUGO_API_URL'): 'https://www.fruugo.com/',
            'CEDFRUUGO_CONSUMER_ID' => Configuration::get('CEDFRUUGO_CONSUMER_ID') ?
                Configuration::get('CEDFRUUGO_CONSUMER_ID'): '',
            'CEDFRUUGO_CONSUMER_PASSWORD' => Configuration::get('CEDFRUUGO_CONSUMER_PASSWORD') ?
                Configuration::get('CEDFRUUGO_CONSUMER_PASSWORD'): '',
            'CEDFRUUGO_IS_MANUFACTURER' => Configuration::get('CEDFRUUGO_IS_MANUFACTURER') ?
                Configuration::get('CEDFRUUGO_IS_MANUFACTURER'): 0,
            'CEDFRUUGO_PRICE_TYPE' => Configuration::get('CEDFRUUGO_PRICE_TYPE') ?
                Configuration::get('CEDFRUUGO_PRICE_TYPE'): '',
            'CEDFRUUGO_UPLOAD_DISABLE_PRODUCT' => Configuration::get('CEDFRUUGO_UPLOAD_DISABLE_PRODUCT') ?
                Configuration::get('CEDFRUUGO_UPLOAD_DISABLE_PRODUCT'): '',
            'CEDFRUUGO_PRICE_VARIANT_AMOUNT' => Configuration::get('CEDFRUUGO_PRICE_VARIANT_AMOUNT') ?
                Configuration::get('CEDFRUUGO_PRICE_VARIANT_AMOUNT'): '',
            'CEDFRUUGO_PRICE_VARIANT_TYPE' => Configuration::get('CEDFRUUGO_PRICE_VARIANT_TYPE') ?
                Configuration::get('CEDFRUUGO_PRICE_VARIANT_TYPE'): 0,
            'CEDFRUUGO_AUTO_ORDER_PROCESS' => Configuration::get('CEDFRUUGO_AUTO_ORDER_PROCESS') ?
                Configuration::get('CEDFRUUGO_AUTO_ORDER_PROCESS'): false,
            'CEDFRUUGO_AUTO_SYNC_INVENTRY_PRICE_CRON' => Configuration::get('CEDFRUUGO_AUTO_SYNC_INVENTRY_PRICE_CRON') ?
                Configuration::get('CEDFRUUGO_AUTO_SYNC_INVENTRY_PRICE_CRON'): false,
            'CEDFRUUGO_FEED_URL' => Configuration::get('CEDFRUUGO_FEED_URL') ?
                Configuration::get('CEDFRUUGO_FEED_URL') :
                Context::getContext()->shop->getBaseURL(true). 'modules/cedfruugo/product_upload/product_feed.csv',
            'CEDFRUUGO_UPDATE_PRICE_PRODUCT_EDIT' => Configuration::get('CEDFRUUGO_UPDATE_PRICE_PRODUCT_EDIT') ?
                Configuration::get('CEDFRUUGO_UPDATE_PRICE_PRODUCT_EDIT'): false,
            'CEDFRUUGO_LANGUAGE_STORE' => Configuration::get('CEDFRUUGO_LANGUAGE_STORE') ?
                Configuration::get('CEDFRUUGO_LANGUAGE_STORE'): '',
            'CEDFRUUGO_UPDATE_INVENTRY_PRODUCT_EDIT' => Configuration::get('CEDFRUUGO_UPDATE_INVENTRY_PRODUCT_EDIT') ?
                Configuration::get('CEDFRUUGO_UPDATE_INVENTRY_PRODUCT_EDIT'): false,
            'CEDFRUUGO_AUTO_DELETE_PRODUCT' => Configuration::get('CEDFRUUGO_AUTO_DELETE_PRODUCT') ?
                Configuration::get('CEDFRUUGO_AUTO_DELETE_PRODUCT'): false,
            'CEDFRUUGO_CATEGORY_MAP_ALL' => Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL') ?
                Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL'): '',
            'CEDFRUUGO_DEBUG_ENABLE' => Configuration::get('CEDFRUUGO_DEBUG_ENABLE') ?
                Configuration::get('CEDFRUUGO_DEBUG_ENABLE'): true,
            'CEDFRUUGO_CUSTOMER_ID' => Configuration::get('CEDFRUUGO_CUSTOMER_ID') ?
                Configuration::get('CEDFRUUGO_CUSTOMER_ID'): '',
            'CEDFRUUGO_ORDER_STATE' => Configuration::get('CEDFRUUGO_ORDER_STATE') ?
                Configuration::get('CEDFRUUGO_ORDER_STATE'): null,
            'CEDFRUUGO_CARRIER_ID' => Configuration::get('CEDFRUUGO_CARRIER_ID') ?
                Configuration::get('CEDFRUUGO_CARRIER_ID'): null,
            'CEDFRUUGO_ORDER_PAYMENT' => Configuration::get('CEDFRUUGO_ORDER_PAYMENT') ?
                Configuration::get('CEDFRUUGO_ORDER_PAYMENT'): null,
            'CEDFRUUGO_ORDER_STATE_ACKNOWLEDGE' => Configuration::get('CEDFRUUGO_ORDER_STATE_ACKNOWLEDGE') ?
                Configuration::get('CEDFRUUGO_ORDER_STATE_ACKNOWLEDGE'): null,
            'CEDFRUUGO_ORDER_STATE_SHIPPED' => Configuration::get('CEDFRUUGO_ORDER_STATE_SHIPPED') ?
                Configuration::get('CEDFRUUGO_ORDER_STATE_SHIPPED'): null,
            'CEDFRUUGO_ORDER_STATE_CANCELLED' => Configuration::get('CEDFRUUGO_ORDER_STATE_CANCELLED') ?
                Configuration::get('CEDFRUUGO_ORDER_STATE_CANCELLED'): null,
            'CEDFRUUGO_CRON_SECURE_KEY' => Configuration::get('CEDFRUUGO_CRON_SECURE_KEY') ?
                Configuration::get('CEDFRUUGO_CRON_SECURE_KEY'): '',
        );
    }
}
