<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include(_PS_MODULE_DIR_.'/cedfruugo/classes/CedfruugoHelper.php');
include(_PS_MODULE_DIR_.'/cedfruugo/classes/CedfruugoOrder.php');

if (!Tools::isSubmit('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFRUUGO_CRON_SECURE_KEY')) {
    die('Secure key not matched');
}
try {
    $CedfruugoHelper = new CedfruugoHelper;
    $CedfruugoOrder = new CedfruugoOrder;

    $url ='orders/download';
    $params= array();
    $order = array('from' => date('Y-m-d'));
    $order_data = $CedfruugoOrder->fetchOrder($params, $url, $order);
    $CedfruugoHelper->log(
        'OrderFetch Cron',
        'Info',
        'Cron For Order Fetch',
        Tools::jsonEncode($res)
    );
    die(Tools::jsonEncode($res));
} catch (Exception $e) {

    $CedfruugoHelper->log(
        'CronFetchOrder',
        'Exception',
        $e->getMessage(),
        $e->getMessage(),
        true
    );
    die(Tools::jsonEncode(array(
        'success' => false,
        'message' => $e->getMessage()
    )));
}
