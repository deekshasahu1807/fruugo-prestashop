<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFruugo
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include(_PS_MODULE_DIR_.'/cedfruugo/classes/CedfruugoHelper.php');


if (!Tools::isSubmit('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFRUUGO_CRON_SECURE_KEY'))
{
    die('Secure key not matched');
}

try {
  $CedfruugoHelper = new CedfruugoHelper;
  $product_ids = array();
  $allproducts = Configuration::get('CEDFRUUGO_CATEGORY_MAP_ALL');

    if($allproducts) {
        $query = Db::getInstance()->ExecuteS("SELECT `id_product` FROM " . _DB_PREFIX_ . "product");
        if (is_array($query) && count($query)) {
            foreach ($query as $value) {
                if (isset($value['id_product']) && $value['id_product']) {
                    $product_ids[] = $value['id_product'];
                }
            }
        }
    } else {
        $query = Db::getInstance()->ExecuteS("SELECT `mapped_categories` FROM `" . _DB_PREFIX_ . "fruugo_category_list` WHERE `mapped_categories` != '' ORDER BY `mapped_categories` DESC");

        if (is_array($query) && count($query)) {
            foreach ($query as $value) {
                if (isset($value['mapped_categories']) && $value['mapped_categories']) {
                    $value['mapped_categories'] = unserialize($value['mapped_categories']);
                    $categories = implode(',', $value['mapped_categories']);

                    if($categories) {
                        $sql = Db::getInstance()->ExecuteS("SELECT p.`id_product` FROM `". _DB_PREFIX_ ."category_product` cp LEFT JOIN `" . _DB_PREFIX_ . "product` p ON (p.id_product = cp.id_product) LEFT JOIN `"._DB_PREFIX_."fruugo_products` fp ON (p.id_product = fp.`product_id`) WHERE p.`id_category_default` IN (" . $categories . ")");
                        if (is_array($sql) && count($sql)) {
                            foreach ($sql as $val) {
                                if (isset($val['id_product']) && $val['id_product']) {
                                    $product_ids[] = $val['id_product'];
                                }
                            }
                        }
                    }
                }
            }
        }

        $query =  Db::getInstance()->ExecuteS("SELECT `product_id` FROM `". _DB_PREFIX_ ."fruugo_products` WHERE `fruugo_status` != 'Excluded' AND `category` != ''");

        if (is_array($query) && count($query)) {
            foreach ($query as $val) {
                if (isset($val['product_id']) && $val['product_id']) {
                    $product_ids[] = $val['product_id'];
                }
            }
        }
        //echo '<pre>'; print_r($product_ids); die;
    }
    $product_ids = array_unique($product_ids);
    asort($product_ids);
    $product_ids = array_values($product_ids);
    $productids_chunk = array_chunk($product_ids, '1000');
    $ids = array();
    $db = Db::getInstance();
    $sql = "SELECT `inventory_chunk` FROM `" . _DB_PREFIX_ . "fruugo_products_cron` WHERE `type` = 'uploadproducts'";
    $result = $db->executeS($sql);
    if (count($result)) {
        $ids = json_decode($result[0]['inventory_chunk'], true);
    } else {
        $db->insert(
            'fruugo_products_cron',
            array(
                'inventory_chunk' => pSQL(json_encode($productids_chunk)),
                'type' => 'uploadproducts'
            )
        );
        $ids = $productids_chunk;
    }
    foreach ($ids as $key => $values)
    {
        $result = $CedfruugoHelper->uploadProducts($values);
        if ($result) {
            $res = $db->delete(
                'fruugo_products_cron',
                'type="uploadproducts"'
            );
            unset($ids[$key]);
            $ids = array_values($ids);
            $ins_res = $db->insert(
                'fruugo_products_cron',
                array(
                    'inventory_chunk' => pSQL(json_encode($ids)),
                    'type' => 'uploadproducts'
                )
            );
        }
    }
   die(json_encode(array('success' => true, 'message' => $result)));
} catch (Exception $e) {
    $CedfruugoHelper->log('Exception on Update Product Status:'.$e);
    die(json_encode(array('success' => false, 'message' => $e->getMessage())));
}